<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Miracles">
    <meta name="keywords" content="Miracles">
    <meta name="author" content="Developer Technology">
    <!-- Titulo -->
    <title>.:: Consultar Documento | Miracles ::.</title>
    <link rel="shortcut icon" href="../img/company/favicon_miracles.png">
    <!--STYLESHEET-->
    <!--=================================================-->
    <!--Open Sans Font [ OPTIONAL ]-->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
    <!--Bootstrap Stylesheet [ REQUIRED ]-->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <!--Nifty Stylesheet [ REQUIRED ]-->
    <link href="../assets/css/nifty.min.css" rel="stylesheet">
    <!--Nifty Premium Icon [ DEMONSTRATION ]-->
    <link href="../assets/css/demo/nifty-demo-icons.min.css" rel="stylesheet">
    <!--=================================================-->
    <!--Pace - Page Load Progress Par [OPTIONAL]-->
    <link href="../assets/plugins/pace/pace.min.css" rel="stylesheet">
    <script src="../assets/plugins/pace/pace.min.js"></script>
    <!--Demo [ DEMONSTRATION ]-->
    <link href="../assets/css/scrollbar.css" rel="stylesheet" type="text/css">
    <link href="../assets/css/loaderGeneral.css" rel="stylesheet">
    <link href="../assets/css/load_login1.css" rel="stylesheet" type="text/css">
</head>
<!--TIPS-->
<body style="cursor: url(../img/company/cursor.png), pointer;">
    <div id="container-loader">
        <img src="../assets/images/svg-icon/loading.svg" width="50">
    </div>
    <div id="load_login"></div>
    <div id="container" class="effect aside-float aside-bright mainnav-sm footer-fixed mainnav-fixed aside-fixed">
        <!--NAVBAR-->
        <!--===================================================-->
        <header id="navbar">
            <div id="navbar-container" class="boxed">
                <div class="navbar-content">
                </div>
            </div>
        </header>
        <!--===================================================-->
        <!--END NAVBAR-->
        <div class="boxed">
            <!--CONTENT CONTAINER-->
            <!--===================================================-->
            <div id="content-container">
                <!--Page content-->
                <!--===================================================-->
                <div id="page-content">
                    
                    <hr class="new-section-sm bord-no">
                    <div class="row">
                        <div class="col-lg-5 col-lg-offset-3">
                            <div class="panel panel-body text-center">
                                <div class="panel-heading" id="tituloInicial">
                                    <h3>Consulta de Comprobante</h3>
                                </div>
                                    <p id="descripcionInicial">Ingrese los siguientes datos que figuran en el CPE:
                                <!--<div class="panel-heading" id="descripcionInicial">
                                    <h3 class="panel-title">Ingrese los siguientes datos que figuran en el CPE:</h3>
                                </div>-->
                    
                                <!--Block Styled Form -->
                                <!--===================================================-->
                                <div id="formulario">
                                    <form class="form-horizontal" method="post" id="consulta_datos" name="consulta_datos" autocomplete="off">
                                        <div class="panel-body">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label" for="rucEmisor">RUC del emisor</label>
                                                <div class="col-sm-9">
                                                    <input type="text" placeholder="N&uacute;mero de RUC del emisor" id="rucEmisor" name="rucEmisor" class="form-control" maxlength="11" required>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label" for="tipoComp">Tipo</label>
                                                <div class="col-sm-9">
                                                    <select class="form-control" id="tipoComp" name="tipoComp" required>
                                                        <option value="01">FACTURA ELECTR&Oacute;NICA</option>
                                                        <option value="03">BOLETA DE VENTA ELECTR&Oacute;NICA</option>
                                                        <option value="07">NOTA DE CR&Eacute;DITO ELECTR&Oacute;NICA</option>
                                                        <option value="08">NOTA DE D&Eacute;BITO ELECTR&Oacute;NICA</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label" for="nComprobante">Comprobante</label>
                                                <div class="col-sm-3">
                                                    <input type="text" placeholder="Serie" id="serieComp" name="serieComp" class="form-control" required onKeyUp="this.value=this.value.toUpperCase();" maxlength="4">
                                                </div>
                                                <div class="col-sm-6">
                                                    <input type="number" placeholder="N&uacute;mero" id="numeroComp" name="numeroComp" class="form-control" required>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label" for="fEmision">Emisi&oacute;n</label>
                                                <div class="col-sm-9">
                                                    <input type="date" id="fEmision" name="fEmision" class="form-control" required>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label" for="monto">Monto</label>
                                                <div class="col-sm-9">
                                                    <input type="text" placeholder="Total por honorarios o importe total" id="monto" name="monto" class="form-control" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="panel-footer text-right">
                                            <button class="btn btn-primary btn-block" type="submit" id="consultar">Validar</button>
                                        </div>
                                    </form>
                                </div>
                                    
                                <div id="respuesta" class="hidden">
                                    <div class="panel-heading">
                                        <h3>Resultado</h3>
                                    </div>
                                    <div id="resultados_ajax"></div>
                                    <br>
                                    <div class="panel-footer text-right">
                                        <button class="btn btn-primary btn-block" onclick="regresar();">Regresar</button>
                                    </div>
                                </div>
                                <!--===================================================-->
                                <!--End Block Styled Form -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- FOOTER -->
        <!--===================================================-->
        <footer id="footer">
            <!-- Visible when footer positions are fixed -->
            <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
            <div class="show-fixed pad-rgt pull-right">
                Mira<strong>cles</strong>
            </div>
            <!-- Visible when footer positions are static -->
            <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
            <div class="hide-fixed pull-right pad-rgt">
                Mira<strong>cles</strong>
            </div>
            <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
            <!-- Remove the class "show-fixed" and "hide-fixed" to make the content always appears. -->
            <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

            <p class="pad-lft">&#0169; 2021 Miracles</p>
        </footer>
        <!--===================================================-->
        <!-- END FOOTER -->
        <!-- SCROLL PAGE BUTTON -->
        <!--===================================================-->
        <button class="scroll-top btn">
            <i class="pci-chevron chevron-up"></i>
        </button>
        <!--===================================================-->
    </div>
    <!--===================================================-->
    <!-- END OF CONTAINER -->
    <!--JAVASCRIPT-->
    <!--=================================================-->
    <!--jQuery [ REQUIRED ]-->
    <script src="../assets/js/jquery.min.js"></script>
    <!--BootstrapJS [ RECOMMENDED ]-->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!--NiftyJS [ RECOMMENDED ]-->
    <script src="../assets/js/nifty.min.js"></script>
    <script src="../js/loader.js"></script>
    <script src="../js/comprobarDocumento.js"></script>
</body>
</html>