/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
//Cambiamos la barra de titulo
$(document). prop('title', '.:: Colaboradores | Miracles ::.');
//
$(document).ready(function(){
  load(1);
  $("#muestraValorAfp").load('../ajax/ajaxAfp.php');
  $("#cargaCargoAjax").load('../ajax/ajaxCargos.php');
  $("#cargaBancoAjax").load('../ajax/ajaxBancos.php');
});
//Busca los datos
function load(page){
  $("#ldng_cat").fadeIn('slow');
  $.ajax({
    url:'../ajax/buscarColaboradores.php',
    beforeSend: function(objeto){ },
    success:function(data){
      $(".outer_div_cat").html(data).fadeIn('slow');
      $('#ldng_cat').html('');
    }
  })
}
//Registra cargo
$("#guardar_cargo" ).submit(function( event ) {
  $('#guardar_datos').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
  $('#guardar_datos').attr("disabled", true);
  var parametros = $(this).serialize();
  $.ajax({
    type: "POST",
    url: "../ajax/nuevoCargo.php",
    data: parametros,
    beforeSend: function(objeto){ },
    success: function(datos){
      $("#resultados_ajax").html(datos);
      $('#guardar_datos').html('Aceptar');
      $('#guardar_datos').attr("disabled", false);
      $("#cargaCargoAjax").load('../ajax/ajaxCargos.php');
      $("#guardar_cargo")[0].reset();
      $("#cargo_nombre").focus();
    }
  });
  event.preventDefault();
})
//Registra banco
$("#guardar_banco" ).submit(function( event ) {
  $('#guardar_datos').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
  $('#guardar_datos').attr("disabled", true);
  var parametros = $(this).serialize();
  $.ajax({
    type: "POST",
    url: "../ajax/nuevoBanco.php",
    data: parametros,
    beforeSend: function(objeto){ },
    success: function(datos){
      $("#resultados_ajax").html(datos);
      $('#guardar_datos').html('Aceptar');
      $('#guardar_datos').attr("disabled", false);
      $("#cargaBancoAjax").load('../ajax/ajaxBancos.php');
      $("#guardar_banco")[0].reset();
      $("#banco_nombre").focus();
    }
  });
  event.preventDefault();
})
//Registra
$("#guardar_colaborador" ).submit(function( event ) {
  $('#guardar_datos').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
  $('#guardar_datos').attr("disabled", true);
  var parametros = $(this).serialize();
  $.ajax({
    type: "POST",
    url: "../ajax/nuevoColaborador.php",
    data: parametros,
    beforeSend: function(objeto){ },
    success: function(datos){
      $("#resultados_ajax").html(datos);
      $('#guardar_datos').html('Aceptar');
      $('#guardar_datos').attr("disabled", false);
      load(1);
      $("#guardar_colaborador")[0].reset();
      $("#tipo_colaborador").focus();
    }
  });
  event.preventDefault();
})
//Edita
$("#editar_colaborador" ).submit(function( event ) {
  $('#actualizar_datos').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
  $('#actualizar_datos').attr("disabled", true);
  var parametros = $(this).serialize();
  $.ajax({
    type: "POST",
    url: "../ajax/editarColaborador.php",
    data: parametros,
    beforeSend: function(objeto){ },
    success: function(datos){
      $("#resultados_ajax2").html(datos);
      $('#actualizar_datos').html('Aceptar');
      $('#actualizar_datos').attr("disabled", false);
      load(1);
      //console.log(datos);
    }
  });
  event.preventDefault();
})
//Suspende
$('#desactivarEntrada').on('show.bs.modal', function(event) {
    var button = $(event.relatedTarget) // Botón que activó el modal
    var id = button.data('id') // Extraer la información de atributos de datos
    var modal = $(this)
    modal.find('#id_colaboradorEntrada').val(id)
})
$("#eliminarDatos1").submit(function(event) {
  $('#eliminar').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
    $('#eliminar').attr("disabled", true);
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/eliminarColaborador1.php",
        data: parametros,
        beforeSend: function(objeto) {},
        success: function(datos) {
            $(".datos_ajax_delete").html(datos);
            $('.datos_ajax_delete').html('');
            $('.datos_ajax_delete').removeClass('ajax-loader');
            $('#eliminar').html('S&iacute;, continuar');
            $('#eliminar').attr("disabled", false);
            $('#desactivarEntrada').modal('hide');
            load(1);
            //loadS(1);
            //console.log(datos);            
        }
    });
    event.preventDefault();
});
//Activa
$('#activarEntrada').on('show.bs.modal', function(event) {
    var button = $(event.relatedTarget) // Botón que activó el modal
    var id = button.data('id') // Extraer la información de atributos de datos
    var modal = $(this)
    modal.find('#id_colaboradorEntrada1').val(id)
})
$("#eliminarDatos2").submit(function(event) {
  $('#eliminar').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
    $('#eliminar').attr("disabled", true);
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/eliminarColaborador2.php",
        data: parametros,
        beforeSend: function(objeto) {},
        success: function(datos) {
            $(".datos_ajax_delete").html(datos);
            $('.datos_ajax_delete').html('');
            $('.datos_ajax_delete').removeClass('ajax-loader');
            $('#eliminar').html('S&iacute;, continuar');
            $('#eliminar').attr("disabled", false);
            $('#activarEntrada').modal('hide');
            load(1);
            //loadS(1);
            //console.log(datos);            
        }
    });
    event.preventDefault();
});
//Elimina
$('#eliminarColaborador').on('show.bs.modal', function(event) {
    var button = $(event.relatedTarget) // Botón que activó el modal
    var id = button.data('id') // Extraer la información de atributos de datos
    var modal = $(this)
    modal.find('#id_colaborador').val(id)
})
$("#eliminarDatos").submit(function(event) {
	$('#eliminar').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
  	$('#eliminar').attr("disabled", true);
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/eliminarColaborador.php",
        data: parametros,
        beforeSend: function(objeto) {},
        success: function(datos) {
            $(".datos_ajax_delete").html(datos);
            $('.datos_ajax_delete').html('');
    		$('.datos_ajax_delete').removeClass('ajax-loader');
    		$('#eliminar').html('S&iacute;, continuar');
      		$('#eliminar').attr("disabled", false);
            $('#eliminarColaborador').modal('hide');
            load(1);
            //console.log(datos);            
        }
    });
    event.preventDefault();
});
//Asocia Usuario
$('#nuevoUsuario').on('show.bs.modal', function(event) {
    var button = $(event.relatedTarget) // Botón que activó el modal
    var id = button.data('id') // Extraer la información de atributos de datos
    var modal = $(this)
    modal.find('#colaborador_id').val(id)
})
$("#guardar_usuario").submit(function(event) {
  $('#guardar_datos').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
    $('#guardar_datos').attr("disabled", true);
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/nuevoUsuario.php",
        data: parametros,
        beforeSend: function(objeto) {},
        success: function(datos) {
            $(".datos_ajax_delete").html(datos);
            $('.datos_ajax_delete').html('');
            $('.datos_ajax_delete').removeClass('ajax-loader');
            $('#guardar_datos').html('S&iacute;, continuar');
            $('#guardar_datos').attr("disabled", false);
            $('#nuevoUsuario').modal('hide');
            load(1);
            //console.log(datos);            
        }
    });
    event.preventDefault();
});
//Carga foto
function upload_image_mod(id_producto){
  $("#load_img_mod").text('Cargando...');
  var inputFileImage = document.getElementById("imagefile_mod");
  var file = inputFileImage.files[0];
  var data = new FormData();
  data.append('imagefile_mod',file);
  data.append('id_producto',id_producto);



  $.ajax({
      url: "../ajax/cargaImagenColaborador.php",        // Url to which the request is send
      type: "POST",             // Type of request to be send, called as method
      data: data,         // Data sent to server, a set of key/value pairs (i.e. form fields and values)
      contentType: false,       // The content type used when sending data to the server.
      cache: false,             // To unable request pages to be cached
      processData:false,        // To send DOMDocument or non processed data file it is set to false
      success: function(data)   // A function to be called if request succeeds
      {
        $("#load_img_mod").html(data);
        load(1);
        //console.log(data);
      }
    });
  event.preventDefault();
}
function carga_img(id_producto) {
  $(".outer_img").load("../ajax/imgColaborador.php?id_producto="+id_producto);
}
//
function carga_firma(id_producto) {
  $(".outer_firma").load("../ajax/firmaColaborador.php?id_producto="+id_producto);
}
//
function upload_firma_mod(id_producto){
  $("#load_firma_mod").text('Cargando...');
  var inputFileImage = document.getElementById("firmafile_mod");
  var file = inputFileImage.files[0];
  var data = new FormData();
  data.append('firmafile_mod',file);
  data.append('id_producto',id_producto);



  $.ajax({
      url: "../ajax/cargaFirmaColaborador.php",        // Url to which the request is send
      type: "POST",             // Type of request to be send, called as method
      data: data,         // Data sent to server, a set of key/value pairs (i.e. form fields and values)
      contentType: false,       // The content type used when sending data to the server.
      cache: false,             // To unable request pages to be cached
      processData:false,        // To send DOMDocument or non processed data file it is set to false
      success: function(data)   // A function to be called if request succeeds
      {
        $("#load_firma_mod").html(data);
        load(1);
      }
    });
  event.preventDefault();
}
function comprobarUsuario() {
  $("#loaderIcon").show();
  jQuery.ajax({
  url: "../ajax/ajaxComprobarUsuario.php",
  data:'user_name='+$("#user_name").val(),
  type: "POST",
  success:function(data){
    $("#estadousuario").html(data);
    $("#loaderIcon").hide();
  },
  error:function (){}
  });
}
//Obtiene los datos en el modal
function obtener_datos(id){
  var nom_colaborador = $("#nom_colaborador"+id).val();
  var tel_colaborador = $("#tel_colaborador"+id).val();
  var email_colaborador = $("#email_colaborador"+id).val();
  var documento_colaborador = $("#documento_colaborador"+id).val();
  var domicilio_colaborador = $("#domicilio_colaborador"+id).val();
  var sueldo_colaborador = $("#sueldo_colaborador"+id).val();
  var tipo_colaborador = $("#tipo_colaborador"+id).val();
  var cumpleanos_colaborador = $("#cumpleanos_colaborador"+id).val();
  var horario_colaborador = $("#horario_colaborador"+id).val();
  var asingacion_colaborador = $("#asingacion_colaborador"+id).val();
  var sexo_colaborador = $("#sexo_colaborador"+id).val();
  var colaborador_hijos = $("#colaborador_hijos"+id).val();
  var colaborador_snpAfp = $("#colaborador_snpAfp"+id).val();
  var colaborador_afp = $("#colaborador_afp"+id).val();
  var colaborador_cargo = $("#colaborador_cargo"+id).val();
  var colaborador_fechaIngreso = $("#colaborador_fechaIngreso"+id).val();
  var colaborador_banco = $("#sexo_colaborador"+id).val();
  var colaborador_numeroCuenta = $("#colaborador_numeroCuenta"+id).val();
  $("#mod_nombre").val(nom_colaborador);
  $("#mod_telefono").val(tel_colaborador);
  $("#mod_email").val(email_colaborador);
  $("#mod_documento").val(documento_colaborador);
  $("#mod_domicilio").val(domicilio_colaborador);
  $("#mod_salario").val(sueldo_colaborador);
  $("#mod_tipo").val(tipo_colaborador);
  $("#mod_cumpleanos").val(cumpleanos_colaborador);
  $("#mod_hora").val(horario_colaborador);
  $("#mod_asignacion").val(asingacion_colaborador);
  $("#mod_sexo").val(sexo_colaborador);
  $("#mod_hijos").val(colaborador_hijos);
  $("#mod_snpAfp").val(colaborador_snpAfp);
  $("#mod_afp").val(colaborador_afp);
  $("#mod_cargo").val(colaborador_cargo);
  $("#mod_fechaIngreso").val(colaborador_fechaIngreso);
  $("#mod_banco").val(colaborador_banco);
  $("#mod_numeroCuenta").val(colaborador_numeroCuenta);
  $("#mod_idColaborador").val(id);
}
//Obtiene los datos en el modal
/*$('#detallesColaborador').on('show.bs.modal', function(event) {
    var button = $(event.relatedTarget) // Botón que activó el modal
    var id = button.data('id')
    var tipo = button.data('tipo')
    var documento = button.data('documento')
    var nombre = button.data('nombre')
    var nombre1 = button.data('nombre1')
    var direccion = button.data('direccion')
    var telefono = button.data('telefono')
    var email = button.data('email')
    var modal = $(this)
    modal.find('#id_colaborador').val(id)
    modal.find('#cliente_tipo').text(tipo)
    modal.find('#cliente_documento').text(documento)
    modal.find('#cliente_nombre').text(nombre)
    modal.find('#cliente_nombre1').text(nombre1)
    modal.find('#cliente_direccion').text(direccion)
    modal.find('#cliente_telefono').text(telefono)
    modal.find('#cliente_email').text(email)
})*/
//Modificamos el mueno lateral
$('#container').addClass("mainnav-lg");
$('#container').removeClass("mainnav-sm page-fixedbar");
//Marcamos el menu lateral
$('#inicio').removeClass("active-link");
$('#pos').removeClass("active-link");
$('#notas').removeClass("active-link");
$('#anuncios').removeClass("active-link");
$('#calendario').removeClass("active-link");
$('#archivos').removeClass("active-link");
//Modulo archivos
$('#caja').removeClass("active-sub");
$('#ulCaja').removeClass('in');
$('#CajaActual').removeClass("active-link");
$('#Movimientos').removeClass("active-link");
//Modulo personas
$('#personas').addClass("active-sub");
$('#ulPersonas').addClass('in');
$('#clientes').removeClass("active-link");
$('#proveedores').removeClass("active-link");
$('#colaboradores').addClass("active-link");
//Modulo restaurante
$('#restaurante').removeClass("active-sub");
$('#ulRestaurante').removeClass('in');
$('#mesas').removeClass("active-link");
$('#seccionesR').removeClass("active-link");
$('#insumos').removeClass("active-link");
//Modulo hospedaje
$('#hospedaje').removeClass("active-sub");
$('#ulHospedaje').removeClass('in');
$('#habitaciones').removeClass("active-link");
$('#seccionesH').removeClass("active-link");
//Modulo escuela
$('#escuela').removeClass("active-sub");
$('#ulEscuela').removeClass('in');
$('#estudiantes').removeClass("active-link");
$('#profesores').removeClass("active-link");
$('#padres').removeClass("active-link");
$('#calificaciones').removeClass("active-link");
$('#horarios').removeClass("active-link");
$('#asistenciaE').removeClass("active-link");
//Modulo clinica
$('#clinica').removeClass("active-sub");
$('#ulClinica').removeClass('in');
$('#admision').removeClass("active-link");
$('#topico').removeClass("active-link");
$('#historias').removeClass("active-link");
$('#especialidades').removeClass("active-link");
$('#medicos').removeClass("active-link");
$('#atencion').removeClass("active-link");
//Modulo marketing
$('#marketing').removeClass("active-sub");
$('#ulMarketing').removeClass('in');
$('#mktEmail').removeClass("active-link");
$('#mktWhatsApp').removeClass("active-link");
//Modulo articulos
$('#articulos').removeClass("active-sub");
$('#ulArticulos').removeClass('in');
$('#marcas').removeClass("active-link");
$('#categorias').removeClass("active-link");
$('#items').removeClass("active-link");
$('#kardex').removeClass("active-link");
$('#traslados').removeClass("active-link");
$('#ajustarInventario').removeClass("active-link");
//Modulo ventas
$('#ventas').removeClass("active-sub");
$('#ulVentas').removeClass('in');
$('#nuevaVenta').removeClass("active-link");
$('#nuevaFactura').removeClass("active-link");
$('#nuevoPedido').removeClass("active-link");
$('#historialVentas').removeClass("active-link");
//Modulo cotizaciones
$('#cotizaciones').removeClass("active-sub");
$('#ulCotizaciones').removeClass('in');
$('#nuevaCotizacion').removeClass("active-link");
$('#historialCotizaciones').removeClass("active-link");
//Modulo egresos
$('#egresos').removeClass("active-sub");
$('#ulEgresos').removeClass('in');
$('#nuevaCompra').removeClass("active-link");
$('#historialCompras').removeClass("active-link");
$('#categoriaGastos').removeClass("active-link");
$('#historialGastos').removeClass("active-link");
//Modulo facturacion electronica
$('#facturacionElectronica').removeClass("active-sub");
$('#ulFacturacionElectronica').removeClass('in');
$('#notaDebito').removeClass("active-sub");
$('#ulNotaDebito').removeClass('in');
$('#nuevaNotaDebitoFactura').removeClass("active-link");
$('#nuevaNotaDebitoBoleta').removeClass("active-link");
$('#notaCredito').removeClass("active-sub");
$('#ulNotaCredito').removeClass('in');
$('#nuevaNotaCreditoFactura').removeClass("active-link");
$('#nuevaNotaCreditoBoleta').removeClass("active-link");
$('#resumenDiario').removeClass("active-link");
$('#documentosElectronicos').removeClass("active-link");
$('#comunicacionBaja').removeClass("active-link");
$('#guiaRemision').removeClass("active-link");
//Modulo contabilidad
$('#contabilidad').removeClass("active-sub");
$('#ulContabilidad').removeClass('in');
$('#librosElectronicos').removeClass("active-sub");
$('#ulLibros').removeClass('in');
$('#cajaBancos').removeClass("active-sub");
$('#ulCajaBancos').removeClass('in');
$('#mEfectivo').removeClass("active-link");
$('#mCorriente').removeClass("active-link");
$('#registroInventarios').removeClass("active-link");
$('#registroCompras').removeClass("active-link");
$('#registroVentas').removeClass("active-link");
$('#libroDiario').removeClass("active-link");
$('#libroMayor').removeClass("active-link");
$('#listaBancos').removeClass("active-link");
$('#cuentasBancarias').removeClass("active-link");
$('#medioPagos').removeClass("active-link");
$('#pcge').removeClass("active-link");
//Modulo creditos
$('#creditos').removeClass("active-sub");
$('#ulCreditos').removeClass('in');
$('#cuentasPagar').removeClass("active-link");
$('#cuentasCobrar').removeClass("active-link");
//Modulo rrhh
$('#rrhh').removeClass("active-sub");
$('#ulRH').removeClass('in');
$('#variablesDescansos').removeClass("active-link");
$('#consultaAsistencia').removeClass("active-link");
$('#listaAsistencia').removeClass("active-link");
$('#listaDescanso').removeClass("active-link");
$('#vacaciones').removeClass("active-link");
$('#contratos').removeClass("active-link");
$('#cargos').removeClass("active-link");
$('#pagos').removeClass("active-link");
$('#planilla').removeClass("active-link");
//Modulo crm
$('#crm').removeClass("active-sub");
$('#ulCRM').removeClass('in');
$('#tareas').removeClass("active-link");
$('#proyectos').removeClass("active-link");
$('#callCenter').removeClass("active-link");
$('#propuestas').removeClass("active-link");
$('#presupuestos').removeClass("active-link");
$('#historialTickets').removeClass("active-link");
$('#clientesPotenciales').removeClass("active-link");
//Modulo ajustes
$('#ajustes').removeClass("active-sub");
$('#ulAjustes').removeClass('in');
$('#datosEmpresa').removeClass("active-link");
$('#establecimientos').removeClass("active-link");
$('#seriesCorrelativos').removeClass("active-link");
$('#cuentasUsuarios').removeClass("active-link");
$('#accesosUsuarios').removeClass("active-link");
$('#logsUsuarios').removeClass("active-link");
$('#almacenes').removeClass("active-link");
$('#respaldo').removeClass("active-link");
$('#backup').removeClass("active-link");
//Modulo reportes
$('#reportes').removeClass("active-sub");
$('#ulReportes').removeClass('in');
$('#gastos').removeClass("active-link");
$('#reporteVentas').removeClass("active-sub");
$('#ulReporteVentas').removeClass('in');
$('#ventasUsuario').removeClass("active-link");
$('#ventasCliente').removeClass("active-link");
$('#ventasResumen').removeClass("active-link");
$('#reporteCompras').removeClass("active-sub");
$('#ulReporteComras').removeClass('in');
$('#comprasUsuario').removeClass("active-link");
$('#comprasProveedor').removeClass("active-link");
$('#comprasResumen').removeClass("active-link");
$('#consolidado').removeClass("active-link");
$('#balanceProductos').removeClass("active-link");
$('#utilidadesProductos').removeClass("active-link");
$('#gastosVSingresos').removeClass("active-link");