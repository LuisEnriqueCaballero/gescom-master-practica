//Login usuario
function showP() {
    $password=document.getElementById("password");
    if ($password.type=="password") {
        $password.type="text";
        $('.ajaxgif1').removeClass('hide');
        $('.nohidden1').addClass('hide');
    } else {
        $password.type="password";
        $('.ajaxgif1').addClass('hide');
        $('.nohidden1').removeClass('hide');
    }
}
//Lock screen
function showL() {
    $password=document.getElementById("passwordLock");
    if ($password.type=="password") {
        $password.type="text";
        $('.ajaxgif1').removeClass('hide');
        $('.nohidden1').addClass('hide');
    } else {
        $password.type="password";
        $('.ajaxgif1').addClass('hide');
        $('.nohidden1').removeClass('hide');
    }
}