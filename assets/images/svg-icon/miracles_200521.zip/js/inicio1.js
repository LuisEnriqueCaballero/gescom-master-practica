/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
//Redirigimos al modulo
$(document).ready(function() {
	$("#contenido_principal").load("modulos/ss_inicio.php");
	loadS(1);
});

function loadS(page){
  //$("#ldng_cat").fadeIn('slow');
  $.ajax({
    url:'../view/includes/cargaSuc.php',
    beforeSend: function(objeto){ },
    success:function(data){
      $("#cargaSuc").html(data).fadeIn('slow');
      //$('#ldng_cat').html('');
      //console.log(data);
    }
  })
}