/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
$(document).ready(function() {
  $('#loginLock').click(function() {
    var usernameLock=$("#usernameLock").val();
    var passwordLock=$("#passwordLock").val();
    var dataString = 'usernameLock='+usernameLock+'&passwordLock='+passwordLock;
    if($.trim(usernameLock).length>0 && $.trim(passwordLock).length>0) {
      $.ajax({
        type: "POST",
        url: "../ajax/ajaxLock.php",
        data: dataString,
        cache: false,
        beforeSend: function() {
          $('#loginLock').attr("disabled", true);
          $("#loginLock").html('Verificando...');
          $('#load_login').html('<img src="../assets/images/svg-icon/loading.svg" width="50">');
          $('#load_login').addClass('ajax-loader-login');
        },
        success: function(data) {
          if(data) {
            $('#passwordLock').attr("disabled", true);
            $("#loginLock").html('Desbloqueando...');
            setTimeout(' window.location.href = "../view/"; ',2000);
          } else {
            $('#passwordLock').focus();
            $('#loginLock').attr("disabled", false);
            $("#loginLock").html('Desbloquear');
            $.niftyNoty({
                type: 'danger',
                icon : 'pli-exclamation icon-2x',
                message : '<strong>Oopss!</strong><br> La contrase&ntilde;a ingresada es incorrecta.',
                container : 'floating',
                timer : 5000
            });
            //toastr["error"]("Contrase&ntilde;a incorrecta", "Oopss!");
            $('#load_login').html('');
            $('#load_login').removeClass('ajax-loader-login');
          }
        }
      });
    } else {
      if (passwordLock.length==0) {
        $.niftyNoty({
            type: 'warning',
            icon : 'pli-exclamation icon-2x',
            message : '<strong>Oopss!</strong><br> Por favor ingresa tu contrase&ntilde;a para acceder al sistema.',
            container : 'floating',
            timer : 5000
        });

        $('#passwordLock').focus();
      }
    }
  event.preventDefault();
  });
});