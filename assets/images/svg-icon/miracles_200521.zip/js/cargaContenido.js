/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
function cargar_contenido(contenedor,contenido) {
    //Si se tiene conexion a internet cargara el contenido
    if(navigator.onLine) {
        $("#"+contenedor).load(contenido, function(responseTxt, statusTxt, xhr) {
            //Si existe el modulo lo cargara
            if(statusTxt == "success") {
                $("#load_contenido").fadeIn('slow');
                $.ajax({
                    url:contenido,
                    beforeSend: function(objeto) {
                        $('#load_contenido').html('<img src="../assets/images/svg-icon/loading.svg" width="50"><p>');
                        $('#load_contenido').addClass('ajax-loader-contenido');
                    },
                    success:function(data) {
                        //Si carga correctamente se mostrara el contenido
                        if(data != '') {
                            $("#"+contenedor).html(data).fadeIn('slow');
                            $('#load_contenido').html('');
                            $('#load_contenido').removeClass('ajax-loader-contenido');
                        //Caso contrario indicara la alerta
                        } else {
                           vt.error("Ocurri&oacute; un error al cargar el m&oacute;dulo, int&eacute;ntalo nuevamente.", {
                                duration: 2000,
                                fadeDuration: 200,
                                title: "Aviso!",
                                position: "top-left"
                            })
                        }
                    }
                })
            }
            //Caso contrario indicara la alerta
            if(statusTxt == "error") {
                vt.info("No encontramos el m&oacute;dulo, es probable que a&uacute;n est&eacute; en desarrollo.", {
                    duration: 2000,
                    fadeDuration: 200,
                    title: "Aviso!",
                    position: "top-left"
                })
            }             
        });
    //Caso contrario indicara la alerta
    } else {
        vt.error("Por favor verifica tu conexi&oacute;n a internet.", {
            duration: 2000,
            fadeDuration: 200,
            title: "Oopss!",
            position: "top-center"
        });
    }
}