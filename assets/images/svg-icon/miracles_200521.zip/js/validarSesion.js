$(document).ready(function() {
    var is_session_expired = 'no';
    //Verificamos el estado de la sesion
    function check_session() {
        $.ajax({
            url:"funciones/check_session.php",
            method:"POST",
            success:function(data) {
                if(data == '1') {
                    $('#loginModal').modal({
                        backdrop: 'static',
                        keyboard: false,
                    });
                    is_session_expired = 'yes';
                }
            }
        })
    }
    //Hacemos el conteo para abrir la ventana modal
    var count_interval = setInterval(function() {
        check_session();
        if(is_session_expired == 'yes') {
            clearInterval(count_interval);
        }
    }, 3000);
    //Abrimos la ventana modal para iniciar sesion
    $('#login_form').on('submit', function(event) {
        event.preventDefault();
        $.ajax({
            url:"../ajax/ajaxLoginEmpresa.php",
            method:"POST",
            data:$(this).serialize(),
            beforeSend: function(){
                $('#login').attr("disabled", true);
                $("#login").html('Verificando...');
                $('#load_login').html('<img src="../assets/images/svg-icon/loading.svg" width="50">');
                $('#load_login').addClass('ajax-loader-login');
            },
            success:function(data) {
                if(data != '') {
                    $('#username').attr("disabled", true);
                    $("#login").html('Ingresando...');
                    setTimeout(' window.location.href = "../view/"; ',2000);
                } else {
                    vt.error("No encontramos el RUC en nuestra base de datos.", {
                        duration: 5000,
                        fadeDuration: 200,
                        title: "Oopss!",
                        position: "top-right"
                    })
                    $('#username').attr("disabled", false);
                    $('#username').focus();
                    $('#login').attr("disabled", false);
                    $("#login").html('Ingresar');
                    $('#load_login').html('');
                    $('#load_login').removeClass('ajax-loader-login');
                }
            }
        })
   });
})