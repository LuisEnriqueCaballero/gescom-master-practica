/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
function widthFunctions(e) {
    var wh = $(window).height(),
    lth = $('#left-top').height(),
    lbh = $('#left-bottom').height();
    $('#item-list').css("height", wh - 159.6);
    $('#item-list').css("min-height", 400);
    $('#left-middle').css("height", wh - lth - lbh - 154.6);
    $('#left-middle').css("min-height", 200);
    $('#product-list').css("height", wh - lth - lbh - 154.6);
    $('#product-list').css("min-height", 200);
}
$(window).bind("resize", widthFunctions);