/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
window.addEventListener('online', updateStatus);
window.addEventListener('offline', updateStatus);

function updateStatus() {
	var status = document.getElementById('estadoC');
	if (navigator.onLine) {
		$('#estadoC').removeClass('hidden');
        $('#estadoC').addClass('colorA');
        $('#estadoC').removeClass('colorD');
        $('.toast-body').text('En hora buena! Estas conectado a internet.');
	} else {
		$('#estadoC').removeClass('hidden');
        $('#estadoC').addClass('colorD');
        $('#estadoC').removeClass('colorA');
        $('.toast-body').text('Opps! por favor verifica tu conexion a internet.')
	}
	window.setTimeout(function() {
	    $('#estadoC').addClass('hidden');
	}, 5000);
};

updateStatus();