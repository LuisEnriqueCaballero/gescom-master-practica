/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
$(document).ready(function() {
  $('#guardar_datos1').click(function() {
    var documento_colaborador1=$("#documento_colaborador1").val();
    var dataString = 'documento_colaborador1='+documento_colaborador1;
    if($.trim(documento_colaborador1).length>0) {
      $.ajax({
        type: "POST",
        url: "../ajax/ajaxLoginAsistencia1.php",
        data: dataString,
        cache: false,
        beforeSend: function() {
          $('#guardar_datos1').attr("disabled", true);
          $("#guardar_datos1").html('Verificando...');
          $('#load_login').html('<img src="../assets/images/svg-icon/loading.svg" width="50">');
          $('#load_login').addClass('ajax-loader-login');
        },
        success: function(data) {
          if(data == 2) {
            $('#documento_colaborador1').attr("disabled", false);
            $("#guardar_datos1").html('Registrando Salida...');
            $.niftyNoty({
                type: 'success',
                icon : 'pli-exclamation icon-2x',
                message : '<strong>Bien hecho!</strong><br> Tu salida ha sido registrada exitosamente.',
                container : 'floating',
                timer : 5000
            });
            $('#guardar_datos1').attr("disabled", false);
            $("#guardar_datos1").html('Registrar Salida');
            $('#load_login').html('');
            $('#load_login').removeClass('ajax-loader-login');
            $("#guarda_salidaColaborador")[0].reset();
          } else if(data == 3) {
            $.niftyNoty({
                type: 'danger',
                icon : 'pli-exclamation icon-2x',
                message : '<strong>Oopss!</strong><br> No encontramos el documento en nuestra base de datos.',
                container : 'floating',
                timer : 5000
            });
            $('#documento_colaborador1').focus();
            $('#guardar_datos1').attr("disabled", false);
            $("#guardar_datos1").html('Registrar Salida');
            $('#load_login').html('');
            $('#load_login').removeClass('ajax-loader-login');
          } else if(data == 4) {
            $.niftyNoty({
                type: 'info',
                icon : 'pli-exclamation icon-2x',
                message : '<strong>Aviso!</strong><br> Tu salida ya est&aacute; registrada en nuestra base de datos.',
                container : 'floating',
                timer : 5000
            });
            $('#documento_colaborador1').focus();
            $('#guardar_datos1').attr("disabled", false);
            $("#guardar_datos1").html('Registrar Salida');
            $('#load_login').html('');
            $('#load_login').removeClass('ajax-loader-login');
            $("#guarda_salidaColaborador")[0].reset();
          } else if (data == 1) {
            $.niftyNoty({
                type: 'warning',
                icon : 'pli-exclamation icon-2x',
                message : '<strong>Oopss!</strong><br> No est&aacute;s habilitado para registrar tu salida.',
                container : 'floating',
                timer : 5000
            });
            $('#documento_colaborador1').focus();
            $('#guardar_datos1').attr("disabled", false);
            $("#guardar_datos1").html('Registrar Salida');
            $('#load_login').html('');
            $('#load_login').removeClass('ajax-loader-login');
          };
        }
      });
    } else {
      if (documento_colaborador1.length==0) {
        $.niftyNoty({
            type: 'warning',
            icon : 'pli-exclamation icon-2x',
            message : '<strong>Oopss!</strong><br> Por favor ingresa tu documento para registrar tu salida.',
            container : 'floating',
            timer : 5000
        });
        $('#documento_colaborador1').focus();
      }
    }
  event.preventDefault();
  });
});