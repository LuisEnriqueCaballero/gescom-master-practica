$("#consulta_datos" ).submit(function( event ) {
  $('#consultar').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
  $('#consultar').attr("disabled", true);
  var parametros = $(this).serialize();
  $.ajax({
    type: "POST",
    url: "../ajax/consultaDocumento.php",
    data: parametros,
    beforeSend: function(objeto){
    	$('#load_login').html('<img src="../assets/images/svg-icon/loading.svg" width="50">');
      $('#load_login').addClass('ajax-loader-login');
    },
    success: function(datos){
      $('#consultar').html('Aceptar');
      $('#consultar').attr("disabled", false);
      //load(1);
      $("#consulta_datos")[0].reset();
      //$("#banco_nombre").focus();
      //console.log(datos);
      //setTimeout('window.location.href = "../consulta/#/resultado"; ',2000);
      $("#resultados_ajax").html(datos);
      $('#load_login').html('');
      $('#load_login').removeClass('ajax-loader-login');

      $('#formulario').addClass('hidden');
      $('#tituloInicial').addClass('hidden');
      $('#descripcionInicial').addClass('hidden');
      $('#respuesta').removeClass('hidden');
    }
  });
  event.preventDefault();
});
//
function regresar() {
  $('#formulario').removeClass('hidden');
  $('#tituloInicial').removeClass('hidden');
  $('#descripcionInicial').removeClass('hidden');
  $('#respuesta').addClass('hidden');
}