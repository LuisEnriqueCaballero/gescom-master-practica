/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
window.onload=function() {
    var container = document.getElementById('container-loader');
    container.style.visibility = 'hidden';
    container.style.opacity = '0';
}