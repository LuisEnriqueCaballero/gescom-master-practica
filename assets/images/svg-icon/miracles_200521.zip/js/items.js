/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
//Cambiamos la barra de titulo
$(document). prop('title', '.:: Items | Miracles ::.');
//
$(document).ready(function(){
  load(1);
  $("#cod_resultado").load("../ajax/incrementaCodProducto.php");
  $("#cargaMarcaAjax").load("../ajax/ajaxMarcas.php");
  $("#cargaCategoriaAjax").load("../ajax/ajaxCategorias.php");
  $("#carga_fecha").html('<input type="hidden" class="form-control" id="producto_fechaVencimiento" name="producto_fechaVencimiento" onKeyUp="this.value=this.value.toUpperCase();" value="0000-00-00">');
  $('#producto_idSegmento').on('change',function(){
      var countryID = $(this).val();
      if(countryID){
          $.ajax({
              type:'POST',
              url:'../ajax/ajaxDate.php',
              data:'country_id='+countryID,
              success:function(html){
                  $('#producto_idFamilia').html(html);
                  $('#producto_idClase').html('<option value="">-- PRIMERO SELECCIONA UNA FAMILIA --</option>');
                  $('#producto_idProducto').html('<option value="">-- PRIMERO SELECCIONA UNA CLASE --</option>'); 
                  $('#producto_codigo').val('');
              }
          }); 
      }else{
          $('#producto_idFamilia').html('<option value="">-- PRIMERO SELECCIONA UN SEGMENTO --</option>');
          $('#producto_idClase').html('<option value="">-- PRIMERO SELECCIONA UNA FAMILIA --</option>');
          $('#producto_idProducto').html('<option value="">-- PRIMERO SELECCIONA UNA CLASE --</option>');
          $('#producto_codigo').val('');
      }
  });
  
  $('#producto_idFamilia').on('change',function(){
      var stateID = $(this).val();
      if(stateID){
          $.ajax({
              type:'POST',
              url:'../ajax/ajaxDate.php',
              data:'state_id='+stateID,
              success:function(html){
                  $('#producto_idClase').html(html);
              }
          }); 
      }else{
          $('#producto_idClase').html('<option value="">-- PRIMERO SELECCIONA UNA FAMILIA --</option>'); 
          $('#producto_idProducto').html('<option value="">-- PRIMERO SELECCIONA UNA CLASE --</option>');
          $('#producto_codigo').val('');
      }
  });

  $('#producto_idClase').on('change',function(){
      var cityID = $(this).val();
      if(cityID){
          $.ajax({
              type:'POST',
              url:'../ajax/ajaxDate.php',
              data:'city_id='+cityID,
              success:function(html){
                  $('#producto_idProducto').html(html);
              }
          }); 
      }else{
          $('#producto_idProducto').html('<option value="">-- PRIMERO SELECCIONA UNA CLASE --</option>'); 
          $('#producto_codigo').val('');
      }
  });

  $('#producto_idProducto').on('change',function(){
      var productID = $(this).val();
      if(productID){
          $.ajax({
              type:'POST',
              url:'../ajax/ajaxDate.php',
              data:'product_id='+productID,
              success:function(html){
                  $('#producto_codigo').val(html);
              }
          }); 
      }else{
          $('#producto_codigo').val(''); 
      }
  });
});
//Busca los datos
function load(page){
  	$("#ldng_cat").fadeIn('slow');
  	$.ajax({
    	url:'../ajax/buscarItems.php',
    	beforeSend: function(objeto){ },
    	success:function(data){
      		$(".outer_div_cat").html(data).fadeIn('slow');
      		$('#ldng_cat').html('');
    	}
  	})
}
//Registra
$("#guardar_item" ).submit(function( event ) {
  $('#guardar_datos').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
  $('#guardar_datos').attr("disabled", true);
  var parametros = $(this).serialize();
  $.ajax({
    type: "POST",
    url: "../ajax/nuevoItem.php",
    data: parametros,
    beforeSend: function(objeto){ },
    success: function(datos){
      $("#resultados_ajax").html(datos);
      $('#guardar_datos').html('Aceptar');
      $('#guardar_datos').attr("disabled", false);
      $("#cod_resultado").load("../ajax/incrementaCodProducto.php");
      load(1);
      $("#guardar_item")[0].reset();
      $("#producto_codigoBarras").focus();
    }
  });
  event.preventDefault();
})
//Registra marca
$("#guardar_marca" ).submit(function( event ) {
  $('#guardar_datos').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
  $('#guardar_datos').attr("disabled", true);
  var parametros = $(this).serialize();
  $.ajax({
    type: "POST",
    url: "../ajax/nuevoMarca.php",
    data: parametros,
    beforeSend: function(objeto){ },
    success: function(datos){
      $("#resultados_ajax").html(datos);
      $('#guardar_datos').html('Aceptar');
      $('#guardar_datos').attr("disabled", false);
      $("#cargaMarcaAjax").load("../ajax/ajaxMarcas.php");
      $("#guardar_marca")[0].reset();
      $("#nom_marca").focus();
    }
  });
  event.preventDefault();
})
//Registra categoria
$("#guardar_categoria" ).submit(function( event ) {
  $('#guardar_datos').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
  $('#guardar_datos').attr("disabled", true);
  var parametros = $(this).serialize();
  $.ajax({
    type: "POST",
    url: "../ajax/nuevoCategoria.php",
    data: parametros,
    beforeSend: function(objeto){ },
    success: function(datos){
      $("#resultados_ajax").html(datos);
      $('#guardar_datos').html('Aceptar');
      $('#guardar_datos').attr("disabled", false);
      $("#cargaCategoriaAjax").load("../ajax/ajaxCategorias.php");
      $("#guardar_categoria")[0].reset();
      $("#nom_categoria").focus();
    }
  });
  event.preventDefault();
})
//Edita
$("#editar_item" ).submit(function( event ) {
  $('#actualizar_datos').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
  $('#actualizar_datos').attr("disabled", true);
  var parametros = $(this).serialize();
  $.ajax({
    type: "POST",
    url: "../ajax/editarItem.php",
    data: parametros,
    beforeSend: function(objeto){ },
    success: function(datos){
      $("#resultados_ajax2").html(datos);
      $('#actualizar_datos').html('Aceptar');
      $('#actualizar_datos').attr("disabled", false);
      load(1);
      //loadS(1);
      //console.log(datos);
    }
  });
  event.preventDefault();
})
//
function showFv(select){
  if(select.value==''){
    $("#carga_fecha").html('');
  }
  if(select.value==1){
    $("#carga_fecha").html('<input type="hidden" class="form-control" id="producto_fechaVencimiento" name="producto_fechaVencimiento" onKeyUp="this.value=this.value.toUpperCase();" value="0000-00-00">');
  }
  if(select.value==2){
    $("#carga_fecha").html('<label for="producto_fechaVencimiento">F. Vencimiento *</label><input type="date" class="form-control" id="producto_fechaVencimiento" name="producto_fechaVencimiento" onKeyUp="this.value=this.value.toUpperCase();">');
  }
}
//Carga foto
function upload_image_mod(id_producto){
  $("#load_img_mod").text('Cargando...');
  var inputFileImage = document.getElementById("imagefile_mod");
  var file = inputFileImage.files[0];
  var data = new FormData();
  data.append('imagefile_mod',file);
  data.append('id_producto',id_producto);

  $.ajax({
      url: "../ajax/cargaImagenItem.php",        // Url to which the request is send
      type: "POST",             // Type of request to be send, called as method
      data: data,         // Data sent to server, a set of key/value pairs (i.e. form fields and values)
      contentType: false,       // The content type used when sending data to the server.
      cache: false,             // To unable request pages to be cached
      processData:false,        // To send DOMDocument or non processed data file it is set to false
      success: function(data)   // A function to be called if request succeeds
      {
        $("#load_img_mod").html(data);
        load(1);
      }
    });
  event.preventDefault();
}
function carga_img(id_producto) {
  $(".outer_img").load("../ajax/imgItem.php?id_producto="+id_producto);
}
//Obtiene los datos en el modal
function obtener_datos(id){
  var foto_producto = $("#foto_producto"+id).val();
  $("#load_img_mod").val(foto_producto);
  $("#mod_id").val(id);
}
//
function carga_esp(id_producto) {
  $(".outer_img").load("../ajax/espItem.php?id_producto="+id_producto);
}
//
function upload_esp_mod(id_producto){
  $("#resultados_ajax").text('Cargando...');
  var inputFileImage = document.getElementById("esp_file_mod");
  var file = inputFileImage.files[0];
  var data = new FormData();
  data.append('esp_file_mod',file);
  data.append('id_producto',id_producto);



  $.ajax({
      url: "../ajax/cargaEspecificaciones.php",        // Url to which the request is send
      type: "POST",             // Type of request to be send, called as method
      data: data,         // Data sent to server, a set of key/value pairs (i.e. form fields and values)
      contentType: false,       // The content type used when sending data to the server.
      cache: false,             // To unable request pages to be cached
      processData:false,        // To send DOMDocument or non processed data file it is set to false
      success: function(data)   // A function to be called if request succeeds
      {
        $("#resultados_ajax").html(data);
        //console.log(data);
        load(1);
      }
    });
  event.preventDefault();
}

//
function carga_fic(id_producto) {
  $(".outer_img").load("../ajax/fichaItem.php?id_producto="+id_producto);
}
//
function upload_fic_mod(id_producto){
  $("#load_img_mod").text('Cargando...');
  var inputFileImage = document.getElementById("imagefile_mod2");
  var file = inputFileImage.files[0];
  var data = new FormData();
  data.append('imagefile_mod2',file);
  data.append('id_producto',id_producto);



  $.ajax({
      url: "../ajax/cargaFicha.php",        // Url to which the request is send
      type: "POST",             // Type of request to be send, called as method
      data: data,         // Data sent to server, a set of key/value pairs (i.e. form fields and values)
      contentType: false,       // The content type used when sending data to the server.
      cache: false,             // To unable request pages to be cached
      processData:false,        // To send DOMDocument or non processed data file it is set to false
      success: function(data)   // A function to be called if request succeeds
      {
        $("#load_img_mod").html(data);
        load(1);
        //console.log(data);
      }
    });
  event.preventDefault();
}
//Elimina
$('#eliminarItem').on('show.bs.modal', function(event) {
    var button = $(event.relatedTarget) // Bot��n que activ�� el modal
    var id = button.data('id') // Extraer la informaci��n de atributos de datos
    var modal = $(this)
    modal.find('#id_item').val(id)
})
$("#eliminarDatos").submit(function(event) {
  $('#eliminar').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
    $('#eliminar').attr("disabled", true);
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/eliminarItem.php",
        data: parametros,
        beforeSend: function(objeto) {},
        success: function(datos) {
            $(".datos_ajax_delete").html(datos);
            $('.datos_ajax_delete').html('');
            $('.datos_ajax_delete').removeClass('ajax-loader');
            $('#eliminar').html('S&iacute;, continuar');
            $('#eliminar').attr("disabled", false);
            $('#eliminarItem').modal('hide');
            load(1);
            //console.log(datos);            
        }
    });
    event.preventDefault();
});
//Obtiene los datos en el modal
function obtener_datos(id){
  var producto_codigoBarras = $("#producto_codigoBarras"+id).val();
  var producto_nombre = $("#producto_nombre"+id).val();
  var producto_descripcion = $("#producto_descripcion"+id).val();
  var producto_codigo = $("#producto_codigo"+id).val();
  var producto_idCategoria = $("#producto_idCategoria"+id).val();
  var producto_idMarca = $("#producto_idMarca"+id).val();
  var producto_idUnidadMedida = $("#producto_idUnidadMedida"+id).val();
  var producto_idProveedor = $("#producto_idProveedor"+id).val();
  var producto_afectacion = $("#producto_afectacion"+id).val();
  var producto_monVenta = $("#producto_monVenta"+id).val();
  var producto_costo = $("#producto_costo"+id).val();
  var producto_precio = $("#producto_precio"+id).val();
  var producto_stock = $("#producto_stock"+id).val();
  var producto_minimo = $("#producto_minimo"+id).val();
  var producto_icbper = $("#producto_icbper"+id).val();
  var producto_fechaVencimiento1 = $("#producto_fechaVencimiento1"+id).val();
  $("#mod_barras").val(producto_codigoBarras);
  $("#mod_nombre").val(producto_nombre);
  $("#mod_descripcion").val(producto_descripcion);
  $("#mod_codigo").val(producto_codigo);
  $("#mod_idCategoria").val(producto_idCategoria);
  $("#mod_idMarca").val(producto_idMarca);
  $("#mod_idUnidadMedida").val(producto_idUnidadMedida);
  $("#mod_idProveedor").val(producto_idProveedor);
  $("#mod_afectacion").val(producto_afectacion);
  $("#mod_monVenta").val(producto_monVenta);
  $("#mod_costo").val(producto_costo);
  $("#mod_precio").val(producto_precio);
  $("#mod_stock").val(producto_stock);
  $("#mod_minimo").val(producto_minimo);
  $("#mod_icbper").val(producto_icbper);
  $("#mod_fechaVencimiento1").val(producto_fechaVencimiento1);
  $("#mod_idItem").val(id);
}
//Modificamos el mueno lateral
$('#container').addClass("mainnav-lg");
$('#container').removeClass("mainnav-sm page-fixedbar");
//Marcamos el menu lateral
$('#inicio').removeClass("active-link");
$('#pos').removeClass("active-link");
$('#notas').removeClass("active-link");
$('#anuncios').removeClass("active-link");
$('#calendario').removeClass("active-link");
$('#archivos').removeClass("active-link");
//Modulo archivos
$('#caja').removeClass("active-sub");
$('#ulCaja').removeClass('in');
$('#CajaActual').removeClass("active-link");
$('#Movimientos').removeClass("active-link");
//Modulo personas
$('#personas').removeClass("active-sub");
$('#ulPersonas').removeClass('in');
$('#clientes').removeClass("active-link");
$('#proveedores').removeClass("active-link");
$('#colaboradores').removeClass("active-link");
//Modulo restaurante
$('#restaurante').removeClass("active-sub");
$('#ulRestaurante').removeClass('in');
$('#mesas').removeClass("active-link");
$('#seccionesR').removeClass("active-link");
$('#insumos').removeClass("active-link");
//Modulo hospedaje
$('#hospedaje').removeClass("active-sub");
$('#ulHospedaje').removeClass('in');
$('#habitaciones').removeClass("active-link");
$('#seccionesH').removeClass("active-link");
//Modulo escuela
$('#escuela').removeClass("active-sub");
$('#ulEscuela').removeClass('in');
$('#estudiantes').removeClass("active-link");
$('#profesores').removeClass("active-link");
$('#padres').removeClass("active-link");
$('#calificaciones').removeClass("active-link");
$('#horarios').removeClass("active-link");
$('#asistenciaE').removeClass("active-link");
//Modulo clinica
$('#clinica').removeClass("active-sub");
$('#ulClinica').removeClass('in');
$('#admision').removeClass("active-link");
$('#topico').removeClass("active-link");
$('#historias').removeClass("active-link");
$('#especialidades').removeClass("active-link");
$('#medicos').removeClass("active-link");
$('#atencion').removeClass("active-link");
//Modulo marketing
$('#marketing').removeClass("active-sub");
$('#ulMarketing').removeClass('in');
$('#mktEmail').removeClass("active-link");
$('#mktWhatsApp').removeClass("active-link");
//Modulo articulos
$('#articulos').addClass("active-sub");
$('#ulArticulos').addClass('in');
$('#marcas').removeClass("active-link");
$('#categorias').removeClass("active-link");
$('#items').addClass("active-link");
$('#kardex').removeClass("active-link");
$('#traslados').removeClass("active-link");
$('#ajustarInventario').removeClass("active-link");
//Modulo ventas
$('#ventas').removeClass("active-sub");
$('#ulVentas').removeClass('in');
$('#nuevaVenta').removeClass("active-link");
$('#nuevaFactura').removeClass("active-link");
$('#nuevoPedido').removeClass("active-link");
$('#historialVentas').removeClass("active-link");
//Modulo cotizaciones
$('#cotizaciones').removeClass("active-sub");
$('#ulCotizaciones').removeClass('in');
$('#nuevaCotizacion').removeClass("active-link");
$('#historialCotizaciones').removeClass("active-link");
//Modulo egresos
$('#egresos').removeClass("active-sub");
$('#ulEgresos').removeClass('in');
$('#nuevaCompra').removeClass("active-link");
$('#historialCompras').removeClass("active-link");
$('#categoriaGastos').removeClass("active-link");
$('#historialGastos').removeClass("active-link");
//Modulo facturacion electronica
$('#facturacionElectronica').removeClass("active-sub");
$('#ulFacturacionElectronica').removeClass('in');
$('#notaDebito').removeClass("active-sub");
$('#ulNotaDebito').removeClass('in');
$('#nuevaNotaDebitoFactura').removeClass("active-link");
$('#nuevaNotaDebitoBoleta').removeClass("active-link");
$('#notaCredito').removeClass("active-sub");
$('#ulNotaCredito').removeClass('in');
$('#nuevaNotaCreditoFactura').removeClass("active-link");
$('#nuevaNotaCreditoBoleta').removeClass("active-link");
$('#resumenDiario').removeClass("active-link");
$('#documentosElectronicos').removeClass("active-link");
$('#comunicacionBaja').removeClass("active-link");
$('#guiaRemision').removeClass("active-link");
//Modulo contabilidad
$('#contabilidad').removeClass("active-sub");
$('#ulContabilidad').removeClass('in');
$('#librosElectronicos').removeClass("active-sub");
$('#ulLibros').removeClass('in');
$('#cajaBancos').removeClass("active-sub");
$('#ulCajaBancos').removeClass('in');
$('#mEfectivo').removeClass("active-link");
$('#mCorriente').removeClass("active-link");
$('#registroInventarios').removeClass("active-link");
$('#registroCompras').removeClass("active-link");
$('#registroVentas').removeClass("active-link");
$('#libroDiario').removeClass("active-link");
$('#libroMayor').removeClass("active-link");
$('#listaBancos').removeClass("active-link");
$('#cuentasBancarias').removeClass("active-link");
$('#medioPagos').removeClass("active-link");
$('#pcge').removeClass("active-link");
//Modulo creditos
$('#creditos').removeClass("active-sub");
$('#ulCreditos').removeClass('in');
$('#cuentasPagar').removeClass("active-link");
$('#cuentasCobrar').removeClass("active-link");
//Modulo rrhh
$('#rrhh').removeClass("active-sub");
$('#ulRH').removeClass('in');
$('#variablesDescansos').removeClass("active-link");
$('#consultaAsistencia').removeClass("active-link");
$('#listaAsistencia').removeClass("active-link");
$('#listaDescanso').removeClass("active-link");
$('#vacaciones').removeClass("active-link");
$('#contratos').removeClass("active-link");
$('#cargos').removeClass("active-link");
$('#pagos').removeClass("active-link");
$('#planilla').removeClass("active-link");
//Modulo crm
$('#crm').removeClass("active-sub");
$('#ulCRM').removeClass('in');
$('#tareas').removeClass("active-link");
$('#proyectos').removeClass("active-link");
$('#callCenter').removeClass("active-link");
$('#propuestas').removeClass("active-link");
$('#presupuestos').removeClass("active-link");
$('#historialTickets').removeClass("active-link");
$('#clientesPotenciales').removeClass("active-link");
//Modulo ajustes
$('#ajustes').removeClass("active-sub");
$('#ulAjustes').removeClass('in');
$('#datosEmpresa').removeClass("active-link");
$('#establecimientos').removeClass("active-link");
$('#seriesCorrelativos').removeClass("active-link");
$('#cuentasUsuarios').removeClass("active-link");
$('#accesosUsuarios').removeClass("active-link");
$('#logsUsuarios').removeClass("active-link");
$('#almacenes').removeClass("active-link");
$('#respaldo').removeClass("active-link");
$('#backup').removeClass("active-link");
//Modulo reportes
$('#reportes').removeClass("active-sub");
$('#ulReportes').removeClass('in');
$('#gastos').removeClass("active-link");
$('#reporteVentas').removeClass("active-sub");
$('#ulReporteVentas').removeClass('in');
$('#ventasUsuario').removeClass("active-link");
$('#ventasCliente').removeClass("active-link");
$('#ventasResumen').removeClass("active-link");
$('#reporteCompras').removeClass("active-sub");
$('#ulReporteComras').removeClass('in');
$('#comprasUsuario').removeClass("active-link");
$('#comprasProveedor').removeClass("active-link");
$('#comprasResumen').removeClass("active-link");
$('#consolidado').removeClass("active-link");
$('#balanceProductos').removeClass("active-link");
$('#utilidadesProductos').removeClass("active-link");
$('#gastosVSingresos').removeClass("active-link");