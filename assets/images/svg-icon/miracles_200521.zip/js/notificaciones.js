//
$(document).ready(function(){
  loadCcalendario(1);
  loadNcalendario(1);
});
//Busca los datos
function loadCcalendario(page){
  //$("#ldng_cat").fadeIn('slow');
  $.ajax({
    url:'../ajax/notContCalendario.php',
    beforeSend: function(objeto){ },
    success:function(data){
      $("#notCalendar").text(data);
      //$('#ldng_cat').html('');
    }
  })
}

function loadNcalendario(page){
  //$("#ldng_cat").fadeIn('slow');
  $.ajax({
    url:'../ajax/notCargaCalendario.php',
    beforeSend: function(objeto){ },
    success:function(data){
      $("#cargaCalendario").html(data);
      //$('#ldng_cat').html('');
    }
  })
}