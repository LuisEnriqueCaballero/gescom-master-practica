$(document).ready(function() {
    var is_session_expired = 'no';
    //Verificamos el estado de la sesion
    function check_session() {
        $.ajax({
            url:"funciones/check_session1.php",
            method:"POST",
            success:function(data) {
                if(data == '1') {
                    /*$('#loginModal').modal({
                        backdrop: 'static',
                        keyboard: false,
                    });*/
                    $.niftyNoty({
                        type: 'info',
                        icon : 'pli-exclamation icon-2x',
                        message : '<strong>Aviso!</strong><br> Tu sesi&oacute;n ha caducado, por favor incia sesi&oacute;n nuevamente.',
                        container : 'floating',
                        timer : 5000
                    });
                    setTimeout(' window.location.href = "../view/"; ',2000);
                    is_session_expired = 'yes';
                }
            }
        })
    }
    //Hacemos el conteo para abrir la ventana modal
    var count_interval = setInterval(function() {
        check_session();
        if(is_session_expired == 'yes') {
            clearInterval(count_interval);
        }
    }, 3000);
})