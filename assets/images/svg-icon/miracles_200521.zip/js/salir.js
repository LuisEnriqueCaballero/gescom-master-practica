function salir() {
    $("#load_login").fadeIn('slow');
        $.ajax({
        url: 'logoutt.php',
        beforeSend: function(objeto) {
            $('#load_login').html('<img src="../assets/images/svg-icon/loading.svg" width="50">');
            $('#load_login').addClass('ajax-loader-login');
            $('#is').attr("disabled", true);
            $('#passwordLock').attr("disabled", true);
            $('#loginLock').attr("disabled", true);
            $('#is').html('Est&aacute;s saliendo del sistema...');
        },
        success: function(data) {
            vt.success("Estamos cerrando tu sesi&oacute;n...", {
                duration: 2000,
                fadeDuration: 200,
                title: "Nos vemos pronto",
                position: "top-right"
            })
            setTimeout('window.location.href ="../view"; ',2000);
        }
    })
}