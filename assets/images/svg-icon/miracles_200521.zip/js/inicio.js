/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
//Redirigimos al modulo
setInterval(
    function(){
      $('#cargaConectados1').load('../ajax/cargaConectados.php');
    },1000
);