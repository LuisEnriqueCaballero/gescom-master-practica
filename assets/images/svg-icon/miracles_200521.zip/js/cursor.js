/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
let div = document.querySelector('#menuCursor');
window.oncontextmenu = (e) => {
    e.preventDefault();
    div.style.top = e.offsetY + 'px';
    div.style.left = e.offsetX + 'px';
    div.classList.add('showCursor');
}
window.onclick = () => {div.classList.remove('showCursor');}