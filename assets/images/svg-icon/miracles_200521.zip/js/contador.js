/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
const input = document.querySelector("form input"),
counter = document.querySelector("form .counter"),
maxLength = input.getAttribute("maxlength");
//Ejecutamos el contador
input.onkeyup = () => {
  counter.innerText = maxLength - input.value.length;
}