/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
$( document ).ready(function() {
	$( "#logout" ).click(function() {
		$.ajax({
			type: "GET",
			url: "../view/logout.php",
			data: ({ logout : 1 }),
			dataType: "html",
			beforeSend: function(){
				$('#logout').attr("disabled", true);
				$('#cancelar_salir').attr("disabled", true);
				$("#logout").html('<img src="../img/company/load1.svg" style="width: 16px;"> &nbsp;Verificando...');
				$('#load_login').html('<img src="../assets/images/svg-icon/loading.svg" width="50">');
      			$('#load_login').addClass('ajax-loader-login');
				$('#salir').modal('hide');
			},
			success: function(data) {
				$('#logout').attr("disabled", true);
				$('#cancelar_salir').attr("disabled", true);
				$("#logout").html('<img src="../img/company/load1.svg" style="width: 16px;"> &nbsp;Cerrando sesi&oacute;n...');
				//toastr["success"]("Estamos cerrando tu sesi&oacute;n...", "Bien hecho!");
				vt.success("Estamos cerrando tu sesi&oacute;n...", {
	                duration: 5000,
	                fadeDuration: 200,
	                title: "Nos vemos pronto",
	                position: "top-right"
	            })
				setTimeout(' window.location.href = "../view/"; ',2000);
			},
			error: function() {
				$('#logout').attr("disabled", false);
				$('#cancelar_salir').attr("disabled", false);
				$("#logout").html('S&iacute;, cerrar sesi&oacute;n');
				//toastr["error"]("Ocurri&oacute; un error...", "Oops!");
				vt.error("Ocurri&oacute; un error desconocido.", {
	                duration: 5000,
	                fadeDuration: 200,
	                title: "Oopss",
	                position: "top-right"
	            })
			}
		});
	});
});