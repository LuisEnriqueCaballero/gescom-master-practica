/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
$(document).ready(function() {
  $('#loginLog').click(function() {
    var usernameLog=$("#usernameLog").val();
    var password=$("#password").val();
    var dataString = 'usernameLog='+usernameLog+'&password='+password;
    if($.trim(usernameLog).length>0 && $.trim(password).length>0) {
      $.ajax({
        type: "POST",
        url: "../ajax/ajaxLogin.php",
        data: dataString,
        cache: false,
        beforeSend: function() {
          $('#loginLog').attr("disabled", true);
          $("#loginLog").html('Verificando...');
          $('#load_login').html('<img src="../assets/images/svg-icon/loading.svg" width="50">');
          $('#load_login').addClass('ajax-loader-login');
        },
        success: function(data) {
          if(data == 2) {
            $('#usernameLog').attr("disabled", true);
            $('#password').attr("disabled", true);
            $("#loginLog").html('Conectando...');
            setTimeout('window.location.href = "../view/"; ',2000);
          } else if (data == 3) {
            $.niftyNoty({
                type: 'danger',
                icon : 'pli-exclamation icon-2x',
                message : '<strong>Oopss!</strong><br> El usuario o la contrase&ntilde;a son incorrectos.',
                container : 'floating',
                timer : 5000
            });
            $('#usernameLog').focus();
            $('#loginLog').attr("disabled", false);
            $("#loginLog").html('Iniciar Sesi&oacute;n');
            $('#load_login').html('');
            $('#load_login').removeClass('ajax-loader-login');
          } else if (data == 1) {
            $.niftyNoty({
                type: 'info',
                icon : 'pli-exclamation icon-2x',
                message : '<strong>Oopss!</strong><br> El acceso del usuario est&aacute; desactivado.',
                container : 'floating',
                timer : 5000
            });
            $('#usernameLog').focus();
            $('#loginLog').attr("disabled", false);
            $("#loginLog").html('Iniciar Sesi&oacute;n');
            $('#load_login').html('');
            $('#load_login').removeClass('ajax-loader-login');
          }
        }
      });
    } else {
      if (usernameLog.length==0 && password.length==0) {
        $.niftyNoty({
            type: 'warning',
            icon : 'pli-exclamation icon-2x',
            message : '<strong>Oopss!</strong><br> Por favor ingresa tu usuario y contrase&ntilde;a para acceder al sistema.',
            container : 'floating',
            timer : 5000
        });
        $('#usernameLog').focus();
      } else if (usernameLog.length==0) {
        $.niftyNoty({
            type: 'warning',
            icon : 'pli-exclamation icon-2x',
            message : '<strong>Oopss!</strong><br> Por favor ingresa tu usuario para acceder al sistema.',
            container : 'floating',
            timer : 5000
        });
        $('#usernameLog').focus();
      } else {
        $.niftyNoty({
            type: 'warning',
            icon : 'pli-exclamation icon-2x',
            message : '<strong>Oopss!</strong><br> Por favor ingresa tu contrase&ntilde;a para acceder al sistema.',
            container : 'floating',
            timer : 5000
        });
        $('#password').focus();
      }
    }
  event.preventDefault();
  });
});