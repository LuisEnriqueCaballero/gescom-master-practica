/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
$(document).ready(function() {
  $('#forgot').click(function() {
    var txt_email=$("#txt_email").val();
    //var password=$("#password").val();
    var dataString = 'txt_email='+txt_email;
    if($.trim(txt_email).length>0) {
      $.ajax({
        type: "POST",
        url: "../ajax/ajaxForgot.php",
        data: dataString,
        cache: false,
        beforeSend: function() {
          $("#txt_email").attr("disabled", true);
          $('#forgot').attr("disabled", true);
          $("#forgot").html('Verificando...');
          $('#load_login').html('<img src="../assets/images/svg-icon/loading.svg" width="50">');
          $('#load_login').addClass('ajax-loader-login');
        },
        success: function(data) {
          if(data) {
            $("#forgot").html('Enviar');
            $("#resultados_ajax").html(data);
            $("#fgp")[0].reset();
            $("#txt_email").attr("disabled", false);
            $('#forgot').attr("disabled", false);
            $('#txt_email').focus();
            $('#load_login').html('');
            $('#load_login').removeClass('ajax-loader-login');
            //console.log(data);
          } else {
            $("#fgp")[0].reset();
            $('#txt_email').focus();
            $('#load_login').html('');
            $('#load_login').removeClass('ajax-loader-login');
          }
        }
      });
    } else {
      if (txt_email.length==0) {
        $.niftyNoty({
            type: 'warning',
            icon : 'pli-exclamation icon-2x',
            message : '<strong>Oopss!</strong><br> Por favor ingresa tu Correo Electr&oacute;nico para enviarte tu nueva contrase&ntilde;a.',
            container : 'floating',
            timer : 5000
        });
        $('#txt_email').focus();
      }
    }
  event.preventDefault();
  });
});