//Login usuario
function showPa() {
    $passwordA=document.getElementById("passwordA");
    if ($passwordA.type=="password") {
        $passwordA.type="text";
        $('.ajaxgif1').removeClass('hide');
        $('.nohidden1').addClass('hide');
    } else {
        $passwordA.type="password";
        $('.ajaxgif1').addClass('hide');
        $('.nohidden1').removeClass('hide');
    }
}
//Lock screen
function showLa() {
    $passwordA=document.getElementById("passwordALock");
    if ($passwordA.type=="password") {
        $passwordA.type="text";
        $('.ajaxgif1').removeClass('hide');
        $('.nohidden1').addClass('hide');
    } else {
        $passwordA.type="password";
        $('.ajaxgif1').addClass('hide');
        $('.nohidden1').removeClass('hide');
    }
}