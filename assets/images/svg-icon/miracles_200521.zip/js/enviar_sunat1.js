function enviar(id) {
    $('#enviar_sunat').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Enviando...');
    $('#enviar_sunat').attr("disabled", true);
    $.ajax({
        type: "GET",
        url: "../view/pdf/documentos/enviar_sunat.php",
        data: "fac="+id,
        beforeSend: function(objeto){
            $('#load_contenido_venta').html('<img src="../img/company/shoppingCart.svg" width="150">');
            $('#load_contenido_venta').addClass('ajax-loader-contenido_venta');
        },
        success: function(datos){
            //$('#enviar_sunat').html('<img src="../assets/images/svg-icon/sunat.svg" class="img-fluid" alt="settings" style="width: 15px; height: 15px;"> Documento Enviado');
            if(datos != "") {
                $("#resultados_ajax").html(datos);
                $('#load_contenido_venta').html('');
                $('#load_contenido_venta').removeClass('ajax-loader-contenido_venta');
                //load(1);
                loadF(1);
                loadB(1);
                loadNC(1);
                loadND(1);
                loadNP(1);

                //console.log(datos);
            } else {
                $('#enviar_sunat').html('<span class="fa fa-paper-plane"></span> Enviar SUNAT');
                $('#enviar_sunat').attr("disabled", false);
                //toastr["danger"]("Ocurri&oacute; un error", "Oopss!");                            
            }
        }
    });
}