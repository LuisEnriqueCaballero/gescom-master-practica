/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
$(document).ready(function() {
  $('#login_ruc').click(function() {
    var username=$("#username").val();
    var dataString = 'username='+username;
    if($.trim(username).length>0) {
      $.ajax({
        type: "POST",
        url: "../ajax/ajaxLoginEmpresa.php",
        data: dataString,
        cache: false,
        beforeSend: function() {
          $('#login_ruc').attr("disabled", true);
          $("#login_ruc").html('Verificando...');
          $('#load_login').html('<img src="../assets/images/svg-icon/loading.svg" width="50">');
          $('#load_login').addClass('ajax-loader-login');
        },
        success: function(data) {
          if(data == 2) {
            $('#username').attr("disabled", true);
            $("#login_ruc").html('Ingresando...');
            setTimeout('window.location.href = "../view/"; ',2000);
          } else if(data == 3) {
            $.niftyNoty({
                type: 'danger',
                icon : 'pli-exclamation icon-2x',
                message : '<strong>Oopss!</strong><br> No encontramos el RUC en nuestra base de datos.',
                container : 'floating',
                timer : 5000
            });
            $('#username').focus();
            $('#login_ruc').attr("disabled", false);
            $("#login_ruc").html('Ingresar');
            $('#load_login').html('');
            $('#load_login').removeClass('ajax-loader-login');
          } else if (data == 1) {
            $.niftyNoty({
                type: 'info',
                icon : 'pli-exclamation icon-2x',
                message : '<strong>Oopss!</strong><br> El RUC no est&aacute; habilitado para acceder al sistema.',
                container : 'floating',
                timer : 5000
            });
            $('#username').focus();
            $('#login_ruc').attr("disabled", false);
            $("#login_ruc").html('Ingresar');
            $('#load_login').html('');
            $('#load_login').removeClass('ajax-loader-login');
          };
        }
      });
    } else {
      if (username.length==0) {
        $.niftyNoty({
            type: 'warning',
            icon : 'pli-exclamation icon-2x',
            message : '<strong>Oopss!</strong><br> Por favor ingresa tu RUC para iniciar el sistema.',
            container : 'floating',
            timer : 5000
        });
        $('#username').focus();
      }
    }
  event.preventDefault();
  });
});