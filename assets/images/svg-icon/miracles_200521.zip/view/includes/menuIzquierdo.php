<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
//Nos conectamos a la base de datos
require_once "../config/general.php";
require_once "../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../config/conexion.php"; //Contiene funcion que conecta a la base de datos
include "../view/funciones/funciones.php";
//Verificamos el sexo del usuario loqueado
$sex    = $_SESSION['usuario_sexo'];
$actual = $_SESSION['usuario_id'];
$empresa  = $_SESSION['datosEmpresa_id'];
if ($sex==1) {
   $sexo = "o";
}
if ($sex==2) {
   $sexo = "a";
}
//Datos del usuario
$sql_usuario            = mysqli_query($con,"select * from usuarios where usuario_id='$actual'");
$rw_usuario             = mysqli_fetch_array($sql_usuario);
$usuario_idColaborador  = $rw_usuario['usuario_idColaborador'];
$usuario_alias          = $rw_usuario['usuario_alias'];
$usuario_accesos        = $rw_usuario['usuario_accesos'];
//Datos del colaborador
$sql_colaborador        = mysqli_query($con,"select * from colaboradores where colaborador_id='$usuario_idColaborador'");
$rw_colaborador         = mysqli_fetch_array($sql_colaborador);
$colaborador_foto       = $rw_colaborador['colaborador_foto'];
$colaborador_cargo      = $rw_colaborador['colaborador_cargo'];
//Datos del cargo
$sql_cargo              = mysqli_query($con,"select * from cargo where cargo_id='$colaborador_cargo'");
$rw_cargo               = mysqli_fetch_array($sql_cargo);
$cargo_nombre           = $rw_cargo['cargo_nombre'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo); 
//Validamos el rubro
$sql_rubro              = "select * from datosempresa where datosEmpresa_id=$empresa";
$rw_rubro               = mysqli_query($con,$sql_rubro);//recuperando el registro
$rs_rubro               = mysqli_fetch_array($rw_rubro);//trasformar el registro en un vector asociativo
$modulo_rubro           = $rs_rubro["datosEmpresa_rubro"];
$rubro                  = explode(".", $modulo_rubro); 
//Foto del usuario
if ($colaborador_foto == 'man.jpg' or $colaborador_foto == 'woman.jpg') {
  if ($colaborador_foto == 'man.jpg') {
    $rutaFoto = '<img class="img-circle img-md" src="../img/user/man.jpg">';
  }
  if ($colaborador_foto == 'woman.jpg') {
    $rutaFoto = '<img class="img-circle img-md" src="../img/user/woman.jpg">';
  }

} else {
  $rutaFoto = '<img class="img-circle img-md" src="../img/user/'.$datosEmpresa_ruc.'/'.$colaborador_foto.'">';
}
?>
<nav id="mainnav-container" class="bg-whiteD">
                <div id="mainnav" class="bg-whiteD">
                    <!--Menu-->
                    <!--================================-->
                    <div id="mainnav-menu-wrap">
                        <div class="nano">
                            <div class="nano-content">
                                <!--Profile Widget-->
                                <!--================================-->
                                <div id="mainnav-profile" class="mainnav-profile">
                                    <div class="profile-wrap text-center bg-whiteD">
                                        <div class="pad-btm">
                                            <?php echo $rutaFoto; ?>
                                        </div>
                                        <a href="#profile-nav" class="box-block" data-toggle="collapse" aria-expanded="false">
                                            <span class="pull-right dropdown-toggle">
                                                <i class="dropdown-caret"></i>
                                            </span>
                                            <p class="mnp-name"><?php echo $usuario_alias; ?></p>
                                            <span class="mnp-desc"><?php echo $cargo_nombre; ?></span>
                                        </a>
                                    </div>
                                    <div id="profile-nav" class="collapse list-group bg-trans bg-whiteD1">
                                        <a href="#/ss_miPerfil" style="cursor: url(../img/company/cursorH1.png), pointer;" class="list-group-item">
                                            <i class="demo-pli-male icon-lg icon-fw"></i> Mi Perfil
                                        </a>
                                        <?php if($a[183]==1 || $a[184]==1 || $a[185]==1 || $a[186]==1 || $a[187]==1 || $a[188]==1){ ?>
                                        <a href="#/cf_datosEmpresa" style="cursor: url(../img/company/cursorH1.png), pointer;" class="list-group-item">
                                            <i class="demo-pli-gear icon-lg icon-fw"></i> Configuraciones
                                        </a>
                                        <?php } ?>
                                        <a onclick="window.open('https://www.youtube.com/watch?v=oQYJ8kDOko4&list=PLi7VO-BXieO8oTG_FzDV-1GLPpO6ALGb3','_blank');" style="cursor: url(../img/company/cursorH1.png), pointer;" class="list-group-item">
                                            <i class="demo-pli-video icon-lg icon-fw"></i> Video Tutoriales
                                        </a>
                                        <a data-toggle="modal" data-target="#salir" style="cursor: url(../img/company/cursorH1.png), pointer;" class="list-group-item">
                                            <i class="demo-pli-unlock icon-lg icon-fw"></i> Cerrar Sesi&oacute;n
                                        </a>
                                    </div>
                                </div>
                                <!--Shortcut buttons-->
                                <!--================================-->
                                <div id="mainnav-shortcut" class="">
                                    <ul class="list-unstyled shortcut-wrap">
                                        <li class="col-xs-3" data-content="Mi perfil">
                                            <a class="shortcut-grid" href="#/ss_miPerfil" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                                <div class="icon-wrap icon-wrap-sm icon-circle bg-mint">
                                                <i class="demo-pli-male"></i>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="col-xs-3" data-content="Video Tutoriales">
                                            <a class="shortcut-grid" onclick="window.open('https://www.youtube.com/watch?v=oQYJ8kDOko4&list=PLi7VO-BXieO8oTG_FzDV-1GLPpO6ALGb3','_blank');" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                                <div class="icon-wrap icon-wrap-sm icon-circle bg-warning">
                                                <i class="demo-pli-video"></i>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="col-xs-3" data-content="Bloquear Sesi&oacute;n">
                                            <a class="shortcut-grid" data-toggle="modal" data-target="#lockscreen" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                                <div class="icon-wrap icon-wrap-sm icon-circle bg-purple">
                                                <i class="demo-pli-lock-2"></i>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="col-xs-3" data-content="Cerrar Sesi&oacute;n">
                                            <a class="shortcut-grid" data-toggle="modal" data-target="#salir" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                                <div class="icon-wrap icon-wrap-sm icon-circle bg-success">
                                                <i class="demo-pli-unlock"></i>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <!--================================-->
                                <!--End shortcut buttons-->
                                <ul id="mainnav-menu" class="list-group">
                                    <!--Category name-->
                                    <li class="list-header">Menu de navegaci&oacute;n</li>
                                    <?php if($a[0]==1){ ?>
                                    <!-- Inicio -->
                                    <li class="bg-whiteD" id="inicio">
                                        <a href="#/ss_inicio" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/house.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">
                                                Inicio
                                            </span>
                                        </a>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[1]==1){ ?>
                                    <!-- TPV -->
                                    <li class="bg-whiteD" id="pos">
                                        <a href="#/pos" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/escala.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">
                                                TPV
                                            </span>
                                        </a>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[2]==1){ ?>
                                    <!-- Notas -->
                                    <li class="hidden bg-whiteD" id="notas">
                                        <a href="#/ss_notas" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/post-it.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">
                                                Notas
                                            </span>
                                        </a>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[3]==1){ ?>
                                    <!-- Anuncios -->
                                    <li class="hidden bg-whiteD" id="anuncios">
                                        <a href="#/ss_anuncios" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/altoparlante.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">
                                                Anuncios
                                            </span>
                                        </a>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[4]==1){ ?>
                                    <!-- Calendario -->
                                    <li class="bg-whiteD" id="calendario">
                                        <a href="#/ss_calendario" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/calendar.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">
                                                Calendario
                                            </span>
                                        </a>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[5]==1){ ?>
                                    <!-- Archivos -->
                                    <li class="bg-whiteD" id="archivos">
                                        <a href="#/ss_archivos" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/folder1.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">
                                                Archivos
                                            </span>
                                        </a>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[6]==1 || $a[7]==1 || $a[8]==1 || $a[9]==1 || $a[229]==1){ ?>
                                    <!-- Caja -->
                                    <li class="bg-whiteD" id="caja">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/cashier.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Caja</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulCaja">
                                            <?php if($a[6]==1 || $a[7]==1){ ?>
                                            <li class="" id="CajaActual"><a href="#/ca_caja" style="cursor: url(../img/company/cursorH1.png), pointer;">Administrar Caja</a></li>
                                            <?php } ?>
                                            <?php if($a[8]==1 || $a[9]==1 || $a[229]==1){ ?>
                                            <li class="" id="Movimientos"><a href="#/ca_movCajas" style="cursor: url(../img/company/cursorH1.png), pointer;">Hist&oacute;rico Caja</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[10]==1 || $a[11]==1 || $a[12]==1 || $a[13]==1 || $a[14]==1 || $a[15]==1 || $a[16]==1 || $a[17]==1 || $a[18]==1 || $a[19]==1 || $a[20]==1 || $a[21]==1 || $a[22]==1 || $a[23]==1){ ?>
                                    <!-- Personas -->
                                    <li class="bg-whiteD" id="personas">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/teamwork.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Personas</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulPersonas">
                                            <?php if($a[10]==1 || $a[11]==1 || $a[12]==1 || $a[13]==1){ ?>
                                            <li id="clientes"><a href="#/pp_clientes" style="cursor: url(../img/company/cursorH1.png), pointer;">Clientes</a></li>
                                            <?php } ?>
                                            <?php if($a[14]==1 || $a[15]==1 || $a[16]==1 || $a[17]==1){ ?>
                                            <li id="proveedores"><a href="#/pp_proveedores" style="cursor: url(../img/company/cursorH1.png), pointer;">Proveedores</a></li>
                                            <?php } ?>
                                            <?php if($a[18]==1 || $a[19]==1 || $a[20]==1 || $a[21]==1 || $a[22]==1 || $a[23]==1){ ?>
                                            <li id="colaboradores"><a href="#/pp_colaboradores" style="cursor: url(../img/company/cursorH1.png), pointer;">Colaboradores</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if ($rubro[0]==1) { ?>
                                    <!-- Restaurante -->
                                    <li class="bg-whiteD" id="restaurante">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/restaurant.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Restaurante</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulRestaurante">
                                            <li id="mesas"><a href="#/hc_admision" style="cursor: url(../img/company/cursorH1.png), pointer;">Mesas</a></li>
                                            <li id="seccionesR"><a href="#/hc_topico" style="cursor: url(../img/company/cursorH1.png), pointer;">Secciones</a></li>
                                            <li id="insumos"><a href="#/hc_laboratorio" style="cursor: url(../img/company/cursorH1.png), pointer;">Insumos</a></li>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if ($rubro[1]==1) { ?>
                                    <!-- Hospedaje -->
                                    <li class="bg-whiteD" id="hospedaje">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/hotel.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Hospedaje</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulHospedaje">
                                            <li id="habitaciones"><a href="#/hc_admision" style="cursor: url(../img/company/cursorH1.png), pointer;">Habitaciones</a></li>
                                            <li id="SeccionesH"><a href="#/hc_topico" style="cursor: url(../img/company/cursorH1.png), pointer;">Secciones</a></li>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if ($rubro[2]==1) { ?>
                                    <!-- Escuela -->
                                    <li class="bg-whiteD" id="escuela">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/school.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Escuela</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulEscuela">
                                            <li id="estudiantes"><a href="#/hc_admision" style="cursor: url(../img/company/cursorH1.png), pointer;">Estudiantes</a></li>
                                            <li id="profesores"><a href="#/hc_topico" style="cursor: url(../img/company/cursorH1.png), pointer;">Profesores</a></li>
                                            <li id="padres"><a href="#/hc_laboratorio" style="cursor: url(../img/company/cursorH1.png), pointer;">Padres</a></li>
                                            <li id="calificaciones"><a href="#/hc_especialidades" style="cursor: url(../img/company/cursorH1.png), pointer;">Calificaciones</a></li>
                                            <li id="horarios"><a href="#/hc_medicos" style="cursor: url(../img/company/cursorH1.png), pointer;">Horarios</a></li>
                                            <li id="asistenciaE"><a href="#/hc_vista" style="cursor: url(../img/company/cursorH1.png), pointer;">Asistencia</a></li>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if ($rubro[3]==1) { ?>
                                    <?php if($a[231]==1 || $a[232]==1 || $a[233]==1 || $a[234]==1 || $a[235]==1 || $a[236]==1 || $a[237]==1 || $a[238]==1 || $a[239]==1 || $a[240]==1 || $a[241]==1 || $a[242]==1 || $a[243]==1 || $a[234]==1 || $a[235]==1 || $a[236]==1 || $a[247]==1){ ?>
                                    <!-- Clinica -->
                                    <li class="bg-whiteD" id="clinica">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/hospital.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Cl&iacute;nica</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulClinica">
                                            <?php if($a[231]==1 || $a[232]==1){ ?>
                                            <li id="admision"><a href="#/hc_admision" style="cursor: url(../img/company/cursorH1.png), pointer;">Admisi&oacute;n</a></li>
                                            <?php } ?>
                                            <?php if($a[233]==1 || $a[234]==1){ ?>
                                            <li id="topico"><a href="#/hc_topico" style="cursor: url(../img/company/cursorH1.png), pointer;">T&oacute;pico</a></li>
                                            <?php } ?>
                                            <?php if($a[235]==1 || $a[236]==1 || $a[237]==1){ ?>
                                            <li id="historias"><a href="#/hc_historias" style="cursor: url(../img/company/cursorH1.png), pointer;">Historias</a></li>
                                            <?php } ?>
                                            <?php if($a[238]==1 || $a[239]==1 || $a[240]==1 || $a[241]==1){ ?>
                                            <li id="especialidades"><a href="#/hc_especialidades" style="cursor: url(../img/company/cursorH1.png), pointer;">Especialidades</a></li>
                                            <?php } ?>
                                            <?php if($a[242]==1 || $a[243]==1 || $a[244]==1 || $a[245]==1){ ?>
                                            <li id="medicos"><a href="#/hc_medicos" style="cursor: url(../img/company/cursorH1.png), pointer;">M&eacute;dicos</a></li>
                                            <?php } ?>
                                            <?php if($a[246]==1 || $a[247]==1){ ?>
                                            <li id="atencion"><a href="#/hc_atencion" style="cursor: url(../img/company/cursorH1.png), pointer;">Atenci&oacute;n</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php } ?>
                                    <?php if($a[24]==1 || $a[25]==1){ ?>
                                    <!-- Marketing -->
                                    <li class="bg-whiteD" id="marketing">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/social-media.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Marketing</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulMarketing">
                                            <?php if($a[24]==1){ ?>
                                            <li id="mktEmail"><a href="#/mk_email" style="cursor: url(../img/company/cursorH1.png), pointer;">Email</a></li>
                                            <?php } ?>
                                            <?php if($a[25]==1){ ?>
                                            <li id="mktWhatsApp" class="hidden"><a href="#/mk_whatsapp" style="cursor: url(../img/company/cursorH1.png), pointer;">WhatsApp</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[26]==1 || $a[27]==1 || $a[28]==1 || $a[29]==1 || $a[30]==1 || $a[31]==1 || $a[32]==1 || $a[33]==1 || $a[34]==1 || $a[35]==1 || $a[36]==1 || $a[37]==1 || $a[38]==1 || $a[39]==1 || $a[40]==1 || $a[41]==1 || $a[42]==1 || $a[43]==1 || $a[44]==1 || $a[45]==1 || $a[46]==1){ ?>
                                    <!-- Articulos-->
                                    <li class="bg-whiteD" id="articulos">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/trolley.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Art&iacute;culos</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulArticulos">
                                            <?php if($a[26]==1 || $a[27]==1 || $a[28]==1 || $a[29]==1){ ?>
                                            <li id="marcas"><a href="#/pr_marcas" style="cursor: url(../img/company/cursorH1.png), pointer;">Marcas</a></li>
                                            <?php } ?>
                                            <?php if($a[30]==1 || $a[31]==1 || $a[32]==1 || $a[33]==1){ ?>
                                            <li id="categorias"><a href="#/pr_categorias" style="cursor: url(../img/company/cursorH1.png), pointer;">Categor&iacute;as</a></li>
                                            <?php } ?>
                                            <?php if($a[34]==1 || $a[35]==1 || $a[36]==1 || $a[37]==1 || $a[38]==1 || $a[39]==1 || $a[40]==1){ ?>
                                            <li id="items"><a href="#/pr_items" style="cursor: url(../img/company/cursorH1.png), pointer;">&Iacute;tems</a></li>
                                            <?php } ?>
                                            <?php if($a[41]==1){ ?>
                                            <li id="kardex"><a href="#/pr_kardex" style="cursor: url(../img/company/cursorH1.png), pointer;">Kardex</a></li>
                                            <?php } ?>
                                            <?php if($a[42]==1 || $a[43]==1){ ?>
                                            <li id="traslados"><a href="#/pr_traslados" style="cursor: url(../img/company/cursorH1.png), pointer;">Traslados</a></li>
                                            <?php } ?>
                                            <?php if($a[44]==1 || $a[45]==1 || $a[46]==1){ ?>
                                            <li id="ajustarInventario"><a href="#/pr_ajustarInventario" style="cursor: url(../img/company/cursorH1.png), pointer;">Ajustes</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[47]==1 || $a[48]==1 || $a[49]==1 || $a[50]==1 || $a[51]==1 || $a[52]==1 || $a[53]==1 || $a[54]==1 || $a[55]==1 || $a[56]==1 || $a[57]==1 || $a[58]==1 || $a[59]==1 || $a[60]==1 || $a[61]==1 || $a[62]==1 || $a[63]==1 || $a[64]==1 || $a[65]==1 || $a[66]==1 || $a[67]==1 || $a[68]==1){ ?>
                                    <!-- Ventas -->
                                    <li class="bg-whiteD" id="ventas">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/shopping-bag1.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Ventas</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulVentas">
                                            <?php if($a[47]==1){ ?>
                                            <li id="nuevaVenta"><a href="#/vv_nuevaVenta" style="cursor: url(../img/company/cursorH1.png), pointer;">Nueva Boleta</a></li>
                                            <?php } ?>
                                            <?php if($a[48]==1){ ?>
                                            <li id="nuevaFactura"><a href="#/vv_nuevaFactura" style="cursor: url(../img/company/cursorH1.png), pointer;">Nueva Factura</a></li>
                                            <?php } ?>
                                            <?php if($a[49]==1){ ?>
                                            <li id="nuevoPedido"><a href="#/vv_nuevoPedido" style="cursor: url(../img/company/cursorH1.png), pointer;">Nuevo Pedido</a></li>
                                            <?php } ?>
                                            <?php if($a[50]==1 || $a[51]==1 || $a[52]==1 || $a[53]==1 || $a[54]==1 || $a[55]==1 || $a[56]==1 || $a[57]==1 || $a[58]==1 || $a[59]==1 || $a[60]==1 || $a[61]==1 || $a[62]==1 || $a[63]==1 || $a[64]==1 || $a[65]==1 || $a[66]==1 || $a[67]==1 || $a[68]==1){ ?>
                                            <li id="historialVentas"><a href="#/vv_ventas" style="cursor: url(../img/company/cursorH1.png), pointer;">Historial Documentos</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[69]==1 || $a[70]==1 || $a[71]==1 || $a[72]==1 || $a[73]==1 || $a[74]==1){ ?>
                                    <!-- Cotizaciones -->
                                    <li class="bg-whiteD" id="cotizaciones">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/quote.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Cotizaciones</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulCotizaciones">
                                            <?php if($a[69]==1){ ?>
                                            <li id="nuevaCotizacion"><a href="#/co_nuevaCotizacion" style="cursor: url(../img/company/cursorH1.png), pointer;">Nueva Cotizaci&oacute;n</a></li>
                                            <?php } ?>
                                            <?php if($a[70]==1 || $a[71]==1 || $a[72]==1 || $a[73]==1 || $a[74]==1){ ?>
                                            <li id="historialCotizaciones"><a href="#/co_cotizaciones" style="cursor: url(../img/company/cursorH1.png), pointer;">Historial Cotizaciones</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[75]==1 || $a[76]==1 || $a[77]==1 || $a[78]==1 || $a[79]==1 /*|| $a[80]==1 || $a[81]==1 || $a[82]==1 || $a[83]==1 */|| $a[84]==1 /*|| $a[85]==1 */|| $a[86]==1 || $a[87]==1){ ?>
                                    <!-- Egresos -->
                                    <li class="bg-whiteD" id="egresos">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/spending.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Egresos</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulEgresos">
                                            <?php if($a[75]==1){ ?>
                                            <li id="nuevaCompra"><a href="#/cm_nuevaCompra" style="cursor: url(../img/company/cursorH1.png), pointer;">Nueva Compra</a></li>
                                            <?php } ?>
                                            <?php if($a[76]==1 || $a[77]==1 || $a[78]==1 || $a[79]==1){ ?>
                                            <li id="historialCompras"><a href="#/cm_compras" style="cursor: url(../img/company/cursorH1.png), pointer;">Historial Compras</a></li>
                                            <?php } ?>
                                            <!--<?php if($a[80]==1 || $a[81]==1 || $a[82]==1 || $a[83]==1){ ?>
                                            <li id="categoriaGastos"><a href="#/cm_catGastos" style="cursor: url(../img/company/cursorH1.png), pointer;">Categor&iacute;a Gastos</a></li>
                                            <?php } ?>-->
                                            <?php if($a[84]==1 /*|| $a[85]==1 */|| $a[86]==1 || $a[87]==1){ ?>
                                            <li id="historialGastos"><a href="#/cm_gastos" style="cursor: url(../img/company/cursorH1.png), pointer;">Historial Gastos</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[88]==1 || $a[89]==1 || $a[90]==1 || $a[91]==1 || $a[92]==1 || $a[93]==1 || $a[94]==1){ ?>
                                    <!-- Fact. Electronica-->
                                    <li class="bg-whiteD" id="facturacionElectronica">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/sunat.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Fact. Electr&oacute;nica</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulFacturacionElectronica">
                                            <?php if($a[88]==1 || $a[89]==1){ ?>
                                            <li class="bg-whiteD1" id="notaDebito">
                                                <a style="cursor: url(../img/company/cursorH1.png), pointer;">Nota D&eacute;bito<i class="arrow"></i></a>
                                                <ul class="collapse bg-whiteD1" id="ulNotaDebito">
                                                    <?php if($a[88]==1){ ?>
                                                    <li id="nuevaNotaDebitoFactura"><a href="#/fe_nuevaNDFactura" style="cursor: url(../img/company/cursorH1.png), pointer;">Nuevo Para Factura</a></li>
                                                    <?php } ?>
                                                    <?php if($a[89]==1){ ?>
                                                    <li id="nuevaNotaDebitoBoleta"><a href="#/fe_nuevaNDBoleta" style="cursor: url(../img/company/cursorH1.png), pointer;">Nuevo Para Boleta</a></li>
                                                    <?php } ?>
                                                </ul>
                                            </li>
                                            <?php } ?>
                                            <?php if($a[90]==1 || $a[91]==1){ ?>
                                            <li class="bg-whiteD1" id="notaCredito">
                                                <a style="cursor: url(../img/company/cursorH1.png), pointer;">Nota Cr&eacute;dito<i class="arrow"></i></a>
                                                <ul class="collapse bg-whiteD1" id="ulNotaCredito">
                                                    <?php if($a[90]==1){ ?>
                                                    <li id="nuevaNotaCreditoFactura"><a href="#/fe_nuevaNCFactura" style="cursor: url(../img/company/cursorH1.png), pointer;">Nuevo Para Factura</a></li>
                                                    <?php } ?>
                                                    <?php if($a[91]==1){ ?>
                                                    <li id="nuevaNotaCreditoBoleta"><a href="#/fe_nuevaNCBoleta" style="cursor: url(../img/company/cursorH1.png), pointer;">Nuevo Para Boleta</a></li>
                                                    <?php } ?>
                                                </ul>
                                            </li>
                                            <?php } ?>
                                            <?php if($a[92]==1){ ?>
                                            <li id="resumenDiario"><a href="#/fe_resumenBoletas" style="cursor: url(../img/company/cursorH1.png), pointer;">Resumen Diario</a></li>
                                            <?php } ?>
                                            <?php if($a[93]==1){ ?>
                                            <li id="comunicacionBaja"><a href="#/fe_comunicacionBaja" style="cursor: url(../img/company/cursorH1.png), pointer;">Comunicaci&oacute;n Baja</a></li>
                                            <?php } ?>
                                            <?php if($a[94]==1){ ?>
                                            <li id="guiaRemision"><a href="#/fe_guiaRemision" style="cursor: url(../img/company/cursorH1.png), pointer;">Gu&iacute;a Remisi&oacute;n</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[95]==1 || $a[96]==1 || $a[97]==1 || $a[98]==1 || $a[99]==1 || $a[100]==1 || $a[101]==1 || $a[102]==1 || $a[103]==1 || $a[104]==1 || $a[105]==1 || $a[106]==1 || $a[107]==1 || $a[108]==1 || $a[109]==1 || $a[110]==1 || $a[111]==1 || $a[112]==1 || $a[113]==1 || $a[114]==1 || $a[115]==1 || $a[116]==1){ ?>
                                    <!-- Contabilidad-->
                                    <li class="bg-whiteD" id="contabilidad">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/accounting.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Contabilidad</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulContabilidad">
                                            <?php if($a[95]==1 || $a[96]==1 || $a[97]==1 || $a[98]==1 || $a[99]==1 || $a[100]==1 || $a[101]==1 || $a[102]==1){ ?>
                                            <li class="bg-whiteD1" id="librosElectronicos">
                                                <a style="cursor: url(../img/company/cursorH1.png), pointer;">Libros Electr&oacute;nicos<i class="arrow"></i></a>
                                                <ul class="collapse bg-whiteD1" id="ulLibros">
                                                    <?php if($a[95]==1 || $a[96]==1){ ?>
                                                    <li class="bg-whiteD1" id="cajaBancos" class="hidden">
                                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">Caja Bancos<i class="arrow"></i></a>
                                                        <ul class="collapse bg-whiteD1" id="ulCajaBancos">
                                                            <?php if($a[95]==1){ ?>
                                                            <li id="mEfectivo"><a href="#/cc_mEfectivo" style="cursor: url(../img/company/cursorH1.png), pointer;">Mov. Efectivo</a></li>
                                                            <?php } ?>
                                                            <?php if($a[96]==1){ ?>
                                                            <li id="mCorriente"><a href="#/cc_mCorriente" style="cursor: url(../img/company/cursorH1.png), pointer;">Mov. Cta. Corriente</a></li>
                                                            <?php } ?>
                                                        </ul>
                                                    </li>
                                                    <?php } ?>
                                                    <?php if($a[97]==1){ ?>
                                                    <li id="registroInventarios" class="hidden"><a href="#/cc_registroInventarios" style="cursor: url(../img/company/cursorH1.png), pointer;">Registro Inventarios</a></li>
                                                    <?php } ?>
                                                    <?php if($a[98]==1){ ?>
                                                    <li id="registroCompras"><a href="#/cc_registroCompras" style="cursor: url(../img/company/cursorH1.png), pointer;">Registro Compras</a></li>
                                                    <?php } ?>
                                                    <?php if($a[99]==1){ ?>
                                                    <li id="registroVentas"><a href="#/cc_registroVentas" style="cursor: url(../img/company/cursorH1.png), pointer;">Registro Ventas</a></li>
                                                    <?php } ?>
                                                    <?php if($a[100]==1 || $a[101]==1){ ?>
                                                    <li id="libroDiario" class="hidden"><a href="#/cc_libroDiario" style="cursor: url(../img/company/cursorH1.png), pointer;">Libro Diario</a></li>
                                                    <?php } ?>
                                                    <?php if($a[102]==1){ ?>
                                                    <li id="libroMayor" class="hidden"><a href="#/cc_libroMayor" style="cursor: url(../img/company/cursorH1.png), pointer;">Libro Mayor</a></li>
                                                    <?php } ?>
                                                </ul>
                                            </li>
                                            <?php } ?>
                                            <?php if($a[103]==1 || $a[104]==1 || $a[105]==1 || $a[106]==1){ ?>
                                            <li id="listaBancos"><a href="#/cc_bancos" style="cursor: url(../img/company/cursorH1.png), pointer;">Listado Bancos</a></li>
                                            <?php } ?>
                                            <?php if($a[107]==1 || $a[108]==1 || $a[109]==1 || $a[110]==1 || $a[111]==1 || $a[112]==1){ ?>
                                            <li id="cuentasBancarias"><a href="#/cc_cuentasBancarias" style="cursor: url(../img/company/cursorH1.png), pointer;">Cuentas Bancarias</a></li>
                                            <?php } ?>
                                            <?php if($a[113]==1 || $a[114]==1 || $a[115]==1 || $a[116]==1){ ?>
                                            <li id="pcge" class=""><a href="#/cc_pcge" style="cursor: url(../img/company/cursorH1.png), pointer;">Cat&aacute;logo Cuentas</a></li>
                                            <?php } ?>
                                            <?php if($a[225]==1 || $a[226]==1 || $a[227]==1 || $a[228]==1){ ?>
                                            <li id="medioPagos"><a href="#/cc_medioPagos" style="cursor: url(../img/company/cursorH1.png), pointer;">Medio Pago</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[117]==1 || $a[118]==1 || $a[119]==1 || $a[120]==1 || $a[121]==1 || $a[122]==1){ ?>
                                    <!-- Creditos -->
                                    <li class="bg-whiteD" id="creditos">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/cashback.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Cr&eacute;ditos</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulCreditos">
                                            <?php if($a[117]==1 || $a[118]==1 || $a[119]==1){ ?>
                                            <li id="cuentasPagar"><a href="#/cc_cuentasPagar" style="cursor: url(../img/company/cursorH1.png), pointer;">Cuentas Por Pagar</a></li>
                                            <?php } ?>
                                            <?php if($a[120]==1 || $a[121]==1 || $a[122]==1){ ?>
                                            <li id="cuentasCobrar"><a href="#/cc_cuentasCobrar" style="cursor: url(../img/company/cursorH1.png), pointer;">Cuentas Por Cobrar</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[123]==1 || $a[124]==1 || $a[125]==1 || $a[126]==1 || $a[127]==1 || $a[128]==1 || $a[129]==1 || $a[130]==1 || $a[131]==1 || $a[132]==1 || $a[133]==1 || $a[134]==1 || $a[135]==1 || $a[136]==1 || $a[137]==1 || $a[138]==1 || $a[139]==1 || $a[140]==1 || $a[141]==1 || $a[142]==1 || $a[143]==1 || $a[144]==1 || $a[145]==1 || $a[146]==1 || $a[147]==1 || $a[148]==1 || $a[149]==1 || $a[150]==1 || $a[151]==1 || $a[152]==1 || $a[153]==1 || $a[154]==1){ ?>
                                    <!-- RRHH -->
                                    <li class="bg-whiteD" id="rrhh">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/meeting.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">RR.HH</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulRH">
                                            <?php if($a[123]==1 || $a[124]==1 || $a[125]==1 || $a[126]==1){ ?>
                                            <li id="variablesDescansos"><a href="#/rh_varLaboral" style="cursor: url(../img/company/cursorH1.png), pointer;">Variables Laborales</a></li>
                                            <?php } ?>
                                            <?php if($a[127]==1 || $a[128]==1 || $a[129]==1){ ?>
                                            <li id="consultaAsistencia" class="hidden"><a href="#/rh_consultaAsistencia" style="cursor: url(../img/company/cursorH1.png), pointer;">Consulta Asistencia</a></li>
                                            <?php } ?>
                                            <?php if($a[131]==1 || $a[132]==1 || $a[133]==1 || $a[134]==1 || $a[130]==1){ ?>
                                            <li id="listaAsistencia"><a href="#/rh_listaAsistencia" style="cursor: url(../img/company/cursorH1.png), pointer;">Lista Asistencia</a></li>
                                            <?php } ?>
                                            <?php if($a[135]==1 || $a[136]==1 || $a[137]==1 || $a[138]==1){ ?>
                                            <li id="listaDescanso" class="hidden"><a href="#/rh_listaDescanso" style="cursor: url(../img/company/cursorH1.png), pointer;">Lista Descanso</a></li>
                                            <?php } ?>
                                            <?php if($a[139]==1 || $a[140]==1 || $a[141]==1 || $a[142]==1){ ?>
                                            <li id="vacaciones" class="hidden"><a href="#/rh_vacaciones" style="cursor: url(../img/company/cursorH1.png), pointer;">Vacaciones</a></li>
                                            <?php } ?>
                                            <?php if($a[143]==1 || $a[144]==1 || $a[145]==1 || $a[146]==1){ ?>
                                            <li id="contratos" class="hidden"><a href="#/rh_contratos" style="cursor: url(../img/company/cursorH1.png), pointer;">Contratos</a></li>
                                            <?php } ?>
                                            <?php if($a[221]==1 || $a[222]==1 || $a[223]==1 || $a[224]==1){ ?>
                                            <li id="cargos"><a href="#/rh_cargos" style="cursor: url(../img/company/cursorH1.png), pointer;">Cargos</a></li>
                                            <?php } ?>
                                            <?php if($a[147]==1 || $a[148]==1 || $a[149]==1 || $a[150]==1){ ?>
                                            <li id="pagos" class="hidden"><a href="#/rh_pagos" style="cursor: url(../img/company/cursorH1.png), pointer;">Pagos</a></li>
                                            <?php } ?>
                                            <?php if($a[151]==1 || $a[152]==1 || $a[153]==1 || $a[154]==1){ ?>
                                            <li id="planilla" class="hidden"><a href="#/rh_planilla" style="cursor: url(../img/company/cursorH1.png), pointer;">Planilla</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[155]==1 || $a[156]==1 || $a[157]==1 || $a[158]==1 || $a[159]==1 || $a[160]==1 || $a[161]==1 || $a[162]==1 || $a[163]==1 || $a[164]==1 || $a[165]==1 || $a[166]==1 || $a[167]==1 || $a[168]==1 || $a[169]==1 || $a[170]==1 || $a[171]==1 || $a[172]==1 || $a[173]==1 || $a[174]==1 || $a[175]==1 || $a[176]==1 || $a[177]==1 || $a[178]==1 || $a[179]==1 || $a[180]==1 || $a[181]==1 || $a[182]==1 || $a[248]==1 || $a[249]==1 || $a[250]==1 || $a[251]==1 || $a[252]==1 || $a[253]==1 || $a[254]==1 || $a[255]==1 || $a[256]==1 || $a[257]==1 || $a[258]==1 || $a[259]==1){ ?>
                                    <!-- CRM -->
                                    <li class="bg-whiteD" id="crm" class="hidden">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/crm.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">CRM</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulCRM">
                                            <?php if($a[155]==1 || $a[156]==1 || $a[157]==1 || $a[158]==1){ ?>
                                            <li id="tareas"><a href="#/crm_tareas" style="cursor: url(../img/company/cursorH1.png), pointer;">Tareas</a></li>
                                            <?php } ?>
                                            <?php if($a[159]==1 || $a[160]==1 || $a[161]==1 || $a[162]==1 || $a[248]==1 || $a[249]==1 || $a[250]==1 || $a[251]==1 || $a[252]==1 || $a[253]==1 || $a[254]==1 || $a[255]==1 || $a[256]==1 || $a[257]==1 || $a[258]==1 || $a[259]==1){ ?>
                                            <li id="proyectos"><a href="#/crm_proyectos" style="cursor: url(../img/company/cursorH1.png), pointer;">Proyectos</a></li>
                                            <?php } ?>
                                            <?php if($a[163]==1 || $a[164]==1 || $a[165]==1 || $a[166]==1){ ?>
                                            <li id="callCenter"><a href="#/crm_callCenter" style="cursor: url(../img/company/cursorH1.png), pointer;">Call Center</a></li>
                                            <?php } ?>
                                            <?php if($a[167]==1 || $a[168]==1 || $a[169]==1 || $a[170]==1){ ?>
                                            <li id="propuestas"><a href="#/crm_propuestas" style="cursor: url(../img/company/cursorH1.png), pointer;">Propuestas</a></li>
                                            <?php } ?>
                                            <?php if($a[171]==1 || $a[172]==1 || $a[173]==1 || $a[174]==1){ ?>
                                            <li id="presupuestos"><a href="#/crm_presupuestos" style="cursor: url(../img/company/cursorH1.png), pointer;">Presupuestos</a></li>
                                            <?php } ?>
                                            <?php if($a[175]==1 || $a[176]==1 || $a[177]==1 || $a[178]==1){ ?>
                                            <li id="historialTickets"><a href="#/crm_tickets" style="cursor: url(../img/company/cursorH1.png), pointer;">Historial Tickets</a></li>
                                            <?php } ?>
                                            <?php if($a[179]==1 || $a[180]==1 || $a[181]==1 || $a[182]==1){ ?>
                                            <li id="clientesPotenciales"><a href="#/crm_potenciales" style="cursor: url(../img/company/cursorH1.png), pointer;">Clientes Potenciales</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[183]==1 || $a[184]==1 || $a[185]==1 || $a[186]==1 || $a[187]==1 || $a[188]==1 || $a[189]==1 || $a[190]==1 || $a[191]==1 || $a[192]==1 || $a[193]==1 || $a[194]==1 || $a[195]==1 || $a[196]==1 || $a[197]==1 || $a[198]==1 || $a[199]==1 || $a[200]==1 || $a[201]==1 || $a[202]==1 || $a[203]==1 || $a[204]==1 || $a[205]==1 || $a[206]==1 || $a[207]==1 || $a[208]==1 || $a[209]==1){ ?>
                                    <!-- Ajustes -->
                                    <li class="bg-whiteD" id="ajustes">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/settings1.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Ajustes</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulAjustes">
                                            <?php if($a[183]==1 || $a[184]==1 || $a[185]==1 || $a[186]==1 || $a[187]==1 || $a[188]==1){ ?>
                                            <li id="datosEmpresa"><a href="#/cf_datosEmpresa" style="cursor: url(../img/company/cursorH1.png), pointer;">Datos Empresa</a></li>
                                            <?php } ?>
                                            <?php if($a[189]==1 || $a[190]==1 || $a[191]==1 || $a[192]==1){ ?>
                                            <li id="establecimientos"><a href="#/cf_establecimientos" style="cursor: url(../img/company/cursorH1.png), pointer;">Establecimientos</a></li>
                                            <?php } ?>
                                            <?php if($a[193]==1 || $a[194]==1){ ?>
                                            <li id="seriesCorrelativos"><a href="#/cf_seriesCorrelativos" style="cursor: url(../img/company/cursorH1.png), pointer;">Series Correlativos</a></li>
                                            <?php } ?>
                                            <?php if($a[195]==1 || $a[196]==1 || $a[197]==1 || $a[198]==1){ ?>
                                            <li id="cuentasUsuarios"><a href="#/cf_usuarios" style="cursor: url(../img/company/cursorH1.png), pointer;">Cuentas Usuarios</a></li>
                                            <?php } ?>
                                            <?php if($a[199]==1 || $a[200]==1 || $a[201]==1 || $a[202]==1){ ?>
                                            <li id="accesosUsuarios"><a href="#/cf_accesosUsuarios" style="cursor: url(../img/company/cursorH1.png), pointer;">Grupos Usuarios</a></li>
                                            <?php } ?>
                                            <?php if($a[203]==1){ ?>
                                            <li id="logsUsuarios"><a href="#/cf_logUsuarios" style="cursor: url(../img/company/cursorH1.png), pointer;">Log Usuarios</a></li>
                                            <?php } ?>
                                            <?php if($a[204]==1 || $a[205]==1 || $a[206]==1 || $a[207]==1){ ?>
                                            <li id="almacenes"><a href="#/cf_almacenes" style="cursor: url(../img/company/cursorH1.png), pointer;">Almacenes</a></li>
                                            <?php } ?>
                                            <?php if($a[208]==1){ ?>
                                            <li id="respaldo" class="hidden"><a href="#/cf_respaldo" style="cursor: url(../img/company/cursorH1.png), pointer;">Respaldo</a></li>
                                            <?php } ?>
                                            <?php if($a[209]==1){ ?>
                                            <li id="backup" class="hidden"><a href="#/cf_bakcup" style="cursor: url(../img/company/cursorH1.png), pointer;">Backup</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if($a[210]==1 || $a[211]==1 || $a[212]==1 || $a[213]==1 || $a[214]==1 || $a[215]==1 || $a[216]==1 || $a[217]==1 || $a[218]==1 || $a[219]==1 || $a[220]==1){ ?>
                                    <!-- Reportes -->
                                    <li class="bg-whiteD" id="reportes">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/statistics.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Reportes</span>
                                            <i class="arrow"></i>
                                        </a>
                                        <ul class="collapse bg-whiteD1" id="ulReportes">
                                            <?php if($a[210]==1){ ?>
                                            <li class="bg-whiteD1" id="gastos" class="hidden"><a href="#/rp_gastos" style="cursor: url(../img/company/cursorH1.png), pointer;">Gastos</a></li>
                                            <?php } ?>
                                            <?php if($a[211]==1 || $a[212]==1 || $a[213]==1){ ?>
                                            <li id="reporteVentas">
                                                <a style="cursor: url(../img/company/cursorH1.png), pointer;">Ventas<i class="arrow"></i></a>
                                                <ul class="collapse bg-whiteD1" id="ulReporteVentas">
                                                    <?php if($a[211]==1){ ?>
                                                    <li id="ventasUsuario"><a href="#/rp_ventasUsuario" style="cursor: url(../img/company/cursorH1.png), pointer;">Ventas Usuario</a></li>
                                                    <?php } ?>
                                                    <?php if($a[212]==1){ ?>
                                                    <li id="ventasCliente"><a href="#/rp_ventasCliente" style="cursor: url(../img/company/cursorH1.png), pointer;">Ventas Cliente</a></li>
                                                    <?php } ?>
                                                    <?php if($a[213]==1){ ?>
                                                    <li id="ventasResumen" class="hidden"><a href="#/rp_ventasResumen" style="cursor: url(../img/company/cursorH1.png), pointer;">Resumen</a></li>
                                                    <?php } ?>
                                                </ul>
                                            </li>
                                            <?php } ?>
                                            <?php if($a[214]==1 || $a[215]==1 || $a[216]==1){ ?>
                                            <li class="bg-whiteD1" id="reporteCompras" class="hidden">
                                                <a style="cursor: url(../img/company/cursorH1.png), pointer;">Compras<i class="arrow"></i></a>
                                                <ul class="collapse bg-whiteD1" id="ulReporteCompras">
                                                    <?php if($a[214]==1){ ?>
                                                    <li id="comprasUsuario"><a href="#/rp_comprasUsuario" style="cursor: url(../img/company/cursorH1.png), pointer;">Compras Usuario</a></li>
                                                    <?php } ?>
                                                    <?php if($a[215]==1){ ?>
                                                    <li id="comprasProveedor"><a href="#/rp_comprasProveedor" style="cursor: url(../img/company/cursorH1.png), pointer;">Compras Proveedor</a></li>
                                                    <?php } ?>
                                                    <?php if($a[216]==1){ ?>
                                                    <li id="comprasResumen"><a href="#/rp_comprasResumen" style="cursor: url(../img/company/cursorH1.png), pointer;">Resumen</a></li>
                                                    <?php } ?>
                                                </ul>
                                            </li>
                                            <?php } ?>
                                            <?php if($a[217]==1){ ?>
                                            <li id="consolidado"><a href="#/rp_consolidado" style="cursor: url(../img/company/cursorH1.png), pointer;">Consolidado</a></li>
                                            <?php } ?>
                                            <?php if($a[218]==1){ ?>
                                            <li id="balanceProductos"><a href="#/rp_balanceProductos" style="cursor: url(../img/company/cursorH1.png), pointer;">Balance &Iacute;tems</a></li>
                                            <?php } ?>
                                            <?php if($a[219]==1){ ?>
                                            <li id="utilidadesProductos"><a href="#/rp_utilidadesProductos" style="cursor: url(../img/company/cursorH1.png), pointer;">Utilidad &Iacute;tems</a></li>
                                            <?php } ?>
                                            <?php if($a[220]==1){ ?>
                                            <li id="gastosVSingresos" class="hidden"><a href="#/rp_gastosIngresos" style="cursor: url(../img/company/cursorH1.png), pointer;">Ingresos VS Egresos</a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <li class="list-divider"></li>
                                    <!-- Extras -->
                                    <li class="list-header">Extras</li>
                                    <li class="bg-whiteD">
                                        <a onclick="window.open('https://www.youtube.com/watch?v=oQYJ8kDOko4&list=PLi7VO-BXieO8oTG_FzDV-1GLPpO6ALGb3','_blank');" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/mp4.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Video Tutoriales</span>
                                        </a>
                                    </li>
                                    <li class="bg-whiteD">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <img src="../assets/images/svg-icon/pdf1.svg" style="width: 20px;">
                                            <i></i>
                                            <span class="menu-title">Manual Usuario</span>
                                        </a>
                                    </li>
                                </ul>
                                <!--Widget-->
                                <!--================================-->
                                <div class="mainnav-widget hidden">
                                    <!-- Show the button on collapsed navigation -->
                                    <div class="show-small">
                                        <a style="cursor: url(../img/company/cursorH1.png), pointer;" data-toggle="menu-widget" data-target="#demo-wg-server">
                                            <i class="demo-pli-monitor-2"></i>
                                        </a>
                                    </div>
                                    <!-- Hide the content on collapsed navigation -->
                                    <div id="demo-wg-server" class="hide-small mainnav-widget-content">
                                        <ul class="list-group">
                                            <li class="list-header pad-no mar-ver">Estado Del Servidor</li>
                                            <li class="mar-btm">
                                                <span class="label label-primary pull-right">15%</span>
                                                <p>Uso De CPU</p>
                                                <div class="progress progress-sm">
                                                    <div class="progress-bar progress-bar-primary" style="width: 15%;">
                                                        <span class="sr-only">15%</span>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="mar-btm">
                                                <span class="label label-purple pull-right">75%</span>
                                                <p>Banda Ancha</p>
                                                <div class="progress progress-sm">
                                                    <div class="progress-bar progress-bar-purple" style="width: 75%;">
                                                        <span class="sr-only">75%</span>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <!--================================-->
                                <!--End widget-->
                            </div>
                        </div>
                    </div>
                    <!--================================-->
                    <!--End menu-->
                </div>
            </nav>