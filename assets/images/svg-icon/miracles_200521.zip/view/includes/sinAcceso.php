<div id="content-container">
    <div id="page-head">
        <div class="text-center cls-content">
            <h1 class="error-code text-info">ERROR!</h1>
        </div>
    </div>
    <div id="page-content">
        <div class="text-center cls-content">
            <p class="h4 text-uppercase text-bold">Acceso denegado!</p>
            <div class="pad-btm">
                Lo sentimos, no cuentas con los permisos necesario para acceder a este m&oacute;dulo.
            </div>
        </div>
    </div>
</div>