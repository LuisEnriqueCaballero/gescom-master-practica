<div id="content-container">
    <div id="page-head">
        <div class="text-center cls-content">
            <h1 class="error-code text-info">ERROR!</h1>
        </div>
    </div>
    <div id="page-content">
        <div class="text-center cls-content">
            <p class="h4 text-uppercase text-bold">No eres m&eacute;dico!</p>
            <div class="pad-btm">
                Lo sentimos, tu usuario no est&aacute; asociado como m&eacute;dico para realizar la atenci&oacute;n. <br><br> <a href="#/hc_atencion" class="btn btn-primary">Regresar</a>.
            </div>
        </div>
    </div>
</div>