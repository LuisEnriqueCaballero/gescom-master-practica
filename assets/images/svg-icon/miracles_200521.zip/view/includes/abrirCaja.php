<div id="content-container">
    <div id="page-head">
        <div class="text-center cls-content">
            <h1 class="error-code text-info">ERROR!</h1>
        </div>
    </div>
    <div id="page-content">
        <div class="text-center cls-content">
            <p class="h4 text-uppercase text-bold">Sin caja!</p>
            <div class="pad-btm">
                Lo sentimos, tu usuario no tiene una caja registrada para el d&iacute;a, por favor apertura una caja desde el siguiente bot&oacute;n <br><br> <a href="#/ca_caja" class="btn btn-primary">Ir a caja</a>.
            </div>
        </div>
    </div>
</div>