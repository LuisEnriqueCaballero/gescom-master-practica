<footer id="footer" class="hidden-xs bg-whiteD">
            <!-- Datos de logueo -->
            <div class="show-fixed pad-rgt pull-right">
                <b>Empresa: </b><?php echo $datosEmpresa_nombre; ?> | <b>Establecimiento: </b><?php echo $sucursal_nombre; ?>
            </div>
            <!-- Datos del servidor -->
            <div class="hide-fixed pull-right pad-rgt">
                14GB of <strong>512GB</strong> Free.
            </div>
            <!-- Copyright -->
            <p class="pad-lft">&#0169; 2021 Miracles</p>
        </footer>