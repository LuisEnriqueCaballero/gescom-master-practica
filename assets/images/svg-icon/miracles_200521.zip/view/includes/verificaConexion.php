<style type="text/css">
#estadoC {
	bottom: 0px;
	width: 100%;
	height: 35px;
	position: fixed;
	z-index: 10051;
	padding: 6px;
	color: #fff;
	text-align: center;
	border-top: 0.5px solid #424242;
}
.colorA {
	background: #4CAF50;
}
.colorD {
	background: #F44336;
}
</style>
<div id="estadoC" class="colorA toast-body"></div>