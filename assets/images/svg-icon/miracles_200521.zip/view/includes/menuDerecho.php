<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
require_once "../config/general.php";
require_once "../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../config/conexion.php"; //Contiene funcion que conecta a la base de datos
$actual = $_SESSION['usuario_id'];
$empresa = $_SESSION['datosEmpresa_id'];

function checked($valor){ 
    if($valor==1){
        return 'checked';
    }else{
        return '';
    }
     
}

$sql_usuario            = mysqli_query($con,"select * from usuarios where usuario_id='$actual'");
$rw_usuario             = mysqli_fetch_array($sql_usuario);
$usuario_ajustes        = $rw_usuario["usuario_ajustes"];
$usuario_accesos        = $rw_usuario['usuario_accesos'];
$rubro                  = explode(".", $usuario_ajustes);

$c1=checked($rubro[0]);
$c2=checked($rubro[1]);
$c3=checked($rubro[2]);

$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$acceso                 = explode(".", $modulo);

$sql_empresa            = mysqli_query($con,"select * from datosempresa where datosEmpresa_id='$empresa'");
$rw_empresa             = mysqli_fetch_array($sql_empresa);
$tipoenvio              = $rw_empresa["tipoenvio"];

if ($tipoenvio == 2) {
    $marcado = 'checked';
}
if ($tipoenvio == 1) {
    $marcado = '';
}
?>
<aside id="aside-container">
                <div id="aside" class="bg-whiteD">
                    <div class="nano">
                        <div class="nano-content">
                            <!--Nav tabs-->
                            <!--================================-->
                            <ul class="nav nav-tabs nav-justified">
                                <li class="active">
                                    <a href="#demo-asd-tab-1" data-toggle="tab" class="bg-whiteD">
                                        <i class="demo-pli-speech-bubble-7 icon-lg"></i> Chat
                                    </a>
                                </li>
                                <li>
                                    <a href="#demo-asd-tab-2" data-toggle="tab" class="bg-whiteD">
                                        <i class="demo-pli-information icon-lg icon-fw"></i> Info
                                    </a>
                                </li>
                                <li>
                                    <a href="#demo-asd-tab-3" data-toggle="tab" class="bg-whiteD">
                                        <i class="demo-pli-wrench icon-lg icon-fw"></i> Ajustes
                                    </a>
                                </li>
                            </ul>
                            <!--================================-->
                            <!--End nav tabs-->
                            <!-- Tabs Content -->
                            <!--================================-->
                            <div class="tab-content">
                                <!--First tab (Contact list)-->
                                <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                <div class="tab-pane fade in active" id="demo-asd-tab-1">
                                    <p class="pad-all text-main text-sm text-uppercase text-bold">
                                        USUARIOS
                                    </p>
                                    <!--Family-->
                                    <div class="list-group bg-trans">
                                        <div id="cargaConectados1"></div>
                                    </div>
                                </div>
                                <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                <!--End first tab (Contact list)-->
                                <!--Second tab (Custom layout)-->
                                <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                <div class="tab-pane fade" id="demo-asd-tab-2">
                                    <!--Monthly billing-->
                                    <div class="pad-all hidden">
                                        <p class="pad-ver text-main text-sm text-uppercase text-bold">PLAN B&Aacute;SICO</p>
                                        <p>Get <strong class="text-main">$5.00</strong> off your next bill by making sure your full payment reaches us before August 5, 2018.</p>
                                    </div>
                                    <hr class="new-section-xs hidden">
                                    <div class="pad-all">
                                        <span class="pad-ver text-main text-sm text-uppercase text-bold">PR&Oacute;XIMA FACTURACI&Oacute;N</span>
                                        <p class="text-sm">05 junio 2021</p>
                                        <p class="text-2x text-thin text-main">S/50.00</p>
                                        <button class="btn btn-block btn-success mar-top hidden">Pay Now</button>
                                    </div>
                                    <hr>
                                    <p class="pad-all text-main text-sm text-uppercase text-bold">INFORMACI&Oacute;N ADICIONAL</p>
                                    <!--Simple Menu-->
                                    <div class="list-group bg-trans">
                                        <a data-toggle="modal" data-target="#terminosCondiciones" class="list-group-item"><i class="demo-pli-information icon-lg icon-fw"></i> T&eacute;rminos Y Condiciones</a>
                                        <a data-toggle="modal" data-target="#terminosPrivacidad" class="list-group-item"><i class="demo-pli-information icon-lg icon-fw"></i> Pol&iacute;ticas De Privacidad</a>
                                        <a data-toggle="modal" data-target="#terminosGarantia" class="list-group-item"><i class="demo-pli-information icon-lg icon-fw"></i> Pol&iacute;ticas De Garant&iacute;a</a>
                                    </div>
                                    <hr>
                                    <div class="text-center">
                                        <div><i class="demo-pli-old-telephone icon-3x"></i></div>
                                        <p class="text-lg text-semibold text-main"> (51) 951-345-257 </p>
                                    </div>
                                </div>
                                <!--End second tab (Custom layout)-->
                                <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                <!--Third tab (Settings)-->
                                <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                <div class="tab-pane fade" id="demo-asd-tab-3">
                                    <ul class="list-group bg-trans">
                                        <li class="pad-top list-header">
                                            <p class="text-main text-sm text-uppercase text-bold mar-no">CONFIGURACIONES GENERALES</p>
                                        </li>
                                        <?php if($acceso[186]==1){ ?>
                                        <li class="list-group-item">
                                            <div class="pull-right">
                                                <input class="toggle-switch" id="demo-switch-1" type="checkbox" <?php echo $marcado; ?> onclick="clickAutomatico();">
                                                <label for="demo-switch-1"></label>
                                            </div>
                                            <div class="alertaAutomatico"></div>
                                            <p class="mar-no text-main">Env&iacute;o Autom&aacute;tico</p>
                                            <small class="text-muted">Los documentos electr&oacute;nicos ser&aacute;n enviados autom&aacute;ticamente a SUNAT.</small>
                                        </li>
                                        <?php } ?>
                                        <li class="list-group-item">
                                            <div class="pull-right">
                                                <input class="toggle-switch" id="darkSwitch" type="checkbox" <?php echo $c3; ?> value="1">
                                                <label for="darkSwitch"></label>
                                            </div>
                                            <p class="mar-no text-main">Modo Oscuro</p>
                                            <small class="text-muted">Poner la pantalla en negro para ahorrar bater&iacute;a y cuidar tus ojos.</small>
                                        </li>
                                    </ul>
                                    <hr>
                                    <ul class="list-group pad-btm bg-trans">
                                        <li class="list-header"><p class="text-main text-sm text-uppercase text-bold mar-no">CONFIGURACIONES P&Uacute;BLICAS</p></li>
                                        <li class="list-group-item">
                                            <div class="pull-right">
                                                <input class="toggle-switch" id="demo-switch-4" type="checkbox" <?php echo $c1; ?> value="1" onclick="clickActivo();">
                                                <label for="demo-switch-4"></label>
                                            </div>
                                            <div class="alertaActivo"></div>
                                            Estado Activo
                                        </li>
                                        <li class="list-group-item">
                                            <div class="pull-right">
                                                <input class="toggle-switch" id="demo-switch-5" type="checkbox" <?php echo $c2; ?> value="1" onclick="clickOffline();">
                                                <label for="demo-switch-5"></label>
                                            </div>
                                            <div class="alertaOffline"></div>
                                            Ver Usuarios Desconectados
                                        </li>
                                    </ul>
                                </div>
                                <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                                <!--Third tab (Settings)-->
                            </div>
                        </div>
                    </div>
                </div>
            </aside>
            <script>
                function clickActivo(){
                    $.ajax({
                        url:'../ajax/cambiaActivo.php',
                        beforeSend: function(objeto){ },
                        success:function(data){
                            $(".alertaActivo").html(data).fadeIn('slow');
                            //$('#ldng_cat').html('');
                        }
                    })
                }

                function clickOffline(){
                    $.ajax({
                        url:'../ajax/cambiaOffline.php',
                        beforeSend: function(objeto){ },
                        success:function(data){
                            $(".alertaOffline").html(data).fadeIn('slow');
                            //$('#ldng_cat').html('');
                        }
                    })
                }

                function clickAutomatico(){
                    $.ajax({
                        url:'../ajax/cambiaAutomatico.php',
                        beforeSend: function(objeto){ },
                        success:function(data){
                            $(".alertaAutomatico").html(data).fadeIn('slow');
                            //$('#ldng_cat').html('');
                        }
                    })
                }
            </script>