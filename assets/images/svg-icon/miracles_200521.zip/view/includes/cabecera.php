<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
//
$sql_empresa=mysqli_query($con,"select * from datosempresa where datosEmpresa_id=$empresa");
$rw_tienda=mysqli_fetch_array($sql_empresa);
$datosEmpresa_ruc=$rw_tienda['datosEmpresa_ruc'];
//Sesion del usuario loqueado
$actual = $_SESSION['usuario_id'];
//Datos del usuario
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id='$actual'");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_idColaborador=$rw_usuario['usuario_idColaborador'];
$usuario_alias=$rw_usuario['usuario_alias'];
//Datos del conlaborador
$sql_colaborador=mysqli_query($con,"select * from colaboradores where colaborador_id='$usuario_idColaborador'");
$rw_colaborador=mysqli_fetch_array($sql_colaborador);
$colaborador_foto=$rw_colaborador['colaborador_foto'];
$colaborador_sucursal=$rw_colaborador['colaborador_sucursal'];
//Foto del usuario
if ($colaborador_foto == 'man.jpg' or $colaborador_foto == 'woman.jpg') {
  if ($colaborador_foto == 'man.jpg') {
    $rutaFotoCabecera = '<img src="../img/user/man.jpg" style="width: 25px;">';
    $rutaFotoCabeceraM = '<img src="../img/user/man.jpg" style="height: 20px;">';
  }
  if ($colaborador_foto == 'woman.jpg') {
    $rutaFotoCabecera = '<img src="../img/user/woman.jpg" style="width: 25px;">';
    $rutaFotoCabeceraM = '<img src="../img/user/man.jpg" style="height: 20px;">';
  }

} else {
  $rutaFotoCabecera = '<img src="../img/user/'.$datosEmpresa_ruc.'/'.$colaborador_foto.'" style="width: 25px;">';
  $rutaFotoCabeceraM = '<img src="../img/user/'.$datosEmpresa_ruc."/".$colaborador_foto.'" style="height: 20px;">';
}

if ($datosEmpresa_favicon == 'favicon.png') {
    $rutaFav = '<img src="../img/company/favicon.png" alt="'.$datosEmpresa_nombre.'" class="brand-icon" style="width: 40px; height: 40px; margin-top: 10px; margin-left: 7px;">';
} else {
    $rutaFav = '<img src="../img/company/'.$datosEmpresa_ruc.'/'.$datosEmpresa_favicon.'" alt="'.$datosEmpresa_nombre.'" class="brand-icon" style="width: 40px; height: 40px; margin-top: 10px; margin-left: 7px;">';
}
?>
<header id="navbar">
            <div id="navbar-container" class="boxed bg-lightD">
                <!-- Logo y nombre -->
                <div class="navbar-header bg-lightD">
                    <a href="#/ss_inicio" style="cursor: url(../img/company/cursorH1.png), pointer;" class="navbar-brand">
                        <?php echo $rutaFav; ?>
                        <div class="brand-title bg-lightD">
                            <span class="brand-text"><?php echo $datosEmpresa_nombre; ?></span>
                        </div>
                    </a>
                </div>
                <!-- Navbar -->
                <div class="navbar-content bg-lightD">
                    <ul class="nav navbar-top-links">
                        <!-- Menu hamburguesa -->
                        <li class="tgl-menu-btn">
                            <a class="mainnav-toggle" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                <i class="demo-pli-list-view"></i>
                            </a>
                        </li>
                        <!-- Buscador -->
                        <li>
                            <div class="custom-search-form">
                                <label class="btn btn-trans" for="search-input" data-toggle="collapse" data-target="#nav-searchbox">
                                    <i class="demo-pli-magnifi-glass"></i>
                                </label>
                                <form>
                                    <div class="search-container collapse" id="nav-searchbox">
                                        <input id="search-input" type="text" class="form-control" placeholder="Buscar...">
                                    </div>
                                </form>
                            </div>
                        </li>
                    </ul>
                    <ul class="nav navbar-top-links bg-lightD">
                        <!-- Mega menu-->
                        
                        <!-- Notificaciones -->
                        <li class="dropdown">
                            <a style="cursor: url(../img/company/cursorH1.png), pointer;" data-toggle="dropdown" class="dropdown-toggle bg-lightD">
                                <i class="fa fa-bell"></i>
                                <span class="badge badge-header badge-danger"></span>
                            </a>
                            <!-- Menu -->
                            <div class="dropdown-menu dropdown-menu-md dropdown-menu-right bg-lightD">
                                <div class="nano scrollable">
                                    <div class="nano-content">
                                        <ul class="head-list">
                                            <li>
                                                <a class="media" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                                    <div class="media-left">
                                                        <i class="demo-pli-file-edit icon-2x"></i>
                                                    </div>
                                                    <div class="media-body">
                                                        <p class="mar-no text-nowrap text-main text-semibold">Anuncio Nuevo</p>
                                                        <small>Hace 5 horas</small>
                                                    </div>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Pie -->
                                <div class="pad-all bord-top">
                                    <a style="cursor: url(../img/company/cursorH1.png), pointer;" class="btn-link text-main box-block"></a>
                                </div>
                            </div>
                        </li>

                        <li class="dropdown">
                            <a style="cursor: url(../img/company/cursorH1.png), pointer;" data-toggle="dropdown" class="dropdown-toggle bg-lightD">
                                <i class="fa fa-calendar"></i>
                                <span class="badge badge-header badge-danger" id="notCalendar"></span>
                            </a>
                            <!-- Menu -->
                            <div class="dropdown-menu dropdown-menu-md dropdown-menu-right bg-lightD">
                                <!-- Pie -->
                                <div class="pad-all bord-top">
                                    <a style="cursor: url(../img/company/cursorH1.png), pointer; text-decoration: none;" class="btn-link text-main box-block">
                                        <i class="fa fa-calendar pull-right"></i>Eventos para hoy
                                    </a>
                                </div>
                                <div class="nano scrollable">
                                    <div class="nano-content">
                                        <ul class="head-list">
                                            <div id="cargaCalendario"></div>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <!-- Menu usuario -->
                        <li id="dropdown-user" class="dropdown">
                            <a style="cursor: url(../img/company/cursorH1.png), pointer;" data-toggle="dropdown" class="dropdown-toggle text-right bg-lightD">
                                <!-- Foto -->
                                <span class="ic-user pull-right">
                                    <?php echo $rutaFotoCabecera; ?>
                                </span>
                                <!-- Username -->
                                <div class="username hidden-xs"><?php echo $_SESSION['usuario_alias']; ?></div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-sm dropdown-menu-right panel-default bg-lightD">
                                <ul class="head-list">
                                    <li>
                                        <a href="#/ss_miPerfil" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <?php echo $rutaFotoCabeceraM; ?>
                                            <i class="icon-lg icon-fw"></i> Mi Perfil
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#/ss_mensajes" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                            <span class="badge badge-danger pull-right">9</span>
                                            <img src="../assets/images/svg-icon/chat.svg" style="height: 20px;">
                                            <i class="icon-lg icon-fw"></i> Mensajes
                                        </a>
                                    </li>
                                    <li>
                                        <a data-toggle="modal" data-target="#change_password" style="cursor: url(../img/company/cursorH1.png), pointer;"><img src="../assets/images/svg-icon/lock.svg" style="height: 20px;"><i class="icon-lg icon-fw"></i> Cambiar contrase&ntilde;a</a>
                                    </li>
                                    <?php if ($colaborador_sucursal == 0) { ?>
                                    <li>
                                        <a data-toggle="modal" data-target="#cambiaEstablecimiento" style="cursor: url(../img/company/cursorH1.png), pointer;"><img src="../assets/images/svg-icon/shops.svg" style="height: 20px;"><i class="icon-lg icon-fw"></i> Cambiar Establecimiento</a>
                                    </li>
                                    <?php } ?>
                                    <li>
                                        <a data-toggle="modal" data-target="#lockscreen" style="cursor: url(../img/company/cursorH1.png), pointer;"><img src="../assets/images/svg-icon/lock1.svg" style="height: 20px;"><i class="icon-lg icon-fw"></i> Bloquear Sesi&oacute;n</a>
                                    </li>
                                    <li>
                                        <a data-toggle="modal" data-target="#salir" style="cursor: url(../img/company/cursorH1.png), pointer;"><img src="../assets/images/svg-icon/arrow.svg" style="height: 20px;"><i class="icon-lg icon-fw"></i> Cerrar Sesi&oacute;n</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li>
                            <a style="cursor: url(../img/company/cursorH1.png), pointer;" class="aside-toggle">
                                <i class="demo-pli-dot-vertical"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </header>