<div id="menuCursor">
	<ul id="ulCursor">
		<li id="liCursor"><i class="fa fa-home"></i>Inicio<span>Ctrl + i</span></a></li>
		<li id="liCursor"><a href="">Nueva Boleta</a></li>
		<li id="liCursor"><a href="">Nueva Factura</a></li>
		<li id="liCursor"><a href="">Nuevo Pedido</a></li>
		<li id="liCursor"><a href="">TPV</a></li>
	</ul>
</div>