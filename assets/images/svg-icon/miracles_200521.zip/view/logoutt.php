<?php
include("../config/db.php");
include("../config/conexion.php");
session_start();
$usuario_id = $_SESSION['usuario_id'];
$status = "Desconectado ahora";
$sql = mysqli_query($con, "UPDATE usuarios SET usuario_status = '{$status}' WHERE usuario_id={$usuario_id}");
if(!empty($_SESSION['usuario_id']))
{
$_SESSION['usuario_id']='';
session_destroy();
}

header("Location:../view/");