<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
session_start();
//requerimos el archivo de configuracion
require_once "../config/general.php"; //Contiene las variables generales
//Nos conectamos a la base de datos
require_once "../config/db.php";
require_once "../config/conexion.php";
//Validamos la sesion de la empresa
if (!empty($_SESSION['user_empresa_status'])) {
    $empresa = $_SESSION['datosEmpresa_id'];
    //Datos de la empresa logueada
    $sql_empresa=mysqli_query($con,"select * from datosempresa where datosEmpresa_id=$empresa");
    $rw_tienda=mysqli_fetch_array($sql_empresa);
    $datosEmpresa_nombre=$rw_tienda['datosEmpresa_nombre'];
    $datosEmpresa_favicon=$rw_tienda['datosEmpresa_favicon'];
    $datosEmpresa_ruc=$rw_tienda['datosEmpresa_ruc'];

    if ($datosEmpresa_favicon == 'favicon.png') {
        $rutaFavicon = '<link rel="shortcut icon" href="../img/company/favicon.png">';
    } else {
        $rutaFavicon = '<link rel="shortcut icon" href="../img/company/'.$datosEmpresa_ruc.'/'.$datosEmpresa_favicon.'">';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Miracles">
    <meta name="keywords" content="Miracles">
    <meta name="author" content="Developer Technology">
    <!-- Titulo -->
    <!--=================================================-->
    <?php if(!empty($_SESSION['user_empresa_status']) and !empty($_SESSION['user_login_status']) and $_SESSION['tienda'] != "" and !empty($_SESSION['usuario_clave'])) { ?>
    <!-- Si esta dentro del panel -->
    <title>.:: Panel | <?php echo $datosEmpresa_nombre; ?> ::.</title>
    <?php } ?>
    <?php if(!empty($_SESSION['user_login_status']) and empty($_SESSION['usuario_clave'])) { ?>
    <!-- Si esta en la pantalla de bloqueo -->
    <title>.:: LockScreen | <?php echo $datosEmpresa_nombre; ?> ::.</title>
    <?php } ?>
    <?php if(!empty($_SESSION['user_login_status']) and $_SESSION['tienda'] == "") { ?>
    <!-- Si en el listado de establecimientos -->
    <title>.:: Establecimientos | <?php echo $datosEmpresa_nombre; ?> ::.</title>
    <?php } ?>
    <?php if(!empty($_SESSION['user_empresa_status']) and $_SESSION['tienda'] == "cero") { ?>
    <!-- Si esta en el login del usuario -->
    <title>.:: Login Usuario | <?php echo $datosEmpresa_nombre; ?> ::.</title>
    <?php } ?>
    <?php if(empty($_SESSION['user_empresa_status'])) { ?>
    <!-- Si esta en el login de la empresa -->
    <title>.:: Login Empresa | Miracles ::.</title>
    <?php } ?>
    <!-- Favicon -->
    <!--=================================================-->
    <?php if (!empty($_SESSION['user_empresa_status'])) { ?>
    <!-- Si hay una sesion de empresa -->
    <?php echo $rutaFavicon; ?>
    <?php } else { ?>
    <!-- Si no hay una sesion de empresa -->
    <link rel="shortcut icon" href="../img/company/favicon.png">
    <?php } ?>
    <!-- Estilos -->
    <!--=================================================-->
    <!-- Open Sans Font -->
    <link href='../assets/css/fuentes/openSans.css' rel='stylesheet' type='text/css'>
    <!-- Bootstrap Stylesheet -->
    <link href="../assets/css/bootstrap.css" rel="stylesheet">
    <!-- Nifty Stylesheet -->
    <link href="../assets/css/style.css" rel="stylesheet">
    <!-- Nifty Stylesheet -->
    <link href="../assets/css/chat.css" rel="stylesheet">
    <!-- Login loading -->
    <link href="../assets/css/load_login1.css" rel="stylesheet" type="text/css">
    <!-- Content loading -->
    <link href="../assets/css/load_contenido1.css" rel="stylesheet" type="text/css">
    <!-- Load venta -->
    <link href="../assets/css/load_venta.css" rel="stylesheet" type="text/css">
    <!-- Nifty Premium Icon -->
    <link href="../assets/css/demo/nifty-demo-icons.min.css" rel="stylesheet">
    <!-- Pace - Page Load Progress Par -->
    <link href="../assets/plugins/pace/pace.min.css" rel="stylesheet">
    <!-- Loader general -->
    <link href="../assets/css/loaderGeneral.css" rel="stylesheet">
    <!-- Validacion de formulario -->
    <link href="../assets/css/validar.css" rel="stylesheet">
    <!-- Carpetas -->
    <link href="../assets/css/carpetas.css" rel="stylesheet" type="text/css">
    <link href="../assets/css/carpetas1.css" rel="stylesheet" type="text/css">
    <!-- Treeview -->
    <!--<link href="../assets/css/treeview.css" rel="stylesheet">-->
    <!--<link href="../assets/plugins/jstree/themes/default/style.css" rel="stylesheet">-->
    <!-- Toastr -->
    <link href="../assets/plugins/toastr/toastr.min.css" rel="stylesheet" type="text/css">
    <!-- Chosen -->
    <link href="../assets/plugins/chosen/chosen.min.css" rel="stylesheet">
    <!-- Select Bootstrap -->
    <link href="../assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet">
    <link href="../assets/plugins/select2/css/select2.min.css" rel="stylesheet">
    <!-- Table Bootstrap -->
    <link href="../assets/plugins/bootstrap-table/bootstrap-table.min.css" rel="stylesheet">
    <!-- Editable Table -->
    <link href="../assets/plugins/x-editable/css/bootstrap-editable.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Animate -->
    <link href="../assets/plugins/animate-css/animate.min.css" rel="stylesheet">
    <!-- Time picker -->
    <link href="../assets/plugins/bootstrap-timepicker/bootstrap-timepicker.css" rel="stylesheet">
    <!-- Date picker -->
    <link href="../assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet">
    <!-- Autocomplete -->
    <link href="../js/jquery-ui.css" rel="stylesheet">
    <!-- Date range -->
    <link href="../assets/plugins/bootstrap-daterangepicker/daterangepicker1.css" rel="stylesheet">
    <!-- ScrollBar -->
    <link href="../assets/css/scrollbar.css" rel="stylesheet" type="text/css">
    <!-- Richtext -->
    <link href="../assets/plugins/rich/src/richtext.min.css" rel="stylesheet">
    <!-- Morris chart -->
    <link href="../assets/plugins/morris-js/morris.min.css" rel="stylesheet">
    <!-- Cursor 
    <link href="../assets/css/cursor.css" rel="stylesheet">-->
    <!-- Full calendar -->
    <link href="../assets/plugins/fullcalendar/fullcalendar.min.css" rel="stylesheet">
    <link href="../assets/plugins/fullcalendar/nifty-skin/fullcalendar-nifty.min.css" rel="stylesheet">
    <!-- Modo oscuro -->
    <link rel="stylesheet" href="../assets/css/dark-mode.css">
    <!-- -->
    <link rel="stylesheet" href="../assets/css/bootstrap-treeview.min.css" />
</head>
<!--TIPS-->
<body style="cursor: url(../img/company/cursor.png), pointer;" class="bg-whiteD">
    <!-- Loader general -->
    <div id="container-loader">
        <img src="../assets/images/svg-icon/loading.svg" width="50">
    </div>
    <!-- loader del login -->
    <div id="load_login"></div>
    <?php include "includes/verificaConexion.php"; ?>
    <?php
    //Verificamos que la sesion de la empresa, la sesion del usuario, la sesion del establecimiento y la clave del usuario no esten vacios
    if(!empty($_SESSION['user_empresa_status']) and !empty($_SESSION['user_login_status']) and $_SESSION['tienda'] != "" and !empty($_SESSION['usuario_clave'])) {
        $empresa = $_SESSION['datosEmpresa_id'];
        $tienda  = $_SESSION['tienda'];
        //Datos de la empresa logueada
        $sql_empresa=mysqli_query($con,"select * from datosempresa where datosEmpresa_id=$empresa");
        $rw_tienda=mysqli_fetch_array($sql_empresa);
        $datosEmpresa_logo=$rw_tienda['datosEmpresa_logo'];
        $datosEmpresa_nombre=$rw_tienda['datosEmpresa_nombre'];
        $datosEmpresa_favicon=$rw_tienda['datosEmpresa_favicon'];
        //Datos del establecimiento logueado
        $sql_sucursal=mysqli_query($con,"select * from sucursales where sucursal_tienda=$tienda");
        $rw_sucursal=mysqli_fetch_array($sql_sucursal);
        $sucursal_nombre=$rw_sucursal['sucursal_nombre'];
    ?>
    <!-- Panel principal -->
    <!-- Incluimos los modales del panel -->
    <?php include "modal/lock.php"; ?>
    <?php include "modal/logout.php"; ?>
    <?php include "modal/cambiarClave.php"; ?>
    <?php include "modal/cambiarEstablecimiento.php"; ?>
    <?php include "modal/terminosCondiciones.php"; ?>
    <?php include "modal/terminosPrivacidad.php"; ?>
    <?php include "modal/terminosGarantia.php"; ?>
    <!--<?php include "includes/cursor.php"; ?>-->
    <div id="container" class="effect aside-float aside-bright mainnav-lg footer-fixed mainnav-fixed aside-fixed">
        <!-- Incluimos la cabecera -->
        <?php include "includes/cabecera.php"; ?>
        <!-- Cuerpo -->
        <div class="boxed">
            <!-- Incluimos el loader del contenido -->
            <div class="datos_ajax_delete"></div>
            <div id="load_contenido"></div>
            <!--<div id="contenido_principal"></div>-->
            <!-- Cargamos el contenido -->
            <section></section>
            <!-- Incluimos el lateral derecho -->
            <?php include "includes/menuDerecho.php"; ?>
            <!-- Incluimos el lateral izquierdo -->
            <?php include "includes/menuIzquierdo.php"; ?>
        </div>
        <!-- Incluimos el pie de pagina -->
        <?php include "includes/pie.php" ?>
        <aside id="chats"></aside>
        <!-- Incluimos el boton para regresar arriba -->
        <button class="scroll-top btn" style="cursor: url(../img/company/cursorH1.png), pointer;">
            <i class="pci-chevron chevron-up"></i>
        </button>
    </div>
    <!-- Ventana modal de sesion expirada -->
    <form id="login_form" action="" method="post" autocomplete="off">
        <div class="modal fade" id="loginModal" role="dialog">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Sesi&oacute;n Expirada</h4>
                    </div>
                    <div class="modal-body">
                        <span id="error_message"></span>
                        <div class="form-group">
                            <input type="text" id="username" name="username" class="form-control" placeholder="Ingresa tu RUC" onKeyUp="this.value=this.value.toUpperCase();" required="">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary btn-block" id="login" style="cursor: url(../img/company/cursorH1.png), pointer;">Ingresar</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <?php } ?>
    <?php
    //Si el usuario esta logueado y su clave vacia lo redirecciona a la pantalla de bloqueo
    if(!empty($_SESSION['user_login_status']) and empty($_SESSION['usuario_clave'])) {
        $empresa1 = $_SESSION['datosEmpresa_id'];
        //Datos de la empresa
        $sql_empresa_lg=mysqli_query($con,"select * from datosempresa where datosEmpresa_id=$empresa1");
        $rw_tienda_lg=mysqli_fetch_array($sql_empresa_lg);
        $datosEmpresa_nombre=$rw_tienda_lg['datosEmpresa_nombre'];
    ?>
    <!-- Pagina bloqueo -->
    <div id="container" class="cls-container">
        <div class="cls-content">
            <div class="cls-content-sm panel">
                <div class="panel-body" style="background: #fff; border-radius: 10px; box-shadow: 2px 2px 10px #666">
                    <div class="mar-ver pad-btm">
                        <h1 class="h3"><?php echo $_SESSION['usuario_alias']; ?></h1>
                        <span><?php echo $datosEmpresa_nombre; ?></span>
                    </div>
                    <div class="pad-btm mar-btm">
                        <img alt="Profile Picture" class="img-lg img-circle img-border-light" src="../img/user/<?php echo $_SESSION['usuario_foto']; ?>">
                    </div>
                    <p>Ingresa tu contrase&ntilde;a para desbloquear</p>
                    <form id="lg1" action="" method="post" autocomplete="off">
                        <div class="form-group">
                            <div class="input-group mar-btm">
                                <input type="text" class="input hidden" id="usernameLock" name="usernameLock" onKeyUp="this.value=this.value.toUpperCase();" required="" value="<?php echo $_SESSION['usuario_alias']; ?>">
                                <input type="password" class="form-control" id="passwordLock" name="passwordLock" placeholder="Contrase&ntilde;a" onKeyUp="this.value=this.value.toUpperCase();" required autofocus>
                                <div class="input-group-addon btn btn-default" onclick="showL()"><i class="fa fa-eye nohidden1"></i><i class="fa fa-eye-slash ajaxgif1 hide"></i></div>
                            </div>
                            <span class="hidden" id="pass-val">Escribe tu contrase&ntilde;a</span>
                        </div>
                        <div class="form-group text-right">
                            <button class="btn btn-block btn-success" type="submit" id="loginLock" style="cursor: url(../img/company/cursorH1.png), pointer;">Desbloquear Sesi&oacute;n</button>
                        </div>
                    </form>
                    <div class="pad-ver">
                        <a onclick="salir();" style="cursor: url(../img/company/cursorH1.png), pointer;" class="btn-link mar-rgt text-bold" id="is">Iniciar sesi&oacute;n con una cuenta diferente</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
    <?php
    //Si el usuario esta logueado y no hay sesion del establecimiento lo redirecciona al listado de establecimientos
    if(!empty($_SESSION['user_login_status']) and $_SESSION['tienda'] == "") {
        $tienda = $_SESSION['tienda'];
        $empresa1 = $_SESSION['datosEmpresa_id'];
        //Datos de la empresa
        $sql_empresa=mysqli_query($con,"select * from datosempresa where datosEmpresa_id=$empresa1");
        $rw_tienda=mysqli_fetch_array($sql_empresa);
        $datosEmpresa_id=$rw_tienda['datosEmpresa_id'];
        //Datos del establecimiento
        $sql = "select * from sucursales where sucursal_idEmpresa=$datosEmpresa_id and sucursal_activo=1 order by sucursal_nombre asc";
        $query = mysqli_query($con,$sql);
        //Ruta a redirigir
        $url = $ruta."/view/#/ss_inicio";
        $a   = $url;
    ?>
    <!-- Pagina establecimientos -->
    <div id="container" class="cls-container">
        <div class="cls-content">
            <div class="cls-content-sm panel">
                <div class="panel-body" style="background: #fff; border-radius: 10px; box-shadow: 2px 2px 10px #666">
                    <div class="infobar-settings-sidebar-body">
                        <div class="custom-mode-setting">
                            <?php
                            //Recorremos el listado de los establecimientos
                            while ($row = mysqli_fetch_array($query)) {
                                $sucursal_id            = $row['sucursal_id'];
                                $sucursal_nombre        = $row['sucursal_nombre'];
                                $sucursal_direccion     = $row['sucursal_direccion'];
                                $sucursal_tienda        = $row['sucursal_tienda'];
                                //Redirigimos al panel con la sesion del establecimiento
                                for($i = 1 ;$i<=$sucursal_tienda;$i++){
                                    $tienda_actual = "window.open('ss_tienda.php?t=".$i."&a=".$a."','_self')";
                                }
                                //Si tenemos sesion activa se deshabilita el establecimiento actual
                                if ($sucursal_tienda == $tienda) { ?>
                                <li class="list-group-item" style="background: #FFF9CC;">
                                    <a>
                                        <div class="media">
                                            <img class="align-self-center mr-3" src="../assets/images/svg-icon/shops.svg" alt=" " style="width: 48px; height: 48px;">
                                            <div class="media-body p-t-10">
                                                <p class="mb-0 d-inline"><?php echo $sucursal_nombre;?></p>
                                                <!--<img src="../assets/images/svg-icon/checkmark.svg" class="img-fluid float-right" style="width: 20px; height: 20px;">-->
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <?php
                                //Caso contrario nos lista todos los establecimientos
                                } else { ?>
                                <li class="list-group-item">
                                    <a onclick="<?php echo $tienda_actual; ?>" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                        <div class="media">
                                            <img class="align-self-center mr-3" src="../img/company/tiendas.png" alt=" " style="width: 48px; height: 48px;">
                                            <div class="media-body p-t-10">
                                                <p class="mb-0 d-inline"><?php echo $sucursal_nombre;?></p>
                                                <!--<img src="../assets/images/svg-icon/right-arrow.svg" class="img-fluid float-right" style="width: 20px; height: 20px;">-->
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <?php } ?>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>    
    </div>
    <?php } ?>
    <?php
    //Si la sesion de la empresa no esta vacia y la sesion de la tienda es igual a "cero" lo redirecciona a la pantalla de logueo
    if(!empty($_SESSION['user_empresa_status']) and $_SESSION['tienda'] == "cero") {
        $empresa1 = $_SESSION['datosEmpresa_id'];
        //Datos de la empresa
        $sql_empresa_lg=mysqli_query($con,"select * from datosempresa where datosEmpresa_id=$empresa1");
        $rw_tienda_lg=mysqli_fetch_array($sql_empresa_lg);
        $datosEmpresa_logo=$rw_tienda_lg['datosEmpresa_logo'];
        $datosEmpresa_ruc=$rw_tienda_lg['datosEmpresa_ruc'];

        if ($datosEmpresa_logo == 'logo.png') {
            $rutaLogo = '<img alt="Profile Picture" class="" src="../img/company/logo.png" style="width: 200px;">';
        } else {
            $rutaLogo = '<img alt="Profile Picture" class="" src="../img/company/'.$datosEmpresa_ruc.'/'.$datosEmpresa_logo.'" style="width: 200px;">';
        }
    ?>
    <!-- Pagina de logueo -->
    <div id="container" class="cls-container">
        <div class="cls-content">
            <div class="cls-content-sm panel">
                <div class="tab-base">
                    
                    <!--Nav Tabs-->
                    <ul class="nav nav-tabs">
                        <li>
                            <a data-toggle="tab" href="#demo-lft-tab-1">Asistencia</a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#demo-lft-tab-2">Salida</a>
                        </li>
                        <li class="active">
                            <a data-toggle="tab" href="#demo-lft-tab-3">Acceder</a>
                        </li>
                    </ul>
        
                    <!--Tabs Content-->
                    <div class="tab-content">
                        <div id="demo-lft-tab-1" class="tab-pane fade">
                            <br>
                            <div>
                                <div class="pad-btm mar-btm">
                                    <?php echo $rutaLogo; ?>
                                </div>
                                <form id="guarda_asistencia" action="" method="post" autocomplete="off">
                                    <div class="form-group">
                                        <input type="number" class="form-control" placeholder="Documento de identidad" autofocus id="documento_colaborador" name="documento_colaborador" onKeyUp="this.value=this.value.toUpperCase();" required>
                                    </div>
                                    <button class="btn btn-primary btn-block" type="submit" id="guardar_datos" style="cursor: url(../img/company/cursorH1.png), pointer;">Registrar Asistencia</button>
                                </form>
                            </div>
                        </div>
                        <div id="demo-lft-tab-2" class="tab-pane fade">
                            <br>
                            <div>
                                <div class="pad-btm mar-btm">
                                    <?php echo $rutaLogo; ?>
                                </div>
                                <form id="guarda_salidaColaborador" action="" method="post" autocomplete="off">
                                    <div class="form-group">
                                        <input type="number" class="form-control" placeholder="Documento de identidad" autofocus id="documento_colaborador1" name="documento_colaborador1" onKeyUp="this.value=this.value.toUpperCase();" required>
                                    </div>
                                    <button class="btn btn-primary btn-block" type="submit" id="guardar_datos1" style="cursor: url(../img/company/cursorH1.png), pointer;">Registrar Salida</button>
                                </form>
                            </div>
                        </div>
                        <div id="demo-lft-tab-3" class="tab-pane fade active in">
                            <br>
                            <div>
                                <div class="pad-btm mar-btm">
                                    <?php echo $rutaLogo; ?>
                                </div>
                                <form id="lg1" action="" method="post" autocomplete="off">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Usuario" autofocus id="usernameLog" name="usernameLog" value="ADMIN" onKeyUp="this.value=this.value.toUpperCase();" required>
                                    </div>
                                    <div class="form-group">
                                        <div class="input-group mar-btm">
                                            <input type="password" class="form-control" placeholder="Contrase&ntilde;a" id="password" name="password" value="PASSWORD" onKeyUp="this.value=this.value.toUpperCase();" required>
                                            <div class="input-group-addon btn btn-default" onclick="showP()" style="cursor: url(../img/company/cursorH1.png), pointer;"><i class="fa fa-eye nohidden1"></i><i class="fa fa-eye-slash ajaxgif1 hide"></i></div>
                                        </div>
                                    </div>
                                    <button class="btn btn-primary btn-block" type="submit" id="loginLog" style="cursor: url(../img/company/cursorH1.png), pointer;">Iniciar Sesi&oacute;n</button>
                                </form>
                            </div>
                            <div class="pad-all">
                                <a data-toggle="modal" data-target="#recuperarClave" style="cursor: url(../img/company/cursorH1.png), pointer;" class="btn-link mar-rgt">Olvid&eacute; mi contrase&ntilde;a</a>
                            </div>
                        </div>
                    </div>
                </div>

                            
            </div>
        </div>
        <!-- Incluimos el modal de recuperacion de clave -->
        <form id="fgp" action="" method="post" autocomplete="off">
          <div class="modal fade" id="recuperarClave" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header" style="background: #ecf0f5;">
                    <button type="button" class="close" data-dismiss="modal" style="cursor: url(../img/company/cursorH1.png), pointer;"><i class="pci-cross pci-circle"></i></button>
                       <h4 class="modal-title">Recuperar Contrase&ntilde;a</h4>
                   </div>
                   <!--Modal body-->
                   <div class="modal-body" style="background: #ecf0f5;">
                        <div id="resultados_ajax"></div>
                      <p class="pad-btm">Ingresa tu direcci&oacute;n de correo electr&oacute;nico para recuperar su contrase&ntilde;a.</p>
                      <input type="email" id="txt_email" name="txt_email" class="form-control" autofocus placeholder="Correo electr&oacute;nico" onKeyUp="this.value=this.value.toUpperCase();" required>
                   </div>
                   <!--Modal footer-->
                   <div class="modal-footer" style="background: #ecf0f5;">
                       <button data-dismiss="modal" class="btn btn-default" type="button" style="cursor: url(../img/company/cursorH1.png), pointer;">Regresar al login</button>
                       <button type="submit" class="btn btn-primary" id="forgot" style="cursor: url(../img/company/cursorH1.png), pointer;">Enviar</button>
                   </div>
               </div>
            </div>
          </div>
        </form>
    </div>
    <?php } ?>
    <?php
    //Si no se inicio la sesion de la empresa lo redirecciona al login principal
    if (empty($_SESSION['user_empresa_status'])) {
    ?>
    <!-- Pagina de logueo RUC -->
    <div id="container" class="cls-container">
        <div class="cls-content">
            <div class="cls-content-sm panel">
                <div class="panel-body" style="background: #fff; border-radius: 10px; box-shadow: 2px 2px 10px #666">
                    <div class="pad-btm mar-btm">
                        <img alt="Profile Picture" class="img-lg img-border-light" src="../img/company/shoppingCart.svg">
                    </div>
                    <div class="mar-ver pad-btm">
                        <h1 class="h3">Bienvenido</h1>
                        <p>Ingresa tu RUC para iniciar sesi&oacute;n</p>
                    </div>
                    <form id="lg1" action="" method="post" autocomplete="off" autocomplete="off">
                        <div class="form-group">
                            <div class="input-group mar-btm">
                                <input type="text" class="form-control" id="username" name="username" onKeyUp="this.value=this.value.toUpperCase();" maxlength="11" placeholder="Ingresa tu RUC" autofocus required pattern="^[0-9]{1,5}(\.[0-9]{0,2})?$" title="Ingresa solo n&uacute;meros">
                                <span class="input-group-addon"><span class="counter">11</span></span>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-block" type="submit" id="login_ruc" style="cursor: url(../img/company/cursorH1.png), pointer;">Ingresar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
    <!--JAVASCRIPT-->
    <!--=================================================-->
    <!-- jQuery -->
    <script src="../assets/js/jquery.min.js"></script>
    <!-- BootstrapJS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- NiftyJS -->
    <script src="../assets/js/nifty.min.js"></script>
    <!-- Toastr -->
    <script src="../assets/plugins/toastr/toastr.min.js"></script>
    <!-- Vanilla -->
    <script src="../assets/plugins/vanilla/vanilla-toast.js"></script>
    <!-- Pace -->
    <script src="../assets/plugins/pace/pace.min.js"></script>
    <!-- Funciones del login RUC -->
    <script src="../js/loginEmpresa4.js"></script>
    <!-- Funciones del login -->
    <script src="../js/loginUsuario2.js"></script>
    <!-- Funcion para recuperar contraseña -->
    <script src="../js/forgotPassword2.js"></script>
    <!-- Asistencia -->
    <script src="../js/asistencia.js"></script>
    <!-- Salida -->
    <script src="../js/asistencia2.js"></script>
    <!-- Cambiar contrasena -->
    <script src="../js/cambiarClave.js"></script>
    <!-- Funcion del bloqueo -->
    <script src="../js/lockscreen.js"></script>
    <script src="../js/loginLock1.js"></script>
    <!-- Cambiar establecimiento -->
    <script src="../js/cambiaEstablecimiento.js"></script>
    <!-- funcion para scerrar sesion -->
    <script src="../js/logoutt.js"></script>
    <!-- Recuperamos el hash de la url y cargamos el contenido -->
    <script src="../js/index1.js"></script>
    <script src="../js/inicio.js"></script>
    <!-- Administrador de archivos -->
    <script src="../assets/plugins/ckfinder/js/sf.js"></script>
    <script src="../assets/plugins/ckfinder/js/tree-a.js"></script>
    <script src="../assets/plugins/ckfinder/ckfinder.js"></script>
    <!-- Editor de texto -->
    <script src="../assets/plugins/ckeditor/ckeditor1.js"></script>
    <script src="../assets/plugins/ckeditor/clasic.js"></script>
    <!-- Select Bootstrap -->
    <script src="../assets/plugins/bootstrap-select/bootstrap-select.min.js"></script>
    <script src="../assets/plugins/select2/js/select2.min.js"></script>
    <!-- Table Bootstrap -->
    <script src="../assets/plugins/bootstrap-table/bootstrap-table.min.js"></script>
    <script src="../assets/plugins/bootstrap-table/locale/bootstrap-table-es-ES.js"></script>
    <!-- Editable Table -->
    <script src="../assets/plugins/x-editable/js/bootstrap-editable.min.js"></script>
    <script src="../assets/plugins/bootstrap-table/extensions/editable/bootstrap-table-editable.js"></script>
    <!-- Time picker -->
    <script src="../assets/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
    <!-- Date picker -->
    <script src="../assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <!-- Masket -->
    <script src="../assets/plugins/masked-input/jquery.maskedinput.min.js"></script>
    <!-- Richtext -->
    <script src="../assets/plugins/rich/src/jquery.richtext.js"></script>
    <!-- Autocomplete -->
    <script src="../js/jquery-ui.js"></script>
    <!-- Alert -->
    <script src="../assets/plugins/alert/sw.js"></script>
    <!-- Date range -->
    <script src="../assets/js/moment.js"></script>
    <script src="../assets/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- Morris chart -->
    <script src="../assets/plugins/morris-js/morris.min.js"></script>
    <script src="../assets/plugins/morris-js/raphael-js/raphael.min.js"></script>
    <!-- Cargamos el loader -->
    <script src="../js/loader.js"></script>
    <!-- Cerramos sesion desde el locksreen -->
    <script src="../js/salir.js"></script>
    <!-- Treeview -->
    <!--<script src="../js/treeview.js"></script>-->
    <!--<script src="../assets/plugins/jstree/jstree.min.js"></script>-->
    <!--<script src="../assets/plugins/jstree/jstree.js"></script>-->
    <script type="text/javascript" charset="utf8" src="../js/bootstrap-treeview.min.js"></script>
    <!-- Full calendar-->
    <script src="../assets/plugins/fullcalendar/lib/jquery-ui.custom.min.js"></script>
    <script src="../assets/plugins/fullcalendar/fullcalendar.min.js"></script>
    <script src="../assets/plugins/fullcalendar/locale/es.js"></script>
    <!-- funcion para enviar documentos a sunar -->
    
    <?php
    //Si no hay sesion de empresa se ejecutara la siguiente funcion
    if (empty($_SESSION['user_empresa_status'])) {
    ?>
    <!-- Contador de caracteres RUC Login -->
    <script src="../js/contador.js"></script>
    <?php } ?>
    <!-- Mostrar y ocultar clave -->
    <script src="../js/mostrarclave.js"></script>
    <!-- Validamos la sesion activa -->
    <?php
    //Si el usuario esta logueado se ejecutara la siguiente funcion
    if(!empty($_SESSION['user_empresa_status']) and !empty($_SESSION['user_login_status']) and $_SESSION['tienda'] != "" and !empty($_SESSION['usuario_clave'])) {
    ?>
    <script src="../js/validarSesion.js"></script>
    <!-- Notificaciones -->
    <script src="../js/notificaciones.js"></script>
    <!-- Usuarios chat -->
    <!--<script src="../js/usuariosChat.js"></script>-->
    <!--<script src="../js/chat.js"></script>-->
    <?php } ?>
    <?php if (!empty($_SESSION['user_empresa_status']) and empty($_SESSION['user_login_status']) and empty($_SESSION['usuario_clave'])) { ?>
    <script src="../js/validarSesion1.js"></script> 
    <?php } ?>
    <!-- Cargamos el contenido -->
    <script src="../js/cargaContenido.js"></script>
    <!-- Cursor 
    <script src="../js/cursor.js"></script>-->
    <!-- Conexion -->
    <script src="../js/conexion.js"></script>
    <!-- Pos -->
    <script src="../js/complementoPos.js"></script>
    <!-- Sparkline -->
    <script src="../assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <!-- Modo oscuro -->
    <script src="../js/dark-mode-switch.js"></script>
</body>
</html>