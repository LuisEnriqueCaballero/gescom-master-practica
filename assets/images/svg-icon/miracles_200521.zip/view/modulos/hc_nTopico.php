<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
session_start();
require_once "../../config/db.php";
require_once "../../config/conexion.php";
$tienda                 = $_SESSION['tienda'];
$cadena                 = $_GET['nTopico'];
$pedido                 = substr($cadena, 0, -4);

$sql_credito=mysqli_query($con,"select * from admision, clientes, especialidades, usuarios, productos where admision.admision_deriva=productos.producto_id and admision.admision_idUsuario=usuarios.usuario_id and admision.admision_idCliente=clientes.cliente_id and admision.admision_idEspecialidad=especialidades.especialidad_id and admision.admision_id=$pedido order by admision.admision_id desc");
$row=mysqli_fetch_array($sql_credito);
//Especialidad
$especialidad_id        = $row['especialidad_id'];
$especialidad_nombre    = $row['especialidad_nombre'];
//Cliente
$cliente_nombre         = $row['cliente_nombre'];
$cliente_documento      = $row['cliente_documento'];
//
$admision_edad          = $row['admision_edad'];
$admision_idCliente     = $row['admision_idCliente'];
$admision_id            = $row['admision_id'];
//
$producto_nombre        = $row['producto_nombre'];

$fecha_nacimiento = $admision_edad;
$dia_actual = date("Y-m-d");
$edad_diff = date_diff(date_create($fecha_nacimiento), date_create($dia_actual));

$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);
?>
<?php if($a[234]==1){ ?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Registrar T&oacute;pico</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load(1);" style="cursor: pointer;">Cl&iacute;nica</a></li>
        <li class="active">Registrar T&oacute;pico</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <form method="post" id="guardar_topico" name="guardar_topico" autocomplete="off" class="form-horizontal" autocomplete="off">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="paciente">Paciente *</label>
                            <input readonly type="text" class="form-control" id="paciente" name="paciente" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" autofocus required value="<?php echo $cliente_nombre; ?>">
                            <input type="hidden" id="topico_idCliente" name="topico_idCliente" value="<?php echo $admision_idCliente; ?>">
                            <input type="hidden" id="admision_id" name="admision_id" value="<?php echo $admision_id; ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="documento">Documento *</label>
                            <input type="text" class="form-control" id="documento" name="documento" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Descripci&oacute;n" value="<?php echo $cliente_documento; ?>" required readonly>
                        </div>
                        <div class="col-md-3">
                            <label for="edad">Edad *</label>
                            <input type="text" class="form-control" id="edad" name="edad" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Descripci&oacute;n" value="<?php echo $edad_diff->format('%y')." a&ntilde;os de edad"; ?>" required readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label for="especialidad">Especialidad *</label>
                            <input type="text" class="form-control" id="especialidad" name="especialidad" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" autofocus required value="<?php echo $especialidad_nombre; ?>" readonly>
                        </div>
                        <div class="col-md-6">
                            <label for="servicio">Producto / Servicio *</label>
                            <input type="text" class="form-control" id="servicio" name="servicio" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" autofocus required value="<?php echo $producto_nombre; ?>" readonly>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-4">
                            <label for="presion">Presi&oacute;n *</label>
                            <input type="text" class="form-control" id="presion" name="presion" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Presi&oacute;n" autofocus required>
                        </div>
                        <div class="col-md-4">
                            <label for="temperatura">Temperatura *</label>
                            <input type="text" class="form-control" id="temperatura" name="temperatura" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Temperatura" required>
                        </div>
                        <div class="col-md-4">
                            <label for="saturacion">Saturaci&oacute;n *</label>
                            <input type="text" class="form-control" id="saturacion" name="saturacion" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Saturaci&oacute;n" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-3">
                            <label for="peso">Peso (kg) *</label>
                            <input type="text" class="form-control" id="peso" name="peso" onKeyUp="this.value=this.value.toUpperCase();Suma();" placeholder="Peso" autofocus required>
                        </div>
                        <div class="col-md-3">
                            <label for="talla">Talla (m) *</label>
                            <input type="text" class="form-control" id="talla" name="talla" onKeyUp="this.value=this.value.toUpperCase();Suma();" placeholder="Talla" required>
                        </div>
                        <div class="col-md-3">
                            <label for="imc">IMC *</label>
                            <input type="text" class="form-control" id="imc" name="imc" onKeyUp="this.value=this.value.toUpperCase();" placeholder="IMC" required>
                        </div>
                        <div class="col-md-3">
                            <label for="estado">Estado *</label>
                            <input type="text" class="form-control" id="estado" name="estado" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Estado" required readonly>
                        </div>
                    </div>
                    <br>
                    <div class="modal-footer">
                       <a class="btn btn-danger" href="#/hc_topico">Regresar</a>
                       <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<?php } else { 
    include "../includes/sinAcceso.php";
} ?>
<script src="../js/clinica/topico1.js"></script>
<script>
//Función que realiza la suma
function Suma() {
   var peso = document.guardar_topico.peso.value;
   var talla = document.guardar_topico.talla.value;
   try{
      //Calculamos el número escrito:
       peso = (isNaN(parseInt(peso)))? 0 : parseInt(peso);
       talla = (isNaN(parseInt(talla)))? 0 : talla;
       var elevado = Math.pow(talla, 2);
       var resultado_imc = (peso/elevado).toFixed(2);
       document.guardar_topico.imc.value = resultado_imc;
       //
       if (resultado_imc < 18) {
        document.guardar_topico.estado.value = 'Delgadez';
       };
       if (resultado_imc > 18 && resultado_imc <= 24.9) {
        document.guardar_topico.estado.value = 'Peso adecuado';
       };
       if (resultado_imc >= 25 && resultado_imc <= 29.9) {
        document.guardar_topico.estado.value = 'Sobrepeso';
       };
       if (resultado_imc > 30) {
        document.guardar_topico.estado.value = 'Obesidad';
       };
       
   }
   //Si se produce un error no hacemos nada
   catch(e) {}
}
</script>