<!-- Start Breadcrumbbar -->
<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
/* Connect To Database*/
session_start();
include "../modal/buscarProductosCompra.php";
include "../modal/registroItem.php";
include "../modal/registroProveedor.php";
include "../modal/youtube/videoCompra.php";

$fecha_cambio = date('Y-m-d');

//$cambio = $_POST['cambio'];

$data = file_get_contents("https://api.apis.net.pe/v1/tipo-cambio-sunat?fecha=".$fecha_cambio);
$info = json_decode($data, true);

if($data==='[]'){
    $datos = array(0 => $info['venta'] == '  ');
    //echo 'nada';
    //echo json_encode($datos);
}else{

$datos = array(
    0 => $info['venta']
);

$valor1 = json_encode($datos);

$valor1 = str_replace("[","",$valor1); 
$valor1 = str_replace("]","",$valor1); 

//echo $valor;
$valor  = number_format($valor1,3);

}

$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);

?>
<?php if($a[75]==1){ ?>
<!-- End Breadcrumbbar -->
<!-- Start Contentbar -->

<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Nueva Compra</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load(1);" style="cursor: pointer;">Egresos</a></li>
        <li class="active">Nueva Compra</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <form role="form" id="datos_factura">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="compras_tipo">Tipo Comprobante *:</label>
                                <select class="form-control" id="compras_tipo" name="compras_tipo">
                                    <option value="1">Factura Electr&oacute;nica</option>
                                    <option value="2">Boleta Electr&oacute;nica</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="almacen_id">Almac&eacute;n *:</label>
                                <select class="form-control" id="almacen_id" name="almacen_id" onchange="load(1);PasarValorC();validaAlmacen();" required>
                                    <option value="">-- Selecciona Almac&eacute;n --</option>
                                    <?php
                                       $sql_segmento ="select * from almacenes where almacen_idSucursal='$tienda' order by almacen_id asc";
                                       $row          =mysqli_query($con,$sql_segmento);
                                       while ($row4 = mysqli_fetch_array($row)) {
                                          $almacen_nombre = $row4["almacen_nombre"];
                                          $almacen_id     = $row4["almacen_id"];
                                    ?>
                                    <option value="<?php echo $almacen_id;?>"><?php  echo $almacen_nombre;?></option>

                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="compras_folio">Serie *:</label>
                                <input type="text" class="form-control" autocomplete="off" id="compras_folio" name="compras_folio" onKeyUp="this.value=this.value.toUpperCase();" required>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="compras_correlativo" class="control-label">N&uacute;mero *:</label>
                                <input type="number" class="form-control" autocomplete="off" id="compras_correlativo" name="compras_correlativo" onKeyUp="this.value=this.value.toUpperCase();" required>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="compras_fecha">Fecha Emisi&oacute;n *:</label>
                                <input type="date" class="form-control" id="compras_fecha" name="compras_fecha"required>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="compras_vencimiento">Fecha Vencimiento *:</label>
                                <input type="date" class="form-control" id="compras_vencimiento" name="compras_vencimiento"required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <label for="cliente_nombre1">Proveedor *:</label>
                            <div class="input-group">
                                <div class="form-group">
                                    <input type="text" id="cliente_nombre1" class="form-control" placeholder="Buscar por documento o nombre" required  tabindex="2" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" required>
                                    <input id="id_cliente" name="id_cliente" type='hidden'>
                                </div>
                                <?php if($a[15]==1){ ?>
                                <div class="input-group-addon btn btn-primary" style="padding: 2px 8px;" data-toggle="modal" data-target="#nuevoProveedor">
                                    <i class="fa fa-plus"></i>
                                </div>
                                <?php } else { ?>
                                <div class="input-group-addon btn btn-primary disabled" style="padding: 2px 8px;">
                                    <i class="fa fa-plus"></i>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="compras_moneda">Moneda *:</label>
                                <select class="form-control" id="compras_moneda" name="compras_moneda" required onchange="tcCompra(this);">
                                    <option value="115">Soles</option>
                                    <option value="151">D&oacute;lares Americanos</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="compras_tipoCambio">T.Cambio *:</label>
                                <input type="text" class="form-control" autocomplete="off" id="compras_tipoCambio" name="compras_tipoCambio" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $valor; ?>" required>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="compras_condiciones">Pago *:</label>
                                <!--<select class="form-control input-sm condiciones" id="condiciones" name="condiciones" onchange="showDiv(this)" required >
                                    <option value="">-- Selecciona --</option>
                                    <option value="1">Contado</option>
                                    <option value="2">Cheque</option>
                                    <option value="3">Transferencia bancaria</option>
                                    <option value="4">Cr&eacute;dito</option>
                                </select>-->
                                <div class="button-list">
                                    <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                        <label class="btn btn-primary active" onclick="cambiaContado1();" data-toggle="modal" data-target="#contadoFactura">
                                            <input type="radio" name="options" checked> CONTADO
                                        </label>
                                        <label class="btn btn-primary" onclick="cambiaCredito1();" data-toggle="modal" data-target="#contadoFactura">
                                            <input type="radio" name="options"> CR&Eacute;DITO
                                        </label>
                                    </div>
                                    <div id="medioPago"><input type="hidden" class="form-control" autocomplete="off" id="condiciones" name="condiciones" value="1" readonly=""></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <div id="resultados3"></div>
                                <?php include "../modal/abonoCompra.php"; ?>
                                <?php include "../modal/cargoCompra.php"; ?>
                                <?php include "../modal/contadoFactura.php"; ?>
                                <div id="factura_contado"><input type="hidden" name="factura_contado" value="101"></div>
                                <div id="factura_cargo"><input type="hidden" name="factura_cargo" value="6011"></div>
                                <div id="factura_abono"><input type="hidden" name="factura_abono" value="4212"></div>
                                <div id="factura_denominacion"><input type="hidden" name="factura_denominacion" value="CAJA"></div>
                                <div id="factura_denominacion1"><input type="hidden" name="factura_denominacion1" value="EMITIDAS"></div>
                                <div id="factura_denominacion2"><input type="hidden" name="factura_denominacion2" value="MERCADERIAS MANUFACTURADAS"></div>
                            </div>
                        </div>
                    </div>
                    <?php include "../modal/registroObservacionesBoleta.php"; ?>

                    <!--<button type="submit" id="guardar_factura" class="btn btn-danger" aria-haspopup="true" aria-expanded="false" style="position: fixed;z-index: 999;right:0px;height:50px;border:2px solid #000;top: 50%;">
                        Procesar Venta
                    </button>-->

                    <div style="position: fixed;z-index: 999;right:0px;top: 34%; box-shadow: 2px 2px 10px #666; border-top-left-radius: 10px; border-bottom-left-radius: 10px;">
                        <button type="submit" id="guardar_factura" class="btn btn-mint" aria-haspopup="true" aria-expanded="false" style="border-bottom-left-radius: 0px; border-bottom-right-radius: 0px; border-top-right-radius: 0px; border-top-left-radius: 10px;">
                            Procesar Compra
                        </button>
                        <br>
                        <div class="btn btn-primary" data-toggle="modal" data-target="#observaciones" style="width: 100%; border-top-left-radius: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px; border-bottom-left-radius: 0px; cursor: pointer;">
                            Observaciones
                        </div>
                        <br>
                        <div class="btn btn-dark" data-toggle="modal" data-target="#buscar" style="width: 100%; border-top-left-radius: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px; border-bottom-left-radius: 10px; cursor: pointer;">
                            Buscar &iacute;tem
                        </div>
                    </div>
                </form>
                <hr>
                <div class="row">
                    <div class="col-md-12">
                        <div id="resultados_ajaxf" class='col-md-12' style="margin-top:10px"></div><!-- Carga los datos ajax -->
                        <form role="form" id="barcode_form">
                            <div class="form-group row">
                                <!--<label for="barcode_qty" class="col-md-1 control-label">Cant:</label>-->
                                <div class="col-md-1">
                                    <input type="text" class="form-control" id="barcode_qty" value="1" readonly autocomplete="off"style="border: 1px solid #232323; border-radius: 4px; height: 35px;">
                                </div>
                                <input type="hidden" name="id_almacen" id="id_almacen">

                                <!--<label for="barcode" class="col-md-1  control-label">C&oacute;digo:</label>-->
                                <div class="col-md-3" align="left">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="barcode" autocomplete="off" readonly tabindex="1" autofocus="true" style="border: 1px solid #232323; border-top-left-radius: 4px; border-bottom-left-radius: 4px; border-right: 1px solid #fff; height: 35px;">
                                        <span class="input-group-btn" style="border: 1px solid #232323; border-left: 1px solid #fff; border-top-right-radius: 0px; border-bottom-right-radius: 0px;">
                                            <button type="submit" class="btn btn-primary"><span class="fa fa-barcode"></span></button>
                                        </span>
                                        <?php if($a[35]==1){ ?> 
                                        <span class="input-group-btn" data-toggle="modal" data-target="#nuevoItem" style="border: 1px solid #232323; border-top-right-radius: 4px; border-bottom-right-radius: 4px; ">
                                            <button type="submit" class="btn btn-primary"><span class="fa fa-plus"></span></button>
                                        </span>
                                        <?php } else { ?>
                                        <span class="input-group-btn disabled" style="border: 1px solid #232323; border-top-right-radius: 4px; border-bottom-right-radius: 4px; ">
                                            <button type="submit" class="btn btn-primary"><span class="fa fa-plus"></span></button>
                                        </span>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <div type="button" accesskey="a" class="btn btn-primary" data-toggle="modal" data-target="#cargoFactura" style="border-top-right-radius: 0px; border-bottom-right-radius: 0px; border-right: 0.5px dashed #666;">
                                            <img src="../assets/images/svg-icon/search1.svg" class="img-fluid" alt="search" style="width: 20px;"> Cargo
                                        </div>
                                        <div type="button" accesskey="a" class="btn btn-primary" data-toggle="modal" data-target="#abonoFactura" style="border-top-left-radius: 0px; border-bottom-left-radius: 0px;">
                                            <img src="../assets/images/svg-icon/search1.svg" class="img-fluid" alt="search" style="width: 20px;"> Abono
                                        </div>
                                    </div>
                                    <div style="margin-left: 200px; margin-top: -42px;">
                                        <div id="cargaDatosC"><label id="nombreCargo"><b>Cargo:</b> 6011 MERCADERIAS MANUFACTURADAS</label><br></div>
                                        <div id="cargaDatosA"><label id="nombreAbono"><b>Abono:</b> 4212 EMITIDAS</label></div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <br><br>
                    <div id="resultados" class='col-md-12'></div>
                </div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>

<!--<form method="post" id="guardar_proveedor" name="guardar_proveedor" autocomplete="off" class="form-horizontal">
   <div class="modal fade" id="nuevoProveedor" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title" id="exampleModalCenterTitle">Nuevo Proveedor</h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <div class="modal-body">
              <div id="resultados_ajax2"></div>
               <div class="form-row">
                  <div class="form-group col-md-6">
                     <label for="cliente_tipo">Tipo de documento *</label>
                     <select required id="cliente_tipo" name="cliente_tipo" class="form-control" onchange="getval(this);">
                        <option value="">SELECCIONAR</option>
                        <?php           
                           $tipo_cliente ="select * from sunat_tipocliente";
                           $row          =mysqli_query($con,$tipo_cliente);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $sunat_tipoCliente_nombre = $row4["sunat_tipoCliente_nombre"];
                              $sunat_tipoCliente_id     = $row4["sunat_tipoCliente_id"];
                        ?>
                        <option value="<?php echo $sunat_tipoCliente_id;?>"><?php  echo $sunat_tipoCliente_nombre;?></option>
                        <?php } ?>
                     </select>
                  </div>
                  <div class="form-group col-md-6">
                     <label for="documento_colaborador">Documento</label>
                     <div class="input-group">
                         <input type="number" class="form-control input-sm" name="documento_colaborador" id="documento_colaborador" onKeyUp="this.value=this.value.toUpperCase();" autocomplete="off" placeholder="Documento" required>
                         <div id="tipo_boton"></div>
                     </div>
                  </div>
               </div>
               <div class="form-row">
                   <div class="form-group col-md-6">
                       <label for="cliente_nombre">Nombres *</label>
                       <input type="text" class="form-control input-sm" id="cliente_nombre" name="cliente_nombre" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Apellidos y nombres" required>
                   </div>
                   <div class="form-group col-md-2">
                       <label for="cliente_departamento">Departamento</label>
                       <input type="text" class="form-control input-sm" id="cliente_departamento" name="cliente_departamento" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Departamento">
                   </div>
                   <div class="form-group col-md-2">
                       <label for="cliente_provincia">Provincia</label>
                       <input type="text" class="form-control input-sm" id="cliente_provincia" name="cliente_provincia" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Provincia">
                   </div>
                   <div class="form-group col-md-2">
                       <label for="cliente_distrito">Distrito</label>
                       <input type="text" class="form-control input-sm" id="cliente_distrito" name="cliente_distrito" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Distrito">
                   </div>
               </div>
               <div class="form-row">
                   <div class="form-group col-md-6">
                       <label for="cliente_direccion">Domicilio *</label>
                       <input type="text" class="form-control input-sm" id="cliente_direccion" name="cliente_direccion" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Domicilio" required>
                   </div>
                   <div class="form-group col-md-6">
                       <label for="cliente_pais">Pa&iacute;s</label>
                       <input type="text" class="form-control input-sm" id="cliente_pais" name="cliente_pais" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Pa&iacute;s">
                   </div>
               </div>
               <div class="form-row">
                   
               </div>
               <div class="form-row">
                   <div class="form-group col-md-6">
                       <label for="cliente_telefono">Tel&eacute;fono *</label>
                       <input type="text" class="form-control input-sm" id="cliente_telefono" name="cliente_telefono" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Tel&eacute;fono" required>
                   </div>
                   <div class="form-group col-md-6">
                       <label for="cliente_email">E-Mail</label>
                       <input type="email" class="form-control input-sm" id="cliente_email" name="cliente_email" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="E-Mail">
                   </div>
               </div>
               <div class="form-row">
                   <div class="form-group col-md-6">
                       <label for="cliente_contacto">Contacto</label>
                       <input type="text" class="form-control input-sm" id="cliente_contacto" name="cliente_contacto" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Contacto">
                   </div>
                   <div class="form-group col-md-6">
                       <label for="cliente_cargo">Cargo</label>
                       <input type="text" class="form-control input-sm" id="cliente_cargo" name="cliente_cargo" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Cargo">
                   </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>-->

<?php } else { 
    include "../includes/sinAcceso.php";
} ?>

<!--<script>
   function getval(sel)
  {
   if(sel.value==''){
      toastr.error("Seleccionar un tipo de documento","Oopss!");
      $("#tipo_boton").html('');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','Documento');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", false);
      $('#cliente_pais').val('');
   }
   if(sel.value==1){
      //toastr.error("Seleccionar un tipo de documento","Oopss!");
      $("#tipo_boton").html('');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','Documento');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", false);
      $('#cliente_pais').val('');
      $('#documento_colaborador').focus();
   }
   if(sel.value==2){
      //toastr.error("Seleccionar un tipo de documento","Oopss!");
      $("#tipo_boton").html('<div id="botoncitoDNI" class="input-group-addon btn btn-primary"><i class="nohidden1"></i></div>');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','DNI');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", true);
      $('#cliente_pais').val('PERU');
      $('#documento_colaborador').focus();

      $(function(){
         $('.nohidden1').html('<i class="la la-search" style="color: #ffff;"></i>');
         $('.nohidden1').attr("disabled", true);
         $('#botoncitoDNI').on('click', function(){
           var documento_colaborador = $('#documento_colaborador').val();
           var url = '../ajax/consultas/reniecColaborador.php';
           $('.nohidden1').html('<img src="../img/company/load1.svg" width="20px">');
           $.ajax({
             type:'POST',
             url:url,
             data:'documento_colaborador='+documento_colaborador,
             success: function(datos_dni){
               $('.nohidden1').html('<i class="la la-search" style="color: #ffff;"></i');
               $('.nohidden1').attr("disabled", false);
               $('#cliente_telefono').focus();
               var datos = eval(datos_dni);
               var nada ='nada';
               if(datos_dni != nada)
                {
                  $('#numero_dni').text(datos[0]);
                  $('#cliente_nombre').val(datos[1]);
                  $('#estado_del_contribuyente').val(datos[2]);
                  $('#condicion_de_domicilio').val(datos[3]);
                  $('#ubgclienteruc').val(datos[4]);
                  $('#tipo_de_via').val(datos[5]);
                  $('#nombre_de_via').val(datos[6]);
                  $('#codigo_de_zona').val(datos[7]);
                  $('#numero').val(datos[8]);
                  $('#interior').val(datos[9]);
                  $('#lote').val(datos[10]);
                  $('#dpto').val(datos[11]);
                  $('#manzana').val(datos[12]);
                  $('#kilometro').val(datos[13]);
                  $('#cliente_departamento').val('-');
                  $('#cliente_provincia').val('-');
                  $('#cliente_distrito').val('-');
                  $('#cliente_direccion').val('-');
                  $('#direcclienteruc').val(datos[18]);
                  $('#ultima_actualizacion').val(datos[19]);
                  $('#informacion_resultado').val(datos[20]);
                  $('#apellido_paterno').val(datos[21]);
                  $('#apellido_materno').val(datos[22]);
                  $('#nombres').val(datos[23]);
                  $('#nombres_completos').val(datos[24]);
                //}
               //if(datos[0]==nada){
                 //alert('DNI no válido o no registrado');
               } if(datos[24] == '  ') {
                 //alert('DNI no válido o no registrado');
                 toastr.warning("No pudimos encontrar el documento...","Aviso!");
                 $("#documento_colaborador").val('');
                 $("#cliente_nombre").val('');
                 $("#cliente_departamento").val('');
                 $("#cliente_provincia").val('');
                 $("#cliente_distrito").val('');
                 $("#cliente_direccion").val('');
                 $('#documento_colaborador').focus();
               }   
            }
           });
         return false;
         });
      });
   }
   if(sel.value==3){
      //toastr.error("Seleccionar un tipo de documento","Aviso!");
      $("#tipo_boton").html('');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','Carnet de extranjeria');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", false);
      $('#cliente_pais').val('');
      $('#documento_colaborador').focus();
   }
   if(sel.value==4){
      //toastr.error("Seleccionar un tipo de documento","Aviso!");
      $("#tipo_boton").html('<div id="botoncitoRUC" class="input-group-addon btn btn-primary"><i class="nohidden1"></i></div>');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','RUC');
      $('#cliente_nombre').attr('placeholder','Razon Social');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", true);
      $('#cliente_pais').val('PERU');
      $('#documento_colaborador').focus();

      $(function(){
         $('.nohidden1').html('<i class="la la-search" style="color: #ffff;"></i>');
         $('#botoncitoRUC').on('click', function(){
           var documento_colaborador = $('#documento_colaborador').val();
           var url = '../ajax/consultas/sunatColaborador.php';
           $('.nohidden1').html('<img src="../img/company/load1.svg" width="20px">');
           $.ajax({
             type:'POST',
             url:url,
             data:'documento_colaborador='+documento_colaborador,
             success: function(datos_ruc){
               $('.nohidden1').html('<i class="la la-search" style="color: #ffff;"></i');
               $('.nohidden1').attr("disabled", false);
               //$('#cliente_telefono').focus();
               var datos = eval(datos_ruc);
               var nada ='nada';
               if(datos_ruc != nada){
                 $('#numero_ruc').text(datos[0]);
                 $('#cliente_nombre').val(datos[1]);
                 $('#estado_del_contribuyente').val(datos[2]);
                 $('#condicion_de_domicilio').val(datos[3]);
                 $('#ubgclienteruc').val(datos[4]);
                 $('#tipo_de_via').val(datos[5]);
                 $('#nombre_de_via').val(datos[6]);
                 $('#codigo_de_zona').val(datos[7]);
                 $('#numero').val(datos[8]);
                 $('#interior').val(datos[9]);
                 $('#lote').val(datos[10]);
                 $('#dpto').val(datos[11]);
                 $('#manzana').val(datos[12]);
                 $('#kilometro').val(datos[13]);
                 if (datos[14] == '') {
                    $('#cliente_departamento').focus();
                 }
                 if (datos[14] != '') {
                    $('#cliente_telefono').focus();
                 }
                 $('#cliente_departamento').val(datos[14]);
                 $('#cliente_provincia').val(datos[15]);
                 $('#cliente_distrito').val(datos[16]);
                 $('#cliente_direccion').val(datos[17]);
                 $('#direcclienteruc').val(datos[18]);
                 $('#ultima_actualizacion').val(datos[19]);
               } if(datos[0] == ''){
                 //alert('RUC no válido o no registrado');
                 toastr.warning("No pudimos encontrar el documento...","Aviso!");
                 $("#documento_colaborador").val('');
                 $('#documento_colaborador').focus();
               }   
             }
           });
           return false;
         });
       });
   }
   if(sel.value==5){
      //toastr.error("Seleccionar un tipo de documento","Aviso!");
      $("#tipo_boton").html('');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','Pasaporte');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", false);
      $('#cliente_pais').val('');
      $('#documento_colaborador').focus();
   }
   if(sel.value==6){
      //toastr.error("Seleccionar un tipo de documento","Oopss!");
      $("#tipo_boton").html('');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','Cedula');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", false);
      $('#cliente_pais').val('');
      $('#documento_colaborador').focus();
   }
  }

  
</script>-->
<script>
    //Registra
    $("#guardar_proveedor" ).submit(function( event ) {
      $('#guardar_datos').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
      $('#guardar_datos').attr("disabled", true);
      var parametros = $(this).serialize();
      $.ajax({
        type: "POST",
        url: "../ajax/nuevoProveedor.php",
        data: parametros,
        beforeSend: function(objeto){ },
        success: function(datos){
          $("#resultados_ajax").html(datos);
          $('#guardar_datos').html('Aceptar');
          $('#guardar_datos').attr("disabled", false);
          load(1);
          $("#guardar_proveedor")[0].reset();
          $("#cliente_tipo").focus();
        }
      });
      event.preventDefault();
    })
    //Registra
    $("#guardar_item" ).submit(function( event ) {
      $('#guardar_datos').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
      $('#guardar_datos').attr("disabled", true);
      var parametros = $(this).serialize();
      $.ajax({
        type: "POST",
        url: "../ajax/nuevoItem.php",
        data: parametros,
        beforeSend: function(objeto){ },
        success: function(datos){
          $("#resultados_ajax").html(datos);
          $('#guardar_datos').html('Aceptar');
          $('#guardar_datos').attr("disabled", false);
          $("#cod_resultado").load("../ajax/incrementaCodProducto.php");
          load(1);
          $("#guardar_item")[0].reset();
          $("#producto_codigoBarras").focus();
        }
      });
      event.preventDefault();
    })
</script>
<script src="../js/nuevaCompra2.js"></script>
<script src="../js/ventanaCentrada.js"></script>
<script>
$(function () {
    $('.textarea').richText();
})
</script>
<script>
$("#tableCargo tbody tr").click(function() {
  var total = $(this).find("td:first-child").text();
  var codigo = $(this).find("td:first-child").next().text();
  var nombre = $(this).find("td:last-child").text();
  $("#factura_cargo").html('<input type="hidden" name="factura_cargo" value="'+codigo+'">');
  $("#factura_denominacion2").html('<input type="hidden" name="factura_denominacion2" value="'+nombre+'">');
  $("#nombreCargo").html('<div id="cargaDatosC"><label id="nombreCargo"><b>Cargo:</b> '+codigo+" "+nombre+'</label></div>');
});
</script>
<script>
$("#tableAbono tbody tr").click(function() {
  var total = $(this).find("td:first-child").text();
  var codigo = $(this).find("td:first-child").next().text();
  var nombre = $(this).find("td:last-child").text();
  $("#factura_abono").html('<input type="hidden" name="factura_abono" value="'+codigo+'">');
  $("#factura_denominacion1").html('<input type="hidden" name="factura_denominacion1" value="'+nombre+'">');
  $("#nombreAbono").html('<div id="cargaDatosA"><label id="nombreCargo"><b>Abono:</b> '+codigo+" "+nombre+'</label></div>');
});
</script>
<script>
$("#tableContado tbody tr").click(function() {
  var codigo = $(this).find("td:first-child").next().text();
  var nombre = $(this).find("td:last-child").text();
  $("#factura_contado").html('<input type="hidden" name="factura_contado" value="'+codigo+'">');
  $("#factura_denominacion").html('<input type="hidden" name="factura_denominacion" value="'+nombre+'">');
});
</script>
<script>
//
$("#datos_factura").submit(function(event) {
    $('#guardar_factura').attr("disabled", true);
    $('#guardar_factura').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
    var id_cliente = $("#id_cliente").val();
    //var resibido = $("#resibido").val();
    /*if (isNaN(resibido)) {
        //$.Notification.notify('error','bottom center','NOTIFICACIÓN', 'EL DATO NO ES VALIDO, INTENTAR DE NUEVO')
        $("#resibido").focus();
        return false;
    }*/
    if (id_cliente == "") {
        //$.Notification.notify('warning','bottom center','NOTIFICACIÓN', 'DEBE SELECCIONAR UN CLIENTE VALIDO')
        toastr['warning']('Seleccionar un provvedor v&aacute;lido', 'Aviso!');
        $("#cliente_nombre1").focus();
        $('#guardar_factura').html('Procesar Compra');
        $('#guardar_factura').attr("disabled", false);
        return false;
    }
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/nuevoCompra.php",
        data: parametros,
        beforeSend: function(objeto) {
            //$("#resultados_ajaxf").html('<img src="../../img/ajax-loader.gif"> Cargando...');
        },
        success: function(datos) {
            $("#resultados_ajaxf").html(datos);
            $('#guardar_factura').html('Procesar Compra');
            $('#guardar_factura').attr("disabled", false);
            $("#datos_factura")[0].reset(); //Recet al formilario de el cliente
            $("#barcode_form")[0].reset(); // Recet al formulario de la fatura
            $("#resultados").load("../ajax/agregarTmpCompras.php"); // carga los datos nuevamente

            $("#cliente_nombre1").val("");
            $("#id_cliente").val("");

            $("#cliente_nombre1").focus();

            load(1);
            //$("#cambiaCorrelativo").load();
            //$("#tituloSerie").load();
        }
    });
    event.preventDefault();
})
</script>
<script>
function upload_image_mod(id_producto){
  $("#load_img_mod").text('Cargando...');
  var inputFileImage = document.getElementById("imagefile_mod");
  var file = inputFileImage.files[0];
  var data = new FormData();
  data.append('imagefile_mod',file);
  data.append('id_producto',id_producto);



  $.ajax({
      url: "../ajax/cargaAdjuntoCompra.php",        // Url to which the request is send
      type: "POST",             // Type of request to be send, called as method
      data: data,         // Data sent to server, a set of key/value pairs (i.e. form fields and values)
      contentType: false,       // The content type used when sending data to the server.
      cache: false,             // To unable request pages to be cached
      processData:false,        // To send DOMDocument or non processed data file it is set to false
      success: function(data)   // A function to be called if request succeeds
      {
        $("#load_img_mod").html(data);
        $('#imagefile_mod').addClass("ocultar_boton");
        //load(1);
      }
    });
  event.preventDefault();
}
</script>
<script>
function tcCompra(sel)
{
    if(sel.value==115){
        load(1);
    }
    if(sel.value==151){
        load(1);
    }
}
</script>
<script>
  function cambiaCredito1() {
    $("#resultados3").load("../ajax/cargaPrima1.php");
    $('#medioPago').html('<div id="medioPago"><input type="hidden" class="form-control" autocomplete="off" id="condiciones" name="condiciones" value="4" readonly=""></div>');
    $("#factura_contado").html('<input type="hidden" name="factura_contado" value="101">');
    $("#factura_denominacion").html('<input type="hidden" name="factura_denominacion" value="CAJA">');
  }
  function cambiaContado1() {
    $("#resultados3").load("../ajax/cargaRecibido1.php");
    $('#medioPago').html('<div id="medioPago"><input type="hidden" class="form-control" autocomplete="off" id="condiciones" name="condiciones" value="1" readonly=""></div>');
    $("#factura_contado").html('<input type="hidden" name="factura_contado" value="101">');
    $("#factura_denominacion").html('<input type="hidden" name="factura_denominacion" value="CAJA">');
    //$('#contadoFactura').modal('show');
  }
</script>