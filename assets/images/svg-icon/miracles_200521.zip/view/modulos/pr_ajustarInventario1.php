<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
session_start();
require_once "../../config/db.php";
require_once "../../config/conexion.php";
//Incluimos las ventanas modales
include "../modal/agregarStock.php";
include "../modal/eliminarStock.php";

$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);

$cadena = $_GET['almacen'];
$id_almacen = substr($cadena, 0, -4);

$_SESSION['almacen'] = $id_almacen;

$sql_almacen=mysqli_query($con,"select * from almacenes where almacen_id=$id_almacen");
$rw_almacen=mysqli_fetch_array($sql_almacen);
$almacen_nombre=$rw_almacen['almacen_nombre'];
?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Ajustar Inventario</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a href="#/pr_ajustarInventario" style="cursor: url(../img/company/cursorH1.png), pointer;">Art&iacute;culos</a></li>
        <li><a onclick="load(1)" style="cursor: url(../img/company/cursorH1.png), pointer;"><?php echo $almacen_nombre; ?></a></li>
        <li class="active">Ajustar Inventario</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <div class="input-group mar-btm">
                    <a href="#/pr_ajustarInventario" class="input-group-addon btn btn-mint" style='cursor: url(../img/company/cursorH1.png), pointer;'><i class="fa fa-reply"></i> Regresar</a>
                    <input type="text" id="producto_nombre" class="form-control" placeholder="Buscar por c&oacute;digo o nombre" required  tabindex="2" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" autofocus>
                    <input id="producto_id" name="producto_id" type='hidden'>
                    <div id="botonBuscar" class="input-group-addon btn btn-primary" onclick='load(1);' style='cursor: url(../img/company/cursorH1.png), pointer;'><i class="fa fa-search"></i></div>
                </div>
                <div id='outer_div'>
                    <br>
                    <div class="alert alert-info" style="text-align: center;">
                        <strong>Primero selecciona un &iacute;tem!</strong> <img src="../assets/images/svg-icon/hand-up.svg" style="width: 40px; cursor: url(../img/company/cursorH1.png), pointer;">
                        <br>Aqu&iacute; se mostrar&aacute; los movimientos del &iacute;tem seleccionado.
                    </div>
                </div>
                <div id="ldng_cat" style="text-align: center;"></div>
                <div id="datos_ajax_delete"></div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<script src="../js/ajustarInventario.js"></script>
<script>
$(function() {
$("#producto_nombre").autocomplete({
  source: "../ajax/autocomplete/productos.php",
  minLength: 1,
  select: function(event, ui) {
    event.preventDefault();
    $('#producto_id').val(ui.item.producto_id);
    $('#producto_nombre').val(ui.item.producto_nombre);
    $('#outer_div').load("../ajax/buscarAjuste.php?producto_id="+ui.item.producto_id);
    //toastr.success("Producto seleccionado","Exito");
    vt.info("El &iacute;tem <b>"+ui.item.producto_nombre+"</b> ha sido seleccionado.", {
        duration: 2000,
        fadeDuration: 200,
        title: "Bien hecho!",
        position: "top-center"
    })
  }
});
});

$("#producto_nombre" ).on( "keydown", function( event ) {
if (event.keyCode== $.ui.keyCode.LEFT || event.keyCode== $.ui.keyCode.RIGHT || event.keyCode== $.ui.keyCode.UP || event.keyCode== $.ui.keyCode.DOWN || event.keyCode== $.ui.keyCode.DELETE || event.keyCode== $.ui.keyCode.BACKSPACE )
{
  $("#producto_id" ).val("");
}
if (event.keyCode==$.ui.keyCode.DELETE){
  $("#producto_nombre" ).val("");
  $("#producto_id" ).val("");
}
});
</script>