<?php
session_start();
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos
include "../modal/copiaSeguridad.php";
$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);
?>
<?php if($a[209]==1){ ?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Bakcup</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load(1);" style="cursor: pointer;">Ajustes</a></li>
        <li class="active">Bakcup</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <!-- Contact Panel -->
        <!---------------------------------->
        <div class="panel">
            <div class="panel-body">
    
                <h3>Copia de seguridad</h3>
                <p>Realizar una copia de seguridad de la base de datos.</p>
                <div class="row">
                    <div class="col-sm-12">
                        <button class="btn btn-primary btn-block" onclick="window.open('../ajax/backup.php','_blank');">Descargar</button>
                    </div>
                </div>
            </div>
        </div>
        <!---------------------------------->
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<?php } else { 
    include "../includes/sinAcceso.php";
} ?>
<script src="../js/backup.js"></script>