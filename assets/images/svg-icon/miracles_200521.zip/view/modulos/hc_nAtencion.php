<?php
session_start();
require_once "../../config/db.php";
require_once "../../config/conexion.php";
$tienda                 = $_SESSION['tienda'];
$cadena                 = $_GET['nAtencion'];
$id_usuario             = $_SESSION['usuario_id'];
$pedido                 = substr($cadena, 0, -4);

$sql_credito=mysqli_query($con,"select * from admision, clientes, especialidades, topico where topico_idAdmision=admision.admision_id and admision.admision_idCliente=clientes.cliente_id and admision.admision_idEspecialidad=especialidades.especialidad_id and admision.admision_id=$pedido order by admision.admision_id desc");
$row=mysqli_fetch_array($sql_credito);
//Especialidad
$especialidad_id        = $row['especialidad_id'];
$especialidad_nombre    = $row['especialidad_nombre'];
//Cliente
$cliente_nombre         = $row['cliente_nombre'];
$cliente_documento      = $row['cliente_documento'];
$cliente_tipo           = $row['cliente_tipo'];
$cliente_telefono       = $row['cliente_telefono'];
$cliente_direccion      = $row['cliente_direccion'];
$cliente_fechaNacimiento = $row['cliente_fechaNacimiento'];
$cliente_procedencia    = $row['cliente_procedencia'];

$sql_tipo=mysqli_query($con,"select * from sunat_tipocliente where sunat_tipoCliente_id='".$cliente_tipo."'");
$rw_tipo=mysqli_fetch_array($sql_tipo);
$sunat_tipoCliente_nombre=$rw_tipo['sunat_tipoCliente_nombre'];
//
$admision_edad          = $row['admision_edad'];
$admision_idCliente     = $row['admision_idCliente'];
$admision_id            = $row['admision_id'];
$admision_idUsuario     = $row['admision_idUsuario'];
$admision_deriva        = $row['admision_deriva'];
//
$topico_presion         = $row['topico_presion'];
$topico_temperatura     = $row['topico_temperatura'];
$topico_saturacion      = $row['topico_saturacion'];
$topico_peso            = $row['topico_peso'];
$topico_talla           = $row['topico_talla'];
$topico_imc             = $row['topico_imc'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id='".$id_usuario."'");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_idColaborador   = $rw_usuario['usuario_idColaborador'];
//
$sql_colaborador=mysqli_query($con,"select * from colaboradores where colaborador_id='".$usuario_idColaborador."'");
$rw_colaborador=mysqli_fetch_array($sql_colaborador);
$colaborador_nombres   = $rw_colaborador['colaborador_nombres'];
$colaborador_id         = $rw_colaborador['colaborador_id'];
//
$sql_medico=mysqli_query($con,"select * from medicos where medico_idColaborador='".$colaborador_id."'");
$rw_medico=mysqli_fetch_array($sql_medico);
$medico_id   = $rw_medico['medico_id'];
$medico_idColaborador   = $rw_medico['medico_idColaborador'];

function calcular_edad($fecha){
$fecha_nac = new DateTime(date('Y/m/d',strtotime($fecha))); // Creo un objeto DateTime de la fecha ingresada
$fecha_hoy =  new DateTime(date('Y/m/d',time())); // Creo un objeto DateTime de la fecha de hoy
$edad = date_diff($fecha_hoy,$fecha_nac); // La funcion ayuda a calcular la diferencia, esto seria un objeto
return $edad;
}

$edad = calcular_edad($admision_edad);

$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);

if ($medico_idColaborador <> $usuario_idColaborador) {
    include "../includes/noMedico.php";
} else { 
?>
<?php if($a[247]==1){ ?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Registrar Atenci&oacute;n</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load(1);" style="cursor: pointer;">Cl&iacute;nica</a></li>
        <li class="active">Registrar Atenci&oacute;n</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <form method="post" id="guardar_historia" name="guardar_historia" autocomplete="off" class="form-horizontal" autocomplete="off">
                    <div id="resultados_ajax"></div>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: red;"><strong>I. FILIACI&Oacute;N:</strong></label>
                        <div class="col-md-4">
                            <label for="paciente">Paciente *</label>
                            <input readonly type="text" class="form-control" id="paciente" name="paciente" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" required value="<?php echo $cliente_nombre; ?>">
                            <input type="hidden" id="historial_idCliente" name="historial_idCliente" value="<?php echo $admision_idCliente; ?>">
                            <input type="hidden" id="historial_idAdmision" name="historial_idAdmision" value="<?php echo $admision_id; ?>">
                            <input type="hidden" id="especialidad_id" name="especialidad_id" value="<?php echo $especialidad_id; ?>">
                        </div>
                        <div class="col-md-2">
                            <label for="documento"><?php echo $sunat_tipoCliente_nombre; ?> *</label>
                            <input type="text" class="form-control" id="documento" name="documento" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Descripci&oacute;n" value="<?php echo $cliente_documento; ?>" required readonly>
                        </div>
                        <div class="col-md-3">
                            <label for="edad">Edad *</label>
                            <input type="text" class="form-control" id="edad" name="edad" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Descripci&oacute;n" value="<?php echo "{$edad->format('%Y')} a&ntilde;os, {$edad->format('%m')} meses, {$edad->format('%d')} d&iacute;as"; ?>" required readonly>
                        </div>
                        <div class="col-md-3">
                            <label for="fecha_nacimiento">F. Nacimiento *</label>
                            <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" required value="<?php echo $cliente_fechaNacimiento; ?>" readonly>
                        </div>
                        <div class="col-md-3">
                            <label for="cliente_telefono">Tel&eacute;fono *</label>
                            <input type="text" class="form-control" id="cliente_telefono" name="cliente_telefono" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Tel&eacute;fono" value="<?php echo $cliente_telefono; ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="cliente_procedencia">Procedencia *</label>
                            <input type="text" class="form-control" id="cliente_procedencia" name="cliente_procedencia" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Procedencia" value="<?php echo $cliente_procedencia; ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="cliente_direccion">Direcci&oacute;n *</label>
                            <input type="text" class="form-control" id="cliente_direccion" name="cliente_direccion" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Direcci&oacute;n" value="<?php echo $cliente_direccion; ?>">
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: red;"><strong>II. MOTIVO DE LA CONSULTA:</strong></label>
                        <div class="col-md-12">
                            <textarea class="form-control" id="historial_motivoConsulta" name="historial_motivoConsulta" onKeyUp="this.value=this.value.toUpperCase();" required></textarea>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: black;"><strong>ENFERMEDAD ACTUAL:</strong></label>
                        <div class="col-md-12">
                            <textarea class="form-control" id="historial_enfermedadActual" name="historial_enfermedadActual" onKeyUp="this.value=this.value.toUpperCase();" required></textarea>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: red;"><strong>III. FUNCIONES BIOL&Oacute;CAS:</strong></label>
                        <div class="col-md-4">
                            <label for="historial_apetito">Apetito</label>
                            <input type="text" class="form-control" id="historial_apetito" name="historial_apetito" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Apetito">
                        </div>
                        <div class="col-md-4">
                            <label for="historial_sed">Sed</label>
                            <input type="text" class="form-control" id="historial_sed" name="historial_sed" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Sed">
                        </div>
                        <div class="col-md-4">
                            <label for="historial_heces">Heces</label>
                            <input type="text" class="form-control" id="historial_heces" name="historial_heces" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Heces">
                        </div>
                        <div class="col-md-4">
                            <label for="historial_diuresis">Diuresis</label>
                            <input type="text" class="form-control" id="historial_diuresis" name="historial_diuresis" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Diuresis">
                        </div>
                        <div class="col-md-4">
                            <label for="historial_suenio">Sue&ntilde;o</label>
                            <input type="text" class="form-control" id="historial_suenio" name="historial_suenio" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Sue&ntilde;o">
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: red;"><strong>IV. ANTECEDENTES:</strong></label>
                        <div class="col-md-4">
                            <label for="historial_habitosNocivosOtros">H&aacute;bitos Nocivos</label>
                                <input class="magic-checkbox" type="checkbox" id="alcohol" name="habito1" value="1" /> <label for="alcohol">Alcohol</label>
                                <input class="magic-checkbox" type="checkbox" id="tabaco" name="habito2" value="1" /> <label for="tabaco">Tabaco</label>
                                <input type="text" class="form-control" id="historial_habitosNocivosOtros" name="historial_habitosNocivosOtros" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Otros">
                        </div>
                        <div class="col-md-4">
                            <label for="historial_fisiologico">Fisiol&oacute;gicos / Gineco-Obst&eacute;tricos</label>
                            <input type="text" class="form-control" id="historial_fisiologico" name="historial_fisiologico" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Fisiol&oacute;gicos / Gineco-Obst&eacute;tricos">
                        </div>
                        <div class="col-md-4">
                            <label for="historial_patologico">Patol&oacute;gicos + Alergias</label>
                            <input type="text" class="form-control" id="historial_patologico" name="historial_patologico" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Patol&oacute;gicos + Alergias">
                        </div>
                        <div class="col-md-4">
                            <label for="historial_familiares">Familiares</label>
                            <input type="text" class="form-control" id="historial_familiares" name="historial_familiares" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Familiares">
                        </div>
                        <div class="col-md-4">
                            <label for="historial_socioeconomico">Socioecon&oacute;micos / Ocupaci&oacute;n</label>
                            <input type="text" class="form-control" id="historial_socioeconomico" name="historial_socioeconomico" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Socioecon&oacute;micos / Ocupaci&oacute;n">
                        </div>
                        <div class="col-md-4">
                            <label for="historial_antecedentesOtros">Otros (Especificar)</label>
                            <input type="text" class="form-control" id="historial_antecedentesOtros" name="historial_antecedentesOtros" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Otros (Especificar)">
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: red;"><strong>V. EXAMEN F&Iacute;SICO:</strong></label>
                        <div class="col-md-3">
                            <label for="historial_frecuenciaCardiaca">Frecuencia Cardiaca *</label>
                            <input type="text" class="form-control" id="historial_frecuenciaCardiaca" name="historial_frecuenciaCardiaca" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Frecuencia Cardiaca" required>
                        </div>
                        <div class="col-md-3">
                            <label for="historial_presionArterial">Presi&oacute;n Arterial*</label>
                            <input type="text" class="form-control" id="historial_presionArterial" name="historial_presionArterial" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Presi&oacute;n" required value="<?php echo $topico_presion; ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="historial_frecuenciaRespiratoria">Frecuencia Respiratoria *</label>
                            <input type="text" class="form-control" id="historial_frecuenciaRespiratoria" name="historial_frecuenciaRespiratoria" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Frecuencia Respiratoria" required>
                        </div>
                        <div class="col-md-3">
                            <label for="historial_temperatura">Temperatura *</label>
                            <input type="text" class="form-control" id="historial_temperatura" name="historial_temperatura" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Temperatura" required value="<?php echo $topico_temperatura; ?>">
                        </div>

                        <div class="col-md-3">
                            <label for="historial_peso">Peso (kg) *</label>
                            <input type="text" class="form-control" id="historial_peso" name="historial_peso" onKeyUp="this.value=this.value.toUpperCase();Suma();" placeholder="Peso" required value="<?php echo $topico_peso; ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="historial_talla">Talla (m) *</label>
                            <input type="text" class="form-control" id="historial_talla" name="historial_talla" onKeyUp="this.value=this.value.toUpperCase();Suma();" placeholder="Talla" required value="<?php echo $topico_talla; ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="historial_imc">IMC *</label>
                            <input type="text" class="form-control" id="historial_imc" name="historial_imc" onKeyUp="this.value=this.value.toUpperCase();" placeholder="IMC" required value="<?php echo $topico_imc; ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="historial_saturacion">Saturaci&oacute;n *</label>
                            <input type="text" class="form-control" id="historial_saturacion" name="historial_saturacion" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Saturaci&oacute;n" required value="<?php echo $topico_saturacion; ?>">
                        </div>

                        <div class="col-md-6">
                            <label for="historial_estadoGeneral">Estado General</label>
                            <input type="text" class="form-control" id="historial_estadoGeneral" name="historial_estadoGeneral" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Estado General">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_piel">Piel</label>
                            <input type="text" class="form-control" id="historial_piel" name="historial_piel" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Piel">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_farena">Farenas</label>
                            <input type="text" class="form-control" id="historial_farena" name="historial_farena" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Farenas">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_linfatico">Linf&aacute;ticos</label>
                            <input type="text" class="form-control" id="historial_linfatico" name="historial_linfatico" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Linf&aacute;ticos">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_apLocomotor">Ap. Locomotor</label>
                            <input type="text" class="form-control" id="historial_apLocomotor" name="historial_apLocomotor" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Ap. Locomotor">
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <div class="col-md-6">
                            <label for="historial_cabeza"><strong>CABEZA</strong></label>
                            <input type="text" class="form-control" id="historial_cabeza" name="historial_cabeza" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Cabeza">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_ojos">Ojos</label>
                            <input type="text" class="form-control" id="historial_ojos" name="historial_ojos" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Ojos">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_fosasNasales">Fosas Nasales</label>
                            <input type="text" class="form-control" id="historial_fosasNasales" name="historial_fosasNasales" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Fosas Nasales">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_boca">Boca</label>
                            <input type="text" class="form-control" id="historial_boca" name="historial_boca" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Boca">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_oido">O&iacute;dos</label>
                            <input type="text" class="form-control" id="historial_oido" name="historial_oido" onKeyUp="this.value=this.value.toUpperCase();" placeholder="O&iacute;dos">
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <div class="col-md-6">
                            <label for="historial_cuello"><strong>CUELLO</strong></label>
                            <input type="text" class="form-control" id="historial_cuello" name="historial_cuello" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Cuello">
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: black;"><strong>T&Oacute;RAX:</strong></label>
                        <div class="col-md-6">
                            <label for="historial_apRespiratorio">Ap. Respiratorio</label>
                            <input type="text" class="form-control" id="historial_apRespiratorio" name="historial_apRespiratorio" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Ap. Respiratorio">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_apCardiovascular">Ap. Cardiovascular</label>
                            <input type="text" class="form-control" id="historial_apCardiovascular" name="historial_apCardiovascular" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Ap. Cardiovascular">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_pulsosPerifericos">Pulsos Perif&eacute;ricos</label>
                            <input type="text" class="form-control" id="historial_pulsosPerifericos" name="historial_pulsosPerifericos" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Pulsos Perif&eacute;ricos">
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                            <label class="col-md-12 col-form-label" style="color: black;"><strong>ABDOMEN:</strong></label>
                        <div class="col-md-6">
                            <label for="historial_auscultacion">Auscultaci&oacute;n</label>
                            <input type="text" class="form-control" id="historial_auscultacion" name="historial_auscultacion" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Auscultaci&oacute;n">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_inspeccion">Inspecci&oacute;n</label>
                            <input type="text" class="form-control" id="historial_inspeccion" name="historial_inspeccion" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Inspecci&oacute;n">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_percusion">Percusi&oacute;n</label>
                            <input type="text" class="form-control" id="historial_percusion" name="historial_percusion" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Percusi&oacute;n">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_palpacion">Palpaci&oacute;n</label>
                            <input type="text" class="form-control" id="historial_palpacion" name="historial_palpacion" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Palpaci&oacute;n">
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <div class="col-md-6">
                            <label for="historial_genitoUrinario"><strong>GENITO-URINARIO</strong></label>
                            <input type="text" class="form-control" id="historial_genitoUrinario" name="historial_genitoUrinario" onKeyUp="this.value=this.value.toUpperCase();" placeholder="GENITO-URINARIO">
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                            <label class="col-md-12 col-form-label" style="color: black;"><strong>NEUROL&Oacute;GICO:</strong></label>
                        <div class="col-md-12">
                            <label for="historial_estadoConciencia">Estado De Conciencia</label>
                            <input type="text" class="form-control" id="historial_estadoConciencia" name="historial_estadoConciencia" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Estado De Conciencia">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_rot">ROT</label>
                            <input type="text" class="form-control" id="historial_rot" name="historial_rot" onKeyUp="this.value=this.value.toUpperCase();" placeholder="ROT">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_coordinacion">Coordinaci&oacute;n</label>
                            <input type="text" class="form-control" id="historial_coordinacion" name="historial_coordinacion" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Coordinaci&oacute;n">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_equilibrio">Equilibrio</label>
                            <input type="text" class="form-control" id="historial_equilibrio" name="historial_equilibrio" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Equilibrio">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_sensibilidad">Sensibilidad</label>
                            <input type="text" class="form-control" id="historial_sensibilidad" name="historial_sensibilidad" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Sensibilidad">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_paresCraneales">Pares Craneales</label>
                            <input type="text" class="form-control" id="historial_paresCraneales" name="historial_paresCraneales" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Pares Craneales">
                        </div>
                        <div class="col-md-6">
                            <label for="historial_signosMeningeos">Signos Men&iacute;ngeos</label>
                            <input type="text" class="form-control" id="historial_signosMeningeos" name="historial_signosMeningeos" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Signos Men&iacute;ngeos">
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: red;"><strong>VI. DIAGN&Oacute;STICO:</strong></label>
                        <div class="col-md-12">
                            <textarea class="form-control" id="historial_diagnostico" name="historial_diagnostico" onKeyUp="this.value=this.value.toUpperCase();" required></textarea>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: red;"><strong>VII. PLAN:</strong></label>
                        <div class="col-md-12">
                            <textarea class="form-control" id="historial_plan" name="historial_plan" onKeyUp="this.value=this.value.toUpperCase();" required></textarea>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: red;"><strong>VIII. RP:</strong></label>
                        <div class="col-md-12">
                            <textarea class="form-control" id="historial_rp" name="historial_rp" onKeyUp="this.value=this.value.toUpperCase();" required></textarea>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: red;"><strong>M&Eacute;DICO:</strong> </label>
                        <div class="col-md-12">
                            <input type="text" class="form-control" id="medico" name="medico" onKeyUp="this.value=this.value.toUpperCase();" placeholder="M&eacute;dico" required value="<?php echo $colaborador_nombres; ?>" readonly>
                            <input type="hidden" name="historial_idMedico" id="historial_idMedico" value="<?php echo $medico_id; ?>">
                            <input type="hidden" name="historial_idProducto" id="historial_idProducto" value="<?php echo $admision_deriva; ?>">
                        </div>
                    </div>
                    <br>
                    
                    <div class="modal-footer">
                       <a class="btn btn-danger" href="#/hc_atencion">Regresar</a>
                       <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<?php } else { 
    include "../includes/sinAcceso.php";
} ?>
<?php } ?>
<script src="../js/clinica/atencion1.js"></script>