<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
session_start();
include("../../config/db.php");
include("../../config/conexion.php");

$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);
?>
<?php if($a[232]==1){ ?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Registrar Admisi&oacute;n</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load(1);" style="cursor: pointer;">Cl&iacute;nica</a></li>
        <li class="active">Registrar Admisi&oacute;n</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <form method="post" id="guardar_admision" name="guardar_admision" autocomplete="off" class="form-horizontal" autocomplete="off">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="cliente_nombre1">Paciente *</label>
                            <input type="hidden" id="id_cliente" name="admision_idCliente">
                            <input type="text" class="form-control" id="cliente_nombre1" placeholder="Buscar cliente por documento o nombre..." required="required" tabindex="2" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();">
                        </div>
                        <div class="col-md-3">
                            <label for="cliente_documento">Documento *</label>
                            <input type="text" class="form-control" id="cliente_documento" name="documento" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Documento" readonly>
                        </div>
                        <div class="col-md-3">
                            <label for="cliente_fechaNacimiento">F. Nacimiento*</label>
                            <input type="date" class="form-control" id="cliente_fechaNacimiento" name="admision_edad" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Edad" required>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-md-6">
                            <label for="admision_idEspecialidad">Especialidad *</label>
                            <select id="admision_idEspecialidad" name="admision_idEspecialidad" class="form-control selectAdEsp" style="width: 100%;" required>
                              <?php $tienda = $_SESSION['tienda'];
                                 $sql_especialidades ="select * from especialidades where especialidad_sucursal='$tienda' order by especialidad_nombre asc";
                                 $row_especialidades          =mysqli_query($con,$sql_especialidades);
                                 while ($row1_especialidades = mysqli_fetch_array($row_especialidades)) {
                                    $especialidad_nombre = $row1_especialidades["especialidad_nombre"];
                                    $especialidad_id     = $row1_especialidades["especialidad_id"];
                              ?>
                              <option value="<?php echo $especialidad_id;?>"><?php  echo $especialidad_nombre;?></option>

                              <?php } ?>
                           </select>
                        </div>
                        <div class="col-md-6">
                            <label for="admision_deriva">Producto / Servicio *</label>
                            <select id="admision_deriva" name="admision_deriva" class="form-control selectAdEsp" style="width: 100%;" required>
                              <?php $tienda = $_SESSION['tienda'];
                                 $sql_especialidades ="select * from productos where producto_idSucursal='$tienda' and producto_stock<>0 order by producto_nombre asc";
                                 $row_especialidades          =mysqli_query($con,$sql_especialidades);
                                 while ($row1_especialidades = mysqli_fetch_array($row_especialidades)) {
                                    $producto_nombre = $row1_especialidades["producto_nombre"];
                                    $producto_id     = $row1_especialidades["producto_id"];
                              ?>
                              <option value="<?php echo $producto_id;?>"><?php  echo $producto_nombre;?></option>

                              <?php } ?>
                           </select>
                        </div>
                    </div>
                    <br>

                    <div class="modal-footer">
                       <a class="btn btn-danger" href="#/hc_admision">Regresar</a>
                       <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<?php } else { 
    include "../includes/sinAcceso.php";
} ?>
<script src="../js/clinica/admision1.js"></script>