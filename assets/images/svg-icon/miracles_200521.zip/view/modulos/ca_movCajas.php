<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
session_start();
require_once "../../config/db.php";
require_once "../../config/conexion.php";
//Incluimos las ventanas modales
include "../modal/cierreCaja.php";

$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);
?>
<?php if($a[9]==1 || $a[10]==1 || $a[229]==1){ ?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Hist&oacute;rico Caja</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load(1);" style="cursor: pointer;">Caja</a></li>
        <li class="active">Hist&oacute;rico Caja</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="input-group" style="float: right;">
                <div class="input-group mar-btm">
                    <input type="text" class="form-control daterange pull-right" value="<?php echo "01" . date('/m/Y') . ' - ' . date('d/m/Y'); ?>" id="range" readonly>
                    <div class="input-group-addon btn btn-primary" onclick='load(1);' style="cursor: url(../img/company/cursorH1.png), pointer;"><i class='fa fa-search'></i></div>
                </div>
            </div>
            <div id="ldng_cat" style="text-align: center;"></div>
            <div id="resultados_ajax"></div>
            <div class='outer_div_cat'></div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>

<?php } else { 
    include "../includes/sinAcceso.php";
} ?>

<script src="../js/movCajas1.js"></script>
<script src="../js/ventanaCentrada.js"></script>
<script>
function imprimir_cajaR(id_caja) {
    VentanaCentrada('../view/pdf/documentos/a4_caja.php?box='+id_caja,'Factura','','1024','768','true');
}
function imprimir_cajaD(id_caja) {
    VentanaCentrada('../view/pdf/documentos/a4_cajaD.php?box='+id_caja,'Factura','','1024','768','true');
}
//
function pdfHCS(){
    var range=$("#range").val();
    VentanaCentrada('../view/pdf/documentos/a4_historicoCajaS.php?action=ajax&range='+range,'Factura','','1024','768','true');
    //window.open('../view/pdf/documentos/registroVentas.php?action=ajax&page='+page+'&range='+range, '_blank');
}
function pdfHCD(){
    var range=$("#range").val();
    VentanaCentrada('../view/pdf/documentos/a4_historicoCajaD.php?action=ajax&range='+range,'Factura','','1024','768','true');
    //window.open('../view/pdf/documentos/registroVentas.php?action=ajax&page='+page+'&range='+range, '_blank');
}
//
function excelHCS(){
    var range=$("#range").val();
    window.open('../view/excel/historicoCajaS.php?action=ajax&range='+range,'_blank');
    //window.open('../view/pdf/documentos/registroVentas.php?action=ajax&page='+page+'&range='+range, '_blank');
}
function excelHCD(){
    var range=$("#range").val();
    window.open('../view/excel/historicoCajaD.php?action=ajax&range='+range,'_blank');
    //window.open('../view/pdf/documentos/registroVentas.php?action=ajax&page='+page+'&range='+range, '_blank');
}
</script>