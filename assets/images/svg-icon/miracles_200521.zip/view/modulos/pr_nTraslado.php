<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
session_start();
require_once "../../config/general.php";
require_once "../../config/db.php";
require_once "../../config/conexion.php";

$user_id = $_SESSION['usuario_id'];
$empresa = $_SESSION['datosEmpresa_id'];
$tienda = $_SESSION['tienda'];
//
include "../modal/buscarProductosTraslado.php";
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);

$session_id=session_id();
$delete = mysqli_query($con, "DELETE FROM tmptraslado WHERE tmpTraslado_session='".$session_id."'");

?>
<?php if($a[43]==1){ ?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Traslados</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a href="#/pr_traslados" style="cursor: pointer;">Art&iacute;culos</a></li>
        <li><a onclick="load(1);" style="cursor: pointer;">Traslados</a></li>
        <li class="active">Nuevo Traslado</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <form method="post" id="guardar_traslado" name="guardar_traslado" autocomplete="off" class="form-horizontal">
                    <div id="resultados_ajax"></div>
                   <label class="col-md-12 col-form-label" style="color: red;"><b>SALIDA:</b></label>
                    <div class="row">
                        <div class="col-md-6">
                            <label for="traslado_sucursalEmite">Establecimiento *</label>
                            <select id="traslado_sucursalEmite" name="traslado_sucursalEmite" class="form-control" style="width: 100%;" required onchange="selectSalida()">
                                <option value="">-- Selecciona Establecimiento --</option>
                              <?php
                                 $sql_sEmite ="select * from sucursales where sucursal_idEmpresa='$empresa' and sucursal_tienda='$tienda' order by sucursal_tienda asc";
                                 $row_sEmite          =mysqli_query($con,$sql_sEmite);
                                 while ($row1_sEmite = mysqli_fetch_array($row_sEmite)) {
                                    $sucursal_nombre = $row1_sEmite["sucursal_nombre"];
                                    $sucursal_tienda     = $row1_sEmite["sucursal_tienda"];
                              ?>
                              <option value="<?php echo $sucursal_tienda;?>"><?php  echo $sucursal_nombre;?></option>

                              <?php } ?>
                           </select>
                        </div>
                        <div class="col-md-3">
                            <label for="traslado_almacenEmite">Almac&eacute;n *</label>
                            <select class="form-control" id="traslado_almacenEmite" name="traslado_almacenEmite" disabled onchange="load1(1)">
                                <option value="">-- Selecciona Almac&eacute;n --</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="traslado_fecha">Fecha *</label>
                            <input type="date" class="form-control" id="traslado_fecha" name="traslado_fecha" value="<?php echo date('Y-m-d'); ?>">
                        </div>
                    </div>
                    <br>
                    <label class="col-md-12 col-form-label" style="color: red;"><b>DESTINO</b>:</label>
                    <div class="row">
                        <div class="col-md-6">
                            <label for="traslado_sucursalDestino">Establecimiento *</label>
                            <select id="traslado_sucursalDestino" name="traslado_sucursalDestino" class="form-control" style="width: 100%;" required onchange="selectDestino()" disabled>
                                <option value="">-- Selecciona Establecimiento --</option>
                              <?php
                                 $sql_sEmite ="select * from sucursales where sucursal_idEmpresa='$empresa' order by sucursal_tienda asc";
                                 $row_sEmite          =mysqli_query($con,$sql_sEmite);
                                 while ($row1_sEmite = mysqli_fetch_array($row_sEmite)) {
                                    $sucursal_nombre = $row1_sEmite["sucursal_nombre"];
                                    $sucursal_tienda     = $row1_sEmite["sucursal_tienda"];
                              ?>
                              <option value="<?php echo $sucursal_tienda;?>"><?php  echo $sucursal_nombre;?></option>

                              <?php } ?>
                           </select>
                        </div>
                        <div class="col-md-3">
                            <label for="traslado_almacenDestino">Almac&eacute;n *</label>
                            <select class="form-control" id="traslado_almacenDestino" name="traslado_almacenDestino" disabled>
                                <option value="">-- Selecciona Almac&eacute;n --</option>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <br>
                            <a class="btn btn-danger" href="#/pr_traslados">Regresar</a>
                            <a class="btn btn-mint" data-toggle="modal" data-target="#buscar" id="buscarI" disabled>Buscar &Iacute;tems</a>
                            <button type="submit" class="btn btn-primary" id="guardar_datos">Procesar Traslado</button>
                        </div>
                    </div>
                </form>
                <br><br>
                <div id="resultados" class='col-md-12'></div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>

<?php } else { 
    include "../includes/sinAcceso.php";
} ?>
<script src="../js/traslados.js"></script>