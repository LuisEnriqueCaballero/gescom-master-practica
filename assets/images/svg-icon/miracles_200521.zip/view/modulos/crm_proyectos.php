<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Proyectos</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
			<li><a href="#/ss_inicio" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
	        <li><a onclick="load(1);" style="cursor: pointer;">CRM</a></li>
			<li class="active">Proyectos</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
	    <div class="row spinner-example">
	        <!-- Double Bounce -->
	        <!---------------------------------->
	        <div class="col-sm-6 col-md-4 col-lg-3" style="text-align: center; cursor: pointer;" onclick="window.open('#/crm_listaProgramas','_self');">
	            <div class="panel">
	                <div class="panel-heading">
	                    <h3 class="panel-title">Programas</h3>
	                </div>
	                <div class="panel-body">
	                    <img src="../assets/images/svg-icon/program.svg" style="width: 100px;">
	                </div>
	            </div>
	        </div>
	        <!-- Wave -->
	        <!---------------------------------->
	        <div class="col-sm-6 col-md-4 col-lg-3" style="text-align: center; cursor: pointer;" onclick="window.open('#/crm_listaGrupos','_self');">
	            <div class="panel">
	                <div class="panel-heading">
	                    <h3 class="panel-title">Grupos</h3>
	                </div>
	                <div class="panel-body">
	                    <img src="../assets/images/svg-icon/group.svg" style="width: 100px;">
	                </div>
	            </div>
	        </div>
	        <!-- Wandering Cubes -->
	        <!---------------------------------->
	        <div class="col-sm-6 col-md-4 col-lg-3" style="text-align: center; cursor: pointer;" onclick="window.open('#/crm_listaMiembros','_self');">
	            <div class="panel">
	                <div class="panel-heading">
	                    <h3 class="panel-title">Miembros</h3>
	                </div>
	                <div class="panel-body">
	                    <img src="../assets/images/svg-icon/member.svg" style="width: 100px;">
	                </div>
	            </div>
	        </div>
	        <!-- Rotate Plane -->
	        <!---------------------------------->
	        <div class="col-sm-6 col-md-4 col-lg-3" style="text-align: center; cursor: pointer;" onclick="window.open('#/crm_listaProyectos','_self');">
	            <div class="panel">
	                <div class="panel-heading">
	                    <h3 class="panel-title">Proyectos</h3>
	                </div>
	                <div class="panel-body">
	                    <img src="../assets/images/svg-icon/project.svg" style="width: 100px;">
	                </div>
	            </div>
	        </div>
	    </div>
	    <!-- -->
	    <div class="panel">
	        <div class="panel-body">
	            <h3>Spinkit</h3>
	            <p>Simple loading spinners animated with CSS. SpinKit uses hardware accelerated (translate and opacity) CSS animations to create smooth and easily customizable animations.</p>
	        </div>
	    </div>
	    <!-- -->
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<script src="../js/proyectos.js"></script>