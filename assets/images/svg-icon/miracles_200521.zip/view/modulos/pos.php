<?php
session_start();
require_once "../../config/general.php";
require_once "../../config/db.php";
require_once "../../config/conexion.php";

include "../modal/modalCat.php";
include "../modal/modalMar.php";
include "../modal/modalPago.php";
include "../modal/modalCancelar.php";
include "../modal/registroCliente.php";
include "../modal/registroItem.php";

$user_id = $_SESSION['usuario_id'];
$empresa = $_SESSION['datosEmpresa_id'];
$tienda = $_SESSION['tienda'];
//
$sql = "select * from almacenes where almacen_idSucursal='$tienda' and almacen_orden='1' and almacen_activo='1'";
$query = mysqli_query($con,$sql);
$row_almacen = mysqli_fetch_array($query);
$almacen_id = $row_almacen['almacen_id'];

$_SESSION['almacen'] = $almacen_id;
//
$actual = date('d/m/Y');
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo); 
//Datos de la empresa
$sql_empresa=mysqli_query($con,"select * from datosempresa where datosEmpresa_id=$empresa");
$rw_tienda=mysqli_fetch_array($sql_empresa);
$datosEmpresa_id=$rw_tienda['datosEmpresa_id'];
$tipoenvio=$rw_tienda['tipoenvio'];
//
$sql_caja               = mysqli_query($con,"select * from caja where caja_sucursal=$tienda and caja_idUsuario=$user_id order by caja_fechaApertura desc limit 1");
$rw_caja                = mysqli_fetch_array($sql_caja);
$caja_fechaApertura     = date('d/m/Y', strtotime($rw_caja['caja_fechaApertura']));
$caja_estado            = $rw_caja['caja_estado'];
$caja_idUsuario         = $rw_caja['caja_idUsuario'];
$caja_fechaCierre       = $rw_caja['caja_fechaCierre'];

?>
<?php if($a[1]==1){
include "../modal/modalPos.php";
?>
<link href="../assets/css/pos/pos2.css" rel="stylesheet">
<link href="../assets/css/pos/modalLateral.css" rel="stylesheet">
<?php
if ($caja_fechaApertura<$actual || $user_id <> $caja_idUsuario) {
  //echo $caja_fechaApertura;
  include "../includes/abrirCaja.php";
} else { ?> 
<div id="content-container" style="margin-top: -19px;" class="bg-whiteD1">
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content" class="bg-whiteD1">
        <div class="row">
            <div class="panel panel-body bg-whiteD">
                <div id="content" style="margin-bottom: -15px; margin-top: -4px; margin-left: -10px; margin-right: -10px;">
                    <div class="c1">
                        <div class="tpv ">
                            <div id="tpv">
                                <div id="tpv-sale-form">                                                     
                                    <div id="leftdiv" class="bg-whiteD1">
                                        <div id="left-top">
                                            <div class="form-group">
                                                <div class="input-group" style="z-index:1;">
                                                    <input type="text"  id="cliente_nombreNPOS" placeholder="Buscar cliente por documento o nombre..." required="required" tabindex="2" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" class="form-control pos-input-tip" style="width:100%;" />

                                                    <input id="tipoenvio" name="tipoenvio" type='hidden' value="<?php echo $tipoenvio; ?>">
                                                    <?php if($a[11]==1){ ?> 
                                                    <div class="input-group-addon no-print btn btn-default" style="padding: 2px 8px;" data-toggle="modal" data-target="#nuevoCliente">
                                                        <i class="fa fa-plus-circle" id="addIcon" style="font-size: 1.5em;"></i>
                                                    </div>
                                                    <?php } else { ?>
                                                    <div class="input-group-addon no-print btn btn-default disabled" style="padding: 2px 8px;">
                                                        <i class="fa fa-plus-circle" id="addIcon" style="font-size: 1.5em;"></i>
                                                    </div>
                                                    <?php } ?>
                                                </div>
                                                <div style="clear:both;"></div>
                                            </div>
                                            <div class="no-print">
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <select class="form-control pos-input-tip" id="tc" name="tc" style="width:100%;" onchange="tcP(this);">
                                                            <option value="115" selected="selected">PEN</option>
                                                            <option value="151">USD</option>
                                                        </select>
                                                        <input type="hidden" name='id_categoria' id='id_categoria' value="">
                                                        <input type="hidden" name='id_marca' id='id_marca' value="">
                                                        <div class="input-group-addon hidden" id="muestraCambio" style="padding: 2px 8px; width: 30%">
                                                            <div id="cargaCambio"></div>
                                                        </div>
                                                        <div class="input-group-addon btn btn-default" style="padding: 2px 8px;" onclick="load(1);" id="reloadC">
                                                            <i class="fa fa-refresh"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="resultados_ajaxf"></div><!-- Carga los datos ajax -->
                                                <form role="form" id="barcode_form">
                                                    <div class="form-group" id="ui">
                                                        <div class="input-group">
                                                            <input type="text" class="form-control hidden" id="barcode_qty" value="1">
                                                            <input type="text" class="form-control" id="barcode" autocomplete="off" placeholder="Escanear c&oacute;digo de &iacute;tem..."  tabindex="1"/>
                                                            <button class="btn btn-xs btn-default hidden">
                                                                <i class="fa fa-barcode" id="addIcon" style="font-size: 1.5em;"></i>
                                                            </button>
                                                            <?php if($a[35]==1){ ?> 
                                                            <div class="input-group-addon btn btn-default" style="padding: 2px 8px;" data-toggle="modal" data-target="#nuevoItem">
                                                                <i class="fa fa-plus-circle" id="addIcon" style="font-size: 1.5em;"></i>
                                                            </div>
                                                            <?php } else { ?>
                                                            <div class="input-group-addon btn btn-default disabled" style="padding: 2px 8px;">
                                                                <i class="fa fa-plus-circle" id="addIcon" style="font-size: 1.5em;"></i>
                                                            <?php } ?>
                                                        </div>
                                                        <div style="clear:both;"></div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                        <div id="print">
                                            <div id="left-middle">
                                                <div id="product-list">
                                                    <div id="resultados"></div>
                                                    <div style="clear:both;"></div>
                                                </div>
                                            </div>
                                            <div style="clear:both;"></div>
                                            <div id="left-bottom">
                                                <div id="cargaT"></div>
                                                <div class="clearfix"></div>
                                                <div id="botbuttons" class="col-xs-12 text-center">
                                                    <input type="hidden" name="biller" id="biller" value="3"/>
                                                    <div class="row">
                                                        <div class="col-xs-6" style="padding: 0;">
                                                            <div class="btn-group-vertical btn-block">
                                                                <button data-toggle="modal" data-target="#modalCancelar" class="btn btn-danger btn-block btn-flat"
                                                                id="reset" style="height:65.5px; border-radius: 0px;">
                                                                    <i class="fa fa-ban" style="margin-right: 5px; font-size: 50px;"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                        <div class="col-xs-6" style="padding: 0;">
                                                            <button data-toggle="modal" data-target="#modalPago" class="btn btn-mint btn-block" style="height:65.5px; border-radius: 0px;">
                                                                <i class="fa fa-chevron-circle-right " style="margin-right: 5px; font-size: 50px;"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div style="clear:both; height:5px;"></div>
                                                <div id="num">
                                                    <div id="icon"></div>
                                                </div>
                                                <span id="hidesuspend"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="cp">
                                    <div id="cpinner" class="bg-whiteD1">
                                        <div class="quick-menu">
                                            <div id="proContainer">
                                                <div id="ajaxproducts">
                                                    <div id="item-list" style="overflow: scroll;">
                                                        <div>
                                                            <input class="form-control" type="text" autocomplete="off" id="q" placeholder="Buscar &iacute;tem por c&oacute;digo, nombre o descripci&oacute;n..." onkeyup="load(1); this.value=this.value.toUpperCase();" autofocus style="margin-top: 0px;">
                                                            <hr style="margin-top: 5px;">
                                                            <div class="outer_div" style="margin-top: -15px;"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div style="clear:both;"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="clear:both;"></div>
                                </div>
                                <div style="clear:both;"></div>
                            </div>
                            <div style="clear:both;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<?php }
?>

<!--<form method="post" id="guardar_cliente" name="guardar_cliente" autocomplete="off" class="form-horizontal">
   <div class="modal fade" id="nuevoCliente" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
               <h4 class="modal-title">Nuevo Cliente</h4>
            </div>
            <div class="modal-body">
              <div id="resultados_ajax2"></div>
               <div class="form-row">
                  <div class="form-group col-md-6">
                     <label for="cliente_tipo">Tipo de documento *</label>
                     <select required id="cliente_tipo" name="cliente_tipo" class="form-control" onchange="getval(this);">
                        <option value="">SELECCIONAR</option>
                        <?php           
                           $tipo_cliente ="select * from sunat_tipocliente";
                           $row          =mysqli_query($con,$tipo_cliente);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $sunat_tipoCliente_nombre = $row4["sunat_tipoCliente_nombre"];
                              $sunat_tipoCliente_id     = $row4["sunat_tipoCliente_id"];
                        ?>
                        <option value="<?php echo $sunat_tipoCliente_id;?>"><?php  echo $sunat_tipoCliente_nombre;?></option>
                        <?php } ?>
                     </select>
                  </div>
                  <div class="form-group col-md-6">
                     <label for="documento_colaborador">Documento</label>
                     <div class="input-group">
                         <input type="number" class="form-control" name="documento_colaborador" id="documento_colaborador" onKeyUp="this.value=this.value.toUpperCase();" autocomplete="off" placeholder="Documento" required>
                         <div id="tipo_boton"></div>
                     </div>
                  </div>
               </div>
               <div class="form-row">
                   <div class="form-group col-md-6">
                       <label for="cliente_nombre">Nombres *</label>
                       <input type="text" class="form-control" id="cliente_nombre" name="cliente_nombre" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Apellidos y nombres" required>
                   </div>
                   <div class="form-group col-md-2">
                       <label for="cliente_departamento">Departamento</label>
                       <input type="text" class="form-control" id="cliente_departamento" name="cliente_departamento" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Departamento">
                   </div>
                   <div class="form-group col-md-2">
                       <label for="cliente_provincia">Provincia</label>
                       <input type="text" class="form-control" id="cliente_provincia" name="cliente_provincia" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Provincia">
                   </div>
                   <div class="form-group col-md-2">
                       <label for="cliente_distrito">Distrito</label>
                       <input type="text" class="form-control" id="cliente_distrito" name="cliente_distrito" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Distrito">
                   </div>
               </div>
               <div class="form-row">
                   <div class="form-group col-md-6">
                       <label for="cliente_direccion">Domicilio *</label>
                       <input type="text" class="form-control" id="cliente_direccion" name="cliente_direccion" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Domicilio" required>
                   </div>
                   <div class="form-group col-md-6">
                       <label for="cliente_pais">Pa&iacute;s</label>
                       <input type="text" class="form-control" id="cliente_pais" name="cliente_pais" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Pa&iacute;s">
                   </div>
               </div>
               <div class="form-row">
                   
               </div>
               <div class="form-row">
                   <div class="form-group col-md-6">
                       <label for="cliente_telefono">Tel&eacute;fono *</label>
                       <input type="text" class="form-control" id="cliente_telefono" name="cliente_telefono" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Tel&eacute;fono" required>
                   </div>
                   <div class="form-group col-md-6">
                       <label for="cliente_email">E-Mail</label>
                       <input type="email" class="form-control" id="cliente_email" name="cliente_email" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="E-Mail">
                   </div>
               </div>
               <div class="form-row">
                   <div class="form-group col-md-6">
                       <label for="cliente_contacto">Contacto</label>
                       <input type="text" class="form-control" id="cliente_contacto" name="cliente_contacto" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Contacto">
                   </div>
                   <div class="form-group col-md-6">
                       <label for="cliente_cargo">Cargo</label>
                       <input type="text" class="form-control" id="cliente_cargo" name="cliente_cargo" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Cargo">
                   </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>-->


    <div class="rotate btn-cat-con">
        <button class="btn btn-danger" style="border-radius: 0px;" onclick="resetear();">Resetar</button>
        <button data-toggle="modal" data-target="#modalMar" class="btn btn-info" style="border-radius: 0px;">Marcas</button>
        <button data-toggle="modal" data-target="#modalCat" class="btn btn-primary" style="border-radius: 0px;">Categor&iacute;as</button>
    </div>
<?php } else { 
    include "../includes/sinAcceso.php";
} ?>
<script src="../js/tpv7.js"></script>
<script src="../js/enviar_sunat1.js"></script>
<script src="../js/ventanaCentrada.js"></script>
<script>
  /*function getval(sel)
  {
   if(sel.value==''){
      vt.info("Debes seleccionar un tipo de documento.", {
          duration: 5000,
          fadeDuration: 200,
          title: "Oopss!",
          position: "top-right"
      })
      $("#tipo_boton").html('');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','Documento');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", false);
      $('#cliente_pais').val('');
   }
   if(sel.value==1){
      $("#tipo_boton").html('');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','Documento');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", false);
      $('#cliente_pais').val('');
      $('#documento_colaborador').focus();
   }
   if(sel.value==2){
      $("#tipo_boton").html('<div id="botoncitoDNI" class="input-group-addon btn btn-white" style="border: 1px solid #666;"><i class="nohidden1"></i></div>');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','DNI');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", true);
      $('#cliente_pais').val('PERU');
      $('#documento_colaborador').focus();

      $(function(){
         $('.nohidden1').html("<img src='../assets/images/svg-icon/reniec.svg' class='img-fluid' alt='settings' style='width: 23px; height: 23px;'>");
         $('.nohidden1').attr("disabled", true);
         $('#botoncitoDNI').on('click', function(){
           var documento_colaborador = $('#documento_colaborador').val();
           var url = '../ajax/consultas/reniecColaborador.php';
           $('.nohidden1').html('<img src="../img/company/load.svg" width="20px">');
           $.ajax({
             type:'POST',
             url:url,
             data:'documento_colaborador='+documento_colaborador,
             success: function(datos_dni){
               $('.nohidden1').html("<img src='../assets/images/svg-icon/reniec.svg' class='img-fluid' alt='settings' style='width: 23px; height: 23px;'>");
               $('.nohidden1').attr("disabled", false);
               $('#cliente_telefono').focus();
               var datos = eval(datos_dni);
               var nada ='nada';
               if(datos_dni != nada)
                {
                  $('#numero_dni').text(datos[0]);
                  $('#cliente_nombre').val(datos[1]);
                  $('#estado_del_contribuyente').val(datos[2]);
                  $('#condicion_de_domicilio').val(datos[3]);
                  $('#ubgclienteruc').val(datos[4]);
                  $('#tipo_de_via').val(datos[5]);
                  $('#nombre_de_via').val(datos[6]);
                  $('#codigo_de_zona').val(datos[7]);
                  $('#numero').val(datos[8]);
                  $('#interior').val(datos[9]);
                  $('#lote').val(datos[10]);
                  $('#dpto').val(datos[11]);
                  $('#manzana').val(datos[12]);
                  $('#kilometro').val(datos[13]);
                  $('#cliente_departamento').val('-');
                  $('#cliente_provincia').val('-');
                  $('#cliente_distrito').val('-');
                  $('#cliente_direccion').val('-');
                  $('#direcclienteruc').val(datos[18]);
                  $('#ultima_actualizacion').val(datos[19]);
                  $('#informacion_resultado').val(datos[20]);
                  $('#apellido_paterno').val(datos[21]);
                  $('#apellido_materno').val(datos[22]);
                  $('#nombres').val(datos[23]);
                  $('#nombres_completos').val(datos[24]);
               } if(datos[24] == '  ') {
                 vt.info("No pudimos encontrar el documento.", {
                    duration: 5000,
                    fadeDuration: 200,
                    title: "Oopss!",
                    position: "top-right"
                })
                 $("#documento_colaborador").val('');
                 $("#cliente_nombre").val('');
                 $("#cliente_departamento").val('');
                 $("#cliente_provincia").val('');
                 $("#cliente_distrito").val('');
                 $("#cliente_direccion").val('');
                 $('#documento_colaborador').focus();
               }   
            }
           });
         return false;
         });
      });
   }
   if(sel.value==3){
      $("#tipo_boton").html('');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','Carnet de extranjeria');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", false);
      $('#cliente_pais').val('');
      $('#documento_colaborador').focus();
   }
   if(sel.value==4){
      $("#tipo_boton").html('<div id="botoncitoRUC" class="input-group-addon btn btn-white" style="border: 1px solid #666;"><i class="nohidden1"></i></div>');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','RUC');
      $('#cliente_nombre').attr('placeholder','Razon Social');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", true);
      $('#cliente_pais').val('PERU');
      $('#documento_colaborador').focus();

      $(function(){
         $('.nohidden1').html("<img src='../assets/images/svg-icon/sunat.svg' class='img-fluid' alt='settings' style='width: 23px; height: 23px;'>");
         $('#botoncitoRUC').on('click', function(){
           var documento_colaborador = $('#documento_colaborador').val();
           var url = '../ajax/consultas/sunatColaborador.php';
           $('.nohidden1').html('<img src="../img/company/load.svg" width="20px">');
           $.ajax({
             type:'POST',
             url:url,
             data:'documento_colaborador='+documento_colaborador,
             success: function(datos_ruc){
               $('.nohidden1').html("<img src='../assets/images/svg-icon/sunat.svg' class='img-fluid' alt='settings' style='width: 23px; height: 23px;'>");
               $('.nohidden1').attr("disabled", false);
               var datos = eval(datos_ruc);
               var nada ='nada';
               if(datos_ruc != nada){
                 $('#numero_ruc').text(datos[0]);
                 $('#cliente_nombre').val(datos[1]);
                 $('#estado_del_contribuyente').val(datos[2]);
                 $('#condicion_de_domicilio').val(datos[3]);
                 $('#ubgclienteruc').val(datos[4]);
                 $('#tipo_de_via').val(datos[5]);
                 $('#nombre_de_via').val(datos[6]);
                 $('#codigo_de_zona').val(datos[7]);
                 $('#numero').val(datos[8]);
                 $('#interior').val(datos[9]);
                 $('#lote').val(datos[10]);
                 $('#dpto').val(datos[11]);
                 $('#manzana').val(datos[12]);
                 $('#kilometro').val(datos[13]);
                 if (datos[14] == '') {
                    $('#cliente_departamento').focus();
                 }
                 if (datos[14] != '') {
                    $('#cliente_telefono').focus();
                 }
                 $('#cliente_departamento').val(datos[14]);
                 $('#cliente_provincia').val(datos[15]);
                 $('#cliente_distrito').val(datos[16]);
                 $('#cliente_direccion').val(datos[17]);
                 $('#direcclienteruc').val(datos[18]);
                 $('#ultima_actualizacion').val(datos[19]);
               } if(datos[0] == ''){
                 //toastr.warning("No pudimos encontrar el documento...","Aviso!");
                 vt.info("No pudimos encontrar el documento.", {
                    duration: 5000,
                    fadeDuration: 200,
                    title: "Oopss!",
                    position: "top-right"
                })
                 $("#documento_colaborador").val('');
                 $('#documento_colaborador').focus();
               }   
             }
           });
           return false;
         });
       });
   }
   if(sel.value==5){
      $("#tipo_boton").html('');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','Pasaporte');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", false);
      $('#cliente_pais').val('');
      $('#documento_colaborador').focus();
   }
   if(sel.value==6){
      $("#tipo_boton").html('');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','Cedula');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", false);
      $('#cliente_pais').val('');
      $('#documento_colaborador').focus();
   }
  }*/
  //Registra
  $("#guardar_cliente" ).submit(function( event ) {
    $('#guardar_datos').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
    $('#guardar_datos').attr("disabled", true);
    var parametros = $(this).serialize();
    $.ajax({
      type: "POST",
      url: "../ajax/nuevoCliente.php",
      data: parametros,
      beforeSend: function(objeto){ },
      success: function(datos){
        $("#resultados_ajax").html(datos);
        $('#guardar_datos').html('Aceptar');
        $('#guardar_datos').attr("disabled", false);
        load(1);
        $("#guardar_cliente")[0].reset();
        $("#cliente_tipo").focus();
      }
    });
    event.preventDefault();
  })
  //Registra
  $("#guardar_item" ).submit(function( event ) {
    $('#guardar_datos').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
    $('#guardar_datos').attr("disabled", true);
    var parametros = $(this).serialize();
    $.ajax({
      type: "POST",
      url: "../ajax/nuevoItem.php",
      data: parametros,
      beforeSend: function(objeto){ },
      success: function(datos){
        $("#resultados_ajax").html(datos);
        $('#guardar_datos').html('Aceptar');
        $('#guardar_datos').attr("disabled", false);
        $("#cod_resultado").load("../ajax/incrementaCodProducto.php");
        load(1);
        $("#guardar_item")[0].reset();
        $("#producto_codigoBarras").focus();
      }
    });
    event.preventDefault();
  })
</script>
<script>
//Tipo factura
function tipoContado() {
    $("#condiciones").val('1');
    $('#factura_fechaVencimiento').val('<?php echo date("Y-m-d") ?>');
}
//Tipo interno
function tipoCredito() {
    $("#condiciones").val('4');
}
</script>

<script>
$(function () {
    $('.textarea').richText();
})
</script>
<script>
//$.blockUI({ message: '<h3> Generando respaldo de base de datos. Por favor espere...</h3>' });


//$('#posTable').stickyTableHeaders({scrollableArea: $('#product-list')});
//$('#product-list, #category-list, #subcategory-list, #brands-list').perfectScrollbar({suppressScrollX: true});
</script>
<script>
// print order function
function imprimir_facturas3(id_factura){
    VentanaCentrada('../view/pdf/documentos/ticket.php?comp='+id_factura,'Factura','','1024','768','true');
}
</script>
<script>
// print order function
function imprimir_facturas2(id_factura){
    VentanaCentrada('../view/pdf/documentos/a4.php?comp='+id_factura,'Factura','','1024','768','true');
}
</script>