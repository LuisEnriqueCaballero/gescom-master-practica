<!-- Start Breadcrumbbar -->
<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
/* Connect To Database*/
session_start();
require_once "../../config/general.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos

$cuentasBancarias_id = $_GET['cuentasBancarias_id'];
$banco_id            = $_GET['banco_id'];
$tienda              = $_SESSION['tienda'];

$sql_historial              = mysqli_query($con,"select * from movimientos where movimiento_idCuenta='$cuentasBancarias_id'");
$rw_historial               = mysqli_fetch_array($sql_historial);
$movimiento_tipoOperacion   = $rw_historial['movimiento_tipoOperacion'];
$movimiento_concepto        = $rw_historial['movimiento_concepto'];
$movimiento_fecha           = $rw_historial['movimiento_fecha'];
$movimiento_monto           = $rw_historial['movimiento_monto'];
$movimiento_idUsuario       = $rw_historial['movimiento_idUsuario'];
//
$sql_banco                  = mysqli_query($con,"select * from bancos where banco_id='$banco_id'");
$rw_banco                   = mysqli_fetch_array($sql_banco);
$banco_nombre               = $rw_banco['banco_nombre'];
//
$sql_cuenta                 = mysqli_query($con,"select * from cuentasbancarias where cuentasBancarias_idBanco='$banco_id'");
$rw_cuenta                  = mysqli_fetch_array($sql_cuenta);
$cuentasBancarias_inicial   = $rw_cuenta['cuentasBancarias_inicial'];
$cuentasBancarias_actual    = $rw_cuenta['cuentasBancarias_actual'];

include "../modal/agregarMovimiento.php";

$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);

?>

<?php if($a[111]==1 || $a[112]==1){ ?>

<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Historial</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: url(../img/company/cursorH1.png), pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load(1)" style="cursor: url(../img/company/cursorH1.png), pointer;">Contabilidad</a></li>
        <li class="active">Historial</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <div class="row">


                    <div class="col-lg-4">

                        <div class="panel">
                            <div class="panel-body text-center">
                                <img alt="Profile Picture" class="img-md mar-btm" src="../assets/images/svg-icon/bank.svg">
                                <p class="text-lg text-semibold mar-no text-main"><?php echo $banco_nombre; ?></p>
                                <p><a class="btn btn-primary btn-xs" href="#/cc_cuentasBancarias"><i class="fa fa-reply"></i> Regresar</a></p>
                                <ul class="list-unstyled text-center bord-top pad-top mar-no row">
                                    <li class="col-xs-6">
                                        <span class="text-lg text-semibold text-main"><?php echo number_format($cuentasBancarias_inicial,2); ?></span>
                                        <p class="text-muted mar-no">MONTO INICIAL</p>
                                    </li>
                                    <li class="col-xs-6">
                                        <span class="text-lg text-semibold text-main" id="carga_actual"></span>
                                        <p class="text-muted mar-no">MONTO ACTUAL</p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="panel panel-color panel-info">
                            <div class="panel-body">
                                <form class="form-horizontal" role="form" id="datos_cotizacion">
                                    <div class="form-group row">
                                        <div class="col-xs-4">
                                            <div class="input-group">
                                                <input type="text" class="form-control daterange pull-right" value="<?php echo "01" . date('/m/Y') . ' - ' . date('d/m/Y'); ?>" id="range" readonly>
                                                <span class="input-group-btn">
                                                    <button class="btn btn-primary" type="button" onclick='load(1);'><i class='fa fa-search'></i></button>
                                                </span>

                                            </div><!-- /input-group -->
                                        </div>
                                        <input type="hidden" name="cuentasBancarias_id" id="cuentasBancarias_id" value="<?php echo $cuentasBancarias_id; ?>">
                                        <input type="hidden" name="banco_id" id="banco_id" value="<?php echo $banco_id; ?>">
                                        <?php if($a[112]==1){ ?>
                                        <div class="col-xs-2">
                                            <div class="btn-group pull-center">
                                                <button type="button" class="btn btn-mint" data-toggle="modal" data-target="#add-stock" data-id="<?php echo $cuentasBancarias_id; ?>" ><i class="fa fa-plus"></i> Movimiento</button>
                                            </div>
                                        </div>
                                        <?php } ?>
                                        <div class="col-xs-2">
                                            <div class="btn-group pull-center">
                                                <button type="button"  onclick="reporte('<?php echo $cuentasBancarias_id; ?>');" class="btn btn-default" title="Imprimir"><i class='fa fa-print'></i> Imprimir Reporte</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <div class="col-md-12" align="center">
                                    <br>
                                    <div id="loader"></div>
                                    <div id="resultados_ajax"></div>
                                    <div class="clearfix"></div>
                                    <div class='outer_div'></div><!-- Carga los datos ajax -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>

<?php } else { 
    include "../includes/sinAcceso.php";
} ?>

<script src="../js/historialCuentas.js"></script>
<script src="../js/ventanaCentrada.js"></script>
<script>
    $(document).ready( function () {
        $(".UpperCase").on("keypress", function () {
            $input=$(this);
            setTimeout(function () {
                $input.val($input.val().toUpperCase());
            },50);
        })
    })
</script>
<script>
//Registra
$("#add_abono" ).submit(function( event ) {
  $('#actualizar_datos').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
  $('#actualizar_datos').attr("disabled", true);
  var parametros = $(this).serialize();
  $.ajax({
    type: "POST",
    url: "../ajax/nuevoMovimiento.php",
    data: parametros,
    beforeSend: function(objeto){ },
    success: function(datos){
      $("#resultados_ajax").html(datos);
      $('#actualizar_datos').html('Aceptar');
      $('#actualizar_datos').attr("disabled", false);
      var cuentasBancarias_id = $("#cuentasBancarias_id").val();
      var banco_id = $("#banco_id").val();
      $("#carga_actual").load("../ajax/cargaActual.php?cuentasBancarias_id="+cuentasBancarias_id+"&banco_id="+banco_id);
      load(1);
      $("#add_abono")[0].reset();
      $("#movimiento_tipoOperacion").focus();
    }
  });
  event.preventDefault();
})
</script>
<script>
    $(function() {
        var cuentasBancarias_id = $("#cuentasBancarias_id").val();
        var banco_id = $("#banco_id").val();
        $("#carga_actual").load("../ajax/cargaActual.php?cuentasBancarias_id="+cuentasBancarias_id+"&banco_id="+banco_id);
        load(1);

//Date range picker
$('.daterange').daterangepicker({
    buttonClasses: ['btn', 'btn-sm'],
    applyClass: 'btn-success',
    cancelClass: 'btn-default',
    locale: {
        format: "DD/MM/YYYY",
        separator: " - ",
        applyLabel: "Aplicar",
        cancelLabel: "Cancelar",
        fromLabel: "Desde",
        toLabel: "Hasta",
        customRangeLabel: "Custom",
        daysOfWeek: [
        "Do",
        "Lu",
        "Ma",
        "Mi",
        "Ju",
        "Vi",
        "Sa"
        ],
        monthNames: [
        "Enero",
        "Febrero",
        "Marzo",
        "Abril",
        "Mayo",
        "Junio",
        "Julio",
        "Agosto",
        "Septiembre",
        "Octubre",
        "Noviembre",
        "Diciembre"
        ],
        firstDay: 1
    },
    opens: "right"

});
});
</script>
<script>
    function reporte(id) {
        var daterange = $("#range").val();
        var cuentasBancarias_id = $("#cuentasBancarias_id").val();
        var banco_id = $("#banco_id").val();
        VentanaCentrada('../view/pdf/documentos/rep_cb.php?daterange='+daterange+'&cuentasBancarias_id='+cuentasBancarias_id+"&banco_id="+banco_id, 'Reporte', '', '800', '600', 'true');
    }
</script>
<script>
    function imprimir_abono(movimiento_id) {
        VentanaCentrada('../view/pdf/documentos/rep_abonoc.php?movimiento_id=' + movimiento_id, 'Reporte', '', '800', '600', 'true');
    }
</script>