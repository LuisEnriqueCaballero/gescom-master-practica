<?php
session_start();
/* Connect To Database*/
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos
//Incluimos los modales
include "../modal/imgItem.php";
include "../modal/registroItem.php";
include "../modal/editarItem.php";
include "../modal/eliminarItem.php";
include "../modal/especificacionesItem.php";
include "../modal/fichaItem.php";

$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);
?>
<?php if($a[34]==1 || $a[35]==1 || $a[36]==1 || $a[37]==1 || $a[38]==1 || $a[39]==1 || $a[40]==1){ ?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">&Iacute;tems</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: url(../img/company/cursorH1.png), pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load(1)" style="cursor: url(../img/company/cursorH1.png), pointer;">Art&iacute;culos</a></li>
        <li class="active">&Iacute;tems</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <div id="ldng_cat" style="text-align: center;"></div>
                <div id="resultados_ajax"></div>
                <div class='outer_div_cat'></div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<?php } else { 
    include "../includes/sinAcceso.php";
} ?>
<script src="../js/items.js"></script>