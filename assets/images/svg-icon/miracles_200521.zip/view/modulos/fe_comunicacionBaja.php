<?php
session_start();
include "../modal/enviarWhatsApp.php";
include "../modal/enviarCorreo.php";
include "../modal/enviarBaja.php";

$empresa = $_SESSION['datosEmpresa_id'];

$sql_empresa=mysqli_query($con,"select * from datosempresa where datosEmpresa_id=$empresa");
$rw_tienda=mysqli_fetch_array($sql_empresa);
$datosEmpresa_ruc=$rw_tienda['datosEmpresa_ruc'];

$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);

?>
<?php if($a[93]==1){ ?>

<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Comunicaci&oacute;n Baja</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load();" style="cursor: pointer;">Fact. Electr&oacute;nica</a></li>
        <li class="active">Historial Comunicaci&oacute;n Baja</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <div class="input-group">
                    <div class="input-group mar-btm">
                        <input type="text" class="form-control daterange pull-right" value="<?php echo "01" . date('/m/Y') . ' - ' . date('d/m/Y'); ?>" id="range" readonly>
                        <div class="input-group-addon btn btn-primary" onclick='load(1);'><i class='fa fa-search'></i></div>
                    </div>
                </div>
                <div id="ldng_cat" style="text-align: center;"></div>
                <div id="resultados_ajax"></div>
                <div class='outer_div_cat'></div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>

<?php } else { 
    include "../includes/sinAcceso.php";
} ?>

<script src="../js/comunicacionBaja.js"></script>
<script src="../js/ventanaCentrada.js"></script>
<script>
$(function () {
        //Initialize Select2 Elements
        $(".select2").select2();
    });
  $(function() {
    load(1);

//Date range picker
$('.daterange').daterangepicker({
  buttonClasses: ['btn', 'btn-sm'],
  applyClass: 'btn-primary',
  cancelClass: 'btn-danger',
  locale: {
    format: "DD/MM/YYYY",
    separator: " - ",
    applyLabel: "Aplicar",
    cancelLabel: "Cancelar",
    fromLabel: "Desde",
    toLabel: "Hasta",
    customRangeLabel: "Personalizado",
    daysOfWeek: [
    "Do",
    "Lu",
    "Ma",
    "Mi",
    "Ju",
    "Vi",
    "Sa"
    ],
    monthNames: [
    "Enero",
    "Febrero",
    "Marzo",
    "Abril",
    "Mayo",
    "Junio",
    "Julio",
    "Agosto",
    "Septiembre",
    "Octubre",
    "Noviembre",
    "Diciembre"
    ],
  },
  ranges: {
       'Hoy': [moment(), moment()],
       'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
       'Ultimos 7 dias': [moment().subtract(6, 'days'), moment()],
       'Ultimos 30 dias': [moment().subtract(29, 'days'), moment()],
       'Este mes': [moment().startOf('month'), moment().endOf('month')],
       'El mes pasado': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    },
  opens: "right"

});
});
</script>
<script>
function xml(id_factura){
    VentanaCentrada('../view/pdf/documentos/documentos/<?php echo $datosEmpresa_ruc; ?>/'+id_factura,'Factura','','1024','768','true');
}
        
        function cdrxml(id_factura){
    VentanaCentrada('../view/pdf/documentos/cdrdocumentos/<?php echo $datosEmpresa_ruc; ?>/'+id_factura,'Documento de baja','','1024','768','true');
}
        
         function imprimir_facturas2(id_factura){
    VentanaCentrada('../view/pdf/documentos/a4.php?comp='+id_factura,'Factura','','1024','768','true');
}
        function imprimir_facturas3(id_factura){
    VentanaCentrada('../view/pdf/documentos/ticket.php?comp='+id_factura,'Factura','','1024','768','true');
}
</script>