<?php
session_start();

include "../modal/enviarMktMail.php";
include "../modal/enviarMktMasivo.php";
include "../modal/editarPlantilla.php";
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos

$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo); 
?>
<?php if($a[24]==1){ ?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Mail Marketing</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: url(../img/company/cursorH1.png), pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load(1);" style="cursor: url(../img/company/cursorH1.png), pointer;">Marketing</a></li>
        <li class="active">Mail Marketing</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <div id="ldng_cat" style="text-align: center;"></div>
                <div id="resultados_ajax"></div>
                <div class='outer_div_cat'></div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<?php } else { 
    include "../includes/sinAcceso.php";
} ?>
<script src="../js/mailMarketing.js"></script>