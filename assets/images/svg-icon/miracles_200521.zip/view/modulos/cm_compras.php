<?php
session_start();
//include "../modal/enviarWhatsAppCot.php";
//include "../modal/enviarCorreoCot.php";
include "../modal/eliminarCompra.php";
include "../modal/adjuntocompra.php";
?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Compras</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a onclick="cargar_contenido('contenido_principal','modulos/ss_inicio.php')" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="cargar_contenido('contenido_principal','modulos/cm_compras.php')" style="cursor: pointer;">Egresos</a></li>
        <li class="active">Historial Compras</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <div class="input-group">
                    <div class="input-group mar-btm">
                        <input type="text" class="form-control daterange pull-right" value="<?php echo "01" . date('/m/Y') . ' - ' . date('d/m/Y'); ?>" id="range" readonly>
                        <div class="input-group-addon btn btn-primary" onclick='load(1);'><i class='fa fa-search'></i></div>
                    </div>
                </div>
                <div id="ldng_cat" style="text-align: center;"></div>
                <div id="resultados_ajax"></div>
                <div class='outer_div_cat'></div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<script src="../js/compras.js"></script>
<script src="../js/ventanaCentrada.js"></script>
<script>
$(function () {
        //Initialize Select2 Elements
        $(".select2").select2();
    });
  $(function() {
    load(1);

//Date range picker
$('.daterange').daterangepicker({
  buttonClasses: ['btn', 'btn-sm'],
  applyClass: 'btn-primary',
  cancelClass: 'btn-danger',
  locale: {
    format: "DD/MM/YYYY",
    separator: " - ",
    applyLabel: "Aplicar",
    cancelLabel: "Cancelar",
    fromLabel: "Desde",
    toLabel: "Hasta",
    customRangeLabel: "Personalizado",
    daysOfWeek: [
    "Do",
    "Lu",
    "Ma",
    "Mi",
    "Ju",
    "Vi",
    "Sa"
    ],
    monthNames: [
    "Enero",
    "Febrero",
    "Marzo",
    "Abril",
    "Mayo",
    "Junio",
    "Julio",
    "Agosto",
    "Septiembre",
    "Octubre",
    "Noviembre",
    "Diciembre"
    ],
  },
  ranges: {
       'Hoy': [moment(), moment()],
       'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
       'Ultimos 7 dias': [moment().subtract(6, 'days'), moment()],
       'Ultimos 30 dias': [moment().subtract(29, 'days'), moment()],
       'Este mes': [moment().startOf('month'), moment().endOf('month')],
       'El mes pasado': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    },
  opens: "right"

});
});
</script>
<script>
//
function carga_img(id_producto) {
  $(".outer_img").load("../ajax/adjuntoCompra.php?id_producto="+id_producto);
}
//
function upload_image_mod(id_producto){
  $("#resultados_ajax").text('Cargando...');
  var inputFileImage = document.getElementById("imagefile_mod");
  var file = inputFileImage.files[0];
  var data = new FormData();
  data.append('imagefile_mod',file);
  data.append('id_producto',id_producto);



  $.ajax({
      url: "../ajax/cargaAdjuntoCompra.php",        // Url to which the request is send
      type: "POST",             // Type of request to be send, called as method
      data: data,         // Data sent to server, a set of key/value pairs (i.e. form fields and values)
      contentType: false,       // The content type used when sending data to the server.
      cache: false,             // To unable request pages to be cached
      processData:false,        // To send DOMDocument or non processed data file it is set to false
      success: function(data)   // A function to be called if request succeeds
      {
        $("#resultados_ajax").html(data);
        $('#imagefile_mod').addClass("ocultar_boton");
        load(1);
      }
    });
  event.preventDefault();
}
</script>
<script>
function imprimir_facturas2(id_factura){
    VentanaCentrada('../img/compras/compra_'+id_factura+'.pdf','Factura','','1024','768','true');
}
//Muestra historial a4
function dCompraPDF(){
    var range=$("#range").val();
    VentanaCentrada('../view/pdf/documentos/a4_historico_cm.php?action=ajax&range='+range,'Factura','','1024','768','true');
}
//Descarga historial excel
function dCompraExcel(){
    var range=$("#range").val();
    window.open('../view/excel/historico_cm.php?action=ajax&range='+range,'_blank');
}
</script>