<!-- Start Breadcrumbbar -->
<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
//include '../../ajax/is_logged.php'; //Archivo verifica que el usario que intenta acceder a la URL esta logueado
/* Connect To Database*/
session_start();
require_once "../../config/general.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos

$empresa    = $_SESSION['datosEmpresa_id'];
$tienda1    = $_SESSION['tienda'];
$cadena = $_GET['factura_id'];
$factura_id = substr($cadena, 0, -4);
//
$id_comp = 8;

$sql         = mysqli_query($con, "select * from seriescorrelativos where serieCorrelativo_idTipoComprobante ='$id_comp' and serieCorrelativo_sucursal='$tienda1'");
$rw          = mysqli_fetch_array($sql);
$serieCorrelativo_folio  = $rw['serieCorrelativo_folio'];
$serieCorrelativo_numero  = $rw['serieCorrelativo_numero']+1;

$numero_factura = str_pad($serieCorrelativo_numero, 8, "0", STR_PAD_LEFT);
//
$sql="select * from facturas, clientes where facturas.factura_idCliente=clientes.cliente_id and facturas.factura_id=$factura_id"; 
$rs=mysqli_query($con,$sql);
while($row= mysqli_fetch_array($rs)){
    $cliente_id=$row['cliente_id'];
    $cliente_nombre=$row['cliente_nombre'];
    $cliente_documento=$row['cliente_documento'];
    $factura_fecha=$row['factura_fecha'];
    $factura_moneda=$row['factura_moneda'];
    $factura_folio=$row['factura_folio'];
    $factura_correlativo=$row['factura_correlativo'];
    $factura_tipo=$row['factura_tipo'];
    $factura_sucursal=$row['factura_sucursal'];
    $cliente_direccion=$row['cliente_direccion'];
    $cliente_ubigeo=$row['cliente_ubigeo'];
    $cliente_contacto=$row['cliente_contacto'];
    $cliente_telefono=$row['cliente_telefono'];
}
//
$dia1=date("d",strtotime($factura_fecha)); 
$mes1=date("m",strtotime($factura_fecha));  
$ano1=date("Y",strtotime($factura_fecha));

$fecha3=$dia1."/".$mes1."/".$ano1;
//
$sql_empresa         = mysqli_query($con, "select * from datosempresa where datosEmpresa_id=$empresa");
$rw_empresa          = mysqli_fetch_array($sql_empresa);
$datosEmpresa_direccion  = $rw_empresa['datosEmpresa_direccion'];
$datosEmpresa_ubigeo = $rw_empresa['datosEmpresa_ubigeo'];
//
$sql_sucursal         = mysqli_query($con, "select * from sucursales where sucursal_tienda=$tienda1");
$rw_sucursal          = mysqli_fetch_array($sql_sucursal);
$sucursal_direccion   = $rw_sucursal['sucursal_direccion'];
?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Gu&iacute;a Remisi&oacute;n</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: url(../img/company/cursorH1.png), pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load(1);" style="cursor: url(../img/company/cursorH1.png), pointer;">Ventas</a></li>
        <li class="active">Gu&iacute;a Remisi&oacute;n</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <form role="form" id="datos_guia" autocomplete="off">
                    <div id="resultados_ajax"></div>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: red;">RECEPCIONISTA / DOCUMENTO ASOCIADO:</label>
                        <div class="col-md-6">
                            <div class="">
                                <label for="razon_social">Raz&oacute;n Social:</label>
                                <input type="text" class="form-control" autocomplete="off" id="razon_social" name="razon_social" readonly="" value="<?php echo $cliente_nombre; ?>">
                                <input id="id_cliente" name="id_cliente" type='hidden' value="<?php echo $cliente_id; ?>">
                                <input id="id_factura" name="id_factura" type='hidden' value="<?php echo $factura_id; ?>">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="">
                                <label for="ruc">RUC:</label>
                                <input type="text" class="form-control" autocomplete="off" id="ruc" name="ruc" readonly="" value="<?php echo $cliente_documento; ?>">
                                <input type="hidden" name="guia_moneda" id="guia_moneda" value="<?php echo $factura_moneda; ?>">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="">
                                <label for="fecha">Fecha:</label>
                                <input type="text" class="form-control" autocomplete="off" id="fecha" name="fecha" readonly="" value="<?php echo $fecha3; ?>">
                            </div>
                        </div>

                        <div class="col-md-1">
                            <div class="">
                                <label for="folio">Folio:</label>
                                <input type="text" class="form-control" autocomplete="off" id="folio" name="folio" readonly="" value="<?php echo $factura_folio; ?>">
                            </div>
                        </div>

                        <div class="col-md-1">
                            <div class="">
                                <label for="numero">N&uacute;mero:</label>
                                <input type="text" class="form-control" autocomplete="off" id="numero" name="numero" readonly="" value="<?php echo $factura_correlativo; ?>">
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: red;">DATOS DE LA GU&Iacute;A:</label>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="serie_remision">Serie Remisi&oacute;n:</label>
                                <input type="text" class="form-control" autocomplete="off" id="serie_remision" name="serie_remision" readonly="" value="<?php echo $serieCorrelativo_folio; ?>">
                                <input id="id_cliente" name="id_cliente" type='hidden'>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="numero_guia">N&uacute;mero Gu&iacute;a:</label>
                                <input type="text" class="form-control" autocomplete="off" readonly="" id="numero_guia" value="<?php echo $numero_factura; ?>">
                                <input type="hidden" class="form-control" autocomplete="off" name="numero_guia" readonly="" value="<?php echo $serieCorrelativo_numero; ?>">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="fecha_traslado">Fecha Traslado:</label>
                                <input type="date" class="form-control" autocomplete="off" id="fecha_traslado" name="fecha_traslado">
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="motivo_traslado">Motivo Traslado:</label>
                                <select class="form-control" id="motivo_traslado" name="motivo_traslado" required>
                                    <option value="">-- Selecciona Motivo de Traslado --</option>
                                    <option value="01-VENTA">VENTA</option>
                                    <option value="14-VENTA SUJETA A CONFIRMACION DEL COMPRADOR">VENTA SUJETA A CONFIRMACION DEL COMPRADOR</option>
                                    <option value="02-COMPRA">COMPRA</option>
                                    <option value="04-TRASLADO ENTRE ESTABLECIMIENTOS DE LA MISMA EMPRESA">TRASLADO ENTRE ESTABLECIMIENTOS DE LA MISMA EMPRESA</option>
                                    <option value="18-TRASLADO EMISOR ITINERANTE CP">TRASLADO EMISOR ITINERANTE CP</option>
                                    <option value="08-IMPORTACION">IMPORTACION</option>
                                    <option value="09-EXPORTACION">EXPORTACION</option>
                                    <option value="19-TRASLADO A ZONA PRIMARIA">TRASLADO A ZONA PRIMARIA</option>
                                    <option value="13-OTROS">OTROS</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: red;">DATOS DE PARTIDA / PESO / PAQUETES:</label>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="direccion_partida">Direcci&oacute;n Partida:</label>
                                <input type="text" class="form-control" autocomplete="off" id="direccion_partida" name="direccion_partida" value="<?php echo $sucursal_direccion; ?>" onKeyUp="this.value=this.value.toUpperCase();">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="ubigeo_partida">Ubigeo Partida:</label>
                                <input type="text" class="form-control" autocomplete="off" id="ubigeo_partida" name="ubigeo_partida" value="<?php echo $datosEmpresa_ubigeo; ?>" onKeyUp="this.value=this.value.toUpperCase();">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="peso">Peso:</label>
                                <input type="text" class="form-control" autocomplete="off" id="peso" name="peso" value="0.00" onKeyUp="this.value=this.value.toUpperCase();">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="numero_paquetes">N&uacute;mero Paquetes:</label>
                                <input type="text" class="form-control" autocomplete="off" id="numero_paquetes" name="numero_paquetes" value="0" onKeyUp="this.value=this.value.toUpperCase();">
                            </div>
                        </div>


                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="ruc_transporte">RUC Transporte:</label>
                                <input type="text" class="form-control" autocomplete="off" id="ruc_transporte" name="ruc_transporte" onKeyUp="this.value=this.value.toUpperCase();">
                                <input id="id_cliente" name="id_cliente" type='hidden'>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="razon_social_transporte">Raz&oacute;n Social Transporte:</label>
                                <input type="text" class="form-control" autocomplete="off" id="razon_social_transporte" name="razon_social_transporte" onKeyUp="this.value=this.value.toUpperCase();">
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="tipo_transporte">Tipo Transporte:</label>
                                <select class="form-control" id="tipo_transporte" name="tipo_transporte" required>
                                    <option value="">-- Selecciona Tipo Transporte --</option>
                                    <option value="01">TRANSPORTE P&Uacute;BLICO</option>
                                    <option value="02">TRANSPORTE PRIVADO</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: red;">DIRECCI&Oacute;N DESTINO:</label>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="direccion_llegada">Direcci&oacute;n Llegada:</label>
                                <input type="text" class="form-control" autocomplete="off" id="direccion_llegada" name="direccion_llegada" value="<?php echo $cliente_direccion; ?>" onKeyUp="this.value=this.value.toUpperCase();">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="contacto_destino">Contacto Destino:</label>
                                <input type="text" class="form-control" autocomplete="off" id="contacto_destino" name="contacto_destino" value="<?php echo $cliente_contacto; ?>" onKeyUp="this.value=this.value.toUpperCase();">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="telefono_destino">Tel&eacute;fono Destino:</label>
                                <input type="text" class="form-control" autocomplete="off" id="telefono_destino" name="telefono_destino" value="<?php echo $cliente_telefono; ?>" onKeyUp="this.value=this.value.toUpperCase();">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="ubigeo_destino">Ubigeo Destino:</label>
                                <input type="text" class="form-control" autocomplete="off" id="ubigeo_destino" name="ubigeo_destino" value="<?php echo $cliente_ubigeo; ?>" onKeyUp="this.value=this.value.toUpperCase();">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="fecha_llegada">Fecha Llegada:</label>
                                <input type="date" class="form-control" autocomplete="off" id="fecha_llegada" name="fecha_llegada">
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label class="col-md-12 col-form-label" style="color: red;">UNIDAD DE TRANSPORTE / CONDUCTOR:</label>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="marca_placa">Veh&iacute;culo Marca y Placa Nro:</label>
                                <input type="text" class="form-control" autocomplete="off" id="marca_placa" name="marca_placa" onKeyUp="this.value=this.value.toUpperCase();">
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="certificado_inscripcion">Certificado de Inscripci&oacute;n Nro:</label>
                                <input type="text" class="form-control" autocomplete="off" id="certificado_inscripcion" name="certificado_inscripcion" onKeyUp="this.value=this.value.toUpperCase();">
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="licencia_conducir">Licencia de Conducir:</label>
                                <input type="text" class="form-control" autocomplete="off" id="licencia_conducir" name="licencia_conducir" onKeyUp="this.value=this.value.toUpperCase();">
                            </div>
                        </div>
                    </div>

                    <div style="position: fixed;z-index: 999;right:0px;top: 50%; box-shadow: 2px 2px 10px #666; border-top-left-radius: 10px; border-bottom-left-radius: 10px;">
                        <button type="submit" id="guardar_guia" class="btn btn-primary" aria-haspopup="true" aria-expanded="false" style="border-bottom-left-radius: 0px; border-bottom-right-radius: 0px; border-top-right-radius: 0px; border-top-left-radius: 10px;">
                            Procesar Gu&iacute;a
                        </button>
                        <br>
                        <div class="btn btn-info" onclick="imprimir_facturas2('<?php echo $factura_id;?>');" style="width: 100%; border-top-left-radius: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px; border-bottom-left-radius: 0px;">
                            Ver Factura
                        </div>
                        <br>
                        <a class="btn btn-default" href="#/fe_guiaRemision" style="width: 100%; border-top-left-radius: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px; border-bottom-left-radius: 10px; cursor: pointer;">
                            Ver Gu&iacute;as
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>

<script src="../js/nuevaGuiaRemision.js"></script>
<script src="../js/ventanaCentrada.js"></script>
<script>
    function imprimir_facturas2(id_factura){
        VentanaCentrada('../view/pdf/documentos/a4.php?comp='+id_factura,'Factura','','1024','768','true');
    }
</script>
<script>
    //
$("#datos_guia" ).submit(function( event ) {
  $('#guardar_guia').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
  $('#guardar_guia').attr("disabled", true);

  var parametros = $(this).serialize();
  $.ajax({
    type: "POST",
    url: "../ajax/nuevoGuiaRemision.php",
    data: parametros,
    beforeSend: function(objeto){ },
    success: function(datos){
      $("#resultados_ajax").html(datos);
      $('#guardar_guia').html('Procesar Gu&iacute;a');
      $('#guardar_guia').attr("disabled", false);
      //load(1);
      var ruta = $('#contenido_principal').load('../view/modulos/fe_guiaRemision.php');
      setTimeout(ruta,2000);
      //$("#add_abono")[0].reset();
      //$("#nom_categoria").focus();
    }
  });
  event.preventDefault();
})
</script>