<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
include("../../config/db.php");
include("../../config/conexion.php");
//Verificamos si el usuario esta logueado, si no esta logueado lo redirecciona al login, si ya esta logueado se queda en el panel
session_start();
if (!isset($_SESSION['user_login_status']) and $_SESSION['user_login_status'] != 1) {
   header("location: ../login/");
   exit;
}

$tienda1    = $_SESSION['tienda'];

$sql_series = "select * from seriescorrelativos where serieCorrelativo_sucursal='$tienda1'";
$result_series = mysqli_query($con, $sql_series);
while ($rw_series = mysqli_fetch_array($result_series, MYSQLI_ASSOC)) {
    if($rw_series['serieCorrelativo_idTipoComprobante']==1){
    $factura=$rw_series['serieCorrelativo_folio'];
    $folio1=$rw_series['serieCorrelativo_numero'];
    
    }
    if($rw_series['serieCorrelativo_idTipoComprobante']==2){
    $boleta=$rw_series['serieCorrelativo_folio'];
    $folio2=$rw_series['serieCorrelativo_numero'];
    }
    if($rw_series['serieCorrelativo_idTipoComprobante']==3){
    $nota_credito=$rw_series['serieCorrelativo_folio'];
    $folio3=$rw_series['serieCorrelativo_numero'];
    }
    if($rw_series['serieCorrelativo_idTipoComprobante']==4){
    $nota_debito=$rw_series['serieCorrelativo_folio'];
    $folio4=$rw_series['serieCorrelativo_numero'];
    }
    if($rw_series['serieCorrelativo_idTipoComprobante']==5){
    $folio5=$rw_series['serieCorrelativo_numero'];
    $nota_venta=$rw_series['serieCorrelativo_folio'];
    }
    if($rw_series['serieCorrelativo_idTipoComprobante']==6){
    $nota_credito1=$rw_series['serieCorrelativo_folio'];
    $folio6=$rw_series['serieCorrelativo_numero'];
    }
    if($rw_series['serieCorrelativo_idTipoComprobante']==7){
    $nota_debito1=$rw_series['serieCorrelativo_folio'];
    $folio7=$rw_series['serieCorrelativo_numero'];
    }
    if($rw_series['serieCorrelativo_idTipoComprobante']==8){
    $folio8=$rw_series['serieCorrelativo_numero'];
    $remision=$rw_series['serieCorrelativo_folio'];
    }
    if($rw_series['serieCorrelativo_idTipoComprobante']==9){
    $cotizacion=$rw_series['serieCorrelativo_folio'];
    $folio9=$rw_series['serieCorrelativo_numero'];
    }
}

$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);

if ($a[194]==1) {
    $disabled = "";
} else {
    $disabled = "disabled";
}

?>
<?php if($a[193]==1 || $a[194]==1){ ?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Series Correlativos</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load(1);" style="cursor: pointer;">Ajustes</a></li>
        <li class="active">Series Correlativos</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <div id="ldng_cat" style="text-align: center;"></div>
                <div class="row">
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">Factura</label>
                        <input type="text" class="form-control txt_serief" placeholder="Factura" onKeyUp="this.value=this.value.toUpperCase();" maxlength="4" value="<?php echo $factura; ?>" id="serie_factura" name="serie_factura" <?php echo $disabled; ?>>
                    </div>
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">N&uacute;mero</label>
                        <input type="number" class="form-control" placeholder="N&uacute;mero" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $folio1; ?>" id="numero_factura" name="numero_factura" <?php echo $disabled; ?>>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">Boleta</label>
                        <input type="text" class="form-control" placeholder="Boleta" onKeyUp="this.value=this.value.toUpperCase();" maxlength="4" value="<?php echo $boleta; ?>" id="serie_boleta" name="serie_boleta" <?php echo $disabled; ?>>
                    </div>
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">N&uacute;mero</label>
                        <input type="number" class="form-control" placeholder="N&uacute;mero" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $folio2; ?>" id="numero_boleta" name="numero_boleta" <?php echo $disabled; ?>>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">Nota Cr&eacute;dito Factura</label>
                        <input type="text" class="form-control" placeholder="Nota Cr&eacute;dito Factura" onKeyUp="this.value=this.value.toUpperCase();" maxlength="4" value="<?php echo $nota_credito; ?>" id="serie_ncF" name="serie_ncF" <?php echo $disabled; ?>>
                    </div>
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">N&uacute;mero</label>
                        <input type="number" class="form-control" placeholder="N&uacute;mero" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $folio3; ?>" id="numero_ncf" name="numero_ncf" <?php echo $disabled; ?>>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">Nota D&eacute;dito Factura</label>
                        <input type="text" class="form-control" placeholder="Nota D&eacute;dito Factura" onKeyUp="this.value=this.value.toUpperCase();" maxlength="4" value="<?php echo $nota_debito; ?>" id="serie_ndF" name="serie_ndF" <?php echo $disabled; ?>>
                    </div>
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">N&uacute;mero</label>
                        <input type="number" class="form-control" placeholder="N&uacute;mero" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $folio4; ?>" id="numero_ndF" name="numero_ndF" <?php echo $disabled; ?>>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">Nota Cr&eacute;dito Boleta</label>
                        <input type="text" class="form-control" placeholder="Nota Cr&eacute;dito Boleta" onKeyUp="this.value=this.value.toUpperCase();" maxlength="4" value="<?php echo $nota_credito1; ?>" id="serie_ncB" name="serie_ncB" <?php echo $disabled; ?>>
                    </div>
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">N&uacute;mero</label>
                        <input type="number" class="form-control" placeholder="N&uacute;mero" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $folio6; ?>" id="numero_ncB" name="numero_ncB" <?php echo $disabled; ?>>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">Nota D&eacute;dito Boleta</label>
                        <input type="text" class="form-control" placeholder="Nota D&eacute;dito Boleta" onKeyUp="this.value=this.value.toUpperCase();" maxlength="4" value="<?php echo $nota_debito1; ?>" id="serie_ndB" name="serie_ndB" <?php echo $disabled; ?>>
                    </div>
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">N&uacute;mero</label>
                        <input type="number" class="form-control" placeholder="N&uacute;mero" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $folio7; ?>" id="numero_ndB" name="numero_ndB" <?php echo $disabled; ?>>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">Nota Pedido</label>
                        <input type="text" class="form-control" placeholder="Nota Pedido" onKeyUp="this.value=this.value.toUpperCase();" maxlength="4" value="<?php echo $nota_venta; ?>" id="serie_notaVenta" name="serie_notaVenta" <?php echo $disabled; ?>>
                    </div>
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">N&uacute;mero</label>
                        <input type="number" class="form-control" placeholder="N&uacute;mero" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $folio5; ?>" id="numero_notaVenta" name="numero_notaVenta" <?php echo $disabled; ?>>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">Gu&iacute;a Remisi&oacute;n</label>
                        <input type="text" class="form-control" placeholder="Gu&iacute; Remisi&oacute;n" onKeyUp="this.value=this.value.toUpperCase();" maxlength="4" value="<?php echo $remision; ?>" id="serie_guiaRemision" name="serie_guiaRemision" <?php echo $disabled; ?>>
                    </div>
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">N&uacute;mero</label>
                        <input type="number" class="form-control" placeholder="N&uacute;mero" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $folio8; ?>" id="numero_guiaRemision" name="numero_guiaRemision" <?php echo $disabled; ?>>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">Cotizaci&oacute;n</label>
                        <input type="text" class="form-control" placeholder="Cotizaci&oacute;n" onKeyUp="this.value=this.value.toUpperCase();" maxlength="4" value="<?php echo $cotizacion; ?>" id="serie_cotizacion" name="serie_cotizacion" <?php echo $disabled; ?>>
                    </div>
                    <div class="col-md-6">
                        <label for="mod_nombre" class="control-label">N&uacute;mero</label>
                        <input type="number" class="form-control" placeholder="N&uacute;mero" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $folio9; ?>" id="numero_cotizacion" name="numero_cotizacion" <?php echo $disabled; ?>>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>

<?php } else { 
    include "../includes/sinAcceso.php";
} ?>

<script src="../js/seriesCorrelativos.js"></script>
<script>
$(document).ready(function () {
    var serie_factura = $("#serie_factura");
    serie_factura.off('blur');
    serie_factura.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);

        desc = $(this).val();
    //Fin validacion
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/editarSerieF.php",
        data: parametros,
        success: function(datos) {
           $("#resultados_ajax2").html(datos);
           toastr.options = {
              "closeButton":false,
              "progressBar": false
            };
            //toastr["success"]("Serie actualizada", "Bien hecho!");
            vt.success("La serie ha sido actualizada exitosamente.", {
                duration: 3000,
                fadeDuration: 200,
                title: "Bien hecho!",
                position: "top-right"
            })
       }
    });
        // }
    });


});
</script>

<script>
$(document).ready(function () {
    var numero_factura = $("#numero_factura");
    numero_factura.off('blur');
    numero_factura.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
    // if(keycode == '13'){
        //id_tmp = $(this).attr("id");
        desc1 = $(this).val();
        //id_pr = $("#id_pr").val();
         //Inicia validacion
         
//Fin validacion
var parametros = $(this).serialize();
$.ajax({
    type: "POST",
    url: "../ajax/editarNumeroF.php",
    data: parametros,
    success: function(datos) {
       $("#resultados_ajax2").html(datos);
       toastr.options = {
          "closeButton":false,
          "progressBar": false
        };
        //toastr["success"]("N&uacute;mero actualizado", "Bien hecho!");
        vt.success("El n&uacute;mero ha sido actualizado exitosamente.", {
            duration: 3000,
            fadeDuration: 200,
            title: "Bien hecho!",
            position: "top-right"
        })
        //console.log(/*id_tmp,*/desc);
   }
});
    // }
});


});
</script>

<script>
$(document).ready(function () {
    var serie_boleta = $("#serie_boleta");
    serie_boleta.off('blur');
    serie_boleta.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);

        desc = $(this).val();
    //Fin validacion
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/editarSerieB.php",
        data: parametros,
        success: function(datos) {
           $("#resultados_ajax2").html(datos);
           toastr.options = {
              "closeButton":false,
              "progressBar": false
            };
            //toastr["success"]("Serie actualizada", "Bien hecho!");
            vt.success("La serie ha sido actualizada exitosamente.", {
                duration: 3000,
                fadeDuration: 200,
                title: "Bien hecho!",
                position: "top-right"
            })
       }
    });
        // }
    });


});
</script>

<script>
$(document).ready(function () {
    var numero_boleta = $("#numero_boleta");
    numero_boleta.off('blur');
    numero_boleta.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
    // if(keycode == '13'){
        //id_tmp = $(this).attr("id");
        desc1 = $(this).val();
        //id_pr = $("#id_pr").val();
         //Inicia validacion
         
//Fin validacion
var parametros = $(this).serialize();
$.ajax({
    type: "POST",
    url: "../ajax/editarNumeroB.php",
    data: parametros,
    success: function(datos) {
       $("#resultados_ajax2").html(datos);
       toastr.options = {
          "closeButton":false,
          "progressBar": false
        };
        //toastr["success"]("N&uacute;mero actualizado", "Bien hecho!");
        vt.success("El n&uacute;mero ha sido actualizado exitosamente.", {
            duration: 3000,
            fadeDuration: 200,
            title: "Bien hecho!",
            position: "top-right"
        })
        //console.log(/*id_tmp,*/desc);
   }
});
    // }
});


});
</script>

<script>
$(document).ready(function () {
    var serie_ncF = $("#serie_ncF");
    serie_ncF.off('blur');
    serie_ncF.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);

        desc = $(this).val();
    //Fin validacion
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/editarSerieNCF.php",
        data: parametros,
        success: function(datos) {
           $("#resultados_ajax2").html(datos);
           toastr.options = {
              "closeButton":false,
              "progressBar": false
            };
            //toastr["success"]("Serie actualizada", "Bien hecho!");
            vt.success("La serie ha sido actualizada exitosamente.", {
                duration: 3000,
                fadeDuration: 200,
                title: "Bien hecho!",
                position: "top-right"
            })
       }
    });
        // }
    });


});
</script>

<script>
$(document).ready(function () {
    var numero_ncf = $("#numero_ncf");
    numero_ncf.off('blur');
    numero_ncf.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
    // if(keycode == '13'){
        //id_tmp = $(this).attr("id");
        desc1 = $(this).val();
        //id_pr = $("#id_pr").val();
         //Inicia validacion
         
//Fin validacion
var parametros = $(this).serialize();
$.ajax({
    type: "POST",
    url: "../ajax/editarNumeroNCF.php",
    data: parametros,
    success: function(datos) {
       $("#resultados_ajax2").html(datos);
       toastr.options = {
          "closeButton":false,
          "progressBar": false
        };
        //toastr["success"]("N&uacute;mero actualizado", "Bien hecho!");
        vt.success("El n&uacute;mero ha sido actualizado exitosamente.", {
            duration: 3000,
            fadeDuration: 200,
            title: "Bien hecho!",
            position: "top-right"
        })
        //console.log(/*id_tmp,*/desc);
   }
});
    // }
});


});
</script>

<script>
$(document).ready(function () {
    var serie_ndF = $("#serie_ndF");
    serie_ndF.off('blur');
    serie_ndF.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);

        desc = $(this).val();
    //Fin validacion
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/editarSerieNDF.php",
        data: parametros,
        success: function(datos) {
           $("#resultados_ajax2").html(datos);
           toastr.options = {
              "closeButton":false,
              "progressBar": false
            };
            //toastr["success"]("Serie actualizada", "Bien hecho!");
            vt.success("La serie ha sido actualizada exitosamente.", {
                duration: 3000,
                fadeDuration: 200,
                title: "Bien hecho!",
                position: "top-right"
            })
       }
    });
        // }
    });


});
</script>

<script>
$(document).ready(function () {
    var numero_ndF = $("#numero_ndF");
    numero_ndF.off('blur');
    numero_ndF.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
    // if(keycode == '13'){
        //id_tmp = $(this).attr("id");
        desc1 = $(this).val();
        //id_pr = $("#id_pr").val();
         //Inicia validacion
         
//Fin validacion
var parametros = $(this).serialize();
$.ajax({
    type: "POST",
    url: "../ajax/editarNumeroNDF.php",
    data: parametros,
    success: function(datos) {
       $("#resultados_ajax2").html(datos);
       toastr.options = {
          "closeButton":false,
          "progressBar": false
        };
        //toastr["success"]("N&uacute;mero actualizado", "Bien hecho!");
        vt.success("El n&uacute;mero ha sido actualizado exitosamente.", {
            duration: 3000,
            fadeDuration: 200,
            title: "Bien hecho!",
            position: "top-right"
        })
        //console.log(/*id_tmp,*/desc);
   }
});
    // }
});


});
</script>

<script>
$(document).ready(function () {
    var serie_ncB = $("#serie_ncB");
    serie_ncB.off('blur');
    serie_ncB.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);

        desc = $(this).val();
    //Fin validacion
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/editarSerieNCB.php",
        data: parametros,
        success: function(datos) {
           $("#resultados_ajax2").html(datos);
           toastr.options = {
              "closeButton":false,
              "progressBar": false
            };
            //toastr["success"]("Serie actualizada", "Bien hecho!");
            vt.success("La serie ha sido actualizada exitosamente.", {
                duration: 3000,
                fadeDuration: 200,
                title: "Bien hecho!",
                position: "top-right"
            })
       }
    });
        // }
    });


});
</script>

<script>
$(document).ready(function () {
    var numero_ncB = $("#numero_ncB");
    numero_ncB.off('blur');
    numero_ncB.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
    // if(keycode == '13'){
        //id_tmp = $(this).attr("id");
        desc1 = $(this).val();
        //id_pr = $("#id_pr").val();
         //Inicia validacion
         
//Fin validacion
var parametros = $(this).serialize();
$.ajax({
    type: "POST",
    url: "../ajax/editarNumeroNCB.php",
    data: parametros,
    success: function(datos) {
       $("#resultados_ajax2").html(datos);
       toastr.options = {
          "closeButton":false,
          "progressBar": false
        };
        //toastr["success"]("N&uacute;mero actualizado", "Bien hecho!");
        vt.success("El n&uacute;mero ha sido actualizado exitosamente.", {
            duration: 3000,
            fadeDuration: 200,
            title: "Bien hecho!",
            position: "top-right"
        })
        //console.log(/*id_tmp,*/desc);
   }
});
    // }
});


});
</script>

<script>
$(document).ready(function () {
    var serie_ndB = $("#serie_ndB");
    serie_ndB.off('blur');
    serie_ndB.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);

        desc = $(this).val();
    //Fin validacion
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/editarSerieNDB.php",
        data: parametros,
        success: function(datos) {
           $("#resultados_ajax2").html(datos);
           toastr.options = {
              "closeButton":false,
              "progressBar": false
            };
            //toastr["success"]("Serie actualizada", "Bien hecho!");
            vt.success("La serie ha sido actualizada exitosamente.", {
                duration: 3000,
                fadeDuration: 200,
                title: "Bien hecho!",
                position: "top-right"
            })
       }
    });
        // }
    });


});
</script>

<script>
$(document).ready(function () {
    var numero_ndB = $("#numero_ndB");
    numero_ndB.off('blur');
    numero_ndB.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
    // if(keycode == '13'){
        //id_tmp = $(this).attr("id");
        desc1 = $(this).val();
        //id_pr = $("#id_pr").val();
         //Inicia validacion
         
//Fin validacion
var parametros = $(this).serialize();
$.ajax({
    type: "POST",
    url: "../ajax/editarNumeroNDB.php",
    data: parametros,
    success: function(datos) {
       $("#resultados_ajax2").html(datos);
       toastr.options = {
          "closeButton":false,
          "progressBar": false
        };
        //toastr["success"]("N&uacute;mero actualizado", "Bien hecho!");
        vt.success("El n&uacute;mero ha sido actualizado exitosamente.", {
            duration: 3000,
            fadeDuration: 200,
            title: "Bien hecho!",
            position: "top-right"
        })
        //console.log(/*id_tmp,*/desc);
   }
});
    // }
});


});
</script>

<script>
$(document).ready(function () {
    var serie_notaVenta = $("#serie_notaVenta");
    serie_notaVenta.off('blur');
    serie_notaVenta.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);

        desc = $(this).val();
    //Fin validacion
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/editarSerieNV.php",
        data: parametros,
        success: function(datos) {
           $("#resultados_ajax2").html(datos);
           toastr.options = {
              "closeButton":false,
              "progressBar": false
            };
            //toastr["success"]("Serie actualizada", "Bien hecho!");
            vt.success("La serie ha sido actualizada exitosamente.", {
                duration: 3000,
                fadeDuration: 200,
                title: "Bien hecho!",
                position: "top-right"
            })
       }
    });
        // }
    });


});
</script>

<script>
$(document).ready(function () {
    var numero_notaVenta = $("#numero_notaVenta");
    numero_notaVenta.off('blur');
    numero_notaVenta.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
    // if(keycode == '13'){
        //id_tmp = $(this).attr("id");
        desc1 = $(this).val();
        //id_pr = $("#id_pr").val();
         //Inicia validacion
         
//Fin validacion
var parametros = $(this).serialize();
$.ajax({
    type: "POST",
    url: "../ajax/editarNumeroNV.php",
    data: parametros,
    success: function(datos) {
       $("#resultados_ajax2").html(datos);
       toastr.options = {
          "closeButton":false,
          "progressBar": false
        };
        //toastr["success"]("N&uacute;mero actualizado", "Bien hecho!");
        vt.success("El n&uacute;mero ha sido actualizado exitosamente.", {
            duration: 3000,
            fadeDuration: 200,
            title: "Bien hecho!",
            position: "top-right"
        })
        //console.log(/*id_tmp,*/desc);
   }
});
    // }
});


});
</script>

<script>
$(document).ready(function () {
    var serie_guiaRemision = $("#serie_guiaRemision");
    serie_guiaRemision.off('blur');
    serie_guiaRemision.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);

        desc = $(this).val();
    //Fin validacion
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/editarSerieGR.php",
        data: parametros,
        success: function(datos) {
           $("#resultados_ajax2").html(datos);
           toastr.options = {
              "closeButton":false,
              "progressBar": false
            };
            //toastr["success"]("Serie actualizada", "Bien hecho!");
            vt.success("La serie ha sido actualizada exitosamente.", {
                duration: 3000,
                fadeDuration: 200,
                title: "Bien hecho!",
                position: "top-right"
            })
       }
    });
        // }
    });


});
</script>

<script>
$(document).ready(function () {
    var numero_guiaRemision = $("#numero_guiaRemision");
    numero_guiaRemision.off('blur');
    numero_guiaRemision.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
    // if(keycode == '13'){
        //id_tmp = $(this).attr("id");
        desc1 = $(this).val();
        //id_pr = $("#id_pr").val();
         //Inicia validacion
         
//Fin validacion
var parametros = $(this).serialize();
$.ajax({
    type: "POST",
    url: "../ajax/editarNumeroGR.php",
    data: parametros,
    success: function(datos) {
       $("#resultados_ajax2").html(datos);
       toastr.options = {
          "closeButton":false,
          "progressBar": false
        };
        //toastr["success"]("N&uacute;mero actualizado", "Bien hecho!");
        vt.success("El n&uacute;mero ha sido actualizado exitosamente.", {
            duration: 3000,
            fadeDuration: 200,
            title: "Bien hecho!",
            position: "top-right"
        })
        //console.log(/*id_tmp,*/desc);
   }
});
    // }
});


});
</script>

<script>
$(document).ready(function () {
    var serie_cotizacion = $("#serie_cotizacion");
    serie_cotizacion.off('blur');
    serie_cotizacion.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);

        desc = $(this).val();
    //Fin validacion
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/editarSerieCT.php",
        data: parametros,
        success: function(datos) {
           $("#resultados_ajax2").html(datos);
           toastr.options = {
              "closeButton":false,
              "progressBar": false
            };
            //toastr["success"]("Serie actualizada", "Bien hecho!");
            vt.success("La serie ha sido actualizada exitosamente.", {
                duration: 3000,
                fadeDuration: 200,
                title: "Bien hecho!",
                position: "top-right"
            })
       }
    });
        // }
    });


});
</script>

<script>
$(document).ready(function () {
    var numero_cotizacion = $("#numero_cotizacion");
    numero_cotizacion.off('blur');
    numero_cotizacion.on('blur',function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
    // if(keycode == '13'){
        //id_tmp = $(this).attr("id");
        desc1 = $(this).val();
        //id_pr = $("#id_pr").val();
         //Inicia validacion
         
//Fin validacion
var parametros = $(this).serialize();
$.ajax({
    type: "POST",
    url: "../ajax/editarNumeroCT.php",
    data: parametros,
    success: function(datos) {
       $("#resultados_ajax2").html(datos);
       toastr.options = {
          "closeButton":false,
          "progressBar": false
        };
        //toastr["success"]("N&uacute;mero actualizado", "Bien hecho!");
        vt.success("El n&uacute;mero ha sido actualizado exitosamente.", {
            duration: 3000,
            fadeDuration: 200,
            title: "Bien hecho!",
            position: "top-right"
        })
        //console.log(/*id_tmp,*/desc);
   }
});
    // }
});


});
</script>