<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
session_start();
/* Connect To Database*/
require_once "../../config/general.php";
require_once "../../config/db.php";
require_once "../../config/conexion.php";
include "../modal/buscarProductosVenta.php";
include "../modal/registroItem.php";
include "../modal/registroCliente.php";
include "../modal/youtube/videoBoleta.php";
//
$session_id=session_id();
$delete = mysqli_query($con, "DELETE FROM tmpcotizaciones WHERE tmpCotizaciones_session='".$session_id."'");
//
$actual = date('d/m/Y');
$user_id = $_SESSION['usuario_id'];
$tienda = $_SESSION['tienda'];
//Sesion de la empresa
$empresa                = $_SESSION['datosEmpresa_id'];
//
//$pedido = $_GET['nPedido'];
$cadena                 = $_GET['cot'];
$pedido                 = substr($cadena, 0, -4);
//Datos de la empresa
$sql_empresa            = mysqli_query($con,"select * from datosempresa where datosEmpresa_id=$empresa");
$rw_tienda              = mysqli_fetch_array($sql_empresa);
$datosEmpresa_id        = $rw_tienda['datosEmpresa_id'];
$datosEmpresa_nombre    = $rw_tienda['datosEmpresa_nombre'];
$datosEmpresa_ruc       = $rw_tienda['datosEmpresa_ruc'];
$datosEmpresa_direccion = $rw_tienda['datosEmpresa_direccion'];
$datosEmpresa_correo    = $rw_tienda['datosEmpresa_correo'];
$datosEmpresa_logo      = $rw_tienda['datosEmpresa_logo'];
$tipoenvio              = $rw_tienda['tipoenvio'];

if ($datosEmpresa_logo == 'logo.png') {
    $rutaLogoCC = '<img src="../img/company/logo.png" style="width: 250px;">';
} else {
    $rutaLogoCC = '<img src="../img/company/'.$datosEmpresa_ruc.'/'.$datosEmpresa_logo.'" style="width: 250px;">';
}
//Usuario actual
$user_id                = $_SESSION['usuario_id'];
//Accesos del usuario
$sql_usuario            = mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario             = mysqli_fetch_array($sql_usuario);
$usuario_accesos        = $rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);
//Datos del documento
$sql_factura            = mysqli_query($con,"select * from facturas_cotizaciones, clientes where facturas_cotizaciones.cotizacion_idCliente=clientes.cliente_id and facturas_cotizaciones.cotizacion_id=$pedido");
$rw_factura             = mysqli_fetch_array($sql_factura);
//
$factura_folio          = $rw_factura['cotizacion_folio'];
$factura_correlativo    = $rw_factura['cotizacion_correlativo'];
$numero_factura         = str_pad($factura_correlativo, 8, "0", STR_PAD_LEFT);
//$ref                    = $rw_factura['ref'];
$factura_condiciones    = $rw_factura['cotizacion_condiciones'];
//$factura_credito        = $rw_factura['cotizacion_credito'];
$valor                  = $rw_factura['cotizacion_tipoCambio'];
$factura_moneda         = $rw_factura['cotizacion_moneda'];
//$dinero_resibido_fac    = $rw_factura['dinero_resibido_fac'];
//
$factura_idCliente      = $rw_factura['cotizacion_idCliente'];
$cliente_documento      = $rw_factura['cliente_documento'];
$cliente_nombre         = $rw_factura['cliente_nombre'];
$cliente_telefono       = $rw_factura['cliente_telefono'];
//
$sql2=mysqli_query($con, "select * from  detallecotizacion where detalleCotizacion_correlativo='".$factura_correlativo."' and detalleCotizacion_folio='".$factura_folio."' and detalleCotizacion_sucursal=$tienda");
//
while ($row2=mysqli_fetch_array($sql2)) {
  $precio_venta=$row2['detalleCotizacion_costo'];
  $cantidad=$row2['detalleCotizacion_cantidad'];
  $dscto=$row2['detalleCotizacion_descuento'];
  $id=$row2['detalleCotizacion_idProducto'];
  $insert_tmp=mysqli_query($con, "INSERT INTO tmpcotizaciones (tmpCotizaciones_idProducto,tmpCotizaciones_cantidad,tmpCotizaciones_precio,tmpCotizaciones_descuento,tmpCotizaciones_session) VALUES ('$id','$cantidad','$precio_venta','$dscto','$session_id')");
}
//
$sql_caja               = mysqli_query($con,"select * from caja where caja_sucursal=$tienda and caja_idUsuario=$user_id order by caja_fechaApertura desc limit 1");
$rw_caja                = mysqli_fetch_array($sql_caja);
$caja_fechaApertura     = date('d/m/Y', strtotime($rw_caja['caja_fechaApertura']));
$caja_estado            = $rw_caja['caja_estado'];
$caja_idUsuario         = $rw_caja['caja_idUsuario'];
$caja_fechaCierre       = $rw_caja['caja_fechaCierre'];
?>
<?php if($a[49]==1){ ?>
<?php if ($caja_fechaApertura<$actual || $user_id <> $caja_idUsuario) {
    include "../includes/abrirCaja.php";
} else { ?>
<div id="content-container">
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <div class="row">
                    <div class="col-md-4" style="text-align: center;">
                      <?php echo $rutaLogoCC; ?>
                    </div>
                    <div class="col-md-4" style="text-align: center;">
                      <strong><?php echo $datosEmpresa_nombre; ?></strong><br>
                      RUC: <?php echo $datosEmpresa_ruc; ?><br>
                      <?php echo $datosEmpresa_correo; ?>
                    </div>
                    <div class="col-md-4" style="text-align: center;">
                        Cotizaci&oacute;n Electr&oacute;nica<br>
                        <h4><?php echo $factura_folio; ?> - <?php echo $numero_factura; ?></h4>
                    </div>
                </div>
                <hr>
                <form role="form" id="datos_facturaConv">
                    <div class="row">
                        <div id="resultados_ajax"></div>
                        <div class="col-md-4">
                            <div class="form-group row">
                                <label for="cliente_nombre1" class="col-sm-4 col-form-label">Cliente *</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" id="cliente_nombre1" class="form-control" placeholder="Buscar por documento o nombre" required  tabindex="2" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $cliente_nombre; ?>">
                                        <span class="input-group-btn">
                                            <?php if($a[11]==1){ ?> 
                                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#nuevoCliente"><li class="fa fa-plus"></li></button>
                                            <?php } else { ?>
                                            <button type="button" class="btn btn-primary" disabled><li class="fa fa-plus"></li></button>
                                            <?php } ?>
                                        </span>
                                        <input id="id_cliente" name="id_cliente" type='hidden' value="<?php echo $factura_idCliente; ?>">
                                        <input id="tipoenvio" name="tipoenvio" type='hidden' value="<?php echo $tipoenvio; ?>">
                                        <input type="hidden" name="tipoCambio" id="tc" value="<?php echo $factura_moneda; ?>">
                                        <input type="hidden" name="valorTipoCambio" id="vtc" value="<?php echo $valor; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="cliente_documento" class="col-sm-4 col-form-label">Documento </label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" autocomplete="off" id="cliente_documento" name="cliente_documento" readonly="" value="<?php echo $cliente_documento; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="cliente_telefono" class="col-sm-4 col-form-label">Tel&eacute;fono </label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" autocomplete="off" id="cliente_telefono" name="cliente_telefono" readonly="" value="<?php echo $cliente_telefono; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="row">
                                <div class="col-md-4" style="display: none;">
                                    <div class="form-group">
                                        <label for="factura_folio">Folio:</label>
                                        <?php echo $factura_folio; ?>
                                        <input type="hidden" name="f_folio" id="f_folio" value="<?php echo $factura_folio; ?>">
                                    </div>
                                </div>
                                <div class="col-md-4" style="display: none;">
                                    <div class="form-group">
                                        <label for="factura_correlativo">Correlativo:</label>
                                        <?php echo $factura_correlativo; ?>
                                        <input type="hidden" name="f_correlativo" id="f_correlativo" value="<?php echo $factura_correlativo; ?>">
                                    </div>
                                </div>
                                <div class="col-md-4" style="display: none;">
                                    <div class="form-group">
                                        <label for="factura_hora">Hora:</label>
                                        <input type="time" class="form-control" id="factura_hora" name="factura_hora" value="<?php echo date('H:i:s') ?>">
                                    </div>
                                </div>
                                <?php include "../modal/registroObservacionesBoleta.php"; ?>
                                <div id="tipoDocumento"></div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group row">
                                <label for="factura_fecha" class="col-sm-4 col-form-label">Fecha *</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="factura_fecha" name="factura_fecha">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="condiciones" class="col-sm-4 col-form-label">Condici&oacute;n *</label>
                                <div class="col-sm-8">
                                    
                                    <div class="button-list">
                                        <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                            <label class="btn btn-primary active" onclick="cambiaContado();" data-toggle="modal" data-target="#contadoFactura">
                                                <input type="radio" name="options" checked> CONTADO
                                            </label>
                                            <label class="btn btn-primary" onclick="cambiaCredito();" data-toggle="modal" data-target="#contadoFactura">
                                                <input type="radio" name="options"> CR&Eacute;DITO
                                            </label>
                                        </div>
                                        <div id="medioPago"><input type="hidden" class="form-control" autocomplete="off" id="condiciones" name="condiciones" value="1" readonly=""></div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-2" style="display: none;">
                                <label for="des">Control STOCK</label>
                                <select class='form-control' id="des" name="des" required>
                                    <option value="0">NO MOVER STOCK</option>
                                    <option value="1" selected>DESCONTAR STOCK(-)</option>
                                    <option value="2">REPONER STOCK(+)</option>
                                </select>
                            </div>


                            <div class="form-group col-md-2" style="display: none;">
                                <label for="nro_doc">Modifica</label>
                                <input type="text" class="form-control" id="nro_doc" name="nro_doc" value="">
                            </div>
                            <div class="form-group col-md-2" style="display: none;">
                                <label for="motivo">Motivo</label>
                                <input type="text" class="form-control" id="motivo" name="motivo" value="">
                            </div>
                            <div class="form-group row">
                                <label for="factura_fechaVencimiento" class="col-sm-4 col-form-label">Vencimiento *</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="factura_fechaVencimiento" name="factura_fechaVencimiento" readonly>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="medio_pago" class="col-sm-4 col-form-label">Medio Pago*</label>
                                <div class="col-sm-8">
                                    <select class="form-control" id="medio_pago" name="medio_pago" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                        <?php
                                             $sql_segmento ="select * from medio_pago where (medioPago_idSucursal='$tienda' or medioPago_idSucursal=0)";
                                             $row          =mysqli_query($con,$sql_segmento);
                                             while ($row4 = mysqli_fetch_array($row)) {
                                                $medioPago_nombre = $row4["medioPago_nombre"];
                                                $medioPago_id     = $row4["medioPago_id"];
                                          ?>
                                          <option value="<?php echo $medioPago_id;?>"><?php  echo $medioPago_nombre;?></option>
                                          <?php } ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="id_comp1" class="col-sm-4 col-form-label">Convertir a *</label>
                                <div class="col-sm-8">
                                    <select class="form-control" id="id_comp1" name="id_comp1" style="cursor: url(../img/company/cursorH1.png), pointer;">
                                        <option value="1">FACTURA ELECTR&Oacute;NICA</option>
                                        <option value="2">BOLETA ELECTR&Oacute;NICA</option>
                                    </select>
                                </div>
                            </div>
                            <div id="resultados3"></div>
                            <?php include "../modal/abonoFactura.php"; ?>
                            <?php include "../modal/cargoFactura.php"; ?>
                            <?php include "../modal/contadoFactura.php"; ?>
                            <div id="factura_contado"><input type="hidden" name="factura_contado" value="101"></div>
                            <div id="factura_cargo"><input type="hidden" name="factura_cargo" value="1211"></div>
                            <div id="factura_abono"><input type="hidden" name="factura_abono" value="70151"></div>
                            <div id="factura_denominacion"><input type="hidden" name="factura_denominacion" value="CAJA"></div>
                            <div id="factura_denominacion1"><input type="hidden" name="factura_denominacion1" value="TERCEROS"></div>
                            <div id="factura_denominacion2"><input type="hidden" name="factura_denominacion2" value="EMITIDAS"></div>
                        </div>
                    </div>
                    
                    <!--<button type="submit" id="guardar_factura" class="btn btn-danger" aria-haspopup="true" aria-expanded="false" style="position: fixed;z-index: 999;right:0px;height:50px;border:2px solid #000;top: 50%;">
                        Procesar Venta
                    </button>-->

                    <div style="position: fixed;z-index: 999;right:0px;top: 40%; box-shadow: 2px 2px 10px #666; border-top-left-radius: 10px; border-bottom-left-radius: 10px;">
                        <button type="submit" id="guardar_factura" class="btn btn-mint" aria-haspopup="true" aria-expanded="false" style="border-bottom-left-radius: 0px; border-bottom-right-radius: 0px; border-top-right-radius: 0px; border-top-left-radius: 10px;">
                            Facturar Cotizaci&oacute;n
                        </button>
                        <br>
                        <div class="btn btn-dark" data-toggle="modal" data-target="#observaciones" style="width: 100%; border-top-left-radius: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px; border-bottom-left-radius: 0px; cursor: pointer;">
                            Observaciones
                        </div>
                        <br>
                        <a class="btn btn-primary" href="#/co_cotizaciones" style="width: 100%; border-top-left-radius: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px; border-bottom-left-radius: 10px; cursor: pointer;">
                            Regresar
                        </a>
                        <!--<br>
                        <div class="btn btn-primary" data-toggle="modal" data-target="#buscar" style="width: 100%; border-top-left-radius: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px; border-bottom-left-radius: 0px;">
                            Buscar &iacute;tem
                        </div>-->
                        <!--<?php if($a[35]==1){ ?> 
                        <br>
                        <div class="btn btn-info" data-toggle="modal" data-target="#nuevoItem" style="width: 100%; border-top-left-radius: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px; border-bottom-left-radius: 10px; cursor: pointer;">
                            Nuevo &iacute;tem
                        </div>
                        <?php } ?>-->
                    </div>
                </form>
                <div class="row">
                    <div class="col-md-12">
                        <div id="resultados_ajaxf" class='col-md-12' style="margin-top:10px"></div><!-- Carga los datos ajax -->
                        <!--<form role="form" id="barcode_form">
                            <div class="form-group row">
                                <div class="col-md-1">
                                    <input type="text" class="form-control" id="barcode_qty" value="1" autocomplete="off"style="border: 1px solid #232323; border-radius: 4px;">
                                </div>

                                <div class="col-md-3" align="left">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="barcode" autocomplete="off" placeholder="Buscar &iacute;tem por c&oacute;digo o nombre..."  tabindex="1" autofocus="true" style="border: 1px solid #232323; border-top-left-radius: 4px; border-bottom-left-radius: 4px; border-right: 1px solid #fff;">
                                        <span class="input-group-btn" style="border: 1px solid #232323; border-top-right-radius: 4px; border-bottom-right-radius: 4px; border-left: 1px solid #fff;">
                                            <button type="submit" class="btn btn-primary"><span class="fa fa-barcode"></span></button>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-md-8" >
                                    <div class="input-group">
                                        <div type="button" accesskey="a" class="btn btn-primary" data-toggle="modal" data-target="#cargoFactura" style="border-top-right-radius: 0px; border-bottom-right-radius: 0px; border-right: 0.5px dashed #666;">
                                            <img src="../assets/images/svg-icon/search1.svg" class="img-fluid" alt="search" style="width: 20px;"> Cargo
                                        </div>
                                        <div type="button" accesskey="a" class="btn btn-primary" data-toggle="modal" data-target="#abonoFactura" style="border-top-left-radius: 0px; border-bottom-left-radius: 0px;">
                                            <img src="../assets/images/svg-icon/search1.svg" class="img-fluid" alt="search" style="width: 20px;"> Abono
                                        </div>
                                    </div>
                                    <div style="margin-left: 200px; margin-top: -42px;">
                                        <div id="cargaDatosC"><label id="nombreCargo"><b>Cargo:</b> 1211 EMITIDAS</label><br></div>
                                        <div id="cargaDatosA"><label id="nombreAbono"><b>Abono:</b> 70151 TERCEROS</label></div>
                                    </div>
                                </div>
                            </div>
                        </form>-->
                    </div>
                    <br><br>
                    <div id="resultados" class='col-md-12'></div>
                </div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<?php } ?>

<!--<form method="post" id="guardar_cliente" name="guardar_cliente" autocomplete="off" class="form-horizontal">
   <div class="modal fade" id="nuevoCliente" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title" id="exampleModalCenterTitle">Nuevo Cliente</h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <div class="modal-body">
              <div id="resultados_ajax2"></div>
               <div class="form-row">
                  <div class="form-group col-md-6">
                     <label for="cliente_tipo">Tipo de documento *</label>
                     <select required id="cliente_tipo" name="cliente_tipo" class="form-control" onchange="getval(this);">
                        <option value="">SELECCIONAR</option>
                        <?php           
                           $tipo_cliente ="select * from sunat_tipocliente";
                           $row          =mysqli_query($con,$tipo_cliente);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $sunat_tipoCliente_nombre = $row4["sunat_tipoCliente_nombre"];
                              $sunat_tipoCliente_id     = $row4["sunat_tipoCliente_id"];
                        ?>
                        <option value="<?php echo $sunat_tipoCliente_id;?>"><?php  echo $sunat_tipoCliente_nombre;?></option>
                        <?php } ?>
                     </select>
                  </div>
                  <div class="form-group col-md-6">
                     <label for="documento_colaborador">Documento</label>
                     <div class="input-group">
                         <input type="number" class="form-control" name="documento_colaborador" id="documento_colaborador" onKeyUp="this.value=this.value.toUpperCase();" autocomplete="off" placeholder="Documento" required>
                         <div id="tipo_boton"></div>
                     </div>
                  </div>
               </div>
               <div class="form-row">
                   <div class="form-group col-md-6">
                       <label for="cliente_nombre">Nombres *</label>
                       <input type="text" class="form-control" id="cliente_nombre" name="cliente_nombre" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Apellidos y nombres" required>
                   </div>
                   <div class="form-group col-md-2">
                       <label for="cliente_departamento">Departamento</label>
                       <input type="text" class="form-control" id="cliente_departamento" name="cliente_departamento" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Departamento">
                   </div>
                   <div class="form-group col-md-2">
                       <label for="cliente_provincia">Provincia</label>
                       <input type="text" class="form-control" id="cliente_provincia" name="cliente_provincia" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Provincia">
                   </div>
                   <div class="form-group col-md-2">
                       <label for="cliente_distrito">Distrito</label>
                       <input type="text" class="form-control" id="cliente_distrito" name="cliente_distrito" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Distrito">
                   </div>
               </div>
               <div class="form-row">
                   <div class="form-group col-md-6">
                       <label for="cliente_direccion">Domicilio *</label>
                       <input type="text" class="form-control" id="cliente_direccion" name="cliente_direccion" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Domicilio" required>
                   </div>
                   <div class="form-group col-md-6">
                       <label for="cliente_pais">Pa&iacute;s</label>
                       <input type="text" class="form-control" id="cliente_pais" name="cliente_pais" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Pa&iacute;s">
                   </div>
               </div>
               <div class="form-row">
                   
               </div>
               <div class="form-row">
                   <div class="form-group col-md-6">
                       <label for="cliente_telefono">Tel&eacute;fono</label>
                       <input type="text" class="form-control" id="cliente_telefono" name="cliente_telefono" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Tel&eacute;fono">
                   </div>
                   <div class="form-group col-md-6">
                       <label for="cliente_email">E-Mail</label>
                       <input type="email" class="form-control" id="cliente_email" name="cliente_email" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="E-Mail">
                   </div>
               </div>
               <div class="form-row">
                   <div class="form-group col-md-6">
                       <label for="cliente_contacto">Contacto</label>
                       <input type="text" class="form-control" id="cliente_contacto" name="cliente_contacto" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Contacto">
                   </div>
                   <div class="form-group col-md-6">
                       <label for="cliente_cargo">Cargo</label>
                       <input type="text" class="form-control" id="cliente_cargo" name="cliente_cargo" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Cargo">
                   </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>-->

<?php } else { 
    include "../includes/sinAcceso.php";
} ?>

<!--<script>
   function getval(sel)
  {
   if(sel.value==''){
      vt.info("Debes seleccionar un tipo de documento.", {
          duration: 5000,
          fadeDuration: 200,
          title: "Oopss!",
          position: "top-right"
      })
      $("#tipo_boton").html('');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','Documento');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", false);
      $('#cliente_pais').val('');
   }
   if(sel.value==1){
      $("#tipo_boton").html('');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','Documento');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", false);
      $('#cliente_pais').val('');
      $('#documento_colaborador').focus();
   }
   if(sel.value==2){
      $("#tipo_boton").html('<div id="botoncitoDNI" class="input-group-addon btn btn-white" style="border: 1px solid #666;"><i class="nohidden1"></i></div>');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','DNI');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", true);
      $('#cliente_pais').val('PERU');
      $('#documento_colaborador').focus();

      $(function(){
         $('.nohidden1').html("<img src='../assets/images/svg-icon/reniec.svg' class='img-fluid' alt='settings' style='width: 23px; height: 23px;'>");
         $('.nohidden1').attr("disabled", true);
         $('#botoncitoDNI').on('click', function(){
           var documento_colaborador = $('#documento_colaborador').val();
           var url = '../ajax/consultas/reniecColaborador.php';
           $('.nohidden1').html('<img src="../img/company/load.svg" width="20px">');
           $.ajax({
             type:'POST',
             url:url,
             data:'documento_colaborador='+documento_colaborador,
             success: function(datos_dni){
               $('.nohidden1').html("<img src='../assets/images/svg-icon/reniec.svg' class='img-fluid' alt='settings' style='width: 23px; height: 23px;'>");
               $('.nohidden1').attr("disabled", false);
               $('#cliente_telefono').focus();
               var datos = eval(datos_dni);
               var nada ='nada';
               if(datos_dni != nada)
                {
                  $('#numero_dni').text(datos[0]);
                  $('#cliente_nombre').val(datos[1]);
                  $('#estado_del_contribuyente').val(datos[2]);
                  $('#condicion_de_domicilio').val(datos[3]);
                  $('#ubgclienteruc').val(datos[4]);
                  $('#tipo_de_via').val(datos[5]);
                  $('#nombre_de_via').val(datos[6]);
                  $('#codigo_de_zona').val(datos[7]);
                  $('#numero').val(datos[8]);
                  $('#interior').val(datos[9]);
                  $('#lote').val(datos[10]);
                  $('#dpto').val(datos[11]);
                  $('#manzana').val(datos[12]);
                  $('#kilometro').val(datos[13]);
                  $('#cliente_departamento').val('-');
                  $('#cliente_provincia').val('-');
                  $('#cliente_distrito').val('-');
                  $('#cliente_direccion').val('-');
                  $('#direcclienteruc').val(datos[18]);
                  $('#ultima_actualizacion').val(datos[19]);
                  $('#informacion_resultado').val(datos[20]);
                  $('#apellido_paterno').val(datos[21]);
                  $('#apellido_materno').val(datos[22]);
                  $('#nombres').val(datos[23]);
                  $('#nombres_completos').val(datos[24]);
               } if(datos[24] == '  ') {
                 vt.info("No pudimos encontrar el documento.", {
                    duration: 5000,
                    fadeDuration: 200,
                    title: "Oopss!",
                    position: "top-right"
                })
                 $("#documento_colaborador").val('');
                 $("#cliente_nombre").val('');
                 $("#cliente_departamento").val('');
                 $("#cliente_provincia").val('');
                 $("#cliente_distrito").val('');
                 $("#cliente_direccion").val('');
                 $('#documento_colaborador').focus();
               }   
            }
           });
         return false;
         });
      });
   }
   if(sel.value==3){
      $("#tipo_boton").html('');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','Carnet de extranjeria');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", false);
      $('#cliente_pais').val('');
      $('#documento_colaborador').focus();
   }
   if(sel.value==4){
      $("#tipo_boton").html('<div id="botoncitoRUC" class="input-group-addon btn btn-white" style="border: 1px solid #666;"><i class="nohidden1"></i></div>');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','RUC');
      $('#cliente_nombre').attr('placeholder','Razon Social');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", true);
      $('#cliente_pais').val('PERU');
      $('#documento_colaborador').focus();

      $(function(){
         $('.nohidden1').html("<img src='../assets/images/svg-icon/sunat.svg' class='img-fluid' alt='settings' style='width: 23px; height: 23px;'>");
         $('#botoncitoRUC').on('click', function(){
           var documento_colaborador = $('#documento_colaborador').val();
           var url = '../ajax/consultas/sunatColaborador.php';
           $('.nohidden1').html('<img src="../img/company/load.svg" width="20px">');
           $.ajax({
             type:'POST',
             url:url,
             data:'documento_colaborador='+documento_colaborador,
             success: function(datos_ruc){
               $('.nohidden1').html("<img src='../assets/images/svg-icon/sunat.svg' class='img-fluid' alt='settings' style='width: 23px; height: 23px;'>");
               $('.nohidden1').attr("disabled", false);
               var datos = eval(datos_ruc);
               var nada ='nada';
               if(datos_ruc != nada){
                 $('#numero_ruc').text(datos[0]);
                 $('#cliente_nombre').val(datos[1]);
                 $('#estado_del_contribuyente').val(datos[2]);
                 $('#condicion_de_domicilio').val(datos[3]);
                 $('#ubgclienteruc').val(datos[4]);
                 $('#tipo_de_via').val(datos[5]);
                 $('#nombre_de_via').val(datos[6]);
                 $('#codigo_de_zona').val(datos[7]);
                 $('#numero').val(datos[8]);
                 $('#interior').val(datos[9]);
                 $('#lote').val(datos[10]);
                 $('#dpto').val(datos[11]);
                 $('#manzana').val(datos[12]);
                 $('#kilometro').val(datos[13]);
                 if (datos[14] == '') {
                    $('#cliente_departamento').focus();
                 }
                 if (datos[14] != '') {
                    $('#cliente_telefono').focus();
                 }
                 $('#cliente_departamento').val(datos[14]);
                 $('#cliente_provincia').val(datos[15]);
                 $('#cliente_distrito').val(datos[16]);
                 $('#cliente_direccion').val(datos[17]);
                 $('#direcclienteruc').val(datos[18]);
                 $('#ultima_actualizacion').val(datos[19]);
               } if(datos[0] == ''){
                 //toastr.warning("No pudimos encontrar el documento...","Aviso!");
                 vt.info("No pudimos encontrar el documento.", {
                    duration: 5000,
                    fadeDuration: 200,
                    title: "Oopss!",
                    position: "top-right"
                })
                 $("#documento_colaborador").val('');
                 $('#documento_colaborador').focus();
               }   
             }
           });
           return false;
         });
       });
   }
   if(sel.value==5){
      $("#tipo_boton").html('');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','Pasaporte');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", false);
      $('#cliente_pais').val('');
      $('#documento_colaborador').focus();
   }
   if(sel.value==6){
      $("#tipo_boton").html('');
      $("#documento_colaborador").val('');
      $("#cliente_nombre").val('');
      $("#cliente_direccion").val('');
      $('#documento_colaborador').attr('placeholder','Cedula');
      $('#cliente_nombre').attr('placeholder','Apellidos y nombres');
      $('#cliente_direccion').attr('placeholder','Domicilio');
      $('#cliente_departamento').val('');
      $('#cliente_provincia').val('');
      $('#cliente_distrito').val('');
      $('#cliente_direccion').val('');
      $('#cliente_pais').attr("readonly", false);
      $('#cliente_pais').val('');
      $('#documento_colaborador').focus();
   }
}
</script>-->
<script>
    $("#guardar_cliente" ).submit(function( event ) {
      $('#guardar_datos').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
      $('#guardar_datos').attr("disabled", true);
      var parametros = $(this).serialize();
      $.ajax({
        type: "POST",
        url: "../ajax/nuevoCliente.php",
        data: parametros,
        beforeSend: function(objeto){ },
        success: function(datos){
          $("#resultados_ajax").html(datos);
          $('#guardar_datos').html('Aceptar');
          $('#guardar_datos').attr("disabled", false);
          load(1);
          $("#guardar_cliente")[0].reset();
          $("#cliente_tipo").focus();
        }
      });
      event.preventDefault();
    })
</script>
<script src="../js/nuevoConvCotizacion.js"></script>
<script src="../js/ventanaCentrada.js"></script>

<script>
$(function () {
    $('.textarea').richText();
})
</script>
<script>
$(function() {
  $('#factura_fecha').daterangepicker({
    singleDatePicker: true,
    showDropdowns: true,
    minYear: 1901,
    buttonClasses: ['btn', 'btn-sm'],
    applyClass: 'btn-primary',
    cancelClass: 'btn-danger',
    locale: {
      format: "YYYY-MM-DD",
      separator: " - ",
      applyLabel: "Aplicar",
      cancelLabel: "Cancelar",
      fromLabel: "Desde",
      toLabel: "Hasta",
      customRangeLabel: "Personalizado",
      daysOfWeek: [
      "Do",
      "Lu",
      "Ma",
      "Mi",
      "Ju",
      "Vi",
      "Sa"
      ],
      monthNames: [
      "Enero",
      "Febrero",
      "Marzo",
      "Abril",
      "Mayo",
      "Junio",
      "Julio",
      "Agosto",
      "Septiembre",
      "Octubre",
      "Noviembre",
      "Diciembre"
      ],
    },
    maxYear: parseInt(moment().format('YYYY'),10)
  }, function(start, end, label) {
    var years = moment().diff(label, 'years');
  });
});
</script>
<script>
$(function() {
  $('#factura_fechaVencimiento').daterangepicker({
    singleDatePicker: true,
    showDropdowns: true,
    minYear: 1901,
    buttonClasses: ['btn', 'btn-sm'],
    applyClass: 'btn-primary',
    cancelClass: 'btn-danger',
    locale: {
      format: "YYYY-MM-DD",
      separator: " - ",
      applyLabel: "Aplicar",
      cancelLabel: "Cancelar",
      fromLabel: "Desde",
      toLabel: "Hasta",
      customRangeLabel: "Personalizado",
      daysOfWeek: [
      "Do",
      "Lu",
      "Ma",
      "Mi",
      "Ju",
      "Vi",
      "Sa"
      ],
      monthNames: [
      "Enero",
      "Febrero",
      "Marzo",
      "Abril",
      "Mayo",
      "Junio",
      "Julio",
      "Agosto",
      "Septiembre",
      "Octubre",
      "Noviembre",
      "Diciembre"
      ],
    },
    maxYear: parseInt(moment().format('YYYY'),10)
  }, function(start, end, label) {
    var years = moment().diff(label, 'years');
  });
});
</script>
<script>
$("#tableCargo tbody tr").click(function() {
  var total = $(this).find("td:first-child").text();
  var codigo = $(this).find("td:first-child").next().text();
  var nombre = $(this).find("td:last-child").text();
  $("#factura_cargo").html('<input type="hidden" name="factura_cargo" value="'+codigo+'">');
  $("#factura_denominacion2").html('<input type="hidden" name="factura_denominacion2" value="'+nombre+'">');
  $("#nombreCargo").html('<div id="cargaDatosC"><label id="nombreCargo"><b>Cargo:</b> '+codigo+" "+nombre+'</label></div>');
});
</script>
<script>
$("#tableAbono tbody tr").click(function() {
  var total = $(this).find("td:first-child").text();
  var codigo = $(this).find("td:first-child").next().text();
  var nombre = $(this).find("td:last-child").text();
  $("#factura_abono").html('<input type="hidden" name="factura_abono" value="'+codigo+'">');
  $("#factura_denominacion1").html('<input type="hidden" name="factura_denominacion1" value="'+nombre+'">');
  $("#nombreAbono").html('<div id="cargaDatosA"><label id="nombreCargo"><b>Abono:</b> '+codigo+" "+nombre+'</label></div>');
});
</script>
<script>
$("#tableContado tbody tr").click(function() {
  var codigo = $(this).find("td:first-child").next().text();
  var nombre = $(this).find("td:last-child").text();
  $("#factura_contado").html('<input type="hidden" name="factura_contado" value="'+codigo+'">');
  $("#factura_denominacion").html('<input type="hidden" name="factura_denominacion" value="'+nombre+'">');
});
</script>
<script>
function tc(sel)
{
    if(sel.value==115){
        $("#muestraTipoCambio").html('<input type="hidden" name="valorTipoCambio" class="form-control" value="<?php echo $valor; ?>">');
        $("#vtc").val('<?php echo $valor; ?>');
        $("#tc").val('115');
    }
    if(sel.value==151){
        $("#muestraTipoCambio").html('<input type="text" name="valorTipoCambio" class="form-control" value="<?php echo $valor; ?>">');
        $("#vtc").val('<?php echo $valor; ?>');
        $("#tc").val('151');
    }
}
//Guardamos la venta
$("#datos_facturaConv").submit(function(event) {
    $('#guardar_factura').attr("disabled", true);
    $('#guardar_factura').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');
    var id_cliente = $("#id_cliente").val();
    var resibido = $("#resibido").val();
    if (isNaN(resibido)) {
        vt.error("Por favor ingresa un dato v&aacute;lido.", {
            duration: 2000,
            fadeDuration: 200,
            title: "Oopss!",
            position: "top-center"
        });
        $('#guardar_factura').html('Facturar Cotizaci&oacute;n');
        $('#guardar_factura').attr("disabled", false);
        $("#resibido").focus();
        return false;
    }
    if (resibido==0) {
        vt.error("Por favor ingresa un valor mayor a cero.", {
            duration: 2000,
            fadeDuration: 200,
            title: "Oopss!",
            position: "top-center"
        });
        $('#guardar_factura').html('Facturar Cotizaci&oacute;n');
        $('#guardar_factura').attr("disabled", false);
        $("#resibido").focus();
        return false;
    }
    if (id_cliente == "") {
        vt.error("Por favor selecciona un cliente v&aacute;lido.", {
            duration: 2000,
            fadeDuration: 200,
            title: "Oopss!",
            position: "top-center"
        })
        //toastr['warning']('Seleccionar un cliente v&aacute;lido', 'Aviso!');
        $("#cliente_nombre1").focus();
        $('#guardar_factura').html('Facturar Cotizaci&oacute;n');
        $('#guardar_factura').attr("disabled", false);
        return false;
    }
    var doc1 = $("#cliente_documento").val();
    var tip_doc = $("#id_comp1").val();
    var n = doc1.length;
    var parametros = $(this).serialize();

    if ((n == 11 && tip_doc==1) |  (n == 8 && tip_doc==2) |  (n == 12 && tip_doc==2) |  (n == 15 && tip_doc==2) ) {

        $.ajax({
            type: "POST",
            url: "../ajax/nuevoConCot.php",
            data: parametros,
            beforeSend: function(objeto) {
                $('#load_contenido_venta').html('<img src="../img/company/shoppingCart.svg" width="150">');
                $('#load_contenido_venta').addClass('ajax-loader-contenido_venta');
            },
            success: function(datos) {
                $("#resultados_ajaxf").html(datos);
                $('#guardar_factura').html('Facturar Cotizaci&oacute;n');
                $('#guardar_factura').attr("disabled", true);
                //$("#datos_factura")[0].reset();
                //$("#barcode_form")[0].reset();
                //$("#resultados").load("../ajax/cargaDetalleCotizacion.php");
                //$("#barcode").focus();
                //$("#cambiaCorrelativo").load('../ajax/documentos/cambiaCotizaci&oacute;n1.php');
                //$("#tituloSerie").load("../ajax/cargaTituloSerie4.php");
                //$("#cliente_nombre1").val("");
                //$("#id_cliente").val("");
                //$("#cliente_documento").val("");
                //$("#cliente_telefono").val("");
                //$("#cliente_direccion").val("");
                $("#cliente_nombre1").attr("disabled", true);
                $('#factura_fechaVencimiento').attr("disabled", true);
                $('#factura_fecha').attr("disabled", true);
                load(1);
                $('#load_contenido_venta').html('');
                $('#load_contenido_venta').removeClass('ajax-loader-contenido_venta');

                var envio = $('#tipoenvio').val();

                if (envio == 2) {
                    $('#modal_vuelto').modal('show');
                    $('#enviar_sunat').click();
                    $('#imprimir2').click();
                }
                if (envio == 1) {
                    $('#modal_vuelto').modal('show');
                    $('#imprimir2').click();
                }
                $('#modal_vuelto').modal('hide');
                setTimeout('window.location.href = "../view/#/co_cotizaciones"; ',2000);
                //console.log(datos);
            }
        });
    } else {
        //swal('El documento ingresado no corresponde al tipo de comprobante');
        /*window.swal({
          title: "Alerta!",
          text: 'El documento ingresado no corresponde al tipo de comprobante',
          icon: "warning",
          //buttons: true,
          dangerMode: false,
        });*/
        //alert(tip_doc);
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'El documento ingresado no corresponde al tipo de comprobante!'
        })
        $('#guardar_factura').html('Facturar Cotizaci&oacute;n');
        $('#guardar_factura').attr("disabled", false);
      }
    event.preventDefault();
})
</script>
<script>
  function cambiaCredito() {
    $("#resultados3").load("../ajax/cargaPrima.php");
    $('#factura_fechaVencimiento').attr("readonly", false);
    $('#medioPago').html('<div id="medioPago"><input type="hidden" class="form-control" autocomplete="off" id="condiciones" name="condiciones" value="4" readonly=""></div>');
    $("#factura_contado").html('<input type="hidden" name="factura_contado" value="101">');
    $("#factura_denominacion").html('<input type="hidden" name="factura_denominacion" value="CAJA">');
  }
  function cambiaContado() {
    $("#resultados3").load("../ajax/cargaRecibido.php");
    $('#factura_fechaVencimiento').attr("readonly", true);
    $('#factura_fechaVencimiento').val('<?php echo date("Y-m-d") ?>');
    $('#medioPago').html('<div id="medioPago"><input type="hidden" class="form-control" autocomplete="off" id="condiciones" name="condiciones" value="1" readonly=""></div>');
    $("#factura_contado").html('<input type="hidden" name="factura_contado" value="101">');
    $("#factura_denominacion").html('<input type="hidden" name="factura_denominacion" value="CAJA">');
  }

  function enviar(id) {
    $('#enviar_sunat').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Enviando...');
    $('#enviar_sunat').attr("disabled", true);
    $.ajax({
        type: "GET",
        url: "../view/pdf/documentos/enviar_sunat.php",
        data: "fac="+id,
        beforeSend: function(objeto){
            $('#load_contenido_venta').html('<img src="../img/company/shoppingCart.svg" width="150">');
            $('#load_contenido_venta').addClass('ajax-loader-contenido_venta');
        },
        success: function(datos){
            $('#enviar_sunat').html('<img src="../assets/images/svg-icon/sunat.svg" class="img-fluid" alt="settings" style="width: 15px; height: 15px;"> Documento Enviado');
            if(datos != "") {
                $("#resultados_ajax").html(datos);
                $("#resultados").load("../ajax/cargaDetalleCotizacion.php");
                //$("#cambiaCorrelativo").load('../ajax/documentos/cambiaBoleta1.php');
                //$("#tituloSerie").load("../ajax/cargaTituloSerie.php");
                $('#load_contenido_venta').html('');
                $('#load_contenido_venta').removeClass('ajax-loader-contenido_venta');
                console.log(datos);
            } else {
                $('#enviar_sunat').html('<span class="fa fa-paper-plane"></span> Enviar SUNAT');
                $('#enviar_sunat').attr("disabled", false);
                //toastr["danger"]("Ocurri&oacute; un error", "Oopss!");                            
            }
        }
    });
}
</script>
<script>
function recargar() {
    $("#resultados").load("../ajax/cargaDetalleCotizacion.php");
    //$("#cambiaCorrelativo").load('../ajax/documentos/cambiaBoleta1.php');
    //$("#tituloSerie").load("../ajax/cargaTituloSerie.php");
}
</script>
<script>
// print order function
function imprimir_facturas3(id_factura){
    VentanaCentrada('../view/pdf/documentos/ticket.php?comp='+id_factura,'Factura','','1024','768','true');
}
</script>
<script>
// print order function
function imprimir_facturas2(id_factura){
    VentanaCentrada('../view/pdf/documentos/a4.php?comp='+id_factura,'Factura','','1024','768','true');
}
</script>