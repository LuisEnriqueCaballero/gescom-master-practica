<!-- Start Breadcrumbbar -->
<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
/* Connect To Database*/
session_start();
require_once "../../config/general.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos

$cadena = $_GET['id_credito'];
$id_credito = substr($cadena, 0, -4);
$tienda     = $_SESSION['tienda'];

$sql_credito=mysqli_query($con,"select * from credito_proveedor, creditos_abonos_prov, proveedores where creditos_abonos_prov.numero_factura=credito_proveedor.numero and creditos_abonos_prov.abono_folio=credito_proveedor.folio and credito_proveedor.id_proveedor=proveedores.proveedor_id and credito_proveedor.id_credito='$id_credito' and credito_proveedor.id_sucursal='$tienda'");
$rw_credito=mysqli_fetch_array($sql_credito);
$credito_folio=$rw_credito['folio'];
$numero_factura=$rw_credito['numero'];
$id_cliente=$rw_credito['id_proveedor'];
$id_abono=$rw_credito['id_abono'];
$cliente_nombre=$rw_credito['proveedor_nombre'];

//$total_abono+=$rw_credito['abono'];
$credito = $rw_credito['monto_abono'];
$saldo   = $rw_credito['saldo_abono'];

include "../modal/agregarAbonoP.php";

$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);

?>

<?php if($a[118]==1 || $a[119]==1){ ?>

<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Historial</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: url(../img/company/cursorH1.png), pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load(1)" style="cursor: url(../img/company/cursorH1.png), pointer;">Cr&eacute;ditos</a></li>
        <li class="active">Historial</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <div class="row">


                    <div class="col-lg-4">

                        <div class="panel">
                            <div class="panel-body text-center">
                                <img alt="Profile Picture" class="img-md mar-btm" src="../assets/images/svg-icon/shipment.svg">
                                <p class="text-lg text-semibold mar-no text-main"><?php echo $cliente_nombre; ?></p>
                                <p><a class="btn btn-primary btn-xs" href="#/cc_cuentasPagar"><i class="fa fa-reply"></i> Regresar</a></p>
                                <ul class="list-unstyled text-center bord-top pad-top mar-no row">
                                    <li class="col-xs-12">
                                        <span class="text-lg text-semibold text-main"><?php echo number_format($credito,2); ?></span>
                                        <p class="text-muted mar-no">MONTO CR&Eacute;DITO</p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="panel panel-color panel-info">
                            <div class="panel-body">
                                <form class="form-horizontal" role="form" id="datos_cotizacion">
                                    <div class="form-group row">
                                        <div class="col-xs-4">
                                            <div class="input-group">
                                                <input type="text" class="form-control daterange pull-right" value="<?php echo "01" . date('/m/Y') . ' - ' . date('d/m/Y'); ?>" id="range" readonly>
                                                <span class="input-group-btn">
                                                    <button class="btn btn-primary" type="button" onclick='load(1);'><i class='fa fa-search'></i></button>
                                                </span>

                                            </div><!-- /input-group -->
                                        </div>
                                        <input type="hidden" name="id_credito" id="id_credito" value="<?php echo $id_credito; ?>">
                                        <?php if($a[119]==1){ ?>
                                        <div class="col-xs-2">
                                            <div class="btn-group pull-center">
                                                <button type="button" class="btn btn-mint" data-toggle="modal" data-target="#add-stock" data-id="<?php echo $id_credito; ?>" ><i class="fa fa-plus"></i> Abono</button>
                                            </div>
                                        </div>
                                        <?php } ?>
                                        <div class="col-xs-2">
                                            <div class="btn-group pull-center">
                                                <button type="button"  onclick="reporte('<?php echo $id_credito; ?>');" class="btn btn-default" title="Imprimir"><i class='fa fa-print'></i> Imprimir Reporte</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <div class="col-md-12" align="center">
                                    <br>
                                    <div id="loader"></div>
                                    <div id="resultados_ajax"></div>
                                    <div class="clearfix"></div>
                                    <div class='outer_div'></div><!-- Carga los datos ajax -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>

<?php } else { 
    include "../includes/sinAcceso.php";
} ?>

            <!-- End Contentbar -->
<script src="../js/abonosProveedores.js"></script>
<script src="../js/ventanaCentrada.js"></script>
<script>
    $(document).ready( function () {
        $(".UpperCase").on("keypress", function () {
            $input=$(this);
            setTimeout(function () {
                $input.val($input.val().toUpperCase());
            },50);
        })
    })
</script>
<script>
    $(function() {
        load(1);

//Date range picker
$('.daterange').daterangepicker({
  buttonClasses: ['btn', 'btn-sm'],
  applyClass: 'btn-primary',
  cancelClass: 'btn-danger',
  locale: {
    format: "DD/MM/YYYY",
    separator: " - ",
    applyLabel: "Aplicar",
    cancelLabel: "Cancelar",
    fromLabel: "Desde",
    toLabel: "Hasta",
    customRangeLabel: "Personalizado",
    daysOfWeek: [
    "Do",
    "Lu",
    "Ma",
    "Mi",
    "Ju",
    "Vi",
    "Sa"
    ],
    monthNames: [
    "Enero",
    "Febrero",
    "Marzo",
    "Abril",
    "Mayo",
    "Junio",
    "Julio",
    "Agosto",
    "Septiembre",
    "Octubre",
    "Noviembre",
    "Diciembre"
    ],
  },
  ranges: {
       'Hoy': [moment(), moment()],
       'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
       'Ultimos 7 dias': [moment().subtract(6, 'days'), moment()],
       'Ultimos 30 dias': [moment().subtract(29, 'days'), moment()],
       'Este mes': [moment().startOf('month'), moment().endOf('month')],
       'El mes pasado': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    },
  opens: "right"

});
});
</script>
<script>
    function reporte(id) {
        var daterange = $("#range").val();
        var id_credito = $("#id_credito").val();
        VentanaCentrada('../view/pdf/documentos/rep_cxp.php?daterange='+daterange+'&id_credito='+id_credito, 'Reporte', '', '800', '600', 'true');
    }
</script>
<script>
    function imprimir_abono(id_abono) {
        VentanaCentrada('../view/pdf/documentos/rep_abono_p.php?id_abono=' + id_abono, 'Reporte', '', '800', '600', 'true');
    }
</script>