<?php
/* Connect To Database*/
require_once "../../config/db.php";
require_once "../../config/conexion.php";
session_start();
//Archivo de funciones PHP
require_once "../funciones/funciones.php";
$usuario_id = $_SESSION['usuario_id'];
$tienda = $_SESSION['tienda'];

$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);

?>
<?php if($a[41]==1){ ?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Almacenes > Kardex</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <!-- Contact Toolbar -->
        <!---------------------------------->
        <!---------------------------------->                    
        <div class="row">
            <?php
                $sql = "select * from almacenes where almacen_idSucursal='$tienda' and almacen_activo='1' order by almacen_id asc";
                $query = mysqli_query($con,$sql);
                while ($row = mysqli_fetch_array($query)) {
                    $almacen_id = $row['almacen_id'];
                    $nombre = substr($row['almacen_direccion'], 0, 28).'...';

                    $user = mysqli_query($con, "select * from productos where producto_idSucursal='$almacen_id'");
                    $num  = mysqli_num_rows($user);
            ?>
            <div class="col-sm-4 col-md-3">
                <!-- Contact Widget -->
                <!---------------------------------->
                <div class="panel pos-rel">
                    <div class="pad-all text-center">
                        <a href="#/pr_kardex1.php?almacen=<?php echo $almacen_id; ?>">
                            <img alt="Profile Picture" class="img-lg mar-ver" src="../assets/images/svg-icon/warehouse.svg">
                            <p class="text-lg text-semibold mar-no text-main"><?php echo $row['almacen_nombre']; ?></p>
                            <p class="text-sm"><b><?php echo $num; ?> &iacute;tems</b></p>
                            <p class="text-sm"><?php echo $nombre; ?></p>
                        </a>
                    </div>
                </div>
                <!---------------------------------->
            </div>
            <?php } ?>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<?php } else { 
    include "../includes/sinAcceso.php";
} ?>
<script src="../js/kardex.js"></script>