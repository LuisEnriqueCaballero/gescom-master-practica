<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
include("../../config/db.php");
include("../../config/conexion.php");
//Verificamos si el usuario esta logueado, si no esta logueado lo redirecciona al login, si ya esta logueado se queda en el panel
session_start();
if (!isset($_SESSION['user_login_status']) and $_SESSION['user_login_status'] != 1) {
   header("location: ../login/");
   exit;
}

$empresa = $_SESSION['datosEmpresa_id'];

$sql_empresa=mysqli_query($con,"select * from datosempresa where datosEmpresa_id=$empresa");
$rw_tienda=mysqli_fetch_array($sql_empresa);

$datosEmpresa_id=$rw_tienda['datosEmpresa_id'];
$datosEmpresa_nombre=$rw_tienda['datosEmpresa_nombre'];
$datosEmpresa_ruc=$rw_tienda['datosEmpresa_ruc'];
$datosEmpresa_direccion=$rw_tienda['datosEmpresa_direccion'];
$datosEmpresa_correo=$rw_tienda['datosEmpresa_correo'];
$datosEmpresa_telefono=$rw_tienda['datosEmpresa_telefono'];
$datosEmpresa_ubigeo=$rw_tienda['datosEmpresa_ubigeo'];
$datosEmpresa_departamento=$rw_tienda['datosEmpresa_departamento'];
$datosEmpresa_provincia=$rw_tienda['datosEmpresa_provincia'];
$datosEmpresa_distrito=$rw_tienda['datosEmpresa_distrito'];
$datosEmpresa_logo=$rw_tienda['datosEmpresa_logo'];
$datosEmpresa_web=$rw_tienda['datosEmpresa_web'];
$datosEmpresa_descripcion=$rw_tienda['datosEmpresa_descripcion'];
$datosEmpresa_eslogan=$rw_tienda['datosEmpresa_eslogan'];
$url         = $rw_tienda['datosEmpresa_favicon'];

$servidor      = $rw_tienda['datosEmpresa_servidor'];
$servidorUsuario   = $rw_tienda['datosEmpresa_servidorUsuario'];
$servidorClave   = $rw_tienda['datosEmpresa_servidorClave'];
$servidorSeguridad  = $rw_tienda['datosEmpresa_servidorSeguridad'];
$servidorPuerto  = $rw_tienda['datosEmpresa_servidorPuerto'];
$servidorEmisorDoc = $rw_tienda['datosEmpresa_servidorEmisorDoc'];
$servidorEmisorMkt = $rw_tienda['datosEmpresa_servidorEmisorMkt'];

$datosEmpresa_venceCertificado = $rw_tienda['datosEmpresa_venceCertificado'];

$fac_ele=$rw_tienda['fac_ele'];
$usuariosol=$rw_tienda['usuariosol'];
$clavesol=$rw_tienda['clavesol'];
$clave=$rw_tienda['clave'];
$tipoenvio=$rw_tienda['tipoenvio'];

if($datosEmpresa_logo == "logo.png"){
  $foto1="logo.png";
}else{
  $foto1=$datosEmpresa_ruc.'/'.$datosEmpresa_logo; 
}

$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);

?>

<?php if($a[183]==1 || $a[184]==1 || $a[185]==1 || $a[186]==1 || $a[187]==1 || $a[188]==1){ ?>

<style>
  .btn-file{overflow:hidden;position:relative;vertical-align:middle;}.btn-file>input{position:absolute;top:0;right:0;margin:0;opacity:0;filter:alpha(opacity=0);transform:translate(-300px, 0) scale(4);font-size:23px;direction:ltr;cursor:pointer;}
  .fileupload{margin-bottom:9px;}.fileupload .uneditable-input{display:inline-block;margin-bottom:0px;vertical-align:middle;cursor:text;}
  .fileupload .thumbnail{overflow:hidden;display:inline-block;margin-bottom:5px;vertical-align:middle;text-align:center;}.fileupload .thumbnail>img{display:inline-block;vertical-align:middle;max-height:100%;}
  .fileupload .btn{vertical-align:middle;}
  .fileupload-exists .fileupload-new,.fileupload-new .fileupload-exists{display:none;}
  .fileupload-inline .fileupload-controls{display:inline;}
  .fileupload-new .input-append .btn-file{-webkit-border-radius:0 3px 3px 0;-moz-border-radius:0 3px 3px 0;border-radius:0 3px 3px 0;}
  .thumbnail-borderless .thumbnail{border:none;padding:0;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;}
  .fileupload-new.thumbnail-borderless .thumbnail{border:1px solid #ddd;}

  .drop-zone {
    max-width: 300px;
    height: 300px;
    padding: 25px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    font-family: "Quicksand", sans-serif;
    font-weight: 500;
    font-size: 20px;
    cursor: pointer;
    color: #cccccc;
    border: 4px dashed #007bff;
    border-radius: 10px;
  }

  .drop-zone--over {
    border-style: solid;
  }

  .drop-zone__input {
    display: none;
  }

  .drop-zone__thumb {
    width: 100%;
    height: 100%;
    border-radius: 10px;
    overflow: hidden;
    background-color: #cccccc;
    background-size: cover;
    position: relative;
  }

  .drop-zone__thumb::after {
    content: attr(data-label);
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    padding: 5px 0;
    color: #ffffff;
    background: rgba(0, 0, 0, 0.75);
    font-size: 14px;
    text-align: center;
  }
</style>

<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Datos Empresa</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a onclick="cargar_contenido('contenido_principal','modulos/ss_inicio.php')" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="cargar_contenido('contenido_principal','modulos/cf_datosEmpresa.php')" style="cursor: pointer;">Ajustes</a></li>
        <li class="active">Datos Empresa</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="">
                <div id="ldng_cat" style="text-align: center;"></div>
                <div id="resultados_ajax"></div>
                <div class="tab-base">
                    <!--Nav Tabs-->
                    <ul class="nav nav-tabs">
                        <?php if($a[183]==1){ ?>
                        <li class="active">
                            <a data-toggle="tab" href="#demo-lft-tab-1"><img src="../assets/images/svg-icon/business-and-trade.svg" class="img-fluid" style="width: 20px; height: 20px;"> Datos Generales</a>
                        </li>
                        <?php } ?>
                        <?php if($a[184]==1){ ?>
                        <li>
                            <a data-toggle="tab" href="#demo-lft-tab-2"><img src='../assets/images/svg-icon/pictures.svg' class='img-fluid' style='width: 20px; height: 20px;'> Cargar Logo</a>
                        </li>
                        <?php } ?>
                        <?php if($a[185]==1){ ?>
                        <li>
                            <a data-toggle="tab" href="#demo-lft-tab-3"><img src='../assets/images/svg-icon/favicon.svg' class='img-fluid' style='width: 20px; height: 20px;'> Cargar Favicon</a>
                        </li>
                        <?php } ?>
                        <?php if($a[186]==1){ ?>
                        <li>
                            <a data-toggle="tab" href="#demo-lft-tab-4"><img src='../assets/images/svg-icon/adjust.svg' class='img-fluid' style='width: 20px; height: 20px;'> Configurar Certificado</a>
                        </li>
                        <?php } ?>
                        <?php if($a[187]==1){ ?>
                        <li>
                            <a data-toggle="tab" href="#demo-lft-tab-5"><img src='../assets/images/svg-icon/certificate.svg' class='img-fluid' style='width: 20px; height: 20px;'> Cargar Certificado</a>
                        </li>
                        <?php } ?>
                        <?php if($a[188]==1){ ?>
                        <li class="hidden">
                            <a data-toggle="tab" href="#demo-lft-tab-6"><img src='../assets/images/svg-icon/gmail.svg' class='img-fluid' style='width: 20px; height: 20px;'> Servidor Correo</a>
                        </li>
                        <?php } ?>
                    </ul>
        
                    <!--Tabs Content-->
                    <div class="tab-content">
                      <!-- Datos generales -->
                      <?php if($a[183]==1){ ?>
                      <div id="demo-lft-tab-1" class="tab-pane fade active in">
                          <p class="text-main text-semibold">Datos Generales</p>
                          <p>Completa el formulario con los datos de tu RUC</p>
                          <form class="form-horizontal" method="post" id="editarDatosEmpresa" name="editarDatosEmpresa" autocomplete="off">
                              <div id="resultados_ajax2"></div>

                              <div class="">
                                  <label for="documento_colaborador" class="control-label">Ruc *</label>
                                  <div class="">

                                  <div class="input-group">
                                        <input maxlength="11" type="text" class="form-control"  id="documento_colaborador" name="documento_colaborador" placeholder="Ingrese RUC" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $datosEmpresa_ruc; ?>" required onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                                        <div id="botoncitoRUC" class="input-group-addon btn btn-white" style="border: 1px solid #666;"><i class="nohidden1" style="color: #fff;"></i></div>
                                      </div>
                                  </div>
                              </div>

                              <div class="">
                                  <label for="cliente_nombre" class="control-label">Raz&oacute;n Social *</label>
                                  <div class="">
                                    <input type="text" class="form-control" id="cliente_nombre" name="cliente_nombre" placeholder="Raz&oacute;n Social" required onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $datosEmpresa_nombre; ?>">
                                      <input type="hidden" name="mod_id" id="mod_id" value="<?php echo $empresa; ?>">
                                  </div>
                              </div>
              
                              <div class="">
                                  <label for="cliente_direccion" class="control-label">Direcci&oacute;n *</label>
                                  <div class="">
                                    <input type="text" class="form-control" id="cliente_direccion" name="cliente_direccion" placeholder="Direcci&oacute;n" required onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $datosEmpresa_direccion; ?>">
                                  </div>
                              </div>

                              <div class="">
                                  <label for="mod_correo" class="control-label">Correo</label>
                                  <div class="">
                                    <input type="text" class="form-control" id="mod_correo" name="mod_correo" placeholder="Correo" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $datosEmpresa_correo; ?>">
                                  </div>
                              </div>

                              <div class="">
                                  <label for="mod_telefono" class="control-label">Tel&eacute;fono</label>
                                  <div class="">
                                    <input type="text" class="form-control" id="mod_telefono" name="mod_telefono" placeholder="Tel&eacute;fono" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $datosEmpresa_telefono; ?>">
                                  </div>
                              </div>

                              <div class="">
                                  <label for="mod_web" class="control-label">P&aacute;gina web</label>
                                  <div class="">
                                    <input type="text" class="form-control" id="mod_web" name="mod_web" placeholder="P&aacute;gina web" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $datosEmpresa_web; ?>">
                                  </div>
                              </div>

                              <div class="">
                                  <label for="mod_descripcion" class="control-label">Descripci&oacute;n</label>
                                  <div class="">
                                    <input type="text" class="form-control" id="mod_descripcion" name="mod_descripcion" placeholder="Descripci&oacute;n" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $datosEmpresa_descripcion; ?>">
                                  </div>
                              </div>

                              <div class="">
                                  <label for="mod_eslogan" class="control-label">Eslogan</label>
                                  <div class="">
                                    <input type="text" class="form-control" id="mod_eslogan" name="mod_eslogan" placeholder="Eslogan" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $datosEmpresa_eslogan; ?>">
                                  </div>
                              </div>

                              <div class="">
                                  <label for="cliente_departamento" class="control-label">Departamento *</label>
                                  <div class="">
                                      <input type="text" class="form-control" id="cliente_departamento" name="cliente_departamento" placeholder="Departamento" onKeyUp="this.value=this.value.toUpperCase();" required value="<?php echo $datosEmpresa_departamento; ?>">
                                  </div>
                               </div>

                              <div class="">
                                  <label for="cliente_provincia" class="control-label">Provincia *</label>
                                  <div class="">
                                      <input type="text" class="form-control" id="cliente_provincia" name="cliente_provincia" placeholder="Provincia" onKeyUp="this.value=this.value.toUpperCase();" required value="<?php echo $datosEmpresa_provincia; ?>">
                                  </div>
                              </div>

                              <div class="">
                                  <label for="cliente_distrito" class="control-label">Distrito *</label>
                                  <div class="">
                                      <input type="text" class="form-control" id="cliente_distrito" name="cliente_distrito" placeholder="Distrito" onKeyUp="this.value=this.value.toUpperCase();" required value="<?php echo $datosEmpresa_distrito; ?>">
                                  </div>
                              </div>
                          
                              <div class="">
                                  <label for="cliente_ubigeo" class="control-label">Ubigeo *</label>
                                  <div class="">
                                    <input type="text" class="form-control" id="cliente_ubigeo" name="cliente_ubigeo" placeholder="Ubigeo" required onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $datosEmpresa_ubigeo; ?>">
                                  </div>
                              </div>
            
                              <div class="modal-footer">
                                  <button type="submit" class="btn btn-primary" id="actualizar_datos">Actualizar datos</button>
                              </div>
                          </form>
                      </div>
                      <?php } ?>
                      <!-- Carga Logo -->
                      <?php if($a[184]==1){ ?>
                      <div id="demo-lft-tab-2" class="tab-pane fade">
                        <p class="text-main text-semibold">Cargar Logo</p>
                        <p>Carga el logo que se mostrar&aacute; en la representaci&oacute;n impre de los documentos y reportes.</p>
                        <div class="datos_ajax_logo"></div>
                        <form id="frmSubirImagenLogo" action="../ajax/cargaImagenLogo.php" method="POST" role="form" enctype="multipart/form-data">
                          <div>
                            <div class="drop-zone">
                              <span class="drop-zone__prompt">
                                <?php
                                if ($datosEmpresa_logo == 'logo.png') {
                                      echo '<img src="../img/company/logo.png" style="width:100%;">';
                                  } else {
                                      echo '<img src="../img/company/'.$datosEmpresa_ruc."/".$datosEmpresa_logo.'" style="width:100%;">';
                                  }
                                ?>
                              </span>
                              <input type="file" id="imagenLogo" name="imagenLogo" class="drop-zone__input hidden" required>
                            </div>
                          </div>
                          <div class="modal-footer">
                            <button class="btn btn-mint" type="submit">Cargar Logo</button>
                          </div>
                        </form>
                      </div>
                      <?php } ?>
                      <!-- Cargar Favicon -->
                      <?php if($a[185]==1){ ?>
                      <div id="demo-lft-tab-3" class="tab-pane fade">
                        <p class="text-main text-semibold">Cargar Favicon</p>
                        <p>Carga el icono que se mostrar&aacute; en el sistema y en algunos reportes.</p>
                        <form id="frmSubirImagen" action="../ajax/cargaImagenFavicon.php" method="POST" role="form" enctype="multipart/form-data">
                          <div>
                            <div class="drop-zone">
                              <span class="drop-zone__prompt">
                                <?php
                                if ($url == 'favicon.png') {
                                      echo '<img src="../img/company/favicon.png" style="width:100%;">';
                                  } else {
                                      echo '<img src="../img/company/'.$datosEmpresa_ruc."/".$url.'" style="width:100%;">';
                                  }
                                ?>
                              </span>
                              <input type="file" id="imagen" name="imagen" class="drop-zone__input hidden" required>
                            </div>
                          </div>
                          <div class="modal-footer">
                            <button class="btn btn-mint" type="submit">Cargar Favicon</button>
                          </div>
                        </form>
                        <div class="datos_ajax_favicon"></div>
                      </div>
                      <?php } ?>
                      <!-- Configurar Certificado -->
                      <?php if($a[186]==1){ ?>
                      <div id="demo-lft-tab-4" class="tab-pane fade">
                          <p class="text-main text-semibold">Configurar Certificado</p>
                          <p>Completa el formulario con los datos de tu certificado digital.</p>
                          <form class="form-horizontal" method="post" id="perfil" name="perfil" autocomplete="off" enctype="multipart/form-data">
                              <div id="resultados_ajax2"></div>
                              <div class="">
                                  <label for="fac_ele" class="control-label">Entorno *</label>
                                  <select class="form-control" id="fac_ele" name="fac_ele">
                                      <?php if ($fac_ele==3) { ?>
                                      <option value="3" selected>Beta</option>
                                      <option value="1" >Producci&oacute;n</option>
                                      <?php } if ($fac_ele==1) { ?>
                                      <option value="1" selected>Producci&oacute;n</option>
                                      <option value="3">Beta</option>
                                      <?php } ?>
                                  </select>
                              </div>

                              <div class="">
                                  <label for="usuariosol" class="control-label">Usuario SOL *</label>
                                  <div class="">
                                    <input type="text" class="form-control" id="usuariosol" name="usuariosol" placeholder="Usuario SOL" required onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $usuariosol; ?>">
                                      <input type="hidden" name="mod_id" id="mod_id" value="1">
                                  </div>
                              </div>
              
                              <div class="">
                                  <label for="clavesol" class="control-label">Clave SOL *</label>
                                  <div class="">
                                    <input type="text" class="form-control" id="clavesol" name="clavesol" placeholder="Clave SOL" required value="<?php echo $clavesol; ?>">
                                  </div>
                              </div>

                              <div class="">
                                  <label for="clave" class="control-label">Clave Certificado Digital</label>
                                  <div class="">
                                    <input type="text" class="form-control" id="clave" name="clave" placeholder="Clave Certificado Digital" value="<?php echo $clave; ?>">
                                  </div>
                              </div>

                              <div class="">
                                  <label for="datosEmpresa_venceCertificado" class="control-label">Fecha Vencimiento</label>
                                  <div class="">
                                    <input type="date" class="form-control" id="datosEmpresa_venceCertificado" name="datosEmpresa_venceCertificado" placeholder="Clave Certificado Digital" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $datosEmpresa_venceCertificado; ?>">
                                  </div>
                              </div>

                              <div class="">
                                  <label for="tipoenvio" class="control-label">Tipo Env&iacute;o *</label>
                                  <select class="form-control" id="tipoenvio" name="tipoenvio">
                                      <?php         
                                         if ($tipoenvio==2) {
                                           ?>
                                          
                                          <option value="2" selected>Autom&aacute;tico</option>
                                          <option value="1" >Manual</option>
                                           <?php
                                         }         
                                         if ($tipoenvio==1) {
                                           ?>
                                          <option value="1" selected>Manual</option>
                                          <option value="2">Autom&aacute;tico</option>
                                          <?php
                                         }         
                                                  
                                      ?>
                                  </select>
                               </div>
            
                              <div class="modal-footer">
                                  <button type="submit" class="btn btn-primary" id="guardar_datos">Actualizar datos</button>
                              </div>
                          </form>
                      </div>
                      <?php } ?>
                      <!-- Cargar Certificado -->
                      <?php if($a[187]==1){ ?>
                      <div id="demo-lft-tab-5" class="tab-pane fade">
                        <p class="text-main text-semibold">Cargar Certificado</p>
                        <p>Carga tu certificado digital para que realice la firma de los documentos electr&oacute;nicos.</p>
                        <div class="datos_ajax_certificado"></div>
                        <form id="frmSubirCertificado" action="../ajax/cargaCertificado.php" method="POST" role="form" enctype="multipart/form-data">
                          <div>
                            <div class="drop-zone">
                              <span class="drop-zone__prompt">
                                <img src="../img/compras/blank.png" style="width:100%;">
                              </span>
                              <input type="file" id="imagenCertificado" name="imagenCertificado" class="drop-zone__input hidden" required>
                            </div>
                          </div>
                          <div class="modal-footer">
                            <button class="btn btn-mint" type="submit">Cargar Certificado</button>
                          </div>
                        </form>
                      </div>
                      <?php } ?>
                      <!-- Servidor Correo -->
                      <?php if($a[188]==1){ ?>
                      <div id="demo-lft-tab-6" class="tab-pane fade">
                          <p class="text-main text-semibold">Configurar Correo</p>
                          <p>Completa el formulario con los datos de tu servidor de correos</p>
                          <form class="form-horizontal" method="post" id="editarDatosEmpresaServidor" name="editarDatosEmpresaServidor" autocomplete="off">
                              <div id="resultados_ajaxServidor"></div>
                              <input type="hidden" name="mod_id" id="mod_id" value="<?php echo $empresa; ?>">
                              <div class="">
                                  <label for="datosEmpresa_servidor" class="control-label">Servidor *</label>
                                  <div class="">
                                    <input type="text" class="form-control" id="datosEmpresa_servidor" name="datosEmpresa_servidor" placeholder="Servidor" required value="<?php echo $servidor; ?>">
                                  </div>
                              </div>
              
                              <div class="">
                                  <label for="datosEmpresa_servidorUsuario" class="control-label">Usuario *</label>
                                  <div class="">
                                    <input type="text" class="form-control" id="datosEmpresa_servidorUsuario" name="datosEmpresa_servidorUsuario" placeholder="Usuario o correo electr&oacute;nico" required value="<?php echo $servidorUsuario; ?>">
                                  </div>
                              </div>

                              <div class="">
                                  <label for="datosEmpresa_servidorClave" class="control-label">Contraseña *</label>
                                  <div class="">
                                      <input type="text" class="form-control" id="datosEmpresa_servidorClave" name="datosEmpresa_servidorClave" placeholder="Contrase&ntilde;a" required value="<?php echo $servidorClave; ?>">
                                  </div>
                               </div>

                              <div class="">
                                  <label for="datosEmpresa_servidorSeguridad" class="control-label">Seguridad *</label>
                                  <div class="">
                                      <input type="text" class="form-control" id="datosEmpresa_servidorSeguridad" name="datosEmpresa_servidorSeguridad" placeholder="Seguridad" required value="<?php echo $servidorSeguridad; ?>">
                                  </div>
                              </div>

                              <div class="">
                                  <label for="datosEmpresa_servidorPuerto" class="control-label">Puerto *</label>
                                  <div class="">
                                      <input type="text" class="form-control" id="datosEmpresa_servidorPuerto" name="datosEmpresa_servidorPuerto" placeholder="Puerto" required value="<?php echo $servidorPuerto; ?>">
                                  </div>
                              </div>
                          
                              <div class="">
                                  <label for="datosEmpresa_servidorEmisorDoc" class="control-label">Emisor Documentos *</label>
                                  <div class="">
                                    <input type="text" class="form-control" id="datosEmpresa_servidorEmisorDoc" name="datosEmpresa_servidorEmisorDoc" placeholder="Emisor de documentos emitidos" required onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $servidorEmisorDoc; ?>">
                                  </div>
                              </div>

                              <div class="">
                                  <label for="datosEmpresa_servidorEmisorMkt" class="control-label">Emisor Marketing *</label>
                                  <div class="">
                                    <input type="text" class="form-control" id="datosEmpresa_servidorEmisorMkt" name="datosEmpresa_servidorEmisorMkt" placeholder="Emisor para campa&ntilde;a de marketing" required onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $servidorEmisorMkt; ?>">
                                  </div>
                              </div>
            
                              <div class="modal-footer">
                                  <button type="submit" class="btn btn-primary" id="actualizar_datos">Actualizar datos</button>
                              </div>
                          </form>
                      </div>
                      <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>

<?php } else { 
    include "../includes/sinAcceso.php";
} ?>

<script src="../js/datosEmpresa.js"></script>
<script>
//Edita los datos generales
$( "#editarDatosEmpresa" ).submit(function( event ) {
  $('#actualizar_datos').html('<img src="../img/company/load1.svg" style="width: 16px;"> &nbsp;Verificando...');
  $('#actualizar_datos').attr("disabled", true);
    
   var parametros = $(this).serialize();
  $.ajax({
    type: "POST",
    url: "../ajax/editarDatosEmpresa.php",
    data: parametros,
    beforeSend: function(objeto){ },
    success: function(datos){
    $("#resultados_ajax2").html(datos);
    $('#actualizar_datos').html('Actualizar datos');
    $('#actualizar_datos').attr("disabled", false);
    load(1);
     }
  });
 event.preventDefault();
})
//Edita datos del certificado
$( "#perfil" ).submit(function( event ) {
$('#guardar_datos').html('<img src="../img/company/load1.svg" style="width: 16px;"> &nbsp;Verificando...');
$('#guardar_datos').attr("disabled", true);
  
 var parametros = $(this).serialize();
   $.ajax({
      type: "POST",
      url: "../ajax/editarDatosEmpresa1.php",
      data: parametros,
       beforeSend: function(objeto){
        $("#resultados_ajax").html("Mensaje: Cargando...");
        },
      success: function(datos){
      $("#resultados_ajax").html(datos);
      $('#guardar_datos').html('Actualizar datos');
      $('#guardar_datos').attr("disabled", false);

      }
  });
  event.preventDefault();
})
//Edita los datos del servidor
$( "#editarDatosEmpresaServidor" ).submit(function( event ) {
  $('#actualizar_datos').html('<img src="../img/company/load1.svg" style="width: 16px;"> &nbsp;Verificando...');
  $('#actualizar_datos').attr("disabled", true);
    
   var parametros = $(this).serialize();
  $.ajax({
    type: "POST",
    url: "../ajax/editarDatosEmpresaServidor.php",
    data: parametros,
    beforeSend: function(objeto){ },
    success: function(datos){
    $("#resultados_ajaxServidor").html(datos);
    $('#actualizar_datos').html('Actualizar datos');
    $('#actualizar_datos').attr("disabled", false);
    load(1);
     }
  });
 event.preventDefault();
})
//Carga el certificado
function upload_image(){
    $(".upload-msg").text('Cargando...');
    var inputFileImage = document.getElementById("fileToUpload");
    var file = inputFileImage.files[0];
    var data = new FormData();
    data.append('fileToUpload',file);
          
    $.ajax({
      url: "../ajax/cargaCertificado.php",
      type: "POST",
      data: data,
      contentType: false,
      cache: false,
      processData:false,
      success: function(data)
      {
        $(".upload-msg").html(data);
        window.setTimeout(function() {
        $(".alert-dismissible").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove();
        }); }, 5000);

      }
    });
    
}
//Busca ruc empresa
$(function(){
     $('.nohidden1').html("<img src='../assets/images/svg-icon/sunat.svg' class='img-fluid' alt='favicon' style='width: 20px; height: 20px;'>");
     $('#botoncitoRUC').on('click', function(){
       var documento_colaborador = $('#documento_colaborador').val();
       var url = '../ajax/consultas/sunatColaborador.php';
       $('.nohidden1').html('<img src="../img/company/load.svg" width="20px">');
       $.ajax({
         type:'POST',
         url:url,
         data:'documento_colaborador='+documento_colaborador,
         success: function(datos_ruc){
           $('.nohidden1').html("<img src='../assets/images/svg-icon/sunat.svg' class='img-fluid' alt='favicon' style='width: 20px; height: 20px;'>");
           $('.nohidden1').attr("disabled", false);
           //$('#cliente_telefono').focus();
           var datos = eval(datos_ruc);
           var nada ='nada';
           if(datos_ruc != nada){
             $('#numero_ruc').text(datos[0]);
             $('#cliente_nombre').val(datos[1]);
             $('#estado_del_contribuyente').val(datos[2]);
             $('#condicion_de_domicilio').val(datos[3]);
             $('#cliente_ubigeo').val(datos[4]);
             $('#tipo_de_via').val(datos[5]);
             $('#nombre_de_via').val(datos[6]);
             $('#codigo_de_zona').val(datos[7]);
             $('#numero').val(datos[8]);
             $('#interior').val(datos[9]);
             $('#lote').val(datos[10]);
             $('#dpto').val(datos[11]);
             $('#manzana').val(datos[12]);
             $('#kilometro').val(datos[13]);
             if (datos[14] == '') {
                $('#cliente_direccion').focus();
             }
             if (datos[14] != '') {
                $('#mod_correo').focus();
             }
             $('#cliente_departamento').val(datos[14]);
             $('#cliente_provincia').val(datos[15]);
             $('#cliente_distrito').val(datos[16]);
             $('#cliente_direccion').val(datos[17]);
             $('#direcclienteruc').val(datos[18]);
             $('#ultima_actualizacion').val(datos[19]);
           } if(datos[0] == ''){
             //alert('RUC no válido o no registrado');
             toastr.warning("No pudimos encontrar el documento...","Aviso!");
             $("#documento_colaborador").val('');
             $('#documento_colaborador').focus();
           }   
         }
       });
       return false;
     });
   });
</script>
<script>

    var frm = $("#frmSubirImagen");
    var btnEnviar = $("button[type=submit]");

    var textoSubir = btnEnviar.text();
    var textoSubiendo = "Cargando...";

    frm.bind("submit",function () {

        var frmData = new FormData;
        frmData.append("imagen",$("input[name=imagen]")[0].files[0]);

        $.ajax({
            url: frm.attr("action"),
            type: frm.attr("method"),
            data: frmData,
            processData: false,
            contentType: false,
            cache: false,
            beforeSend: function (data) {
                btnEnviar.html(textoSubiendo);
                btnEnviar.attr("disabled",true);
            },
            success: function (data) {
                btnEnviar.html('Cargar Favicon');
                btnEnviar.attr("disabled",false);
                $(".datos_ajax_favicon").html(data);
                //carga_img1();
                //$(".outer_img1").load("../ajax/imgFavicon.php"); 
                $("#frmSubirImagen")[0].reset();
            }
        });
        return false;
    });

/*setInterval(
    function(){ 
        $(".outer_img1").load("../ajax/imgFavicon.php"); 
    }, 1000
);*/
</script>

<script>

    var frmLogo = $("#frmSubirImagenLogo");
    var btnEnviarLogo = $("button[type=submit]");

    var textoSubir = btnEnviarLogo.text();
    var textoSubiendoLogo = "Cargando...";

    frmLogo.bind("submit",function () {

        var frmDataLogo = new FormData;
        frmDataLogo.append("imagenLogo",$("input[name=imagenLogo]")[0].files[0]);

        $.ajax({
            url: frmLogo.attr("action"),
            type: frmLogo.attr("method"),
            data: frmDataLogo,
            processData: false,
            contentType: false,
            cache: false,
            beforeSend: function (data) {
                btnEnviarLogo.html(textoSubiendoLogo);
                btnEnviarLogo.attr("disabled",true);
            },
            success: function (data) {
                btnEnviarLogo.html('Cargar Logo');
                btnEnviarLogo.attr("disabled",false);
                $(".datos_ajax_logo").html(data);
                //carga_img1();
                //$(".outer_img1").load("../ajax/imgFavicon.php"); 
                $("#frmSubirImagenLogo")[0].reset();
                //console.log(data);
            }
        });
        return false;
    });

/*setInterval(
    function(){ 
        $(".outer_img1").load("../ajax/imgFavicon.php"); 
    }, 1000
);*/
</script>

<script>

    var frmCert = $("#frmSubirCertificado");
    var btnEnviarCert = $("button[type=submit]");

    var textoSubir = btnEnviarCert.text();
    var textoSubiendoCert = "Cargando...";

    frmCert.bind("submit",function () {

        var frmDataCert = new FormData;
        frmDataCert.append("imagenCertificado",$("input[name=imagenCertificado]")[0].files[0]);

        $.ajax({
            url: frmCert.attr("action"),
            type: frmCert.attr("method"),
            data: frmDataCert,
            processData: false,
            contentType: false,
            cache: false,
            beforeSend: function (data) {
                btnEnviarCert.html(textoSubiendoCert);
                btnEnviarCert.attr("disabled",true);
            },
            success: function (data) {
                btnEnviarCert.html('Cargar Certificado');
                btnEnviarCert.attr("disabled",false);
                $(".datos_ajax_certificado").html(data);
                //carga_img1();
                //$(".outer_img1").load("../ajax/imgFavicon.php"); 
                $("#frmSubirCertificado")[0].reset();
            }
        });
        return false;
    });

/*setInterval(
    function(){ 
        $(".outer_img1").load("../ajax/imgFavicon.php"); 
    }, 1000
);*/
</script>

<script>


    document.querySelectorAll(".drop-zone__input").forEach((inputElement) => {
  const dropZoneElement = inputElement.closest(".drop-zone");

  dropZoneElement.addEventListener("click", (e) => {
    inputElement.click();
  });

  inputElement.addEventListener("change", (e) => {
    if (inputElement.files.length) {
      updateThumbnail(dropZoneElement, inputElement.files[0]);
    }
  });

  dropZoneElement.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZoneElement.classList.add("drop-zone--over");
  });

  ["dragleave", "dragend"].forEach((type) => {
    dropZoneElement.addEventListener(type, (e) => {
      dropZoneElement.classList.remove("drop-zone--over");
    });
  });

  dropZoneElement.addEventListener("drop", (e) => {
    e.preventDefault();

    if (e.dataTransfer.files.length) {
      inputElement.files = e.dataTransfer.files;
      updateThumbnail(dropZoneElement, e.dataTransfer.files[0]);
    }

    dropZoneElement.classList.remove("drop-zone--over");
  });
});

/**
 * Updates the thumbnail on a drop zone element.
 *
 * @param {HTMLElement} dropZoneElement
 * @param {File} file
 */
function updateThumbnail(dropZoneElement, file) {
  let thumbnailElement = dropZoneElement.querySelector(".drop-zone__thumb");

  // First time - remove the prompt
  if (dropZoneElement.querySelector(".drop-zone__prompt")) {
    dropZoneElement.querySelector(".drop-zone__prompt").remove();
  }

  // First time - there is no thumbnail element, so lets create it
  if (!thumbnailElement) {
    thumbnailElement = document.createElement("div");
    thumbnailElement.classList.add("drop-zone__thumb");
    dropZoneElement.appendChild(thumbnailElement);
  }

  thumbnailElement.dataset.label = file.name;

  // Show thumbnail for image files
  if (file.type.startsWith("image/")) {
    const reader = new FileReader();

    reader.readAsDataURL(file);
    reader.onload = () => {
      thumbnailElement.style.backgroundImage = `url('${reader.result}')`;
    };
  } else {
    thumbnailElement.style.backgroundImage = null;
  }
}
</script>