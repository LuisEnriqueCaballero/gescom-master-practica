<?php
session_start();
//include "../modal/enviarWhatsAppCot.php";
//include "../modal/enviarCorreoCot.php";
include "../modal/eliminarCompra.php";
include "../modal/adjuntocompra.php";
?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Gastos</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load(1)" style="cursor: pointer;">Egresos</a></li>
        <li class="active">Historial Gastos</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="tab-base">              
                  <!--Nav Tabs-->
                  <ul class="nav nav-tabs">
                        <li class="active">
                              <a data-toggle="tab" href="#demo-lft-tab-1">SOLES <span class="badge badge-primary">PEN</span></a>
                        </li>
                        <li>
                              <a data-toggle="tab" href="#demo-lft-tab-2">D&Oacute;LARES <span class="badge badge-primary">USD</span></a>
                        </li>
                        <div class="input-group" style="float: right;">
                            <div class="input-group mar-btm">
                                <input type="text" class="form-control daterange pull-right" value="<?php echo "01" . date('/m/Y') . ' - ' . date('d/m/Y'); ?>" id="range" readonly>
                                <div class="input-group-addon btn btn-primary" onclick='loadF(1);loadB(1);loadNC(1);loadND(1);loadNP(1);' style="cursor: url(../img/company/cursorH1.png), pointer;"><i class='fa fa-search'></i></div>
                            </div>
                        </div>
                  </ul>
                  <!--Tabs Content-->
                  <div class="tab-content" style="margin-top: -6px;">
                        <div id="demo-lft-tab-1" class="tab-pane fade active in">
                              <div class="row">
                                    <div class="col-md-12">
                                          <div class="card">
                                                <div class="card-body">
                                                    <div id="ldng_cat" style="text-align: center;"></div>
                                                    <div id="resultados_ajax"></div>
                                                    <div class='outer_div_cat'></div>
                                                </div>
                                          </div>
                                    </div>
                              </div>
                        </div>
                        <div id="demo-lft-tab-2" class="tab-pane fade">
                              <div class="row">
                                    <div class="col-md-12">
                                          <div class="card">
                                                <div class="card-body">
                                                    <div id="ldng_cat_usd" style="text-align: center;"></div>
                                                    <div id="resultados_ajax_usd"></div>
                                                    <div class='outer_div_cat_usd'></div>
                                                </div>
                                          </div>
                                    </div>
                              </div>
                        </div>
                  </div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<script src="../js/gastos.js"></script>
<script>
$(function () {
        //Initialize Select2 Elements
        $(".select2").select2();
    });
  $(function() {
    load(1);

//Date range picker
$('.daterange').daterangepicker({
  buttonClasses: ['btn', 'btn-sm'],
  applyClass: 'btn-primary',
  cancelClass: 'btn-danger',
  locale: {
    format: "DD/MM/YYYY",
    separator: " - ",
    applyLabel: "Aplicar",
    cancelLabel: "Cancelar",
    fromLabel: "Desde",
    toLabel: "Hasta",
    customRangeLabel: "Personalizado",
    daysOfWeek: [
    "Do",
    "Lu",
    "Ma",
    "Mi",
    "Ju",
    "Vi",
    "Sa"
    ],
    monthNames: [
    "Enero",
    "Febrero",
    "Marzo",
    "Abril",
    "Mayo",
    "Junio",
    "Julio",
    "Agosto",
    "Septiembre",
    "Octubre",
    "Noviembre",
    "Diciembre"
    ],
  },
  ranges: {
       'Hoy': [moment(), moment()],
       'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
       'Ultimos 7 dias': [moment().subtract(6, 'days'), moment()],
       'Ultimos 30 dias': [moment().subtract(29, 'days'), moment()],
       'Este mes': [moment().startOf('month'), moment().endOf('month')],
       'El mes pasado': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    },
  opens: "left"

});
});
//Muestra historial a4
function dGastoSPDF(){
    var range=$("#range").val();
    VentanaCentrada('../view/pdf/documentos/a4_historico_gastos.php?action=ajax&range='+range,'Factura','','1024','768','true');
}
//Descarga historial excel
function dGastoSExcel(){
    var range=$("#range").val();
    window.open('../view/excel/historico_gastos.php?action=ajax&range='+range,'_blank');
}
//Muestra historial a4
function dGastoDPDF(){
    var range=$("#range").val();
    VentanaCentrada('../view/pdf/documentos/a4_historico_gastod.php?action=ajax&range='+range,'Factura','','1024','768','true');
}
//Descarga historial excel
function dGastoDExcel(){
    var range=$("#range").val();
    window.open('../view/excel/historico_gastod.php?action=ajax&range='+range,'_blank');
}
</script>