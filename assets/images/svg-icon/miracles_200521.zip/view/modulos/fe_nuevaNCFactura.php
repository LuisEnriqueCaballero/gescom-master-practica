<!-- Start Breadcrumbbar -->
<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
/* Connect To Database*/
session_start();
require_once "../../config/general.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos
include "../modal/buscarProductosVenta.php";
include "../modal/registroItem.php";
//include "../modal/buscarProductosVenta.php";
//include "../modal/registroCliente.php";
$session_id=session_id();
$delete = mysqli_query($con, "DELETE FROM tmpventas WHERE tmpVentas_session='".$session_id."'");

$tienda = $_SESSION['tienda'];
$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);
?>
<?php if($a[90]==1){ ?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Nota Cr&eacute;dito Factura</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load(1);" style="cursor: pointer;">Fact. Electr&oacute;nica</a></li>
        <li class="active">Nota Cr&eacute;dito Factura</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <select class="form-control selectNCF" id="id_factura" name="id_factura" onchange="nc(this);" required>
                    <option value="">-- Selecciona un documento --</option>
                <?php
                $consulta4 = "SELECT * FROM facturas WHERE factura_tipo=1 and factura_venCom=1 and factura_activo=1 and factura_nc=0 and factura_sucursal=$tienda";
                $result4 = mysqli_query($con, $consulta4);
                while ($valor4 = mysqli_fetch_array($result4, MYSQLI_ASSOC)) {
                    $factura_correlativo = $valor4['factura_correlativo'];
                    $numero_factura2 = str_pad($factura_correlativo, 8, "0", STR_PAD_LEFT); ?>     
                    <option  value="<?php echo $valor4['factura_id']; ?>"><?php echo $valor4['factura_folio']."-".$numero_factura2; ?></option>
                <?php } ?>
                </select>
                <div id="ldng_cat" style="text-align: center;"></div>
                <div id="resultados_ajax"></div>
                <div class='outer_div_cat'></div>
                <div id='outer_div_carga'>
                    <br>
                    <div class="alert alert-info" style="text-align: center;">
                        <strong>Primero selecciona una factura!</strong> <img src="../assets/images/svg-icon/hand-up.svg" style="width: 40px;">
                        <br>Aqu&iacute; se mostrar&aacute; el detalle de la factura seleccionada.
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<?php } else { 
    include "../includes/sinAcceso.php";
} ?>
<script src="../js/nuevaNCFactura.js"></script>
<script src="../js/ventanaCentrada.js"></script>
<script>
$('.selectNCF').select2({
  placeholder: 'Buscar documento...',
  width: 'resolve',
  //theme: "classic"
});
</script>
<script>
function nc(sel)
  {
    if(sel.value==''){
        toastr.error("Seleccionar documento","Oopss!");
        $("#outer_div_carga").html(" ");
    }
    else {
        //toastr.success("Almac&eacute;n seleccionado","Bien hecho!");
        $("#outer_div_carga").load("../ajax/cargaNCFactura.php?id_factura="+sel.value);
    }
  }
</script>