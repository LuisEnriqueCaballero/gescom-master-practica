<?php
session_start();
require_once "../../config/general.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos
$empresa = $_SESSION['datosEmpresa_id'];

$sql_empresa=mysqli_query($con,"select * from datosempresa where datosEmpresa_id=$empresa");
$rw_tienda=mysqli_fetch_array($sql_empresa);
$datosEmpresa_ruc=$rw_tienda['datosEmpresa_ruc'];

$user_id = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);

?>
<?php if($a[98]==1){ ?>

<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Registro Compras</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
        <li><a href="#/ss_inicio" style="cursor: pointer;"><i class="demo-pli-home"></i></a></li>
        <li><a onclick="load(1);" style="cursor: pointer;">Contabilidad</a></li>
        <li class="active">Registro Compras</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="panel panel-body">
                <div class="form-inline">
                    <div class="form-group">
                        <label for="demo-inline-inputmail" class="sr-only">Moneda</label>
                        <select class="form-control" name="moneda" onchange="load(1);" id="moneda">
                            <option value="115">SOLES</option>
                            <option value="151">DOLARES</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="demo-inline-inputpass" class="sr-only">Fecha</label>
                        <div class="input-group ">
                            <input type="text" id="range" class="form-control" placeholder="Seleccionar periodo" value="<?php echo date('M Y'); ?>" aria-describedby="basic-addon4" readonly />
                            <div class="input-group-addon btn btn-primary" onclick='load(1);'><i class='fa fa-search'></i></div>
                        </div>
                    </div>
                </div>
                <div id="ldng_cat" style="text-align: center;"></div>
                <div id="resultados_ajax"></div>
                <div class='outer_div_cat'></div>
            </div>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>

<?php } else { 
    include "../includes/sinAcceso.php";
} ?>

<script src="../js/registroCompras2.js"></script>
<script src="../js/ventanaCentrada.js"></script>
<script>
$(function () {
    //Initialize Select2 Elements
    $(".select2").select2();
});
$(function() {
    load(1);
});
$("#range").datepicker({
  changeMonth: true,
  changeYear: true,
  dateFormat: "M yy",
  showButtonPanel: true,
  currentText: "Este mes",
  closeText: 'Cerrar',
  monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
  prevText: '< Ant',
  nextText: 'Sig >',
  onChangeMonthYear: function (year, month, inst) {
    $("#range").val($.datepicker.formatDate('M yy', new Date(year, month - 1, 1)));
  },
  onClose: function(dateText, inst) {
    var month = $(".ui-datepicker-month :selected").val();
    var year = $(".ui-datepicker-year :selected").val();
    $("#range").val($.datepicker.formatDate('M yy', new Date(year, month, 1)));
  }
}).focus(function () {
  $(".ui-datepicker-calendar").hide();
});
</script>
<script>
function excel(page){
    var range=$("#range").val();
    var moneda=$("#moneda").val();
    //VentanaCentrada('../view/excel/registroCompras.php?daterange='+daterange,'Reporte','','800','600','true');
    window.open('../view/excel/registroCompras.php?action=ajax&page='+page+'&range='+range+'&moneda='+moneda, '_blank');
}

function pdf(){
    var range=$("#range").val();
    var moneda=$("#moneda").val();
    VentanaCentrada('../view/pdf/documentos/registroCompras.php?action=ajax&range='+range+'&moneda='+moneda,'Reporte','','800','600','true');
    //window.open('../view/pdf/documentos/registroCompras.php?action=ajax&page='+page+'&range='+range, '_blank');
}
function txt(page){
    var range=$("#range").val();
    var moneda=$("#moneda").val();
    //VentanaCentrada('../view/excel/registroCompras.php?daterange='+daterange,'Reporte','','800','600','true');
    window.open('../view/txt/registroCompras.php?action=ajax&page='+page+'&range='+range+'&moneda='+moneda, '_blank');
}
function txtv(page){
    var range=$("#range").val();
    var moneda=$("#moneda").val();
    //VentanaCentrada('../view/excel/registroCompras.php?daterange='+daterange,'Reporte','','800','600','true');
    window.open('../view/txt/registroComprasV.php?action=ajax&page='+page+'&range='+range+'&moneda='+moneda, '_blank');
}
function txtsv(page){
    var range=$("#range").val();
    var moneda=$("#moneda").val();
    //VentanaCentrada('../view/excel/registroCompras.php?daterange='+daterange,'Reporte','','800','600','true');
    window.open('../view/txt/registroComprasSV.php?action=ajax&page='+page+'&range='+range+'&moneda='+moneda, '_blank');
}
</script>