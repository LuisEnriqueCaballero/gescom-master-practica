<?php
session_start();
/* Connect To Database*/
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos
//Incluimos los modales
include "../modal/imgItem.php";
include "../modal/registroItem.php";
include "../modal/editarItem.php";
include "../modal/eliminarItem.php";
include "../modal/especificacionesItem.php";
include "../modal/fichaItem.php";

$user_id = $_SESSION['usuario_id'];
$tienda  = $_SESSION['tienda'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo);
?>
<?php if($a[34]==1 || $a[35]==1 || $a[36]==1 || $a[37]==1 || $a[38]==1 || $a[39]==1 || $a[40]==1){ ?>
<div id="content-container">
    <div id="page-head">
        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Almacenes > &Iacute;tems</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->
    </div>
    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <!-- Contact Toolbar -->
        <!---------------------------------->
        <!---------------------------------->                    
        <div class="row">
            <?php
                $sql = "select * from almacenes where almacen_idSucursal='$tienda' and almacen_activo='1' order by almacen_id asc";
                $query = mysqli_query($con,$sql);
                while ($row = mysqli_fetch_array($query)) {
                    $almacen_id = $row['almacen_id'];
                    $nombre = substr($row['almacen_direccion'], 0, 28).'...';

                    $user = mysqli_query($con, "select * from productos where producto_idSucursal='$almacen_id'");
                    $num  = mysqli_num_rows($user);
            ?>
            <div class="col-sm-4 col-md-3">
                <!-- Contact Widget -->
                <!---------------------------------->
                <div class="panel pos-rel">
                    <div class="pad-all text-center">
                        <a href="#/pr_items1.php?almacen=<?php echo $almacen_id; ?>">
                            <img alt="Profile Picture" class="img-lg mar-ver" src="../assets/images/svg-icon/warehouse.svg">
                            <p class="text-lg text-semibold mar-no text-main"><?php echo $row['almacen_nombre']; ?></p>
                            <p class="text-sm"><b><?php echo $num; ?> &iacute;tems</b></p>
                            <p class="text-sm"><?php echo $nombre; ?></p>
                        </a>
                    </div>
                </div>
                <!---------------------------------->
            </div>
            <?php } ?>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<?php } else { 
    include "../includes/sinAcceso.php";
} ?>
<script src="../js/items.js"></script>