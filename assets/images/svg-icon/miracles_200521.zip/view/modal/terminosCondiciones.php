<style>
.scroll {
  max-height: 300px;
  overflow: auto;
}
</style>   
   <div class="modal fade" id="terminosCondiciones" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content modal-lg">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                <h4 class="modal-title">T&Eacute;RMINOS DE SERVICIO Y CONDICIONES DE USO</h4>
            </div>
            <div class="modal-body">
               <div class="scroll">
               	<h5>Definiciones</h5>
                  <p style="text-align: justify;">- SERVICIO: La plataforma que compone Moli<strong>POS</strong> <br>
                  - T&Eacute;RMINOS: Los t&eacute;rminos de servicio y condiciones de uso detallados en este documento.</p>
                  <h5>Aceptaci&oacute;n</h5>
                  <p style="text-align: justify;">Se considera autom&aacute;ticamente que al utilizar el <strong>SERVICIO</strong> acepta la validez de estos T&Eacute;RMINOS y est&aacute; obligado a cumplirlas como se indica en este documento sin modificaci&oacute;n alguna.</p>
                  <h5>Garant&iacute;a limitada</h5>
                  <p style="text-align: justify;"><strong>Developer Technology</strong> es responsable en la medida m&aacute;xima permitida por la ley. A excepci&oacute;n de lo especificado en estas condiciones y nuestras GARANT&Iacute;AS DE SEGURIDAD, no somos responsables de ninguna p&eacute;rdida, lesi&oacute;n, demanda, responsabilidad, daño o daños indirectos relacionados con el uso del SERVICIO, esto incluye la inaccesibilidad al SERVICIO, ya sea por errores u omisiones en el contenido o cualquier otro sitio vinculado o por cualquier otra raz&oacute;n.</p>
                  <h5>Modificaci&oacute;n de T&Eacute;RMINOS</h5>
                  <p style="text-align: justify;"><strong>Developer Technology</strong> se reserva el derecho de modificar los T&Eacute;RMINOS y condiciones o pol&iacute;ticas con respecto al uso del SERVICIO en cualquier momento y usted autoriza ser notificado sobre la actualizaci&oacute;n de los mismos.</p>
                  <h5>Derechos de autor</h5>
                  <p style="text-align: justify;">El aspecto y el dise&ntilde;o del sitio est&aacute; protegido. Todos los derechos est&aacute;n reservados. El usuario no puede duplicar, copiar, reutilizar o cualquier parte del HTML / CSS o elementos de dise&ntilde;o visual sin el permiso expreso y por escrito de <strong>Developer Technology</strong>.</p>
                  <h5>Ingenier&iacute;a inversa</h5>
                  <p style="text-align: justify;">Ingenier&iacute;a inversa de la funcionalidad o el dise&ntilde;o del sitio no est&aacute; permitido.</p>
                  <h5>Cancelaci&oacute;n o suspensi&oacute;n</h5>
                  <p style="text-align: justify;">Usted puede cancelar el SERVICIO en cualquier momento despu&eacute;s de haber finalizado el contrato. Tambi&eacute;n puede solicitar la eliminaci&oacute;n o suspensi&oacute;n temporal de su cuenta por email a soporte@developer-technology.net</p>
                  <h5>Pago del SERVICIO</h5>
                  <p style="text-align: justify;">El pago del SERVICIO se realiza el primero de cada mes, caso contrario nos reservamos el derecho de suspender temporalmente el SERVICIO hasta cancelado el mes.</p>
               </div>
               <hr>
               Developer Technology <br>
               RUC 10725799093 <br>
               Lima, Lima, Los Olivos <br>
               soporte@developer-technology.net <br>
               Protegido y cifrado con SSL EV (https://), la seguridad de datos es nuestra prioridad <br>
               Derechos reservados 2019 - <?php echo date('Y'); ?>
               </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
            </div>
         </div>
      </div>
   </div>