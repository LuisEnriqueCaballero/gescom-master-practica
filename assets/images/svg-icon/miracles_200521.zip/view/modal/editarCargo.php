<form method="post" id="editar_cargo" name="editar_cargo" autocomplete="off" class="form-horizontal" autocomplete="off">
   <div class="modal fade" id="editarCargo" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Editar Cargo</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div id="resultados_ajax2"></div>
               <div class="row">
                   <div class="form-group col-md-12">
                       <label for="mod_nombre">Nombre *</label>
                       <input type="text" class="form-control" id="mod_nombre" name="mod_nombre" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" autofocus required>
                       <input type="hidden" name="mod_idCargo" id="mod_idCargo">
                   </div>
               </div>
             </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">Cancelar</button>
                 <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
             </div>
         </div>
     </div>
   </div>

</form>