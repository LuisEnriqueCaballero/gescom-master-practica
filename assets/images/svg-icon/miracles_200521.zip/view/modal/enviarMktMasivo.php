<?php
$sex = $_SESSION['usuario_sexo'];
if ($sex==1) {
   $sexo = "o";
}
if ($sex==2) {
   $sexo = "a";
}
?>
<form id="enviarMasivo">
   <div class="modal fade" id="envioMasivoMail" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">¿Est&aacute;s segur<?php echo $sexo; ?>?</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div class="datos_ajax_delete_masivo"></div>
               <p>Esta acci&oacute;n enviar&aacute; el correo de forma masiva. ¿Deseas continuar?</p>
               <input type="hidden" name="id_clienteMailMasivo" id="id_clienteMailMasivo" value="1">
             </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">No, cancelar</button>
                 <button type="submit" class="btn btn-primary" id="envioMas">S&iacute;, continuar</button>
             </div>
         </div>
     </div>
   </div>
</form>