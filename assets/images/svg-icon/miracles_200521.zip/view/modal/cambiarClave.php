<form method="post" id="editar_password" name="editar_password" autocomplete="off">
   <div class="modal fade" id="change_password" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Cambiar Contrase&ntilde;a</h4>
             </div>
            <div class="modal-body">
              <div id="resultados_ajax"></div>
               <div class="form-group " style="display: none;">
                     <input type="text" class="form-control" id="mod_id" name="mod_id" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Usuario" required value="<?php echo $_SESSION['usuario_id']; ?>">
               </div>
               <div class="form-group ">
                     <input type="password" class="form-control" id="user_password_new" name="user_password_new" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Contrase&ntilde;a *" required>
               </div>
               <div class="form-group ">
                     <input type="password" class="form-control" id="user_password_repeat" name="user_password_repeat" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Repetir contrase&ntilde;a *" required>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="actualizar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>