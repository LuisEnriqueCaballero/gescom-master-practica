<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
?>
<form method="post" id="editar_usuarioP" name="editar_usuarioP" autocomplete="off" class="form-horizontal">

   <div class="modal fade" id="editarUsuarioP" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
              <h4 class="modal-title">Editar Contrase&ntilde;a Usuario</h4>
            </div>
            <div class="modal-body">
              <div id="resultados_ajax2"></div>
              <input type="hidden" name="mod_idUsuarioP" id="mod_idUsuarioP">
              <div class="row">
                  <div class="form-group col-sm-12">
                     <label for="mod_user_password_new">Contrase&ntilde;a</label>
                    <input type="password" class="form-control" id="mod_user_password_new" name="mod_user_password_new" placeholder="Contrase&ntilde;a" onKeyUp="this.value=this.value.toUpperCase();" onBlur="validaContrasena();" required>
                  </div>
               </div>
               <div class="row">
                  <div class="form-group col-sm-12">
                     <label for="mod_user_password_repeat">Repite Contrase&ntilde;a</label>
                    <input type="password" class="form-control" id="mod_user_password_repeat" name="mod_user_password_repeat" placeholder="Repite contrase&ntilde;a" onKeyUp="this.value=this.value.toUpperCase();" readonly required>
                  </div>
              </div>
                  
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="editar">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>