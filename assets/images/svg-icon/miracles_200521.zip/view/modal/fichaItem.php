<div class="modal fade" id="fichaItem" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
     <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
            <h4 class="modal-title">Cargar Ficha T&eacute;cnica</h4>
        </div>
        <div class="modal-body">
        	<div class="datos_ajax_delete"></div>
          <div class="outer_img"></div>
        </div>
     </div>
  </div>
</div>