<form class="form-horizontal"  method="post" name="add_stock" id="add_stock" autocomplete="off">
  <div class="modal fade bs-example-modal-lg" id="add-stock" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog " role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
        <h4 class="modal-title">Agregar Stock</h4>
      </div>
      <div class="modal-body">
        <div id="resultados_ajaxStock"></div>
        <div class="row">
           <div class="form-group col-md-12">
               <label for="quantity">Cantidad *</label>
               <input type="text" class="form-control" id="quantity" name="quantity" placeholder="Cantidad" pattern="^[0-9]{1,5}(\.[0-9]{0,2})?$" title="Ingresa sólo números con 0 ó 2 decimales" maxlength="8" required onKeyUp="this.value=this.value.toUpperCase();">
           </div>
           <div class="form-group col-md-12">
               <label for="reference">Referencia *</label>
               <input type="text" class="form-control" id="reference" name="reference" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Referencia" value="--" required>
           </div>
           <div class="form-group col-md-12">
               <label for="motivo">Motivo *</label>
               <input type="text" class="form-control" id="motivo" name="motivo" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Motivo" required>
           </div>
        </div>
      </div>
      <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary" id="guardar_datos">Guardar</button>
      </div>
    </div>
    </div>
  </div>
</form>