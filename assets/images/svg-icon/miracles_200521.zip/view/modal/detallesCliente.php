<div class='modal fade' id='detallesCliente' tabindex='-1' role='dialog' aria-labelledby='exampleModalCenterTitle' aria-hidden='true'>
   <div class='modal-dialog' role='document'>
      <div class='modal-content'>
          <div class='modal-header'>
            <button type='button' class='close' data-dismiss='modal'><i class='pci-cross pci-circle'></i></button>
            <h4 class='modal-title'><span id="cliente_nombre"></h4>
          </div>
          <div class='modal-body'>
            <input type='hidden' name='id_cliente' id='id_cliente'>
            <div class='media'>
              <div class='media-left'>
                <img class='media-object img-lg' src='../img/client/client.png'>
              </div>
              <div class='media-body'>
                  <p class='mb-0 font-12 font-italic'><b><span id="cliente_direccion"></span></b></p><hr>
                  <b><span id="cliente_tipo"></span>:</b> <span id="cliente_documento"></span><br>
                  <b>Tel&eacute;fono:</b> <span id="cliente_telefono"></span><br>
                  <b>E-Mail:</b> <span id="cliente_email"></span><br>
                  <b>Contacto:</b> <span id="cliente_contacto"></span><br>
                  <b>Cargo:</b> <span id="cliente_cargo"></span><br>
                  <b>Extra:</b> <span id="cliente_extra"></span><br>
                  <b>F. Registro:</b> <span id="cliente_registro"></span>
              </div>
            </div>
         </div>
         <div class='modal-footer'>
            <button type='button' class='btn btn-default' data-dismiss='modal'>Cerrar</button>
         </div>
      </div>
   </div>
</div>