<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
//session_start();
/* Connect To Database*/
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos

$almacen = $_SESSION['almacen'];

$user_id                = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo); 

?>
<form method="post" id="guardar_item" name="guardar_item" autocomplete="off" class="form-horizontal">
   <div class="modal fade" id="nuevoItem" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog modal-lg">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Nuevo &Iacute;tem</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
              <div id="resultados_ajax2"></div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="producto_codigoBarras">C&oacute;digo Barras *</label>
                       <div id="cod_resultado"></div>
                   </div>
                   <div class="col-md-6">
                       <label for="producto_nombre">Nombre *</label>
                       <input type="text" autofocus class="form-control" id="producto_nombre" name="producto_nombre" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" required onblur="PasarCodigo();">
                   </div>
               </div>
               <div class="row">
                  <div class="col-md-6">
                       <label for="producto_descripcion">Descripci&oacute;n</label>
                       <input type="text" class="form-control" id="producto_descripcion" name="producto_descripcion" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Descripci&oacute;n">
                   </div>
                  <div class="col-md-6">
                     <label for="producto_codigo" style="color: red;">C&oacute;digo Producto SUNAT *</label>
                     <div class="input-group">
                         <input type="text" class="form-control" name="producto_codigo" id="producto_codigo" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Buscar c&oacute;digo UNSPSC" readonly data-toggle='modal' data-target='#sunat'>
                         <div class="input-group-addon btn btn-primary" data-toggle='modal' data-target='#sunat'><i class="fa fa-search"></i></div>
                     </div>
                  </div>
               </div>
               <div class="row">
                   
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="producto_idCategoria">Categor&iacute;a *</label>
                       <div class="input-group">
                         <div id="cargaCategoriaAjax"></div>
                          <?php if ($a[31] == 1) { ?>
                            <span class="input-group-btn">
                              <div id="tipo_boton"><div class="btn btn-primary" data-toggle='modal' data-target='#nuevoCategoria'><i class="fa fa-plus"></i></div></div>
                            </span>
                          <?php } else { ?>
                            <span class="input-group-btn">
                              <div id="tipo_boton"><div class="btn btn-primary disabled"><i class="fa fa-plus"></i></div></div>
                            </span>
                          <?php } ?>
                      </div>
                   </div>
                   <div class="col-md-6">
                      <label for="producto_idMarca">Marca *</label>
                      <div class="input-group">
                         <div id="cargaMarcaAjax"></div>
                          <?php if ($a[27] == 1) { ?>
                            <span class="input-group-btn">
                              <div id="tipo_boton"><div class="btn btn-primary" data-toggle='modal' data-target='#nuevoMarca'><i class="fa fa-plus"></i></div></div>
                            </span>
                          <?php } else { ?>
                            <span class="input-group-btn">
                              <div id="tipo_boton"><div class="btn btn-primary disabled"><i class="fa fa-plus"></i></div></div>
                            </span>
                          <?php } ?>
                      </div>
                   </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="producto_idUnidadMedida">Unidad Medida *</label>
                       <select name="producto_idUnidadMedida" id="producto_idUnidadMedida" class="select2 form-control" style="width: 100%; text-align: left;" required>
                          <?php
                             $sql_segmento ="select * from unidadmedida";
                             $row          =mysqli_query($con,$sql_segmento);
                             while ($row4 = mysqli_fetch_array($row)) {
                                $unidadMedida_nombre = $row4["unidadMedida_nombre"];
                                $unidadMedida_id     = $row4["unidadMedida_id"];
                          ?>
                          <option value="<?php echo $unidadMedida_id;?>"><?php  echo $unidadMedida_nombre;?></option>

                          <?php } ?>
                      </select>
                   </div>
                   <div class="col-md-6">
                       <label for="producto_idProveedor">Proveedor *</label>
                       <select name="producto_idProveedor" id="producto_idProveedor" class="select2 form-control" style="width: 100%; text-align: left;" required>
                          <?php $tienda = $_SESSION['tienda'];
                             $sql_segmento ="select * from proveedores where (proveedor_sucursal='$tienda' or proveedor_sucursal=0) order by proveedor_id asc";
                             $row          =mysqli_query($con,$sql_segmento);
                             while ($row4 = mysqli_fetch_array($row)) {
                                $proveedor_nombre = $row4["proveedor_nombre"];
                                $proveedor_id     = $row4["proveedor_id"];
                          ?>
                          <option value="<?php echo $proveedor_id;?>"><?php  echo $proveedor_nombre;?></option>

                          <?php } ?>
                      </select>
                   </div>
               </div>

               <div class="row">
                   <div class="col-md-3">
                       <label for="producto_afectacion">Tipo Afectaci&oacute;n *</label>
                       <select name="producto_afectacion" id="producto_afectacion" class="select2 form-control" style="width: 100%; text-align: left;" required>
                          <?php
                             $sql_segmento ="select * from tipo_afectacion where tipoafectacion_id<= 18";
                             $row          =mysqli_query($con,$sql_segmento);
                             while ($row4 = mysqli_fetch_array($row)) {
                                $tipoafectacion_nombre = $row4["tipoafectacion_nombre"];
                                $tipoafectacion_id     = $row4["tipoafectacion_id"];
                          ?>
                          <option value="<?php echo $tipoafectacion_id;?>"><?php  echo $tipoafectacion_nombre;?></option>

                          <?php } ?>
                      </select>
                   </div>
                   <div class="col-md-3">
                       <label for="producto_monVenta">Moneda *</label>
                       <select name="producto_monVenta" id="producto_monVenta" class="select2 form-control" style="width: 100%; text-align: left;" required>
                          <?php
                             $sql_segmento ="select * from monedas where (moneda_id=115 or moneda_id=151)";
                             $row          =mysqli_query($con,$sql_segmento);
                             while ($row4 = mysqli_fetch_array($row)) {
                                $moneda_nombre = $row4["moneda_nombre"];
                                $moneda_id     = $row4["moneda_id"];
                          ?>
                          <option value="<?php echo $moneda_id;?>"><?php  echo $moneda_nombre;?></option>

                          <?php } ?>
                      </select>
                   </div>
                   <div class="col-md-3">
                       <label for="producto_costo">Costo *</label>
                       <input type="text" class="form-control" id="producto_costo" name="producto_costo" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Costo" required>
                   </div>
                   <div class="col-md-3">
                       <label for="producto_precio">Precio *</label>
                       <input type="text" class="form-control" id="producto_precio" name="producto_precio" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Precio" required>
                   </div>
               </div>

               <div class="row">
                   <div class="col-md-2">
                       <label for="producto_stock">Stock Inicial *</label>
                       <input type="text" class="form-control" id="producto_stock" name="producto_stock" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Stock Inicial" required>
                   </div>
                   <div class="col-md-2">
                       <label for="producto_minimo">Stock M&iacute;nimo *</label>
                       <input type="text" class="form-control" id="producto_minimo" name="producto_minimo" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Stock M&iacute;nimo" required>
                   </div>
                   <div class="col-md-2">
                       <label for="producto_icbper">ICBPER? *</label>
                       <select name="producto_icbper" id="producto_icbper" class="select2 form-control" style="width: 100%; text-align: left;" required>
                          <option value="1">NO</option>
                          <option value="2">S&Iacute;</option>
                      </select>
                   </div>
                   <div class="col-md-3">
                       <label for="producto_fechaVencimiento1">Caduca? *</label>
                       <select name="producto_fechaVencimiento1" id="producto_fechaVencimiento1" class="select2 form-control" style="width: 100%; text-align: left;" required onchange="showFv(this)">
                          <option value="1">NO</option>
                          <option value="2">S&Iacute;</option>
                      </select>
                   </div>
                   <div id="carga_fecha" class="col-md-3"></div>
                   <input type="text" name="almacenP" id="almacenP" value="<?php echo $almacen; ?>" class="hidden">
               </div>

            </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">Cancelar</button>
                 <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
             </div>
         </div>
     </div>
   </div>
   

   <div class="modal fade" id="sunat" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document" style="box-shadow: 2px 2px 10px #666">
          <div class="modal-content">
              <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">C&oacute;digo UNSPSC</h4>
              </div>
              <div class="modal-body">
                <div class="row">
                   <div class="col-md-12">
                       <label for="producto_idSegmento">Segmento *</label>
                       <select name="producto_idSegmento" id="producto_idSegmento" class="select21 form-control" style="width: 100%;">
                          <option value="">-- SEGMENTO --</option>
                          <?php           
                             $sql_segmento ="select * from segmento_producto";
                             $row          =mysqli_query($con,$sql_segmento);
                             while ($row4 = mysqli_fetch_array($row)) {
                                $segmento_nombre = $row4["segmento_nombre"];
                                $segmento_id     = $row4["segmento_id"];
                          ?>
                          <option value="<?php echo $segmento_id;?>"><?php  echo $segmento_nombre;?></option>

                          <?php } ?>
                      </select>
                   </div>

                   <div class="col-md-12">
                       <label for="producto_idFamilia">Familia *</label>
                       <select name="producto_idFamilia" id="producto_idFamilia" class="select21 form-control" style="width: 100%; text-align: left;">
                          <option value="">-- PRIMERO SELECCIONA UN SEGMENTO --</option>
                      </select>
                   </div>
                </div>

                <div class="row">
                   <div class="col-md-12">
                       <label for="producto_idClase">Clase *</label>
                       <select name="producto_idClase" id="producto_idClase" class="select21 form-control" style="width: 100%; text-align: left;">
                          <option value="">-- PRIMERO SELECCIONA UNA FAMILIA --</option>
                      </select>
                   </div>

                   <div class="col-md-12">
                       <label for="producto_idProducto">Producto *</label>
                        <select name="producto_idProducto" id="producto_idProducto" class="select21 form-control" style="width: 100%; text-align: left;">
                            <option value="">-- PRIMERO SELECCIONA UNA CLASE --</option>
                        </select>
                   </div>
                </div>
              </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">De acuerdo</button>
              </div>
          </div>
      </div>
  </div>
</form>
<script>
$('.select21').select2({
  placeholder: 'Selecciona una opcion',
  width: 'resolve',
  dropdownParent: $("#sunat")
  //theme: "classic"
});
//
function PasarCodigo() {
    document.getElementById("producto_codigo").value = document.getElementById("producto_codigoBarras").value;
}
</script>