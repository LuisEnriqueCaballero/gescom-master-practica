<div class="modal left fade" id="modalMar" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Marcas</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
                <div id="ldng_mar"></div>
                <div id="outer_div_mar"></div>
             </div>
         </div>
     </div>
   </div>
<script>
//
$(document).ready(function(){
  loadM(1);
});
//Busca los datos
function loadM(page){
  $("#ldng_mar").fadeIn('slow');
  $.ajax({
    url:'../ajax/buscarMar.php',
    beforeSend: function(objeto){
      $('#ldng_mar').html('<img src="../assets/images/svg-icon/loading.svg" width="50">');
    },
    success:function(data){
      $("#outer_div_mar").html(data).fadeIn('slow');
      $('#ldng_mar').html('');
    }
  })
}
</script>