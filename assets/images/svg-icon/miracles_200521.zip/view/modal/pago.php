<form role="form" id="datos_factura" autocomplete="off" class="form-horizontal">
   <div class="modal fade" id="pagar" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title" id="exampleModalCenterTitle">Procesar Venta</h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <div class="modal-body">
              <div id="resultados_ajaxf"></div>
               <div class="form-group row">
                  <div class="col-sm-6">
                     <div class="input-group">
                         <input type="text" id="cliente_nombre1" class="form-control" placeholder="Buscar por documento o nombre" required  tabindex="2" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" >
                         <span class="input-group-btn">
                             <button type="button" class="btn btn-secondary" data-toggle="modal" data-target="#nuevoCliente"><li class="fa fa-plus"></li></button>
                         </span>
                         <input id="id_cliente" name="id_cliente" type='text'>
                         <input type="hidden" name="tipoCambio" id="tc" value="115">
                         <input type="hidden" name="valorTipoCambio" id="vtc" value="0.00">
                     </div>
                  </div>
                  <div class="col-sm-6" style="text-align: center;">
                     <div class="button-list">
                           <div class="btn-group btn-group-toggle" data-toggle="buttons">
                               <label class="btn btn-primary active" onclick="cambiaBoleta();">
                                   <input type="radio" name="options" checked> Boleta
                               </label>
                               <label class="btn btn-primary" onclick="cambiaFactura();">
                                   <input type="radio" name="options"> Factura
                               </label>
                           </div>
                       </div>
                     <div id="tituloSerie"></div>
                     <select class="form-control" id="tipoCambio" onchange="tc(this);">
                          <?php
                               $sql_segmento ="select * from monedas where (moneda_id=115 or moneda_id=151)";
                               $row          =mysqli_query($con,$sql_segmento);
                               while ($row4 = mysqli_fetch_array($row)) {
                                  $moneda_nombre = $row4["moneda_nombre"];
                                  $moneda_id     = $row4["moneda_id"];
                            ?>
                            <option value="<?php echo $moneda_id;?>"><?php  echo $moneda_nombre;?></option>

                            <?php } ?>
                      </select>
                      <div id="muestraTipoCambio"></div>
                  </div>
               </div>
               <div class="col-md-4" style="display: none;">
                     <div class="form-group">
                         <label for="factura_folio">Folio:</label>
                         <div id="cambiaFolio"></div>
                     </div>
                 </div>
                 <div class="col-md-4" style="display: none;">
                     <div class="form-group">
                         <label for="factura_correlativo">Correlativo:</label>
                         <div id="cambiaCorrelativo"></div>
                     </div>
                 </div>
                 <div class="col-md-4" style="display: none;">
                     <div class="form-group">
                         <label for="factura_hora">Hora:</label>
                         <input type="time" class="form-control" id="factura_hora" name="factura_hora" value="<?php echo date('H:i:s') ?>">
                     </div>
                 </div>
                 <div class="form-group col-md-2" style="display: none;">
                    <label for="des">Control STOCK</label>
                    <select class='form-control' id="des" name="des" required>
                        <option value="0">NO MOVER STOCK</option>
                        <option value="1" selected>DESCONTAR STOCK(-)</option>
                        <option value="2">REPONER STOCK(+)</option>
                    </select>
                </div>
                <div class="form-group col-md-2" style="display: none;">
                    <label for="nro_doc">Modifica</label>
                    <input type="text" class="form-control" id="nro_doc" name="nro_doc" value="">
                </div>
                <div class="form-group col-md-2" style="display: none;">
                    <label for="motivo">Motivo</label>
                    <input type="text" class="form-control" id="motivo" name="motivo" value="">
                </div>
                 <?php include "../view/modal/registroObservacionesBoleta.php"; ?>
                 <div id="tipoDocumento"></div>
               <div class="form-group row">
                  <div class="col-sm-6">
                     <input type="date" class="form-control" id="factura_fecha" name="factura_fecha" value="<?php echo date('Y-m-d') ?>">
                  </div>
                  <div class="col-sm-6">
                     <select class="form-control input-sm condiciones" id="condiciones" name="condiciones" onchange="showDiv(this)" required>
                         <option value="">-- Selecciona --</option>
                         <option value="1">Contado</option>
                         <option value="2">Cheque</option>
                         <option value="3">Transferencia bancaria</option>
                         <option value="4">Crédito</option>
                     </select>
                  </div>
               </div>
               <div class="form-group row">
                  <div class="col-sm-6">
                     <div id="cargaVencimiento"></div>
                  </div>
                  <div class="col-sm-6">
                     <div id="resultados3"></div>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="guardar_factura">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>
<script>
   function showDiv(select){
    if(select.value==4){
      $("#resultados3").load("../ajax/cargaPrimaPos.php");
      $('#cargaVencimiento').html('<input type="date" class="form-control" id="factura_fechaVencimiento" name="factura_fechaVencimiento" value="<?php echo date('Y-m-d') ?>" >');
    } else{
      $("#resultados3").load("../ajax/cargaRecibidoPos.php");
      $('#cargaVencimiento').html('<input type="date" class="form-control" id="factura_fechaVencimiento" name="factura_fechaVencimiento" value="<?php echo date("Y-m-d") ?>" readonly >');
    }
  }

function tc(sel)
{
    if(sel.value==115){
        //toastr.error("Seleccionar almac&eacute;n","Oopss!");
        $("#muestraTipoCambio").html('<input type="hidden" name="valorTipoCambio" class="form-control" value="<?php echo $valor; ?>">');
        $("#vtc").val('<?php echo $valor; ?>');
        $("#tc").val('115');
    }
    if(sel.value==151){
        //toastr.success("Almac&eacute;n seleccionado","Bien hecho!");
        $("#muestraTipoCambio").html('<input type="text" name="valorTipoCambio" class="form-control" value="<?php echo $valor; ?>">');
        $("#vtc").val('<?php echo $valor; ?>');
        $("#tc").val('151');


    }
}
</script>