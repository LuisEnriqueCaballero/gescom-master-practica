<form method="post" id="editar_plan" name="editar_plan" autocomplete="off" class="form-horizontal" autocomplete="off">
   <div class="modal fade" id="editarPlan" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog modal-lg">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Editar Cuenta</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div id="resultados_ajax2"></div>
               <input type="hidden" name="mod_idPlan" id="mod_idPlan">
               <div class="row">
                  <div class="form-group col-md-6">
                       <label for="mod_padre">Cuenta Principal *</label>
                       <div id="cargaPlanContable1"></div>
                   </div>
                   <div class="form-group col-md-6">
                       <label for="mod_codigo">C&oacute;digo *</label>
                       <input type="text" class="form-control" id="mod_codigo" name="mod_codigo" onKeyUp="this.value=this.value.toUpperCase();" placeholder="C&oacute;digo" autofocus required>
                   </div>

                   <div class="form-group col-md-12">
                       <label for="mod_nombre">Nombre *</label>
                       <input type="text" class="form-control" id="mod_nombre" name="mod_nombre" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" required>
                   </div>

                   <div class="form-group col-md-6">
                       <label for="mod_naturaleza">Naturaleza *</label>
                       <select class="form-control" id="mod_naturaleza" name="mod_naturaleza">
                          <option value="1">DEUDORA</option>
                          <option value="2">ACREEDORA</option>
                       </select>
                   </div>

                   <div class="form-group col-md-6">
                       <label for="mod_estado">Estado *</label>
                       <select class="form-control" id="mod_estado" name="mod_estado">
                          <option value="1">ACTIVADO</option>
                          <option value="2">DESACTIVADO</option>
                       </select>
                   </div>
               </div>
             </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">Cancelar</button>
                 <button type="submit" class="btn btn-primary" id="actualizar_datos">Aceptar</button>
             </div>
         </div>
     </div>
   </div>

</form>