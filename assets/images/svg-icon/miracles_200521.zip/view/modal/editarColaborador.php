<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
/* Connect To Database*/
//session_start();
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos
$tienda = $_SESSION['tienda'];
?>
<form method="post" id="editar_colaborador" name="editar_colaborador" autocomplete="off" class="form-horizontal form-validate">
   <div class="modal fade" id="editarColaborador" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
         <div class="modal-content">
            <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Editar Colaborador</h4>
             </div>
            <div class="modal-body">
              <div id="resultados_ajax2"></div>
               <div class="row">
                  <input type="hidden" name="mod_idColaborador" id="mod_idColaborador">
                  <div class="col-md-6">
                     <label for="mod_tipo">Tipo de documento *</label>
                     <select required id="mod_tipo" name="mod_tipo" class="form-control">
                        <option value="">SELECCIONAR</option>
                        <?php           
                           $tipo_cliente ="select * from sunat_tipocliente";
                           $row          =mysqli_query($con,$tipo_cliente);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $sunat_tipoCliente_nombre = $row4["sunat_tipoCliente_nombre"];
                              $sunat_tipoCliente_id     = $row4["sunat_tipoCliente_id"];
                        ?>
                        <option value="<?php echo $sunat_tipoCliente_id;?>"><?php  echo $sunat_tipoCliente_nombre;?></option>
                        <?php } ?>
                     </select>
                  </div>
                  <div class="col-md-6">
                     <label for="mod_documento">Documento</label>
                         <input type="number" class="form-control" name="mod_documento" id="mod_documento" onKeyUp="this.value=this.value.toUpperCase();" autocomplete="off" placeholder="Documento" required>
                  </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="mod_nombre">Nombres *</label>
                       <input type="text" class="form-control" id="mod_nombre" name="mod_nombre" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Apellidos y nombres" required>
                   </div>
                   <div class="col-md-6">
                       <label for="mod_domicilio">Domicilio *</label>
                       <input type="text" class="form-control" id="mod_domicilio" name="mod_domicilio" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Domicilio" required>
                   </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="mod_telefono">Tel&eacute;fono *</label>
                       <input type="text" class="form-control" id="mod_telefono" name="mod_telefono" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Tel&eacute;fono" required>
                   </div>
                   <div class="col-md-6">
                       <label for="mod_email">E-Mail *</label>
                       <input type="email" class="form-control" id="mod_email" name="mod_email" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="E-Mail" required>
                   </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="mod_salario">Salario *</label>
                       <input type="text" class="form-control" id="mod_salario" name="mod_salario" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Salario" required>
                   </div>
                   <div class="col-md-6">
                       <label for="mod_cumpleanos">Cumplea&ntilde;os *</label>
                       <div id="demo-dp-component">
                            <div class="input-group date">
                              <input type="text" class="form-control" id="mod_cumpleanos" name="mod_cumpleanos" required readonly>
                              <span class="input-group-addon"><i class="demo-pli-calendar-4"></i></span>
                            </div>
                        </div>
                   </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="mod_hora">Hora de ingreso *</label>
                       <input type="time" class="form-control" id="mod_hora" name="mod_hora" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Cumplea&ntilde;os" required step="1">
                   </div>
                   <div class="col-md-6">
                       <label for="mod_sexo">SEXO *</label>
                       <select required id="mod_sexo" name="mod_sexo" class="form-control">
                           <option value="">SELECCIONAR</option>
                           <option value="1">MASCULINO</option>
                           <option value="2">FEMENINO</option>
                        </select>
                   </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="mod_asignacion">Asignaci&oacute;n familiar *</label>
                       <select required id="mod_asignacion" name="mod_asignacion" class="form-control">
                           <option value="">SELECCIONAR</option>
                           <option value="1">NO</option>
                           <option value="2">S&Iacute;</option>
                        </select>
                   </div>
                   <div class="col-md-6">
                       <label for="mod_hijos">Hijos *</label>
                       <div id="muestraHijos"><input type="number" class="form-control" id="mod_hijos" name="mod_hijos" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Hijos" required></div>
                   </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="mod_snpAfp">SNP/AFP *</label>
                       <select required id="mod_snpAfp" name="mod_snpAfp" class="form-control" onchange="getSA(this);">
                           <option value="2">AFP</option>
                           <option value="1">SNP</option>
                        </select>
                   </div>
                   <div class="col-md-6">
                      <label for="mod_afp">AFP *</label>
                      <div id="muestraAfp">
                        <select required id="mod_afp" name="mod_afp" class="form-control">
                          <option value="">SELECCIONAR</option>
                          <?php           
                             $tipo_afp ="select * from afp";
                             $row_afp          =mysqli_query($con,$tipo_afp);
                             while ($row1_afp = mysqli_fetch_array($row_afp)) {
                                $afp_nombre = $row1_afp["afp_nombre"];
                                $afp_id     = $row1_afp["afp_id"];
                          ?>
                          <option value="<?php echo $afp_id;?>"><?php  echo $afp_nombre;?></option>
                          <?php } ?>
                        </select>
                      </div>

                   </div>
               </div>

               <div class="row">
                   <div class="col-md-6">
                      <label for="mod_cargo">Cargo *</label>
                        <select required id="mod_cargo" name="mod_cargo" class="form-control">
                          <option value="">SELECCIONAR</option>
                          <?php           
                             $tipo_afp ="select * from cargo where cargo_sucursal=$tienda order by cargo_nombre asc";
                             $row_afp          =mysqli_query($con,$tipo_afp);
                             while ($row1_afp = mysqli_fetch_array($row_afp)) {
                                $cargo_nombre = $row1_afp["cargo_nombre"];
                                $cargo_id     = $row1_afp["cargo_id"];
                          ?>
                          <option value="<?php echo $cargo_id;?>"><?php  echo $cargo_nombre;?></option>
                          <?php } ?>
                        </select>

                   </div>
                   <div class="col-md-6">
                       <label for="mod_fechaIngreso">Fecha Ingreso *</label>
                       <div id="demo-dp-component">
                            <div class="input-group date">
                                <input type="text" class="form-control" id="mod_fechaIngreso" name="mod_fechaIngreso" required readonly>
                                <span class="input-group-addon"><i class="demo-pli-calendar-4"></i></span>
                            </div>
                        </div>
                   </div>
               </div>

               <div class="row">
                   <div class="col-md-6">
                      <label for="mod_banco">Banco *</label>
                        <select required id="mod_banco" name="mod_banco" class="form-control">
                          <option value="">SELECCIONAR</option>
                          <?php           
                             $tipo_afp ="select * from bancos where banco_idSucursal=$tienda order by banco_nombre asc";
                             $row_afp          =mysqli_query($con,$tipo_afp);
                             while ($row1_afp = mysqli_fetch_array($row_afp)) {
                                $banco_nombre = $row1_afp["banco_nombre"];
                                $banco_id     = $row1_afp["banco_id"];
                          ?>
                          <option value="<?php echo $banco_id;?>"><?php  echo $banco_nombre;?></option>
                          <?php } ?>
                        </select>

                   </div>
                   <div class="col-md-6">
                       <label for="mod_numeroCuenta">Cuenta Bancaria *</label>
                       <input type="text" class="form-control" id="mod_numeroCuenta" name="mod_numeroCuenta" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Cuenta Bancaria" required>
                   </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="actualizar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>
<script>
$(function() {
  $('#mod_cumpleanos').daterangepicker({
    singleDatePicker: true,
    showDropdowns: true,
    minYear: 1901,
    buttonClasses: ['btn', 'btn-sm'],
    applyClass: 'btn-primary',
    cancelClass: 'btn-danger',
    locale: {
      format: "DD/MM/YYYY",
      separator: " - ",
      applyLabel: "Aplicar",
      cancelLabel: "Cancelar",
      fromLabel: "Desde",
      toLabel: "Hasta",
      customRangeLabel: "Personalizado",
      daysOfWeek: [
      "Do",
      "Lu",
      "Ma",
      "Mi",
      "Ju",
      "Vi",
      "Sa"
      ],
      monthNames: [
      "Enero",
      "Febrero",
      "Marzo",
      "Abril",
      "Mayo",
      "Junio",
      "Julio",
      "Agosto",
      "Septiembre",
      "Octubre",
      "Noviembre",
      "Diciembre"
      ],
    },
    maxYear: parseInt(moment().format('YYYY'),10)
  }, function(start, end, label) {
    var years = moment().diff(start, 'years');
    vt.info("El colaborador tiene "+ years +" de edad.", {
        duration: 2000,
        fadeDuration: 200,
        title: "Excelente!",
        position: "top-center"
    })
  });
});
</script>
<script>
$(function() {
  $('#mod_fechaIngreso').daterangepicker({
    singleDatePicker: true,
    showDropdowns: true,
    minYear: 1901,
    buttonClasses: ['btn', 'btn-sm'],
    applyClass: 'btn-primary',
    cancelClass: 'btn-danger',
    locale: {
      format: "DD/MM/YYYY",
      separator: " - ",
      applyLabel: "Aplicar",
      cancelLabel: "Cancelar",
      fromLabel: "Desde",
      toLabel: "Hasta",
      customRangeLabel: "Personalizado",
      daysOfWeek: [
      "Do",
      "Lu",
      "Ma",
      "Mi",
      "Ju",
      "Vi",
      "Sa"
      ],
      monthNames: [
      "Enero",
      "Febrero",
      "Marzo",
      "Abril",
      "Mayo",
      "Junio",
      "Julio",
      "Agosto",
      "Septiembre",
      "Octubre",
      "Noviembre",
      "Diciembre"
      ],
    },
    maxYear: parseInt(moment().format('YYYY'),10)
  }, function(start, end, label) {
    var years = moment().diff(label, 'years');
  });
});
</script>