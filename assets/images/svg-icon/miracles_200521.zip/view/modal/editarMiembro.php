<?php
$tienda = $_SESSION['tienda'];
?>
<form method="post" id="editar_miembro" name="editar_miembro" autocomplete="off" class="form-horizontal" autocomplete="off">
   <div class="modal fade" id="editarMiembro" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Nuevo Miembro</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div id="resultados_ajax2"></div>
               <input type="hidden" name="mod_idMiembro" id="mod_idMiembro">
               <div class="row">
                   <div class="form-group col-md-12">
                       <label for="mod_usuario">Usuario *</label>
                       <select class="form-control" id="mod_usuario" name="mod_usuario" required>
                         <option value="">-- Selecciona Usuario --</option>
                         <?php
                          $sql_colaborador=mysqli_query($con,"select * from usuarios, colaboradores where usuarios.usuario_idColaborador=colaboradores.colaborador_id and colaboradores.colaborador_Sucursal=$tienda");
                          while ($row_col = mysqli_fetch_array($sql_colaborador)) {
                            $alias   = $row_col['usuario_alias'];
                            $nombres = $row_col['colaborador_nombres'];
                            $id      = $row_col['usuario_id'];
                          ?>
                          <option value="<?php echo $id; ?>"><?php echo $alias.": ".$nombres; ?></option>
                          <?php }
                         ?>
                       </select>
                   </div>
                   <div class="form-group col-md-12">
                       <label for="mod_rol">Rol *</label>
                       <select class="form-control" id="mod_rol" name="mod_rol" required>
                         <option value="">-- Selecciona Rol --</option>
                         <option value="1">Investigador</option>
                         <option value="2">Colaborador</option>
                       </select>
                   </div>
                   <div class="form-group col-md-12">
                       <label for="mod_grupo">Grupo *</label>
                       <select class="form-control" id="mod_grupo" name="mod_grupo" required>
                         <option value="">-- Selecciona Grupo --</option>
                         <?php
                          $sql_colaborador=mysqli_query($con,"select * from grupos where grupo_idSucursal=$tienda");
                          while ($row_col = mysqli_fetch_array($sql_colaborador)) {
                            $nombres = $row_col['grupo_nombre'];
                            $id      = $row_col['grupo_id'];
                          ?>
                          <option value="<?php echo $id; ?>"><?php echo $nombres; ?></option>
                          <?php }
                         ?>
                       </select>
                   </div>
               </div>
             </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">Cancelar</button>
                 <button type="submit" class="btn btn-primary" id="actualizar_datos">Aceptar</button>
             </div>
         </div>
     </div>
   </div>
</form>