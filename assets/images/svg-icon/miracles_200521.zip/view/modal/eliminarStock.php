<form class="form-horizontal"  method="post" name="remove_stock" id="remove_stock" autocomplete="off">
  <div class="modal fade bs-example-modal-lg" id="remove-stock" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog " role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
        <h4 class="modal-title">Eliminar Stock</h4>
        <div id="resultados_ajax2"></div>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="form-group col-md-12">
            <label for="quantity_remove">Cantidad *</label>
            <input type="text" class="form-control" id="quantity_remove" name="quantity_remove" placeholder="Cantidad" pattern="^[0-9]{1,5}(\.[0-9]{0,2})?$" title="Ingresa sólo números con 0 ó 2 decimales" maxlength="8" required onKeyUp="this.value=this.value.toUpperCase();">
          </div>
        </div>
        <div class="row">
          <div class="form-group col-md-12">
            <label for="reference_remove">Referencia *</label>
            <input type="text" class="form-control" id="reference_remove" name="reference_remove" value="--" placeholder="Referencia" required onKeyUp="this.value=this.value.toUpperCase();">
          </div>
        </div>
        <div class="row">
          <div class="form-group col-md-12">
            <label for="motivo_remove">Motivo *</label>
            <input type="text" class="form-control" id="motivo_remove" name="motivo_remove" placeholder="Motivo" required onKeyUp="this.value=this.value.toUpperCase();">
          </div>
        </div>
      </div>
      <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary" id="eliminar_datos">Guardar</button>
      </div>
    </div>
    </div>
  </div>
</form>