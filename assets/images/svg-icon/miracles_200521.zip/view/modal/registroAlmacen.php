<form method="post" id="guardar_almacen" name="guardar_almacen" autocomplete="off" class="form-horizontal needs-validation" novalidate>
   <div class="modal fade" id="nuevoAlmacen" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
               <h4 class="modal-title">Nuevo almac&eacute;n</h4>
            </div>
            <div class="modal-body">
              <div id="resultados_ajax"></div>
               <div class="row">
                  <div class="form-group col-sm-12">
                     <input type="text" class="form-control" id="nom_marca" name="nom_marca" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" autofocus="" required>
                  </div>
               </div>
               <div class="row">
                  <div class="form-group col-sm-12">
                     <input type="text" class="form-control" id="desc_marca" name="desc_marca" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Direcci&oacute;n" required>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>
<script>
   $("#nom_marca").focus();
</script>