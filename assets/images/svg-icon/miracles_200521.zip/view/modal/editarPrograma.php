<form method="post" id="editar_programa" name="editar_programa" autocomplete="off" class="form-horizontal">
   <div class="modal fade" id="editarPrograma" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Editar Programa</h4>
            </div>
            <div class="modal-body">
              <div id="resultados_ajax2"></div>
               <div class="form-group col-md-12">
                     <input type="text" class="form-control" id="mod_nombre" name="mod_nombre" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" autofocus="" required>
                     <input type="hidden" name="mod_idPrograma" id="mod_idPrograma">
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="actualizar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>