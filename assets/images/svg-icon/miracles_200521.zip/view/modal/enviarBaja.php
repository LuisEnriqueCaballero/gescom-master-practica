<?php
$sex = $_SESSION['usuario_sexo'];
if ($sex==1) {
   $sexo = "o";
}
if ($sex==2) {
   $sexo = "a";
}
?>
<form id="eliminarDatos" autocomplete="off">
   <div class="modal fade" id="enviarBaja" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                <h4 class="modal-title">Enviar Baja</h4>
            </div>
            <div class="modal-body">
            	<div class="datos_ajax_delete"></div>
            	<input type="hidden" id="id_factura" name="id_factura">
               <input type="text" class="form-control" id="motivo" name="motivo" placeholder="Indicar motivo (Ejm: Error en el monto)" required onKeyUp="this.value=this.value.toUpperCase();">
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">No, cancelar</button>
               <button type="submit" class="btn btn-primary" id="eliminar">S&iacute;, continuar</button>
            </div>
         </div>
      </div>
   </div>
</form>