<div class="modal left fade" id="modalCat" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Categor&iacute;as</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
                <div id="ldng_cat"></div>
                <div id="outer_div_cat"></div>
             </div>
         </div>
     </div>
   </div>
<script>
//
$(document).ready(function(){
  loadC(1);
});
//Busca los datos
function loadC(page){
  $("#ldng_cat").fadeIn('slow');
  $.ajax({
    url:'../ajax/buscarCat.php',
    beforeSend: function(objeto){
      $('#ldng_cat').html('<img src="../assets/images/svg-icon/loading.svg" width="50">');
    },
    success:function(data){
      $("#outer_div_cat").html(data).fadeIn('slow');
      $('#ldng_cat').html('');
    }
  })
}
</script>