<style>
.scroll {
  max-height: 300px;
  overflow: auto;
}
</style>     
   <div class="modal fade" id="terminosGarantia" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content modal-lg">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                <h4 class="modal-title">GARANT&Iacute;A DE SEGURIDAD</h4>
            </div>
            <div class="modal-body">
               <div class="scroll">
               	<p style="text-align: justify;">En <strong>Developer Tecnology</strong> sabemos que nuestros clientes conf&iacute;an en nosotros como una parte importante de sus procesos de negocio y el mantenimiento de registros. Tomamos nuestras responsabilidades muy en serio, la seguridad, la fiabilidad y los datos que conforman la aplicaci&oacute;n Moli<strong>POS</strong> son nuestra m&aacute;xima prioridad.</p>
                  <h5>Seguridad SSL</h5>
                  <p style="text-align: justify;">Toda la informaci&oacute;n que viaja entre su navegador y Moli<strong>POS</strong> est&aacute; protegido de miradas indiscretas con el cifrado SSL de 256 bits. El icono de candado en el navegador le permite verificar que usted no est&aacute; ingresando a un sitio de phishing que se hace pasar como <strong>Developer Technology</strong>. Sus datos est&aacute;n seguros en el tr&aacute;nsito.</p>
                  <h5>An&aacute;lisis de vulnerabilidad</h5>
                  <p style="text-align: justify;"><strong>Developer Technology</strong> analiza y busca vulnerabilidades peri&oacute;dicamente. Cualquier problema recientemente identificado se aborda lo m&aacute;s r&aacute;pido posible.</p>
                  <h5>Copias de seguridad</h5>
                  <p style="text-align: justify;">Los datos de su cuenta en Moli<strong>POS</strong> se replica a trav&eacute;s de m&uacute;ltiples servidores de bases de datos en ubicaciones geogr&aacute;ficas distintas para evitar que un solo fallo cause la p&eacute;rdida de datos. Su informaci&oacute;n estar&aacute; segura y sus registros pueden ser restaurados r&aacute;pidamente.</p>
                  <p style="text-align: justify;">Si usted tiene alguna preocupaci&oacute;n de seguridad o pregunta no dude en contactarse con nosotros directamente.</p>
               </div>
               <hr>
               Developer Technology <br>
               RUC 10725799093 <br>
               Lima, Lima, Los Olivos <br>
               soporte@developer-technology.net <br>
               Protegido y cifrado con SSL EV (https://), la seguridad de datos es nuestra prioridad <br>
               Derechos reservados 2019 - <?php echo date('Y'); ?>
               </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
            </div>
         </div>
      </div>
   </div>