<style>
.scroll {
  max-height: 300px;
  overflow: auto;
}
</style>   
   <div class="modal fade" id="terminosPrivacidad" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content modal-lg">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                <h4 class="modal-title">POL&Iacute;TICA DE PRIVACIDAD</h4>
            </div>
            <div class="modal-body">
               <div class="scroll">
               	<p style="text-align: justify;">- Sus datos est&aacute;n a salvo y seguro con nosotros.</p>
                  <p style="text-align: justify;">- <strong>Developer Technology</strong> no comparte la informaci&oacute;n del cliente de ning&uacute;n tipo con nadie. No vamos a vender o alquilar su nombre o informaci&oacute;n personal a terceros. Nosotros no vendemos, alquilamos ni proporcionamos el acceso externo a nuestra lista de correo o los datos que almacenamos. Todos los datos que un usuario se almacena a trav&eacute;s de nuestra plataforma es propiedad exclusiva de ese usuario o negocio. En cualquier momento un usuario o negocio es libre de tomar sus datos y dejar de usar de usar nuestro servicio, o simplemente borrar sus datos en nuestro sistema.</p>
                  <p style="text-align: justify;">- <strong>Developer Technology</strong> s&oacute;lo recopila la informaci&oacute;n personal necesaria para que pueda acceder y utilizar nuestros servicios. Esta informaci&oacute;n personal incluye, pero no est&aacute; limitado a, RUC, raz&oacute;n social o denominaci&oacute;n, nombre y apellido, direcci&oacute;n f&iacute;sica, c&oacute;digo postal, direcci&oacute;n de correo electr&oacute;nico, n&uacute;mero de tel&eacute;fono, fecha de nacimiento u otra informaci&oacute;n personal necesaria para generar documentos legales necesarios.</p>
                  <p style="text-align: justify;">- <strong>Developer Technology</strong> puede revelar informaci&oacute;n personal solo si la ley lo requiere.</p>
               </div>
               <hr>
               Developer Technology <br>
               RUC 10725799093 <br>
               Lima, Lima, Los Olivos <br>
               soporte@developer-technology.net <br>
               Protegido y cifrado con SSL EV (https://), la seguridad de datos es nuestra prioridad <br>
               Derechos reservados 2019 - <?php echo date('Y'); ?>
               </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
            </div>
         </div>
      </div>
   </div>