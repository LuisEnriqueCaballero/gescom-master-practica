<form method="post" id="guardar_variable" name="guardar_variable" autocomplete="off" class="form-horizontal" autocomplete="off">
   <div class="modal fade" id="nuevoVariable" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Nueva Variable</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div id="resultados_ajax"></div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="laboral_codigo">C&oacute;digo *</label>
                       <input type="text" class="form-control" id="laboral_codigo" name="laboral_codigo" onKeyUp="this.value=this.value.toUpperCase();" placeholder="C&oacute;digo" autofocus required>
                   </div>
                   <div class="col-md-6">
                       <label for="laboral_color">Color *</label>
                       <input type="color" class="form-control" id="laboral_color" name="laboral_color" required>
                   </div>
                   <div class="col-md-12">
                       <label for="laboral_nombre">Nombre *</label>
                       <input type="text" class="form-control" id="laboral_nombre" name="laboral_nombre" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" required>
                   </div>
                   <div class="col-md-12">
                       <label for="laboral_descripcion">Descripci&oacute;n *</label>
                       <input type="text" class="form-control" id="laboral_descripcion" name="laboral_descripcion" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Descripci&oacute;n" autofocus required>
                   </div>               </div>
             </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">Cancelar</button>
                 <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
             </div>
         </div>
     </div>
   </div>
</form>