<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
/* Connect To Database*/
//session_start();
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos
$tienda = $_SESSION['tienda'];
$sql_plantilla ="select * from plantilla_mail where plantilla_idSucursal='$tienda'";
$row  =mysqli_query($con,$sql_plantilla);
$row4 = mysqli_fetch_array($row);
$plantilla_titulo = $row4['plantilla_titulo'];
$plantilla_cuerpo = $row4['plantilla_cuerpo'];
?>
<form method="post" id="editar_plantilla" name="editar_plantilla" autocomplete="off" class="form-horizontal">   
   <div class="modal fade" id="plantillaMail" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
         <div id="resultados_ajax2"></div>
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
               <h4 class="modal-title">Plantilla</h4>
            </div>
            <div class="modal-body">
               <div class="form-group row">
                  <div class="col-sm-12">
                     <label for="plantilla_titulo" class="control-label">T&iacute;tulo:</label>
                     <input type="text" class="form-control UpperCase" id="plantilla_titulo" name="plantilla_titulo" autocomplete="off" required placeholder="T&iacute;tulo" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $plantilla_titulo; ?>">
                  </div>
               </div>
               <div class="form-group row">
                  <div class="col-sm-12">
                     <textarea class="textarea" id="editor2" placeholder="Cuerpo del mensaje..." name="plantilla_cuerpo"><?php echo $plantilla_cuerpo; ?></textarea>
                  </div>
               </div>
            </div>
            <input type="hidden" name="valor" id="valor" value="1">
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="actualizar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>
<!--<script>
$(function () {
   $('.textarea').richText();
})
</script>-->
<script>
   
      ClassicEditor
         .create( document.querySelector( '#editor2' ), {
            ckfinder: {
               // To avoid issues, set it to an absolute path that does not start with dots, e.g. '/ckfinder/core/php/(...)'
               uploadUrl: '../core/connector/php/connector.php?command=QuickUpload&type=Files&responseType=json'
            },
            toolbar: [ 'ckfinder', 'imageUpload', '|', 'heading', '|', 'bold', 'italic', '|', 'undo', 'redo' ]

         } )
         .then( function( editor ) {
            // console.log( editor );
         } )
         .catch( function( error ) {
            //console.error( error );
         } );
</script>