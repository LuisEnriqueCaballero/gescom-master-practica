<?php
$sex = $_SESSION['usuario_sexo'];
if ($sex==1) {
   $sexo = "o";
}
if ($sex==2) {
   $sexo = "a";
}
?>
<form id="eliminarDatos">
   <div class="modal fade" id="eliminarVariable" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">¿Est&aacute;s segur<?php echo $sexo; ?>?</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div class="datos_ajax_delete"></div>
               <input type="hidden" id="id_variable" name="id_variable">
               <p>Esta acci&oacute;n eliminar&aacute; de forma permanente el registro. ¿Deseas continuar?</p>
             </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">No, cancelar</button>
                 <button type="submit" class="btn btn-primary" id="eliminar">S&iacute;, continuar</button>
             </div>
         </div>
     </div>
   </div>
</form>