<?php
$sex = $_SESSION['usuario_sexo'];
if ($sex==1) {
   $sexo = "o";
}
if ($sex==2) {
   $sexo = "a";
}
?>
<form id="guardar_caja">
   <div class="modal fade" id="nuevoCaja" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                <h4 class="modal-title">¿Est&aacute;s segur<?php echo $sexo; ?>?</h4>
            </div>
            <div class="modal-body">
            	<div class="datos_ajax_delete"></div>
            	<input type="hidden" id="nom_marca" name="nom_marca" value="1">
               <input type="hidden" id="desc_marca" name="desc_marca" value="1">
               Est&aacute;s a punto de aperturar una caja para ventas. ¿Deseas continuar?
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">No, cancelar</button>
               <button type="submit" class="btn btn-primary" id="guardar_datos">S&iacute;, continuar</button>
            </div>
         </div>
      </div>
   </div>
</form>