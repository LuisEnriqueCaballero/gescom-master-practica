<form method="post" name="guardar_evento" id="guardar_evento" autocomplete="off" class="form-horizontal" autocomplete="off">
  <div class="modal fade" id="ModalAdd" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <!--Modal header-->
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
          <h4 class="modal-title">Nuevo Evento</h4>
        </div>
        <!--Modal body-->
        <div class="modal-body">
          <div id="resultados_ajax"></div>
          <div class="row">
            <div class="col-md-12">
              <label for="title">T&iacute;tulo *</label>
              <input type="text" name="title" class="form-control" id="title" placeholder="T&iacute;tulo" onKeyUp="this.value=this.value.toUpperCase();" required>
            </div>
            <div class="col-md-12">
              <label for="description">Descripci&oacute;n *</label>
              <input type="text" name="description" class="form-control" id="description" placeholder="Descripci&oacute;n" onKeyUp="this.value=this.value.toUpperCase();" required>
            </div>
            <div class="col-md-6">
              <label for="color">Color *</label>
              <input type="color" name="color" class="form-control" id="color" value="#0071c5" required>
            </div>
            <div class="col-md-6">
              <label for="usuario">Tipo *</label>
              <select id="usuario" name="usuario" class="form-control">
                <option value="1">Personal</option>
                <option value="2">P&uacute;blico</option>
              </select>
            </div>
            <div class="col-md-6">
              <label for="start">Inicia *</label>
              <div id="demo-dp-component">
                <div class="input-group date">
                  <input type="text" class="form-control" id="start" name="start" required readonly>
                  <span class="input-group-addon"><i class="demo-pli-calendar-4"></i></span>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <label for="end">Finaliza *</label>
              <div id="demo-dp-component">
                <div class="input-group date">
                  <input type="text" class="form-control" id="end" name="end" required readonly>
                  <span class="input-group-addon"><i class="demo-pli-calendar-4"></i></span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--Modal footer-->
        <div class="modal-footer">
          <button data-dismiss="modal" class="btn btn-default" type="button">Cancelar</button>
          <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
        </div>
      </div>
    </div>
  </div>
</form>
<script>
$(function() {
  $('#start').daterangepicker({
    singleDatePicker: true,
    showDropdowns: true,
    timePicker: true,
    timePicker24Hour: true,
    minYear: 1901,
    buttonClasses: ['btn', 'btn-sm'],
    applyClass: 'btn-primary',
    cancelClass: 'btn-danger',
    locale: {
      format: "YYYY-MM-DD hh:mm:ss",
      separator: " - ",
      applyLabel: "Aplicar",
      cancelLabel: "Cancelar",
      fromLabel: "Desde",
      toLabel: "Hasta",
      customRangeLabel: "Personalizado",
      daysOfWeek: [
      "Do",
      "Lu",
      "Ma",
      "Mi",
      "Ju",
      "Vi",
      "Sa"
      ],
      monthNames: [
      "Enero",
      "Febrero",
      "Marzo",
      "Abril",
      "Mayo",
      "Junio",
      "Julio",
      "Agosto",
      "Septiembre",
      "Octubre",
      "Noviembre",
      "Diciembre"
      ],
    },
    maxYear: parseInt(moment().format('YYYY'),10)
  }, function(start, end, label) {
    var years = moment().diff(label, 'years');
  });
});
</script>
<script>
$(function() {
  $('#end').daterangepicker({
    singleDatePicker: true,
    showDropdowns: true,
    timePicker: true,
    timePicker24Hour: true,
    minYear: 1901,
    buttonClasses: ['btn', 'btn-sm'],
    applyClass: 'btn-primary',
    cancelClass: 'btn-danger',
    locale: {
      format: "YYYY-MM-DD hh:mm:ss",
      separator: " - ",
      applyLabel: "Aplicar",
      cancelLabel: "Cancelar",
      fromLabel: "Desde",
      toLabel: "Hasta",
      customRangeLabel: "Personalizado",
      daysOfWeek: [
      "Do",
      "Lu",
      "Ma",
      "Mi",
      "Ju",
      "Vi",
      "Sa"
      ],
      monthNames: [
      "Enero",
      "Febrero",
      "Marzo",
      "Abril",
      "Mayo",
      "Junio",
      "Julio",
      "Agosto",
      "Septiembre",
      "Octubre",
      "Noviembre",
      "Diciembre"
      ],
    },
    maxYear: parseInt(moment().format('YYYY'),10)
  }, function(start, end, label) {
    var years = moment().diff(label, 'years');
  });
});
</script>