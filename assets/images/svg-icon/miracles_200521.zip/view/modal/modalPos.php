<?php
$sex = $_SESSION['usuario_sexo'];
if ($sex==1) {
   $sexo = "o";
}
if ($sex==2) {
   $sexo = "a";
}
?>
<div class="modal fade" id="modalPOS" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Terminal Punto de Venta</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <p>Bienvenid<?php echo $sexo; ?> a la nueva vista del TPV.</p>
        </div>
      </div>
      <div class="modal-footer">
        <button data-dismiss="modal" class="btn btn-mint btn-block" style="cursor: url(../img/company/cursorH1.png), pointer;" onclick="iniciaPos();">Vamos a ello</button>
      </div>
    </div>
  </div>
</div>