<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
/* Connect To Database*/
//session_start();
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos
$tienda = $_SESSION['tienda'];
?>
<form role="form" id="datos_facturaP">
<div class="modal fade" id="modalPago" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true" >
  <div class="modal-dialog" style="width: 100%;">
    <div class="modal-content">
      <!--Modal header-->
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
      </div>
      <!--Modal body-->
      <div class="modal-body">

        <div class="row">
          <div class="col-xs-2"> <!-- required for floating -->
            <div class="tab-base tab-stacked-left">
              <!--Nav tabs-->
              <ul class="nav nav-tabs">
                <?php
                $sql = "select * from medio_pago where (medioPago_idSucursal=$tienda or medioPago_idSucursal=0) order by medioPago_id asc";
                $query = mysqli_query($con,$sql);
                while ($row = mysqli_fetch_array($query)) {
                  $medioPago_id          = $row['medioPago_id'];
                  $medioPago_nombre      = $row['medioPago_nombre'];
                ?>
                <?php if ($medioPago_id == 1) { ?>
                  <li class="active" onclick="cambiaMedioPago('<?php echo $medioPago_id; ?>');">
                    <a data-toggle="tab" href="#demo-stk-lft-tab-<?php echo $medioPago_id; ?>"><?php echo $medioPago_nombre; ?></a>
                  </li>
                <?php } else { ?>
                  <li class="" onclick="cambiaMedioPago('<?php echo $medioPago_id; ?>');">
                    <a data-toggle="tab" href="#demo-stk-lft-tab-<?php echo $medioPago_id; ?>"><?php echo $medioPago_nombre; ?></a>
                  </li>
                <?php } ?>
                <?php } ?>
                <li class="" style="border: 0.5px dashed #25476a; border-top-left-radius: 13px; border-bottom-left-radius: 13px;">
                  <a data-toggle="tab" href="#demo-stk-lft-tab-obs" style="background-color: #25476a; color: #fff; border-top-left-radius: 13px; border-bottom-left-radius: 13px;">OBSERVACIONES</a>
                </li>
              </ul>
            </div>
          </div>

          <div class="col-xs-10">
            <div class="row">
              <div class="col-md-6">
                <div class="button-list">
                  <div class="btn-group btn-group-toggle" data-toggle="buttons">
                      <label class="btn btn-mint active" style="border-radius: 0px;" onclick="tipoBoleta();">
                          <input type="radio" name="options" checked> Boleta
                      </label>
                      <label class="btn btn-mint" style="border-radius: 0px;" onclick="tipoFactura();">
                          <input type="radio" name="options"> Factura
                      </label>
                      <label class="btn btn-mint" style="border-radius: 0px;" onclick="tipoInterno();">
                          <input type="radio" name="options"> Interno
                      </label>
                  </div>
                </div>
              </div>

              <div class="col-md-6 pull-right">
                <div class="button-list">
                  <div class="btn-group btn-group-toggle" data-toggle="buttons">
                      <label class="btn btn-default active" style="border-radius: 0px;" onclick="tipoContado();">
                          <input type="radio" name="options" checked> Contado
                      </label>
                      <label class="btn btn-default" style="border-radius: 0px;" onclick="tipoCredito();" data-toggle="modal" data-target="#fV">
                          <input type="radio" name="options"> Cr&eacute;dito
                      </label>
                  </div>
                </div>
              </div>

            </div>
            <br>
            <div class="input-group">
              <span class="input-group-addon" id="basic-addon3">MONTO: </span>
              <div id="monto"></div>
            </div>

                <br>
                <div class="input-group">
                  <span class="input-group-addon" id="basic-addon3">PAGA CON: </span>
                  <input type="text" placeholder="0.00" class="form-control pagaCon" id="resibido" name="resibido" aria-describedby="basic-addon3" oninput="$(this).calculateChange<?php echo $medioPago_id; ?>();" autocomplete="off" onblur="PasarValor1();">
                </div>
            <!--Tabs Content-->
            <div class="tab-content">
              <?php
              $sql = "select * from medio_pago where (medioPago_idSucursal=$tienda or medioPago_idSucursal=0) order by medioPago_id asc";
              $query = mysqli_query($con,$sql);
              while ($row = mysqli_fetch_array($query)) {
                $medioPago_id          = $row['medioPago_id'];
                $medioPago_nombre      = $row['medioPago_nombre'];
              ?>
              <?php if ($medioPago_id == 1) { ?>
                <div id="demo-stk-lft-tab-<?php echo $medioPago_id; ?>" class="tab-pane fade active in">
              <?php } else { ?>
                <div id="demo-stk-lft-tab-<?php echo $medioPago_id; ?>" class="tab-pane fade">
              <?php } ?>
                <hr>
                <div class="row">
                  <div class="col-md-9">

                    <div class="row">
                      <div class="col-md-3">
                        <div onclick="$(this).go<?php echo $medioPago_id; ?>(1,false);" class="btn btn-mint btn-lg btn-block">1</div>
                      </div>
                      <div class="col-md-3">
                        <div onclick="$(this).go<?php echo $medioPago_id; ?>(2,false);" class="btn btn-mint btn-lg btn-block">2</div>
                      </div>
                      <div class="col-md-3">
                        <div onclick="$(this).go<?php echo $medioPago_id; ?>(3,false);" class="btn btn-mint btn-lg btn-block">3</div>
                      </div>
                      <div class="col-md-3"></div>
                    </div>

                    <br>

                    <div class="row">
                      <div class="col-md-3">
                        <div onclick="$(this).go<?php echo $medioPago_id; ?>(4,false);" class="btn btn-mint btn-lg btn-block">4</div>
                      </div>
                      <div class="col-md-3">
                        <div onclick="$(this).go<?php echo $medioPago_id; ?>(5,false);" class="btn btn-mint btn-lg btn-block">5</div>
                      </div>
                      <div class="col-md-3">
                        <div onclick="$(this).go<?php echo $medioPago_id; ?>(6,false);" class="btn btn-mint btn-lg btn-block">6</div>
                      </div>
                      <div class="col-md-3"></div>
                    </div>

                    <br>

                    <div class="row">
                      <div class="col-md-3">
                        <div onclick="$(this).go<?php echo $medioPago_id; ?>(7,false);" class="btn btn-mint btn-lg btn-block">7</div>
                      </div>
                      <div class="col-md-3">
                        <div onclick="$(this).go<?php echo $medioPago_id; ?>(8,false);" class="btn btn-mint btn-lg btn-block">8</div>
                      </div>
                      <div class="col-md-3">
                        <div onclick="$(this).go<?php echo $medioPago_id; ?>(9,false);" class="btn btn-mint btn-lg btn-block">9</div>
                      </div>
                      <div class="col-md-3"></div>
                    </div>

                    <br>

                    <div class="row">
                      <div class="col-md-3">
                        <div onclick="$('.pagaCon').val($('.pagaCon').val().substr(0,$('.pagaCon').val().length -1));$(this).calculateChange<?php echo $medioPago_id; ?>();" class="btn btn-mint btn-lg btn-block">⌫</div>
                      </div>
                      <div class="col-md-3">
                        <div onclick="$(this).go<?php echo $medioPago_id; ?>(0,false);" class="btn btn-mint btn-lg btn-block">0</div>
                      </div>
                      <div class="col-md-3">
                        <div onclick="$(this).digits<?php echo $medioPago_id; ?>()" class="btn btn-mint btn-lg btn-block">.</div>
                      </div>
                      <div class="col-md-3"></div>
                    </div>

                  </div>

                  <div class="col-md-3">
                    <div onclick="$('.pagaCon').val('');$(this).calculateChange<?php echo $medioPago_id; ?>();" class="btn btn-danger btn-block btn-lg">AC</div>
                  </div>
                </div>
                <br>
              </div>
              <?php } ?>
              <div id="demo-stk-lft-tab-obs" class="tab-pane fade">
                <input id="obse" placeholder="Observaciones..." name="factura_observaciones" value="Sin observaciones.">
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--Modal footer-->
      
        <input type="hidden" class="form-control" autocomplete="off" id="id_comp" name="id_comp" value="2">
        <input id="id_cliente" name="id_cliente" type='hidden'>
        <input type="hidden" id="tc1" name="tc1" value="115">
        <input type="hidden" class="form-control" autocomplete="off" id="condiciones" name="condiciones" value="1">

        <input id="des" name="des" type='hidden' value="1">
        <input id="nro_doc" name="nro_doc" type='hidden' value="">
        <input id="motivo" name="motivo" type='hidden' value="">

        <input id="mP" name="mP" type='hidden' value="1">

        <div id="factura_contado"><input type="hidden" name="factura_contado" value="101"></div>
        <div id="factura_cargo"><input type="hidden" name="factura_cargo" value="1211"></div>
        <div id="factura_abono"><input type="hidden" name="factura_abono" value="70151"></div>
        <div id="factura_denominacion"><input type="hidden" name="factura_denominacion" value="CAJA"></div>
        <div id="factura_denominacion1"><input type="hidden" name="factura_denominacion1" value="TERCEROS"></div>
        <div id="factura_denominacion2"><input type="hidden" name="factura_denominacion2" value="EMITIDAS"></div>

        <input type="time" class="form-control hidden" id="factura_hora" name="factura_hora" value="<?php echo date('H:i:s') ?>">
        <input type="date" class="form-control hidden" id="factura_fecha" name="factura_fecha" value="<?php echo date('Y-m-d') ?>">

        <input type="hidden" id="valorCambio1" name="valorCambio1" class="form-control">
        <input type="hidden" id="resibido1" name="resibido1" class="form-control">

        <div class="modal-footer">
          <div class="btn btn-default btn-block btn-lg" disabled><span id="txtCambio">CAMBIO:</span> <span id="vuelto">0.00</span> </div>
          <button type="submit" id="guardar_factura" class="btn btn-primary btn-block btn-lg" style="display: none;">PROCESAR</button>
        </div>
      
    </div>
  </div>
</div>


<div class="modal fade" id="fV" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
  <div class="modal-dialog" style="box-shadow: 2px 2px 10px #666">
     <div class="modal-content">
         <!--Modal header-->
         <div class="modal-header">
             <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
             <h4 class="modal-title">Fecha Vencimiento</h4>
         </div>
         <!--Modal body-->
         <div class="modal-body">
           <div class="datos_ajax_delete"></div>
           <p>Por favor seleccione la fecha de vencimiento del documento.</p>
           <input type="text" id="factura_fechaVencimiento" name="factura_fechaVencimiento" class="form-control">
         </div>
         <!--Modal footer-->
         <div class="modal-footer">
             <div data-dismiss="modal" class="btn btn-default" type="button">De acuerdo</div>
         </div>
     </div>
 </div>
</div>

</form>
<script src="../js/enviar_sunat.js"></script>
<script>
$(function() {
  $('#factura_fechaVencimiento').daterangepicker({
    singleDatePicker: true,
    showDropdowns: true,
    minYear: 1901,
    buttonClasses: ['btn', 'btn-sm'],
    applyClass: 'btn-primary',
    cancelClass: 'btn-danger',
    locale: {
      format: "YYYY-MM-DD",
      separator: " - ",
      applyLabel: "Aplicar",
      cancelLabel: "Cancelar",
      fromLabel: "Desde",
      toLabel: "Hasta",
      customRangeLabel: "Personalizado",
      daysOfWeek: [
      "Do",
      "Lu",
      "Ma",
      "Mi",
      "Ju",
      "Vi",
      "Sa"
      ],
      monthNames: [
      "Enero",
      "Febrero",
      "Marzo",
      "Abril",
      "Mayo",
      "Junio",
      "Julio",
      "Agosto",
      "Septiembre",
      "Octubre",
      "Noviembre",
      "Diciembre"
      ],
    },
    maxYear: parseInt(moment().format('YYYY'),10)
  }, function(start, end, label) {
    var years = moment().diff(label, 'years');
  });
});
</script>
<script>
//
$(function () {
  $('#obse').richText();
});
</script>
<script>
//Refrescamos los totales
setInterval(
    function(){
      $('#monto').load('../ajax/cargaTotalesPos1.php');
    },1000
  );
</script>
<?php
$sql = "select * from medio_pago where (medioPago_idSucursal=$tienda or medioPago_idSucursal=0) order by medioPago_id asc";
$query = mysqli_query($con,$sql);
while ($row = mysqli_fetch_array($query)) {
  $medioPago_id          = $row['medioPago_id'];
  $medioPago_nombre      = $row['medioPago_nombre'];
?>
<script>
//
function modalPago(value) { 
  var totalModal =$("#payablePrice").val(value);
}
//efectivo
$.fn.go<?php echo $medioPago_id; ?> = function (value,isDueInput) {
  if(isDueInput) {

  } else {
      $(".pagaCon").val($(".pagaCon").val()+""+value);
      $(this).calculateChange<?php echo $medioPago_id; ?>();
  }
}
//
$.fn.digits<?php echo $medioPago_id; ?> = function() {
  $(".pagaCon").val($(".pagaCon").val()+".");
  $(this).calculateChange<?php echo $medioPago_id; ?>();
}
//
$.fn.calculateChange<?php echo $medioPago_id; ?> = function () {
  var vuelto = $("#payablePrice").val() - $(".pagaCon").val();
  var condiciones = $("#condiciones").val();

  if (condiciones == 1) {
    $("#txtCambio").text('CAMBIO:');
  }
  if (condiciones == 4) {
    $("#txtCambio").text('A CUENTA:');
  }

  if(vuelto <= 0) {
    $("#vuelto").text(-vuelto.toFixed(2));
  } else {
    $("#vuelto").text("-"+vuelto.toFixed(2));
  }
  if(vuelto <= 0 || condiciones == 4) {
      $("#guardar_factura").show();
      $("#resibido").focus();
  } else {
    $("#guardar_factura").hide();
  }
}
</script>
<?php } ?>

<script>
//Guardamos la venta
$("#datos_facturaP").submit(function(event) {
    $('#guardar_factura').attr("disabled", true);
    $('#guardar_factura').html('<img src="../img/company/load1.svg" style="width: 20px;"> &nbsp; Verificando...');

    var id_cliente = $("#id_cliente").val();
    var resibido = $("#resibido").val();

    if (isNaN(resibido)) {
        vt.error("Por favor ingresa un dato v&aacute;lido.", {
            duration: 2000,
            fadeDuration: 200,
            title: "Oopss!",
            position: "top-center"
        });
        $('#guardar_factura').html('Procesar Boleta');
        $('#guardar_factura').attr("disabled", false);
        $("#resibido").focus();
        return false;
    }
    if (resibido==0) {
        vt.error("Por favor ingresa un valor mayor a cero.", {
            duration: 2000,
            fadeDuration: 200,
            title: "Oopss!",
            position: "top-center"
        });
        $('#guardar_factura').html('Procesar Boleta');
        $('#guardar_factura').attr("disabled", false);
        $("#resibido").focus();
        return false;
    }
    if (id_cliente == "") {
        vt.error("Por favor selecciona un cliente v&aacute;lido.", {
            duration: 2000,
            fadeDuration: 200,
            title: "Oopss!",
            position: "top-center"
        })
        //toastr['warning']('Seleccionar un cliente v&aacute;lido', 'Aviso!');
        $("#cliente_nombreNPOS").focus();
        $('#guardar_factura').html('Procesar Boleta');
        $('#guardar_factura').attr("disabled", false);
        return false;
    }
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "../ajax/nuevoVentaPos.php",
        data: parametros,
        beforeSend: function(objeto) {
            $('#load_contenido_venta').html('<img src="../img/company/shoppingCart.svg" width="150">');
            $('#load_contenido_venta').addClass('ajax-loader-contenido_venta');
        },
        success: function(datos) {
            $("#resultados_ajaxf").html(datos);
            $('#guardar_factura').html('PROCESAR');
            $('#guardar_factura').attr("disabled", false);
            $("#datos_facturaP")[0].reset();
            $("#barcode_form")[0].reset();
            $("#resultados").load("../ajax/agregarPOS.php");
            $("#barcode").focus();
            $("#cambiaCorrelativo").load('../ajax/documentos/cambiaBoleta1.php');
            $("#tituloSerie").load("../ajax/cargaTituloSerie.php");
            $("#cliente_nombreNPOS").val("");
            $("#id_cliente").val("");
            $("#cliente_documento").val("");
            $("#cliente_telefono").val("");
            $("#cliente_direccion").val("");
            $("#cliente_nombreNPOS").focus();
            $('#factura_fechaVencimiento').val('<?php echo date("Y-m-d") ?>');
            $('#factura_fecha').val('<?php echo date("Y-m-d") ?>');
            $('#obse').val('Sin observaciones.');
            $("#valorCambio").focus();
            $('#modalPago').modal('hide');
            load(1);
            $('#load_contenido_venta').html('');
            $('#load_contenido_venta').removeClass('ajax-loader-contenido_venta');

            var envio = $('#tipoenvio').val();

            if (envio == 2) {
                $('#modal_vuelto').modal('show');
                $('#enviar_sunat').click();
                $('#imprimir2').click();
            }
            if (envio == 1) {
                $('#modal_vuelto').modal('show');
                $('#imprimir2').click();
            }

            //console.load(url);
        }
    });
    event.preventDefault();
})
</script>