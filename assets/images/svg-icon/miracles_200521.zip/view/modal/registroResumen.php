<form method="post" id="guardar_resumen" name="guardar_resumen">
   <div class="modal fade" id="nuevoResumen" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Enviar Resumen Boletas</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div id="datos_ajax_deleteR"></div>
               <div class="row">
                  <div class="col-12">
                     Buscar por Fecha
                     <div class="input-group">
                        <div class="input-group mar-btm">
                           <input type="date" id="fecha" name="fecha" class="datepicker-here form-control" placeholder="dd/mm/yyyy" aria-describedby="basic-addon2" value="<?php echo date('d/m/Y'); ?>" onchange="load1(1);" required/>
                           <div class="input-group-addon btn btn-primary" onclick='load(1);' id="buscar"><i class='fa fa-search'></i></div>
                        </div>
                     </div>
                     <div id="loader1"></div><!-- Carga gif animado -->
                     <div class="outer_div1" ></div>
                  </div>
               </div>
            </div>
            <!--Modal footer-->
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">No, cancelar</button>
               <button type="submit" class="btn btn-primary" id="guardar_datos">S&iacute;, enviar</button>
            </div>
         </div>
      </div>
   </div>
</form>
<script>
$(document).ready(function(){
   load1(1);
   $('#fecha').datepicker();
});
function load1(page){
   var q= $("#fecha").val();
   $("#loader1").fadeIn('slow');
   $.ajax({
      url:'../ajax/buscarResumenBoletas2.php?action=ajax&page='+page+'&q='+q,
      beforeSend: function(objeto){
         $('#buscar').html('<img src="../img/company/load1.svg" style="width: 20px;">');
      },
      success:function(data){
         $(".outer_div1").html(data).fadeIn('slow');
         $('#buscar').html("<span class='fa fa-search'></span>");
      }
   })
}
</script>