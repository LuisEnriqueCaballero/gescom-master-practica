<?php
$sex = $_SESSION['usuario_sexo'];
if ($sex==1) {
   $sexo = "o";
}
if ($sex==2) {
   $sexo = "a";
}
?>
<form id="eliminarDatos">
   <div class="modal fade" id="eliminarPlan" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                <h4 class="modal-title">¿Est&aacute;s segur<?php echo $sexo; ?>?</h4>
            </div>
            <div class="modal-body">
            	<div class="datos_ajax_delete"></div>
            	<input type="hidden" id="id_plan" name="id_plan">
               Esta acci&oacute;n eliminar&aacute; de forma permanente el registro. ¿Deseas continuar?
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">No, cancelar</button>
               <button type="submit" class="btn btn-primary" id="eliminar">S&iacute;, continuar</button>
            </div>
         </div>
      </div>
   </div>
</form>