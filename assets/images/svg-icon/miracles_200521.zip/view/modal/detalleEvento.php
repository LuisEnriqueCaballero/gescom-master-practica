<div class="modal fade" id="ModalDetalle" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <!--Modal header-->
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
        <h4 class="modal-title"><span id="title"></span> (<span id="usuario"></span>)</h4>
      </div>
      <!--Modal body-->
      <div class="modal-body">
        <div id="resultados_ajax"></div>
        <div class="row">
          <div class="col-md-12">
            <label for="description"><strong>Descripci&oacute;n</strong></label><br>
            <span id="description"></span>
          </div>
          <div class="col-md-6">
            <label for="start"><strong>Inicia</strong></label><br>
            <span id="start"></span>
          </div>
          <div class="col-md-6">
            <label for="end"><strong>Finaliza</strong></label><br>
            <span id="end"></span>
          </div>
        </div>
      </div>
      <!--Modal footer-->
      <div class="modal-footer">
        <button data-dismiss="modal" class="btn btn-default" type="button">Cerrar</button>
      </div>
    </div>
  </div>
</div>