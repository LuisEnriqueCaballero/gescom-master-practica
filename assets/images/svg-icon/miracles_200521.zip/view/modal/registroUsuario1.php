<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
//session_start();
/* Connect To Database*/
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos
$tienda = $_SESSION['tienda'];
$empresa = $_SESSION['datosEmpresa_id'];
?>
<form method="post" id="guardar_usuario" name="guardar_usuario" autocomplete="off" class="form-horizontal">
   <div class="modal fade" id="nuevoUsuario" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
               <h4 class="modal-title">Nuevo Usuario</h4>
            </div>
            <div class="modal-body">
              <div id="resultados_ajax2"></div>
               <div class="row">
                  <div class="form-group col-sm-12">
                     <label for="colaborador_id">Colaborador *</label>
                     <select required id="colaborador_id" name="colaborador_id" class="form-control selectAcceso2" style="width: 100%; text-align: left;">
                        <option value="">-- Selecciona Colaborador --</option>
                        <?php
                           $tipo_cliente ="select * from colaboradores where colaborador_nombres!='ADMINISTRADOR' and colaborador_sucursal='$tienda'";
                           $row          =mysqli_query($con,$tipo_cliente);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $colaborador_nombres = $row4["colaborador_nombres"];
                              $colaborador_id     = $row4["colaborador_id"];
                        ?>
                        <option value="<?php echo $colaborador_id;?>"><?php  echo $colaborador_nombres;?></option>
                        <?php } ?>
                     </select>
                  </div>
               </div>
               <div class="row">
                  <div class="form-group col-sm-12">
                     <label for="user_name">Usuario *</label>
                     <input type="text" class="form-control" id="user_name" name="user_name" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Usuario" required onBlur="comprobarUsuario()">
                     <span id="estadousuario"></span> 
                  </div>
                  <p><img src="../img/company/LoaderIcon.gif" style="width: 22px; display:none;" id="loaderIcon" /></p>
               </div>
               <div class="row">
                  <div class="form-group col-sm-12">
                     <label for="user_password_new">Contrase&ntilde;a *</label>
                    <input type="password" class="form-control" id="user_password_new" name="user_password_new" placeholder="Contrase&ntilde;a" required onKeyUp="this.value=this.value.toUpperCase();">
                  </div>
               </div>
               <div class="row">
                  <div class="form-group col-sm-12">
                     <label for="user_password_repeat">Repite Contrase&ntilde;a *</label>
                    <input type="password" class="form-control" id="user_password_repeat" name="user_password_repeat" placeholder="Repite contrase&ntilde;a" required onKeyUp="this.value=this.value.toUpperCase();">
                  </div>
               </div>
               <div class="row">
                  <div class="form-group col-sm-12">
                     <label for="usuario_persmiso">Permiso *</label>
                     <select name="usuario_persmiso" id="usuario_persmiso" class="selectAcceso1 form-control" style="width: 100%; text-align: left;" required>
                        <option>-- Selecciona Acceso --</option>
                        <?php
                           $sql_segmento ="select * from accesos where acceso_sucursal='$tienda' order by acceso_id asc";
                           $row          =mysqli_query($con,$sql_segmento);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $acceso_nombre = $row4["acceso_nombre"];
                              $acceso_id     = $row4["acceso_id"];
                        ?>
                        <option value="<?php echo $acceso_id;?>"><?php  echo $acceso_nombre;?></option>

                        <?php } ?>
                    </select>
                  </div>
               </div>
               <div class="row">
                  <div class="form-group col-sm-12">
                     <label for="usuario_establecimiento">Establecimiento *</label>
                    <select name="usuario_establecimiento" id="usuario_establecimiento" class="selectAcceso form-control" style="width: 100%; text-align: left;">
                        <?php
                           $sql_segmento ="select * from sucursales where sucursal_idEmpresa='$empresa' and sucursal_activo='1' and sucursal_tienda='$tienda' order by sucursal_tienda asc";
                           $row          =mysqli_query($con,$sql_segmento);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $sucursal_nombre = $row4["sucursal_nombre"];
                              $sucursal_tienda     = $row4["sucursal_tienda"];
                        ?>
                        <option value="<?php echo $sucursal_tienda;?>"><?php  echo $sucursal_nombre;?></option>

                        <?php } ?>
                        <option value="0">TODAS</option>
                    </select>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>