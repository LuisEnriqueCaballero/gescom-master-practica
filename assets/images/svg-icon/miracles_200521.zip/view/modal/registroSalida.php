<?php
$tienda = $_SESSION['tienda'];
?>
<form method="post" id="guardar_salidaModal" name="guardar_salidaModal" autocomplete="off" class="form-horizontal" autocomplete="off">
   <div class="modal fade" id="nuevoSalida" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Registro Salida</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div id="resultados_ajax"></div>
               <div class="row">
                   <div class="col-md-12">
                       <label for="asistencia_idColaborador">Colaborador *</label>
                       <select class="form-control" id="asistencia_idColaborador" name="asistencia_idColaborador" required>
                         <option value="">-- Selecciona Colaborador --</option>
                         <?php
                          $sql_colaborador=mysqli_query($con,"select * from colaboradores where colaborador_sucursal=$tienda");
                          while ($row_col = mysqli_fetch_array($sql_colaborador)) {
                            $nombres = $row_col['colaborador_nombres'];
                            $id      = $row_col['colaborador_id'];
                          ?>
                          <option value="<?php echo $id; ?>"><?php echo $nombres; ?></option>
                          <?php }
                         ?>
                       </select>
                   </div>
                   <div class="col-md-6">
                       <label for="asistencia_salida">Fecha *</label>
                       <input type="date" class="form-control" id="asistencia_salida" name="asistencia_salida" value="<?php echo date('Y-m-d'); ?>" required>
                   </div>
                   <div class="col-md-6">
                       <label for="asistencia_salida_hora">Hora *</label>
                       <input type="time" class="form-control" id="asistencia_salida_hora" name="asistencia_salida_hora" value="<?php echo date('H:i'); ?>" required>
                   </div>
               </div>
             </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">Cancelar</button>
                 <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
             </div>
         </div>
     </div>
   </div>
</form>