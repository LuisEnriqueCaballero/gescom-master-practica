<div class="modal fade" id="detalleTraslado" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
   <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
         <div class="modal-header">
             <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
             <h4 class="modal-title">Detalle Traslado</h4>
         </div>
         <div class="modal-body">
         	<input type="hidden" name="id_dTraslado" id="id_dTraslado">
            <div class="invoice-masthead">
               <div class="invoice-text">
                   <h3 class="text-uppercase text-thin mar-no text-primary"><span id="fecha"></span></h3>
               </div>
           </div>
   
           <div class="invoice-bill row">
               <div class="col-sm-6 text-xs-center">
                   <address>
                       <strong class="text-main">SALIDA</strong><br>
                       <b>Establecimiento: </b><span id="salida"></span><br>
                       <b>Almac&eacute;n: </b><span id="salidas"></span>
                  </address>
               </div>
               <div class="col-sm-6 text-xs-center">
                   <address>
                       <strong class="text-main">DESTINO</strong><br>
                       <b>Establecimiento: </b><span id="destino"></span><br>
                       <b>Almac&eacute;n: </b><span id="destinos"></span>
                  </address>
               </div>
           </div>
   
           <hr class="new-section-sm bord-no">
   
           <div class="row">
               <div class="col-lg-12 table-responsive">
                   <table class="table table-bordered invoice-summary">
                       <thead>
                           <tr class="bg-trans-dark">
                               <th class="min-col text-center text-uppercase">C&oacute;digo</th>
                               <th class="text-uppercase">Descripci&oacute;n</th>
                               <th class="min-col text-center text-uppercase">Cantidad</th>
                           </tr>
                       </thead>
                       <tbody>
                           <tr>
                               <td class="text-center"><span id="codigo"></span></td>
                               <td><strong><span id="nombre"></span></strong>
                                   <small><span id="descripcion"></span></small></td>
                               <td class="text-center"><span id="cantidad"></span></td>
                           </tr>
                       </tbody>
                   </table>
               </div>
           </div>
            
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">De acuerdo</button>
         </div>
      </div>
   </div>
</div>