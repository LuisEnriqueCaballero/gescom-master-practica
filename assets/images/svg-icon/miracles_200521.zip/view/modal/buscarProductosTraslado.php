<div class="modal fade" id="buscar" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  	<div class="modal-dialog modal-lg" role="document">
     	<div class="modal-content">
        	<div class="modal-header">
             	<button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
             	<h4 class="modal-title">Buscar &Iacute;tems</h4>
        	</div>
        	<div class="modal-body">

        		<div class="form-group row">
                  	<div class="col-sm-12">
                  		<div class="input-group">
							<input type="text" autocomplete="off" class="form-control" id="q" placeholder="Buscar por C&oacute;digo, nombre o descripci&oacute;n" onkeyup="load1(1);this.value=this.value.toUpperCase();">
							<span class="input-group-btn">
								<button type="submit" class="btn btn-primary" onclick="load1(1)"><span class="fa fa-search"></span></button>
							</span>
						</div>
                  	</div>
                </div>

                <div class="form-group row">
                  	<div class="col-sm-12">
                  		<div id="loader"></div>
                      <br>
                  		<div class="outer_div" ></div>
                  	</div>
                </div>
        	</div>
	        <div class="modal-footer">
	           <button type="button" class="btn btn-default" data-dismiss="modal">De acuerdo</button>
	        </div>
     	</div>
  	</div>
</div>