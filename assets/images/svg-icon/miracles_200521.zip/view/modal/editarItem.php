<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
//session_start();
/* Connect To Database*/
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos
?>
<form method="post" id="editar_item" name="editar_item" autocomplete="off" class="form-horizontal">
   <div class="modal fade" id="editarItem" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
         <div class="modal-content">
            <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Editar &Iacute;tem</h4>
             </div>
            <div class="modal-body">
              <div id="resultados_ajax2"></div>
              <input type="hidden" name="mod_idItem" id="mod_idItem">
               <div class="row">
                   <div class="col-md-6">
                       <label for="mod_barras">C&oacute;digo Barras *</label>
                       <input type="text" class="form-control" id="mod_barras" name="mod_barras" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="C&oacute;digo Barras" required>
                   </div>
                   <div class="col-md-6">
                       <label for="mod_nombre">Nombre *</label>
                       <input type="text" class="form-control" id="mod_nombre" name="mod_nombre" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" required>
                   </div>
               </div>
               <div class="row">
                  <div class="col-md-6">
                       <label for="mod_descripcion">Descripci&oacute;n</label>
                       <input type="text" class="form-control" id="mod_descripcion" name="mod_descripcion" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Descripci&oacute;n">
                   </div>
                  <div class="col-md-6">
                     <label for="mod_codigo" style="color: red;">C&oacute;digo Producto SUNAT *</label>
                     <div class="input-group">
                         <input type="text" class="form-control" name="mod_codigo" id="mod_codigo" onKeyUp="this.value=this.value.toUpperCase();" autocomplete="off" placeholder="Buscar c&oacute;digo UNSPSC" readonly required data-toggle='modal' data-target='#editarSunat'>
                         <div class="input-group-addon btn btn-primary" data-toggle='modal' data-target='#editarSunat'><i class="fa fa-search"></i></div>
                     </div>
                  </div>
               </div>
               <div class="row">
                   
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="mod_idCategoria">Categor&iacute;a *</label>
                       <select name="mod_idCategoria" id="mod_idCategoria" class="selectedi form-control" style="width: 100%" required>
                          <?php $tienda = $_SESSION['tienda'];
                             $sql_segmento ="select * from categorias where (categoria_sucursal='$tienda' or categoria_sucursal=0) order by categoria_id asc";
                             $row          =mysqli_query($con,$sql_segmento);
                             while ($row4 = mysqli_fetch_array($row)) {
                                $categoria_nombre = $row4["categoria_nombre"];
                                $categoria_id     = $row4["categoria_id"];
                          ?>
                          <option value="<?php echo $categoria_id;?>"><?php  echo $categoria_nombre;?></option>

                          <?php } ?>
                      </select>
                   </div>
                   <div class="col-md-6">
                       <label for="mod_idMarca">Marca *</label>
                       <select name="mod_idMarca" id="mod_idMarca" class="selectedi form-control" style="width: 100%" required>
                          <?php $tienda = $_SESSION['tienda'];
                             $sql_segmento ="select * from marcas where (marca_sucursal='$tienda' or marca_sucursal=0) order by marca_id asc";
                             $row          =mysqli_query($con,$sql_segmento);
                             while ($row4 = mysqli_fetch_array($row)) {
                                $marca_nombre = $row4["marca_nombre"];
                                $marca_id     = $row4["marca_id"];
                          ?>
                          <option value="<?php echo $marca_id;?>"><?php  echo $marca_nombre;?></option>

                          <?php } ?>
                      </select>
                   </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="mod_idUnidadMedida">Unidad Medida *</label>
                       <select name="mod_idUnidadMedida" id="mod_idUnidadMedida" class="selectedi form-control" style="width: 100%" required>
                          <?php
                             $sql_segmento ="select * from unidadmedida";
                             $row          =mysqli_query($con,$sql_segmento);
                             while ($row4 = mysqli_fetch_array($row)) {
                                $unidadMedida_nombre = $row4["unidadMedida_nombre"];
                                $unidadMedida_id     = $row4["unidadMedida_id"];
                          ?>
                          <option value="<?php echo $unidadMedida_id;?>"><?php  echo $unidadMedida_nombre;?></option>

                          <?php } ?>
                      </select>
                   </div>
                   <div class="col-md-6">
                       <label for="mod_idProveedor">Proveedor *</label>
                       <select name="mod_idProveedor" id="mod_idProveedor" class="selectedi form-control" style="width: 100%" required>
                          <?php $tienda = $_SESSION['tienda'];
                             $sql_segmento ="select * from proveedores where (proveedor_sucursal='$tienda' or proveedor_sucursal=0) order by proveedor_id asc";
                             $row          =mysqli_query($con,$sql_segmento);
                             while ($row4 = mysqli_fetch_array($row)) {
                                $proveedor_nombre = $row4["proveedor_nombre"];
                                $proveedor_id     = $row4["proveedor_id"];
                          ?>
                          <option value="<?php echo $proveedor_id;?>"><?php  echo $proveedor_nombre;?></option>

                          <?php } ?>
                      </select>
                   </div>
               </div>

               <div class="row">
                   <div class="col-md-3">
                       <label for="mod_afectacion">Tipo Afectaci&oacute;n *</label>
                       <select name="mod_afectacion" id="mod_afectacion" class="selectedi form-control" style="width: 100%" required>
                          <?php
                             $sql_segmento ="select * from tipo_afectacion where tipoafectacion_id<= 18";
                             $row          =mysqli_query($con,$sql_segmento);
                             while ($row4 = mysqli_fetch_array($row)) {
                                $tipoafectacion_nombre = $row4["tipoafectacion_nombre"];
                                $tipoafectacion_id     = $row4["tipoafectacion_id"];
                          ?>
                          <option value="<?php echo $tipoafectacion_id;?>"><?php  echo $tipoafectacion_nombre;?></option>

                          <?php } ?>
                      </select>
                   </div>
                   <div class="col-md-3">
                       <label for="mod_monVenta">Moneda *</label>
                       <select name="mod_monVenta" id="mod_monVenta" class="selectedi form-control" style="width: 100%" required>
                          <?php
                             $sql_segmento ="select * from monedas where (moneda_id=115 or moneda_id=151)";
                             $row          =mysqli_query($con,$sql_segmento);
                             while ($row4 = mysqli_fetch_array($row)) {
                                $moneda_nombre = $row4["moneda_nombre"];
                                $moneda_id     = $row4["moneda_id"];
                          ?>
                          <option value="<?php echo $moneda_id;?>"><?php  echo $moneda_nombre;?></option>

                          <?php } ?>
                      </select>
                   </div>
                   <div class="col-md-3">
                       <label for="mod_costo">Costo *</label>
                       <input type="text" class="form-control" id="mod_costo" name="mod_costo" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Costo" required>
                   </div>
                   <div class="col-md-3">
                       <label for="mod_precio">Precio *</label>
                       <input type="text" class="form-control" id="mod_precio" name="mod_precio" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Precio" required>
                   </div>
               </div>

               <div class="row">
                   <div class="col-md-2">
                       <label for="mod_stock">Stock Actual *</label>
                       <input type="text" class="form-control" id="mod_stock" name="mod_stock" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Stock Actual" required readonly>
                   </div>
                   <div class="col-md-2">
                       <label for="mod_minimo">Stock M&iacute;nimo *</label>
                       <input type="text" class="form-control" id="mod_minimo" name="mod_minimo" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Stock M&iacute;nimo" required>
                   </div>
                   <div class="col-md-2">
                       <label for="mod_icbper">¿ICBPER? *</label>
                       <select name="mod_icbper" id="mod_icbper" class="form-control" required>
                          <option value="1">NO</option>
                          <option value="2">S&Iacute;</option>
                      </select>
                   </div>
                   <div class="col-md-3">
                       <label for="mod_fechaVencimiento1">¿Caduca? *</label>
                       <select name="mod_fechaVencimiento1" id="mod_fechaVencimiento1" class="selectedi form-control" style="width: 100%" onchange="showFv1(this)" required>
                          <option value="1">NO</option>
                          <option value="2">S&Iacute;</option>
                      </select>
                   </div>
                   <div id="carga_fecha1" class="col-md-3"></div>
               </div>

            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="actualizar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
   

   <div class="modal fade" id="editarSunat" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document" style="box-shadow: 2px 2px 10px #666">
          <div class="modal-content">
              <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">C&oacute;digo UNSPSC</h4>
              </div>
              <div class="modal-body">
                <div class="row">
                   <div class="col-md-12">
                       <label for="producto_idSegmento1">Segmento *</label>
                       <select name="producto_idSegmento1" id="producto_idSegmento1" class="selecteds form-control" style="width: 100%">
                          <option value="">-- SEGMENTO --</option>
                          <?php           
                             $sql_segmento ="select * from segmento_producto";
                             $row          =mysqli_query($con,$sql_segmento);
                             while ($row4 = mysqli_fetch_array($row)) {
                                $segmento_nombre = $row4["segmento_nombre"];
                                $segmento_id     = $row4["segmento_id"];
                          ?>
                          <option value="<?php echo $segmento_id;?>"><?php  echo $segmento_nombre;?></option>

                          <?php } ?>
                      </select>
                   </div>

                   <div class="col-md-12">
                       <label for="producto_idFamilia1">Familia *</label>
                       <select name="producto_idFamilia1" id="producto_idFamilia1" class="selecteds form-control" style="width: 100%">
                          <option value="">-- PRIMERO SELECCIONA UN SEGMENTO --</option>
                      </select>
                   </div>
                </div>

                <div class="row">
                   <div class="col-md-12">
                       <label for="producto_idClase1">Clase *</label>
                       <select name="producto_idClase1" id="producto_idClase1" class="selecteds form-control" style="width: 100%">
                          <option value="">-- PRIMERO SELECCIONA UNA FAMILIA --</option>
                      </select>
                   </div>

                   <div class="col-md-12">
                       <label for="producto_idProducto1">Producto *</label>
                        <select name="producto_idProducto1" id="producto_idProducto1" class="selecteds form-control" style="width: 100%">
                            <option value="">-- PRIMERO SELECCIONA UNA CLASE --</option>
                        </select>
                   </div>
                </div>
              </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">De acuerdo</button>
              </div>
          </div>
      </div>
  </div>
</form>
<script>

$('.selecteds').select2({
  placeholder: 'Selecciona una opcion',
  width: 'resolve',
  dropdownParent: $("#editarSunat")
  //theme: "classic"
});
</script>

<script>
$(document).ready(function(){
 
    $('#producto_idSegmento1').on('change',function(){
        var countryID = $(this).val();
        if(countryID){
            $.ajax({
                type:'POST',
                url:'../ajax/ajaxDate.php',
                data:'country_id='+countryID,
                success:function(html){
                    $('#producto_idFamilia1').html(html);
                    $('#producto_idClase1').html('<option value="">-- PRIMERO SELECCIONA UNA FAMILIA --</option>');
                    $('#producto_idProducto1').html('<option value="">-- PRIMERO SELECCIONA UNA CLASE --</option>'); 
                    $('#mod_codigo').val('');
                }
            }); 
        }else{
            $('#producto_idFamilia1').html('<option value="">-- PRIMERO SELECCIONA UN SEGMENTO --</option>');
            $('#producto_idClase1').html('<option value="">-- PRIMERO SELECCIONA UNA FAMILIA --</option>');
            $('#producto_idProducto1').html('<option value="">-- PRIMERO SELECCIONA UNA CLASE --</option>');
            $('#mod_codigo').val('');
        }
    });
    
    $('#producto_idFamilia1').on('change',function(){
        var stateID = $(this).val();
        if(stateID){
            $.ajax({
                type:'POST',
                url:'../ajax/ajaxDate.php',
                data:'state_id='+stateID,
                success:function(html){
                    $('#producto_idClase1').html(html);
                }
            }); 
        }else{
            $('#producto_idClase1').html('<option value="">-- PRIMERO SELECCIONA UNA FAMILIA --</option>'); 
            $('#producto_idProducto1').html('<option value="">-- PRIMERO SELECCIONA UNA CLASE --</option>');
            $('#mod_codigo').val('');
        }
    });

    $('#producto_idClase1').on('change',function(){
        var cityID = $(this).val();
        if(cityID){
            $.ajax({
                type:'POST',
                url:'../ajax/ajaxDate.php',
                data:'city_id='+cityID,
                success:function(html){
                    $('#producto_idProducto1').html(html);
                }
            }); 
        }else{
            $('#producto_idProducto1').html('<option value="">-- PRIMERO SELECCIONA UNA CLASE --</option>'); 
            $('#mod_codigo').val('');
        }
    });

    $('#producto_idProducto1').on('change',function(){
        var productID = $(this).val();
        if(productID){
            $.ajax({
                type:'POST',
                url:'../ajax/ajaxDate.php',
                data:'product_id='+productID,
                success:function(html){
                    $('#mod_codigo').val(html);
                }
            }); 
        }else{
            $('#mod_codigo').val(''); 
        }
    });
});
</script>

<script>
  function showFv1(select){
    if(select.value==''){
      $("#carga_fecha1").html('');
    }
    if(select.value==1){
      $("#carga_fecha1").html('<input type="hidden" class="form-control" id="producto_fechaVencimiento" name="producto_fechaVencimiento" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" value="0000-00-00">');
    }
    if(select.value==2){
      $("#carga_fecha1").html('<label for="producto_fechaVencimiento">F. Vencimiento *</label><input type="date" class="form-control" id="producto_fechaVencimiento" name="producto_fechaVencimiento" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();">');
    }
  }
</script>