   <div class="modal fade" id="observaciones" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
               <h4 class="modal-title">Observaciones</h4>
            </div>
            <div class="modal-body">
               	<textarea class="textarea" placeholder="Observaciones..." name="factura_observaciones">
        		     </textarea>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">De acuerdo</button>
            </div>
         </div>
      </div>
   </div>