<form method="post" id="editar_cuenta" name="editar_cuenta" autocomplete="off" class="form-horizontal">
   <div class="modal fade" id="editarCuenta" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                <h4 class="modal-title">Editar cuenta</h4>
            </div>
            <div class="modal-body">
               <div id="resultados_ajax2"></div>
               <input type="hidden" name="mod_idCuentaBancaria" id="mod_idCuentaBancaria">
               <div class="row">
                  <div class="col-sm-12">
                     <label for="mod_banco">Banco *</label>
                     <select name="mod_banco" id="mod_banco" class="form-control" required>
                        <option value="">-- Selecciona un banco --</option>
                        <?php $tienda = $_SESSION['tienda'];
                           $sql_segmento ="select * from bancos where banco_idSucursal='$tienda' order by banco_nombre asc";
                           $row          =mysqli_query($con,$sql_segmento);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $banco_nombre = $row4["banco_nombre"];
                              $banco_id     = $row4["banco_id"];
                        ?>
                        <option value="<?php echo $banco_id;?>"><?php  echo $banco_nombre;?></option>

                        <?php } ?>
                      </select>
                  </div>
               </div>
               <div class="row">
                  <div class="col-sm-12">
                     <label for="mod_tipo">Tipo *</label>
                     <select name="mod_tipo" id="mod_tipo" class="form-control" required>
                        <option value="">-- Selecciona un tipo de cuenta --</option>
                        <?php $tienda = $_SESSION['tienda'];
                           $sql_segmento ="select * from tipocuentas where tipoCuenta_idSucursal='$tienda' order by tipoCuenta_nombre asc";
                           $row          =mysqli_query($con,$sql_segmento);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $tipoCuenta_nombre = $row4["tipoCuenta_nombre"];
                              $tipoCuenta_id     = $row4["tipoCuenta_id"];
                        ?>
                        <option value="<?php echo $tipoCuenta_id;?>"><?php  echo $tipoCuenta_nombre;?></option>

                        <?php } ?>
                      </select>
                  </div>
               </div>
               <div class="row">
                  <div class="col-sm-12">
                     <label for="mod_moneda">Moneda *</label>
                     <select name="mod_moneda" id="mod_moneda" class="form-control" required>
                        <option value="">-- Selecciona una moneda --</option>
                        <?php
                           $sql_segmento ="select * from monedas where (moneda_id=115 or moneda_id=151)";
                           $row          =mysqli_query($con,$sql_segmento);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $moneda_nombre = $row4["moneda_nombre"];
                              $moneda_id     = $row4["moneda_id"];
                        ?>
                        <option value="<?php echo $moneda_id;?>"><?php  echo $moneda_nombre;?></option>

                        <?php } ?>
                      </select>
                  </div>
               </div>
               <div class="row">
                  <div class="col-sm-12">
                     <label for="mod_numero">N&uacute;mero de cuenta *</label>
                     <input type="text" class="form-control" id="mod_numero" name="mod_numero" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="N&uacute;mero de cuenta" autofocus="" required onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                  </div>
               </div>
               <div class="row">
                  <div class="col-sm-12">
                     <label for="mod_inicial">Monto inicial *</label>
                     <input type="text" class="form-control" id="mod_inicial" name="mod_inicial" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Monto inicial" autofocus="" required readonly>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="actualizar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>