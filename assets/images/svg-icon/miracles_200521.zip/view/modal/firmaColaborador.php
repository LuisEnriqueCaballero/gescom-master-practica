<div class="modal fade" id="firmaColaborador" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
     <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
            <h4 class="modal-title">Cargar Firma</h4>
        </div>
        <div class="modal-body">
        	<div id="load_firma_mod"></div>
			    <div class="outer_firma"></div>
        </div>
     </div>
  </div>
</div>