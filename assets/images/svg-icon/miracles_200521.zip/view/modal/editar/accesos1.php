<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
session_start();
require_once "../../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../../config/conexion.php"; //Contiene funcion que conecta a la base de datos
//Sesion de la empresa
$empresa = $_SESSION['datosEmpresa_id'];
//Recogemos los datos marcados
function checked($valor){ 
    if($valor==1){
        return 'checked';
    }else{
        return '';
    }
     
}
//Recogemos el id
if (isset($_GET["id"])) {
    $id    = $_GET["id"];
    $id    = intval($id);
    $sql   = "select * from accesos where acceso_id='$id'";
    $query = mysqli_query($con, $sql);
    $num   = mysqli_num_rows($query);
    if ($num == 1) {
        $rw       = mysqli_fetch_array($query);
        $name     = $rw['acceso_nombre'];
        $cadena   = $rw['acceso_permiso'];
        $archivos = substr_count($cadena, ";");
    }
} else {echo "No hay id";}
//Recogemos el rubro adicional
$sql_rubro              = "select * from datosempresa where datosEmpresa_id=$empresa";
$rw_rubro               = mysqli_query($con,$sql_rubro);//recuperando el registro
$rs_rubro               = mysqli_fetch_array($rw_rubro);//trasformar el registro en un vector asociativo
$modulo_rubro           = $rs_rubro["datosEmpresa_rubro"];
$rubro                  = explode(".", $modulo_rubro);

$a=explode(".",$cadena);
//
$c1=checked($a[0]);
$c2=checked($a[1]);
$c3=checked($a[2]);
$c4=checked($a[3]);
$c5=checked($a[4]);
$c6=checked($a[5]);
$c7=checked($a[6]);
$c8=checked($a[7]);
$c9=checked($a[8]);
$c10=checked($a[9]);
$c11=checked($a[10]);
$c12=checked($a[11]);
$c13=checked($a[12]);
$c14=checked($a[13]);
$c15=checked($a[14]);
$c16=checked($a[15]);
$c17=checked($a[16]);
$c18=checked($a[17]);
$c19=checked($a[18]);
$c20=checked($a[19]);
$c21=checked($a[20]);
$c22=checked($a[21]);
$c23=checked($a[22]);
$c24=checked($a[23]);
$c25=checked($a[24]);
$c26=checked($a[25]);
$c27=checked($a[26]);
$c28=checked($a[27]);
$c29=checked($a[28]);
$c30=checked($a[29]);
$c31=checked($a[30]);
$c32=checked($a[31]);
$c33=checked($a[32]);
$c34=checked($a[33]);
$c35=checked($a[34]);
$c36=checked($a[35]);
$c37=checked($a[36]);
$c38=checked($a[37]);
$c39=checked($a[38]);
$c40=checked($a[39]);
$c41=checked($a[40]);
$c42=checked($a[41]);
$c43=checked($a[42]);
$c44=checked($a[43]);
$c45=checked($a[44]);
$c46=checked($a[45]);
$c47=checked($a[46]);
$c48=checked($a[47]);
$c49=checked($a[48]);
$c50=checked($a[49]);
$c51=checked($a[50]);
$c52=checked($a[51]);
$c53=checked($a[52]);
$c54=checked($a[53]);
$c55=checked($a[54]);
$c56=checked($a[55]);
$c57=checked($a[56]);
$c58=checked($a[57]);
$c59=checked($a[58]);
$c60=checked($a[59]);
$c61=checked($a[60]);
$c62=checked($a[61]);
$c63=checked($a[62]);
$c64=checked($a[63]);
$c65=checked($a[64]);
$c66=checked($a[65]);
$c67=checked($a[66]);
$c68=checked($a[67]);
$c69=checked($a[68]);
$c70=checked($a[69]);
$c71=checked($a[70]);
$c72=checked($a[71]);
$c73=checked($a[72]);
$c74=checked($a[73]);
$c75=checked($a[74]);
$c76=checked($a[75]);
$c77=checked($a[76]);
$c78=checked($a[77]);
$c79=checked($a[78]);
$c80=checked($a[79]);
$c81=checked($a[80]);
$c82=checked($a[81]);
$c83=checked($a[82]);
$c84=checked($a[83]);
$c85=checked($a[84]);
$c86=checked($a[85]);
$c87=checked($a[86]);
$c88=checked($a[87]);
$c89=checked($a[88]);
$c90=checked($a[89]);
$c91=checked($a[90]);
$c92=checked($a[91]);
$c93=checked($a[92]);
$c94=checked($a[93]);
$c95=checked($a[94]);
$c96=checked($a[95]);
$c97=checked($a[96]);
$c98=checked($a[97]);
$c99=checked($a[98]);
$c100=checked($a[99]);

$c101=checked($a[100]);
$c102=checked($a[101]);
$c103=checked($a[102]);
$c104=checked($a[103]);
$c105=checked($a[104]);
$c106=checked($a[105]);
$c107=checked($a[106]);
$c108=checked($a[107]);
$c109=checked($a[108]);
$c110=checked($a[109]);
$c111=checked($a[110]);
$c112=checked($a[111]);
$c113=checked($a[112]);
$c114=checked($a[113]);
$c115=checked($a[114]);
$c116=checked($a[115]);
$c117=checked($a[116]);
$c118=checked($a[117]);
$c119=checked($a[118]);
$c120=checked($a[119]);
$c121=checked($a[120]);
$c122=checked($a[121]);
$c123=checked($a[122]);
$c124=checked($a[123]);
$c125=checked($a[124]);
$c126=checked($a[125]);
$c127=checked($a[126]);
$c128=checked($a[127]);
$c129=checked($a[128]);
$c130=checked($a[129]);
$c131=checked($a[130]);
$c132=checked($a[131]);
$c133=checked($a[132]);
$c134=checked($a[133]);
$c135=checked($a[134]);
$c136=checked($a[135]);
$c137=checked($a[136]);
$c138=checked($a[137]);
$c139=checked($a[138]);
$c140=checked($a[139]);
$c141=checked($a[140]);
$c142=checked($a[141]);
$c143=checked($a[142]);
$c144=checked($a[143]);
$c145=checked($a[144]);
$c146=checked($a[145]);
$c147=checked($a[146]);
$c148=checked($a[147]);
$c149=checked($a[148]);
$c150=checked($a[149]);
$c151=checked($a[150]);
$c152=checked($a[151]);
$c153=checked($a[152]);
$c154=checked($a[153]);
$c155=checked($a[154]);
$c156=checked($a[155]);
$c157=checked($a[156]);
$c158=checked($a[157]);
$c159=checked($a[158]);
$c160=checked($a[159]);
$c161=checked($a[160]);
$c162=checked($a[161]);
$c163=checked($a[162]);
$c164=checked($a[163]);
$c165=checked($a[164]);
$c166=checked($a[165]);
$c167=checked($a[166]);
$c168=checked($a[167]);
$c169=checked($a[168]);
$c170=checked($a[169]);
$c171=checked($a[170]);
$c172=checked($a[171]);
$c173=checked($a[172]);
$c174=checked($a[173]);
$c175=checked($a[174]);
$c176=checked($a[175]);
$c177=checked($a[176]);
$c178=checked($a[177]);
$c179=checked($a[178]);
$c180=checked($a[179]);
$c181=checked($a[180]);
$c182=checked($a[181]);
$c183=checked($a[182]);
$c184=checked($a[183]);
$c185=checked($a[184]);
$c186=checked($a[185]);
$c187=checked($a[186]);
$c188=checked($a[187]);
$c189=checked($a[188]);
$c190=checked($a[189]);
$c191=checked($a[190]);
$c192=checked($a[191]);
$c193=checked($a[192]);
$c194=checked($a[193]);
$c195=checked($a[194]);
$c196=checked($a[195]);
$c197=checked($a[196]);
$c198=checked($a[197]);
$c199=checked($a[198]);
$c200=checked($a[199]);

$c201=checked($a[200]);
$c202=checked($a[201]);
$c203=checked($a[202]);
$c204=checked($a[203]);
$c205=checked($a[204]);
$c206=checked($a[205]);
$c207=checked($a[206]);
$c208=checked($a[207]);
$c209=checked($a[208]);
$c210=checked($a[209]);
$c211=checked($a[210]);
$c212=checked($a[211]);
$c213=checked($a[212]);
$c214=checked($a[213]);
$c215=checked($a[214]);
$c216=checked($a[215]);
$c217=checked($a[216]);
$c218=checked($a[217]);
$c219=checked($a[218]);
$c220=checked($a[219]);
$c221=checked($a[220]);
$c222=checked($a[221]);
$c223=checked($a[222]);
$c224=checked($a[223]);
$c225=checked($a[224]);
$c226=checked($a[225]);
$c227=checked($a[226]);
$c228=checked($a[227]);
$c229=checked($a[228]);
$c230=checked($a[229]);
$c231=checked($a[230]);
$c232=checked($a[231]);
$c233=checked($a[232]);
$c234=checked($a[233]);
$c235=checked($a[234]);
$c236=checked($a[235]);
$c237=checked($a[236]);
$c238=checked($a[237]);
$c239=checked($a[238]);
$c240=checked($a[239]);
$c241=checked($a[240]);
$c242=checked($a[241]);
$c243=checked($a[242]);
$c244=checked($a[243]);
$c245=checked($a[244]);
$c246=checked($a[245]);
$c247=checked($a[246]);
$c248=checked($a[247]);
$c249=checked($a[248]);
$c250=checked($a[249]);
$c251=checked($a[250]);
$c252=checked($a[251]);
$c253=checked($a[252]);
$c254=checked($a[253]);
$c255=checked($a[254]);
$c256=checked($a[255]);
$c257=checked($a[256]);
$c258=checked($a[257]);
$c259=checked($a[258]);
$c260=checked($a[259]);
$c261=checked($a[260]);
$c262=checked($a[261]);
$c263=checked($a[262]);

?>

              
                <div class="form-group row">
                  <div class="col-sm-12">
                     <label for="mod_nombresAcceso" class="control-label">Nombre:</label>
                  <input type="text" class="form-control" id="mod_nombresAcceso" name="mod_nombresAcceso" autocomplete="off" required placeholder="Nombre del grupo de acceso" onKeyUp="this.value=this.value.toUpperCase();" value="<?php echo $name; ?>">
                  <input type="hidden" id="mod_idAcceso" name="mod_idAcceso" value="<?php echo $id; ?>">
                  <div id="resultados_ajax1"></div>
                  </div>
                </div>
            <div class="scroll">
              <div class="css-treeview">
                <ul>
                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-inicio" name="mod_a1" <?php echo $c1; ?> value="1"/><label for="mod_item-inicio">&nbsp;&nbsp;&nbsp;&nbsp;Inicio</label></li>
                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-tpv" name="mod_a2" <?php echo $c2; ?> value="1"/><label for="mod_item-tpv">&nbsp;&nbsp;&nbsp;&nbsp;TPV</label></li>
                    <li class="hidden"><input class="magic-checkbox" type="checkbox" id="mod_item-notas" name="mod_a3" <?php echo $c3; ?> value="1"/><label for="mod_item-notas">&nbsp;&nbsp;&nbsp;&nbsp;Notas</label></li>
                    <li class="hidden"><input class="magic-checkbox" type="checkbox" id="mod_item-anuncios" name="mod_a4" <?php echo $c4; ?> value="1"/><label for="mod_item-anuncios">&nbsp;&nbsp;&nbsp;&nbsp;Anuncios</label></li>
                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-calendario" name="mod_a5" <?php echo $c5; ?> value="1"/><label for="mod_item-calendario">&nbsp;&nbsp;&nbsp;&nbsp;Calendario</label></li>
                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-archivos" name="mod_a6" <?php echo $c6; ?> value="1"/><label for="mod_item-archivos">&nbsp;&nbsp;&nbsp;&nbsp;Archivos</label></li>
                    <li><input type="checkbox" id="mod_item-caja" style="position: absolute; opacity: 0;"/><label for="mod_item-caja">Caja</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-caja-actual" style="position: absolute; opacity: 0;"/><label for="mod_item-caja-actual">Administrar Caja</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-caja-actual-aperturar" name="mod_a7" <?php echo $c7; ?> value="1"/><label for="mod_item-caja-actual-aperturar">&nbsp;&nbsp;&nbsp;&nbsp;Aperturar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-caja-actual-cerrar" name="mod_a8" <?php echo $c8; ?> value="1"/><label for="mod_item-caja-actual-cerrar">&nbsp;&nbsp;&nbsp;&nbsp;Cerrar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-caja-movimientos" style="position: absolute; opacity: 0;"/><label for="mod_item-caja-movimientos">Hist&oacute;rico Caja</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-caja-movimientos-pdf" name="mod_a9" <?php echo $c9; ?> value="1"/><label for="mod_item-caja-movimientos-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-caja-movimientos-excel" name="mod_a10" <?php echo $c10; ?> value="1"/><label for="mod_item-caja-movimientos-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-caja-movimientos-cerrarCajas" name="mod_a230" <?php echo $c230; ?> value="1"/><label for="mod_item-caja-movimientos-cerrarCajas">&nbsp;&nbsp;&nbsp;&nbsp;Cerrar Cajas</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-personas" style="position: absolute; opacity: 0;"/><label for="mod_item-personas">Personas</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-personas-clientes" style="position: absolute; opacity: 0;"/><label for="mod_item-personas-clientes">Clientes</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-clientes-ver" name="mod_a11" <?php echo $c11; ?> value="1"/><label for="mod_item-personas-clientes-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-clientes-agregar" name="mod_a12" <?php echo $c12; ?> value="1"/><label for="mod_item-personas-clientes-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-clientes-editar" name="mod_a13" <?php echo $c13; ?> value="1"/><label for="mod_item-personas-clientes-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-clientes-eliminar" name="mod_a14" <?php echo $c14; ?> value="1"/><label for="mod_item-personas-clientes-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-personas-proveedores" style="position: absolute; opacity: 0;"/><label for="mod_item-personas-proveedores">Proveedores</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-proveedores-ver" name="mod_a15" <?php echo $c15; ?> value="1"/><label for="mod_item-personas-proveedores-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-proveedores-agregar" name="mod_a16" <?php echo $c16; ?> value="1"/><label for="mod_item-personas-proveedores-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-proveedores-editar" name="mod_a17" <?php echo $c17; ?> value="1"/><label for="mod_item-personas-proveedores-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-proveedores-eliminar" name="mod_a18" <?php echo $c18; ?> value="1"/><label for="mod_item-personas-proveedores-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-personas-colaboradores" style="position: absolute; opacity: 0;"/><label for="mod_item-personas-colaboradores">Colaboradores</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-colaboradores-ver" name="mod_a19" <?php echo $c19; ?> value="1"/><label for="mod_item-personas-colaboradores-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-colaboradores-agregar" name="mod_a20" <?php echo $c20; ?> value="1"/><label for="mod_item-personas-colaboradores-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-colaboradores-editar" name="mod_a21" <?php echo $c21; ?> value="1"/><label for="mod_item-personas-colaboradores-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-colaboradores-usuario" name="mod_a22" <?php echo $c22; ?> value="1"/><label for="mod_item-personas-colaboradores-usuario">&nbsp;&nbsp;&nbsp;&nbsp;Crear Usuario</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-colaboradores-foto" name="mod_a23" <?php echo $c23; ?> value="1"/><label for="mod_item-personas-colaboradores-foto">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Foto</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-colaboradores-firma" name="mod_a261" <?php echo $c261; ?> value="1"/><label for="mod_item-personas-colaboradores-firma">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Firma</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-colaboradores-entrada" name="mod_a262" <?php echo $c262; ?> value="1"/><label for="mod_item-personas-colaboradores-entrada">&nbsp;&nbsp;&nbsp;&nbsp;Activar / Desactivar Entrada</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-colaboradores-eliminar" name="mod_a24" <?php echo $c24; ?> value="1"/><label for="mod_item-personas-colaboradores-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <?php if ($rubro[3]==1) { ?>
                    <li><input type="checkbox" id="mod_item-clinica" style="position: absolute; opacity: 0;"/><label for="mod_item-clinica">Cl&iacute;nica</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-clinica-admision" style="position: absolute; opacity: 0;"/><label for="mod_item-clinica-admision">Admisi&oacute;n</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-admision-ver" name="mod_a232" <?php echo $c232; ?> value="1"/><label for="mod_item-clinica-admision-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-admision-agregar" name="mod_a233" <?php echo $c233; ?> value="1"/><label for="mod_item-clinica-admision-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-clinica-topico" style="position: absolute; opacity: 0;"/><label for="mod_item-clinica-topico">T&oacute;pico</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-topico-ver" name="mod_a234" <?php echo $c234; ?> value="1"/><label for="mod_item-clinica-topico-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-topico-agregar" name="mod_a235" <?php echo $c235; ?> value="1"/><label for="mod_item-clinica-topico-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-clinica-historias" style="position: absolute; opacity: 0;"/><label for="mod_item-clinica-historias">Historias</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-historias-ver" name="mod_a236" <?php echo $c236; ?> value="1"/><label for="mod_item-clinica-historias-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-historias-agregar" name="mod_a237" <?php echo $c237; ?> value="1"/><label for="mod_item-clinica-historias-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Imprimir</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-historias-editar" name="mod_a238" <?php echo $c238; ?> value="1"/><label for="mod_item-clinica-historias-editar">&nbsp;&nbsp;&nbsp;&nbsp;Facturar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-clinica-especialidades" style="position: absolute; opacity: 0;"/><label for="mod_item-clinica-especialidades">Especialidades</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-especialidades-ver" name="mod_a239" <?php echo $c239; ?> value="1"/><label for="mod_item-clinica-especialidades-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-especialidades-agregar" name="mod_a240" <?php echo $c240; ?> value="1"/><label for="mod_item-clinica-especialidades-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-especialidades-editar" name="mod_a241" <?php echo $c241; ?> value="1"/><label for="mod_item-clinica-especialidades-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-especialidades-eliminar" name="mod_a242" <?php echo $c242; ?> value="1"/><label for="mod_item-clinica-especialidades-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-clinica-medicos" style="position: absolute; opacity: 0;"/><label for="mod_item-clinica-medicos">M&eacute;dicos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-medicos-ver" name="mod_a243" <?php echo $c243; ?> value="1"/><label for="mod_item-clinica-medicos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-medicos-agregar" name="mod_a244" <?php echo $c244; ?> value="1"/><label for="mod_item-clinica-medicos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-medicos-editar" name="mod_a245" <?php echo $c245; ?> value="1"/><label for="mod_item-clinica-medicos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-medicos-eliminar" name="mod_a246" <?php echo $c246; ?> value="1"/><label for="mod_item-clinica-medicos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-clinica-atencion" style="position: absolute; opacity: 0;"/><label for="mod_item-clinica-atencion">Atenci&oacute;n</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-atencion-ver" name="mod_a247" <?php echo $c247; ?> value="1"/><label for="mod_item-clinica-atencion-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-atencion-agregar" name="mod_a248" <?php echo $c248; ?> value="1"/><label for="mod_item-clinica-atencion-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Atender</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <?php } ?>
                    <li><input type="checkbox" id="mod_item-marketing" style="position: absolute; opacity: 0;"/><label for="mod_item-marketing">Marketing</label>
                        <ul>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-marketing-email" name="mod_a25" <?php echo $c25; ?> value="1"/><label for="mod_item-marketing-email">&nbsp;&nbsp;&nbsp;&nbsp;Email</label></li>
                            <li class="hidden"><input class="magic-checkbox" type="checkbox" id="mod_item-marketing-whatsapp" name="mod_a26" <?php echo $c26; ?> value="1"/><label for="mod_item-marketing-whatsapp">&nbsp;&nbsp;&nbsp;&nbsp;WhatsApp</label></li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-articulos" style="position: absolute; opacity: 0;"/><label for="mod_item-articulos">Art&iacute;culos</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-articulos-marcas" style="position: absolute; opacity: 0;"/><label for="mod_item-articulos-marcas">Marcas</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-marcas-ver" name="mod_a27" <?php echo $c27; ?> value="1"/><label for="mod_item-articulos-marcas-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-marcas-agregar" name="mod_a28" <?php echo $c28; ?> value="1"/><label for="mod_item-articulos-marcas-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-marcas-editar" name="mod_a29" <?php echo $c29; ?> value="1"/><label for="mod_item-articulos-marcas-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-marcas-eliminar" name="mod_a30" <?php echo $c30; ?> value="1"/><label for="mod_item-articulos-marcas-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-articulos-categorias" style="position: absolute; opacity: 0;"/><label for="mod_item-articulos-categorias">Categor&iacute;as</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-categorias-ver" name="mod_a31" <?php echo $c31; ?> value="1"/><label for="mod_item-articulos-categorias-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-categorias-agregar" name="mod_a32" <?php echo $c32; ?> value="1"/><label for="mod_item-articulos-categorias-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-categorias-editar" name="mod_a33" <?php echo $c33; ?> value="1"/><label for="mod_item-articulos-categorias-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-categorias-eliminar" name="mod_a34" <?php echo $c34; ?> value="1"/><label for="mod_item-articulos-categorias-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-articulos-mod_items" style="position: absolute; opacity: 0;"/><label for="mod_item-articulos-mod_items">&Iacute;tems</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-mod_items-ver" name="mod_a35" <?php echo $c35; ?> value="1"/><label for="mod_item-articulos-mod_items-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-mod_items-agregar" name="mod_a36" <?php echo $c36; ?> value="1"/><label for="mod_item-articulos-mod_items-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-mod_items-editar" name="mod_a37" <?php echo $c37; ?> value="1"/><label for="mod_item-articulos-mod_items-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-mod_items-eliminar" name="mod_a38" <?php echo $c38; ?> value="1"/><label for="mod_item-articulos-mod_items-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-mod_items-foto" name="mod_a39" <?php echo $c39; ?> value="1"/><label for="mod_item-articulos-mod_items-foto">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Foto</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-mod_items-especificaciones" <?php echo $c40; ?> name="mod_a40" value="1"/><label for="mod_item-articulos-mod_items-especificaciones">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Especificaciones</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-mod_items-ficha" name="mod_a41" <?php echo $c41; ?> value="1"/><label for="mod_item-articulos-mod_items-ficha">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Ficha T&eacute;cnica</label></li>
                                </ul>
                            </li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-kardex" name="mod_a42" <?php echo $c42; ?> value="1"/><label for="mod_item-articulos-kardex">&nbsp;&nbsp;&nbsp;&nbsp;Kardex</label></li>
                            <li><input type="checkbox" id="mod_item-articulos-traslados" style="position: absolute; opacity: 0;"/><label for="mod_item-articulos-traslados">Traslados</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-traslados-ver" name="mod_a43" <?php echo $c43; ?> value="1"/><label for="mod_item-articulos-traslados-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-traslados-agregar" name="mod_a44" <?php echo $c44; ?> value="1"/><label for="mod_item-articulos-traslados-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-articulos-ajustes" style="position: absolute; opacity: 0;"/><label for="mod_item-articulos-ajustes">Ajustes</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-ajustes-ver" name="mod_a45" <?php echo $c45; ?> value="1"/><label for="mod_item-articulos-ajustes-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-ajustes-agregar" name="mod_a46" <?php echo $c46; ?> value="1"/><label for="mod_item-articulos-ajustes-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar Stock</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-ajustes-eliminar" name="mod_a47" <?php echo $c47; ?> value="1"/><label for="mod_item-articulos-ajustes-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Quitar Stock</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-ventas" style="position: absolute; opacity: 0;"/><label for="mod_item-ventas">Ventas</label>
                        <ul>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-nboleta" name="mod_a48" <?php echo $c48; ?> value="1"/><label for="mod_item-ventas-nboleta">&nbsp;&nbsp;&nbsp;&nbsp;Nueva Boleta</label></li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-nfactura" name="mod_a49" <?php echo $c49; ?> value="1"/><label for="mod_item-ventas-nfactura">&nbsp;&nbsp;&nbsp;&nbsp;Nueva Factura</label></li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-npedido" name="mod_a50" <?php echo $c50; ?> value="1"/><label for="mod_item-ventas-npedido">&nbsp;&nbsp;&nbsp;&nbsp;Nuevo Pedido</label></li>
                            <li><input type="checkbox" id="mod_item-ventas-documentos" style="position: absolute; opacity: 0;"/><label for="mod_item-ventas-documentos">Historial Documentos</label>
                                <ul>
                                    <li><input type="checkbox" id="mod_item-ventas-documentos-boletas" style="position: absolute; opacity: 0;"/><label for="mod_item-ventas-documentos-boletas">Boletas</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-boletas-ver" name="mod_a51" <?php echo $c51; ?> value="1"/><label for="mod_item-ventas-documentos-boletas-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-boletas-anular" name="mod_a52" <?php echo $c52; ?> value="1"/><label for="mod_item-ventas-documentos-boletas-anular">&nbsp;&nbsp;&nbsp;&nbsp;Anular</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-boletas-pdf" name="mod_a53" <?php echo $c53; ?> value="1"/><label for="mod_item-ventas-documentos-boletas-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-boletas-excel" name="mod_a54" <?php echo $c54; ?> value="1"/><label for="mod_item-ventas-documentos-boletas-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                        </ul>
                                    </li>
                                    <li><input type="checkbox" id="mod_item-ventas-documentos-facturas" style="position: absolute; opacity: 0;"/><label for="mod_item-ventas-documentos-facturas">Facturas</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-facturas-ver" name="mod_a55" <?php echo $c55; ?> value="1"/><label for="mod_item-ventas-documentos-facturas-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-facturas-anular" name="mod_a56" <?php echo $c56; ?> value="1"/><label for="mod_item-ventas-documentos-facturas-anular">&nbsp;&nbsp;&nbsp;&nbsp;Anular</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-facturas-pdf" name="mod_a57" <?php echo $c57; ?> value="1"/><label for="mod_item-ventas-documentos-facturas-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-facturas-excel" name="mod_a58" <?php echo $c58; ?> value="1"/><label for="mod_item-ventas-documentos-facturas-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                        </ul>
                                    </li>
                                    <li><input type="checkbox" id="mod_item-ventas-documentos-nCreditos" style="position: absolute; opacity: 0;"/><label for="mod_item-ventas-documentos-nCreditos">N. Cr&eacute;ditos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nCreditos-ver" name="mod_a59" <?php echo $c59; ?> value="1"/><label for="mod_item-ventas-documentos-nCreditos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nCreditos-pdf" name="mod_a60" <?php echo $c60; ?> value="1"/><label for="mod_item-ventas-documentos-nCreditos-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nCreditos-excel" name="mod_a61" <?php echo $c61; ?> value="1"/><label for="mod_item-ventas-documentos-nCreditos-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                        </ul>
                                    </li>
                                    <li><input type="checkbox" id="mod_item-ventas-documentos-nDebitos" style="position: absolute; opacity: 0;"/><label for="mod_item-ventas-documentos-nDebitos">N. D&eacute;bitos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nDebitos-ver" name="mod_a62" <?php echo $c62; ?> value="1"/><label for="mod_item-ventas-documentos-nDebitos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nDebitos-pdf" name="mod_a63" <?php echo $c63; ?> value="1"/><label for="mod_item-ventas-documentos-nDebitos-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nDebitos-excel" name="mod_a64" <?php echo $c64; ?> value="1"/><label for="mod_item-ventas-documentos-nDebitos-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                        </ul>
                                    </li>
                                    <li><input type="checkbox" id="mod_item-ventas-documentos-nPedidos" style="position: absolute; opacity: 0;"/><label for="mod_item-ventas-documentos-nPedidos">N. Pedidos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nPedidos-ver" name="mod_a65" <?php echo $c65; ?> value="1"/><label for="mod_item-ventas-documentos-nPedidos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nPedidos-facturar" name="mod_a66" <?php echo $c66; ?> value="1"/><label for="mod_item-ventas-documentos-nPedidos-facturar">&nbsp;&nbsp;&nbsp;&nbsp;Facturar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nPedidos-anular" name="mod_a67" <?php echo $c67; ?> value="1"/><label for="mod_item-ventas-documentos-nPedidos-anular">&nbsp;&nbsp;&nbsp;&nbsp;Anular</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nPedidos-pdf" name="mod_a68" <?php echo $c68; ?> value="1"/><label for="mod_item-ventas-documentos-nPedidos-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nPedidos-excel" name="mod_a69" <?php echo $c69; ?> value="1"/><label for="mod_item-ventas-documentos-nPedidos-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-cotizaciones" style="position: absolute; opacity: 0;"/><label for="mod_item-cotizaciones">Cotizaciones</label>
                        <ul>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-cotizaciones-nCotizacion" name="mod_a70" <?php echo $c70; ?> value="1"/><label for="mod_item-cotizaciones-nCotizacion">&nbsp;&nbsp;&nbsp;&nbsp;Nueva Cotizaci&oacute;n</label></li>
                            <li><input type="checkbox" id="mod_item-cotizaciones-cotizaciones" style="position: absolute; opacity: 0;"/><label for="mod_item-cotizaciones-cotizaciones">Historial Cotizaciones</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-cotizaciones-cotizaciones-ver" name="mod_a71" <?php echo $c71; ?> value="1"/><label for="mod_item-cotizaciones-cotizaciones-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-cotizaciones-cotizaciones-facturar" name="mod_a72" <?php echo $c72; ?> value="1"/><label for="mod_item-cotizaciones-cotizaciones-facturar">&nbsp;&nbsp;&nbsp;&nbsp;Facturar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-cotizaciones-cotizaciones-anular" name="mod_a73" <?php echo $c73; ?> value="1"/><label for="mod_item-cotizaciones-cotizaciones-anular">&nbsp;&nbsp;&nbsp;&nbsp;Anular</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-cotizaciones-cotizaciones-pdf" name="mod_a74" <?php echo $c74; ?> value="1"/><label for="mod_item-cotizaciones-cotizaciones-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-cotizaciones-cotizaciones-excel" name="mod_a75" <?php echo $c75; ?> value="1"/><label for="mod_item-cotizaciones-cotizaciones-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-egresos" style="position: absolute; opacity: 0;"/><label for="mod_item-egresos">Egresos</label>
                        <ul>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-nCompra" name="mod_a76" <?php echo $c76; ?> value="1"/><label for="mod_item-egresos-nCompra">&nbsp;&nbsp;&nbsp;&nbsp;Nueva Compra</label></li>
                            <li><input type="checkbox" id="mod_item-egresos-compras" style="position: absolute; opacity: 0;"/><label for="mod_item-egresos-compras">Historial Compras</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-compras-ver" name="mod_a77" <?php echo $c77; ?> value="1"/><label for="mod_item-egresos-compras-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-compras-anular" name="mod_a78" <?php echo $c78; ?> value="1"/><label for="mod_item-egresos-compras-anular">&nbsp;&nbsp;&nbsp;&nbsp;Anular</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-compras-pdf" name="mod_a79" <?php echo $c79; ?> value="1"/><label for="mod_item-egresos-compras-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-compras-excel" name="mod_a80" <?php echo $c80; ?> value="1"/><label for="mod_item-egresos-compras-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                </ul>
                            </li>
                            <!--<li><input type="checkbox" id="mod_item-egresos-categorias" style="position: absolute; opacity: 0;"/><label for="mod_item-egresos-categorias">Categor&iacute;a Gastos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-categorias-ver" name="mod_a81" <?php echo $c81; ?> value="1"/><label for="mod_item-egresos-categorias-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-categorias-agregar" name="mod_a82" <?php echo $c82; ?> value="1"/><label for="mod_item-egresos-categorias-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-categorias-editar" name="mod_a83" <?php echo $c83; ?> value="1"/><label for="mod_item-egresos-categorias-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-categorias-eliminar" name="mod_a84" <?php echo $c84; ?> value="1"/><label for="mod_item-egresos-categorias-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>-->
                            <li><input type="checkbox" id="mod_item-egresos-gastos" style="position: absolute; opacity: 0;"/><label for="mod_item-egresos-gastos">Historial Gastos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-gastos-ver" name="mod_a85" <?php echo $c85; ?> value="1"/><label for="mod_item-egresos-gastos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <!--<li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-gastos-anular" name="mod_a86" <?php echo $c86; ?> value="1"/><label for="mod_item-egresos-gastos-anular">&nbsp;&nbsp;&nbsp;&nbsp;Anular</label></li>-->
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-gastos-pdf" name="mod_a87" <?php echo $c87; ?> value="1"/><label for="mod_item-egresos-gastos-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-gastos-excel" name="mod_a88" <?php echo $c88; ?> value="1"/><label for="mod_item-egresos-gastos-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-fElectronica" style="position: absolute; opacity: 0;"/><label for="mod_item-fElectronica">Fact. Electr&oacute;nica</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-fElectronica-nDebito" style="position: absolute; opacity: 0;"/><label for="mod_item-fElectronica-nDebito">Nota D&eacute;bito</label>
                                <ul>
                                  <li><input class="magic-checkbox" type="checkbox" id="mod_item-fElectronica-nDebito-factura" name="mod_a89" <?php echo $c89; ?> value="1"/><label for="mod_item-fElectronica-nDebito-factura">&nbsp;&nbsp;&nbsp;&nbsp;Nuevo Para Factura</label></li>
                                  <li><input class="magic-checkbox" type="checkbox" id="mod_item-fElectronica-nDebito-boleta" name="mod_a90" <?php echo $c90; ?> value="1"/><label for="mod_item-fElectronica-nDebito-boleta">&nbsp;&nbsp;&nbsp;&nbsp;Nuevo Para Boleta</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-fElectronica-nCredito" style="position: absolute; opacity: 0;"/><label for="mod_item-fElectronica-nCredito">Nota Cr&eacute;dito</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-fElectronica-nCredito-factura" name="mod_a91" <?php echo $c91; ?> value="1"/><label for="mod_item-fElectronica-nCredito-factura">&nbsp;&nbsp;&nbsp;&nbsp;Nuevo Para Factura</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-fElectronica-nCredito-boleta" name="mod_a92" <?php echo $c92; ?> value="1"/><label for="mod_item-fElectronica-nCredito-boleta">&nbsp;&nbsp;&nbsp;&nbsp;Nuevo Para Boleta</label></li>
                                </ul>
                            </li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-fElectronica-rDiario" name="mod_a93" <?php echo $c93; ?> value="1"/><label for="mod_item-fElectronica-rDiario">&nbsp;&nbsp;&nbsp;&nbsp;Resumen Diario</label></li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-fElectronica-cBaja" name="mod_a94" <?php echo $c94; ?> value="1"/><label for="mod_item-fElectronica-cBaja">&nbsp;&nbsp;&nbsp;&nbsp;Comunicaci&oacute;n Baja</label></li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-fElectronica-gRemision" name="mod_a95" <?php echo $c95; ?> value="1"/><label for="mod_item-fElectronica-gRemision">&nbsp;&nbsp;&nbsp;&nbsp;Gu&iacute;a Remisi&oacute;n</label></li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-contabilidad" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad">Contabilidad</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-contabilidad-lElectronicos" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-lElectronicos">Libros Electr&oacute;nicos</label>
                                <ul>
                                    <li class="hidden"><input type="checkbox" id="mod_item-contabilidad-lElectronicos-cb" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-lElectronicos-cb">Caja Bancos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-cb-mEfectivo" name="mod_a96" <?php echo $c96; ?> value="1"/><label for="mod_item-contabilidad-lElectronicos-cb-mEfectivo">&nbsp;&nbsp;&nbsp;&nbsp;Mov. Efectivo</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-cb-mCta" name="mod_a97" <?php echo $c97; ?> value="1"/><label for="mod_item-contabilidad-lElectronicos-cb-mCta">&nbsp;&nbsp;&nbsp;&nbsp;Mov. Cta. Corriente</label></li>
                                        </ul>
                                    </li>
                                    <li class="hidden"><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-rInventario" name="mod_a98" <?php echo $c98; ?> value="1"/><label for="mod_item-contabilidad-lElectronicos-rInventario">&nbsp;&nbsp;&nbsp;&nbsp;Registro Inventarios</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-rCompras" name="mod_a99" <?php echo $c99; ?> value="1"/><label for="mod_item-contabilidad-lElectronicos-rCompras">&nbsp;&nbsp;&nbsp;&nbsp;Registro Compras</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-rVentas" name="mod_a100" <?php echo $c100; ?> value="1"/><label for="mod_item-contabilidad-lElectronicos-rVentas">&nbsp;&nbsp;&nbsp;&nbsp;Registro Ventas</label></li>
                                    <li class="hidden"><input type="checkbox" id="mod_item-contabilidad-lElectronicos-lDiario" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-lElectronicos-lDiario">Libro Diario</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-lDiario-ver" name="mod_a101" <?php echo $c101; ?> value="1"/><label for="mod_item-contabilidad-lElectronicos-lDiario-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-lDiario-agregar" name="mod_a102" <?php echo $c102; ?> value="1"/><label for="mod_item-contabilidad-lElectronicos-lDiario-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Registrar Asiento</label></li>
                                        </ul>
                                    </li>
                                    <li class="hidden"><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-lMayor" name="mod_a103" <?php echo $c103; ?> value="1"/><label for="mod_item-contabilidad-lElectronicos-lMayor">&nbsp;&nbsp;&nbsp;&nbsp;Libro Mayor</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-contabilidad-bancos" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-bancos">Listado Bancos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-bancos-ver" name="mod_a104" <?php echo $c104; ?> value="1"/><label for="mod_item-contabilidad-bancos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-bancos-agregar" name="mod_a105" <?php echo $c105; ?> value="1"/><label for="mod_item-contabilidad-bancos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-bancos-editar" name="mod_a106" <?php echo $c106; ?> value="1"/><label for="mod_item-contabilidad-bancos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-bancos-eliminar" name="mod_a107" <?php echo $c107; ?> value="1"/><label for="mod_item-contabilidad-bancos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-contabilidad-cBancarias" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-cBancarias">Cuentas Bancarias</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-cBancarias-ver" name="mod_a108" <?php echo $c108; ?> value="1"/><label for="mod_item-contabilidad-cBancarias-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-cBancarias-agregar" name="mod_a109" <?php echo $c109; ?> value="1"/><label for="mod_item-contabilidad-cBancarias-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-cBancarias-editar" name="mod_a110" <?php echo $c110; ?> value="1"/><label for="mod_item-contabilidad-cBancarias-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-cBancarias-eliminar" name="mod_a111" <?php echo $c111; ?> value="1"/><label for="mod_item-contabilidad-cBancarias-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                    <li><input type="checkbox" id="mod_item-contabilidad-cBancarias-movimientos" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-cBancarias-movimientos">Movimientos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-cBancarias-movimientos-ver" name="mod_a112" <?php echo $c112; ?> value="1"/><label for="mod_item-contabilidad-cBancarias-movimientos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-cBancarias-movimientos-agregar" name="mod_a113" <?php echo $c113; ?> value="1"/><label for="mod_item-contabilidad-cBancarias-movimientos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li class=""><input type="checkbox" id="mod_item-contabilidad-pcge" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-pcge">Cat&aacute;logo Cuentas</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-pcge-ver" name="mod_a114" <?php echo $c124; ?> value="1"/><label for="mod_item-contabilidad-pcge-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-pcge-agregar" name="mod_a115" <?php echo $c125; ?> value="1"/><label for="mod_item-contabilidad-pcge-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-pcge-editar" name="mod_a116" <?php echo $c116; ?> value="1"/><label for="mod_item-contabilidad-pcge-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-pcge-eliminar" name="mod_a117" <?php echo $c117; ?> value="1"/><label for="mod_item-contabilidad-pcge-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-contabilidad-mPago" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-mPago">Medio Pago</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-mPago-ver" name="mod_a226" <?php echo $c226; ?> value="1"/><label for="mod_item-contabilidad-mPago-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-mPago-agregar" name="mod_a227" <?php echo $c227; ?> value="1"/><label for="mod_item-contabilidad-mPago-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-mPago-editar" name="mod_a228" <?php echo $c228; ?> value="1"/><label for="mod_item-contabilidad-mPago-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-mPago-eliminar" name="mod_a229" <?php echo $c229; ?> value="1"/><label for="mod_item-contabilidad-mPago-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-creditos" style="position: absolute; opacity: 0;"/><label for="mod_item-creditos">Cr&eacute;ditos</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-creditos-cPagar" style="position: absolute; opacity: 0;"/><label for="mod_item-creditos-cPagar">Cuentas Por Pagar</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-creditos-cPagar-ver" name="mod_a118" <?php echo $c118; ?> value="1"/><label for="mod_item-creditos-cPagar-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input type="checkbox" id="mod_item-creditos-cPagar-movimientos" style="position: absolute; opacity: 0;"/><label for="mod_item-creditos-cPagar-movimientos">Movimientos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-creditos-cPagar-movimientos-ver" name="mod_a119" <?php echo $c119; ?> value="1"/><label for="mod_item-creditos-cPagar-movimientos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-creditos-cPagar-movimientos-agregar" name="mod_a120" <?php echo $c120; ?> value="1"/><label for="mod_item-creditos-cPagar-movimientos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-creditos-cCobrar" style="position: absolute; opacity: 0;"/><label for="mod_item-creditos-cCobrar">Cuentas Por Cobrar</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-creditos-cCobrar-ver" name="mod_a121" <?php echo $c121; ?> value="1"/><label for="mod_item-creditos-cCobrar-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input type="checkbox" id="mod_item-creditos-cCobrar-movimientos" style="position: absolute; opacity: 0;"/><label for="mod_item-creditos-cCobrar-movimientos">Movimientos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-creditos-cCobrar-movimientos-ver" name="mod_a122" <?php echo $c122; ?> value="1"/><label for="mod_item-creditos-cCobrar-movimientos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-creditos-cCobrar-movimientos-agregar" name="mod_a123" <?php echo $c123; ?> value="1"/><label for="mod_item-creditos-cCobrar-movimientos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-rrhh" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh">RR.HH</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-rrhh-vDescansos" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-vDescansos">Variables Laborales</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vDescansos-ver" name="mod_a124" <?php echo $c124; ?> value="1"/><label for="mod_item-rrhh-vDescansos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vDescansos-agregar" name="mod_a125" <?php echo $c125; ?> value="1"/><label for="mod_item-rrhh-vDescansos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vDescansos-editar" name="mod_a126" <?php echo $c126; ?> value="1"/><label for="mod_item-rrhh-vDescansos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vDescansos-eliminar" name="mod_a127" <?php echo $c127; ?> value="1"/><label for="mod_item-rrhh-vDescansos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li class="hidden"><input type="checkbox" id="mod_item-rrhh-cAsistencia" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-cAsistencia">Consulta Asistencia</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-cAsistencia-ver" name="mod_a128" <?php echo $c128; ?> value="1"/><label for="mod_item-rrhh-cAsistencia-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-cAsistencia-pdf" name="mod_a129" <?php echo $c129; ?> value="1"/><label for="mod_item-rrhh-cAsistencia-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-cAsistencia-excel" name="mod_a130" <?php echo $c130; ?> value="1"/><label for="mod_item-rrhh-cAsistencia-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-rrhh-lAsistencia" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-lAsistencia">Lista Asistencia</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lAsistencia-ver" name="mod_a132" <?php echo $c132; ?> value="1"/><label for="mod_item-rrhh-lAsistencia-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lAsistencia-entrada" name="mod_a133" <?php echo $c133; ?> value="1"/><label for="mod_item-rrhh-lAsistencia-entrada">&nbsp;&nbsp;&nbsp;&nbsp;Registrar Entrada</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lAsistencia-salida" name="mod_a131" <?php echo $c131; ?> value="1"/><label for="mod_item-rrhh-lAsistencia-salida">&nbsp;&nbsp;&nbsp;&nbsp;Registrar Salida</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lAsistencia-pdf" name="mod_a134" <?php echo $c134; ?> value="1"/><label for="mod_item-rrhh-lAsistencia-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lAsistencia-excel" name="mod_a135" <?php echo $c135; ?> value="1"/><label for="mod_item-rrhh-lAsistencia-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                </ul>
                            </li>
                            <li class="hidden"><input type="checkbox" id="mod_item-rrhh-lDescanso" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-lDescanso">Lista Descanso</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lDescanso-ver" name="mod_a136" <?php echo $c136; ?> value="1"/><label for="mod_item-rrhh-lDescanso-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lDescanso-agregar" name="mod_a137" <?php echo $c137; ?> value="1"/><label for="mod_item-rrhh-lDescanso-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lDescanso-editar" name="mod_a138" <?php echo $c138; ?> value="1"/><label for="mod_item-rrhh-lDescanso-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lDescanso-eliminar" name="mod_a139" <?php echo $c139; ?> value="1"/><label for="mod_item-rrhh-lDescanso-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li class="hidden"><input type="checkbox" id="mod_item-rrhh-vacaciones" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-vacaciones">Vacaciones</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vacaciones-ver" name="mod_a140" <?php echo $c140; ?> value="1"/><label for="mod_item-rrhh-vacaciones-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vacaciones-agregar" name="mod_a141" <?php echo $c141; ?> value="1"/><label for="mod_item-rrhh-vacaciones-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vacaciones-editar" name="mod_a142" <?php echo $c142; ?> value="1"/><label for="mod_item-rrhh-vacaciones-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vacaciones-eliminar" name="mod_a143" <?php echo $c143; ?> value="1"/><label for="mod_item-rrhh-vacaciones-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li class="hidden"><input type="checkbox" id="mod_item-rrhh-contratos" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-contratos">Contratos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-contratos-ver" name="mod_a144" <?php echo $c144; ?> value="1"/><label for="mod_item-rrhh-contratos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-contratos-agregar" name="mod_a145" <?php echo $c145; ?> value="1"/><label for="mod_item-rrhh-contratos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-contratos-editar" name="mod_a146" <?php echo $c146; ?> value="1"/><label for="mod_item-rrhh-contratos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-contratos-eliminar" name="mod_a147" <?php echo $c147; ?> value="1"/><label for="mod_item-rrhh-contratos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-rrhh-cargos" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-cargos">Cargos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-cargos-ver" name="mod_a222" <?php echo $c222; ?> value="1"/><label for="mod_item-rrhh-cargos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-cargos-agregar" name="mod_a223" <?php echo $c223; ?> value="1"/><label for="mod_item-rrhh-cargos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-cargos-editar" name="mod_a224" <?php echo $c224; ?> value="1"/><label for="mod_item-rrhh-cargos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-cargos-eliminar" name="mod_a225" <?php echo $c225; ?> value="1"/><label for="mod_item-rrhh-cargos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li class="hidden"><input type="checkbox" id="mod_item-rrhh-pagos" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-pagos">Pagos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-pagos-ver" name="mod_a148" <?php echo $c148; ?> value="1"/><label for="mod_item-rrhh-pagos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-pagos-agregar" name="mod_a149" <?php echo $c149; ?> value="1"/><label for="mod_item-rrhh-pagos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-pagos-editar" name="mod_a150" <?php echo $c150; ?> value="1"/><label for="mod_item-rrhh-pagos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-pagos-eliminar" name="mod_a151" <?php echo $c151; ?> value="1"/><label for="mod_item-rrhh-pagos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li class="hidden"><input type="checkbox" id="mod_item-rrhh-planilla" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-planilla">Planilla</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-planilla-ver" name="mod_a152" <?php echo $c152; ?> value="1"/><label for="mod_item-rrhh-planilla-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-planilla-agregar" name="mod_a153" <?php echo $c153; ?> value="1"/><label for="mod_item-rrhh-planilla-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-planilla-editar" name="mod_a154" <?php echo $c154; ?> value="1"/><label for="mod_item-rrhh-planilla-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-planilla-eliminar" name="mod_a155" <?php echo $c155; ?> value="1"/><label for="mod_item-rrhh-planilla-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="hidden"><input type="checkbox" id="mod_item-crm" style="position: absolute; opacity: 0;"/><label for="mod_item-crm">CRM</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-crm-tareas" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-tareas">Tareas</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-tareas-ver" name="mod_a156" <?php echo $c156; ?> value="1"/><label for="mod_item-crm-tareas-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-tareas-agregar" name="mod_a157" <?php echo $c157; ?> value="1"/><label for="mod_item-crm-tareas-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-tareas-editar" name="mod_a158" <?php echo $c158; ?> value="1"/><label for="mod_item-crm-tareas-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-tareas-eliminar" name="mod_a159" <?php echo $c159; ?> value="1"/><label for="mod_item-crm-tareas-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-crm-proyectos" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-proyectos">Proyectos</label>
                                <ul>
                                    <li><input type="checkbox" id="mod_item-crm-proyectos-programas" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-proyectos-programas">Programas</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-programas-ver" name="mod_a160" <?php echo $c160; ?> value="1"/><label for="mod_item-crm-proyectos-programas-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-programas-agregar" name="mod_a249" <?php echo $c249; ?> value="1"/><label for="mod_item-crm-proyectos-programas-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-programas-editar" name="mod_a250" <?php echo $c250; ?> value="1"/><label for="mod_item-crm-proyectos-programas-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-programas-eliminar" name="mod_a251" <?php echo $c251; ?> value="1"/><label for="mod_item-crm-proyectos-programas-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                        </ul>
                                    </li>
                                    <li><input type="checkbox" id="mod_item-crm-proyectos-grupos" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-proyectos-grupos">Grupos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-grupos-ver" name="mod_a161" <?php echo $c161; ?> value="1"/><label for="mod_item-crm-proyectos-grupos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-grupos-agregar" name="mod_a252" <?php echo $c252; ?> value="1"/><label for="mod_item-crm-proyectos-grupos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-grupos-editar" name="mod_a253" <?php echo $c253; ?> value="1"/><label for="mod_item-crm-proyectos-grupos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-grupos-eliminar" name="mod_a254" <?php echo $c254; ?> value="1"/><label for="mod_item-crm-proyectos-grupos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                        </ul>
                                    </li>
                                    <li><input type="checkbox" id="mod_item-crm-proyectos-miembros" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-proyectos-miembros">Miembros</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-miembros-ver" name="mod_a162" <?php echo $c162; ?> value="1"/><label for="mod_item-crm-proyectos-miembros-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-miembros-agregar" name="mod_a255" <?php echo $c255; ?> value="1"/><label for="mod_item-crm-proyectos-miembros-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-miembros-editar" name="mod_a256" <?php echo $c256; ?> value="1"/><label for="mod_item-crm-proyectos-miembros-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-miembros-eliminar" name="mod_a257" <?php echo $c257; ?> value="1"/><label for="mod_item-crm-proyectos-miembros-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                        </ul>
                                    </li>
                                    <li><input type="checkbox" id="mod_item-crm-proyectos-poyectos" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-proyectos-poyectos">Proyectos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-poyectos-ver" name="mod_a163" <?php echo $c163; ?> value="1"/><label for="mod_item-crm-proyectos-poyectos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-poyectos-agregar" name="mod_a258" <?php echo $c258; ?> value="1"/><label for="mod_item-crm-proyectos-poyectos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-poyectos-editar" name="mod_a259" <?php echo $c259; ?> value="1"/><label for="mod_item-crm-proyectos-poyectos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-poyectos-eliminar" name="mod_a260" <?php echo $c260; ?> value="1"/><label for="mod_item-crm-proyectos-poyectos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-crm-callCenter" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-callCenter">Call Center</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-callCenter-ver" name="mod_a164" <?php echo $c164; ?> value="1"/><label for="mod_item-crm-callCenter-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-callCenter-agregar" name="mod_a165" <?php echo $c165; ?> value="1"/><label for="mod_item-crm-callCenter-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-callCenter-editar" name="mod_a166" <?php echo $c166; ?> value="1"/><label for="mod_item-crm-callCenter-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-callCenter-eliminar" name="mod_a167" <?php echo $c167; ?> value="1"/><label for="mod_item-crm-callCenter-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-crm-propuestas" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-propuestas">Propuestas</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-propuestas-ver" name="mod_a168" <?php echo $c168; ?> value="1"/><label for="mod_item-crm-propuestas-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-propuestas-agregar" name="mod_a169" <?php echo $c169; ?> value="1"/><label for="mod_item-crm-propuestas-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-propuestas-editar" name="mod_a170" <?php echo $c170; ?> value="1"/><label for="mod_item-crm-propuestas-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-propuestas-eliminar" name="mod_a171" <?php echo $c171; ?> value="1"/><label for="mod_item-crm-propuestas-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-crm-presupuestos" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-presupuestos">Presupuestos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-presupuestos-ver" name="mod_a172" <?php echo $c172; ?> value="1"/><label for="mod_item-crm-presupuestos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-presupuestos-agregar" name="mod_a173" <?php echo $c173; ?> value="1"/><label for="mod_item-crm-presupuestos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-presupuestos-editar" name="mod_a174" <?php echo $c174; ?> value="1"/><label for="mod_item-crm-presupuestos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-presupuestos-eliminar" name="mod_a175" <?php echo $c175; ?> value="1"/><label for="mod_item-crm-presupuestos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-crm-hTickets" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-hTickets">Historial Tickets</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-hTickets-ver" name="mod_a176" <?php echo $c176; ?> value="1"/><label for="mod_item-crm-hTickets-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-hTickets-agregar" name="mod_a177" <?php echo $c177; ?> value="1"/><label for="mod_item-crm-hTickets-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-hTickets-editar" name="mod_a178" <?php echo $c178; ?> value="1"/><label for="mod_item-crm-hTickets-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-hTickets-eliminar" name="mod_a179" <?php echo $c179; ?> value="1"/><label for="mod_item-crm-hTickets-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-crm-cPotenciales" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-cPotenciales">Clientes Potenciales</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-cPotenciales-ver" name="mod_a180" <?php echo $c180; ?> value="1"/><label for="mod_item-crm-cPotenciales-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-cPotenciales-agregar" name="mod_a181" <?php echo $c181; ?> value="1"/><label for="mod_item-crm-cPotenciales-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-cPotenciales-editar" name="mod_a182" <?php echo $c182; ?> value="1"/><label for="mod_item-crm-cPotenciales-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-cPotenciales-eliminar" name="mod_a183" <?php echo $c183; ?> value="1"/><label for="mod_item-crm-cPotenciales-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-ajustes" style="position: absolute; opacity: 0;"/><label for="mod_item-ajustes">Ajustes</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-ajustes-dEmpresa" style="position: absolute; opacity: 0;"/><label for="mod_item-ajustes-dEmpresa">Datos Empresa</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-dEmpresa-dGenerales" name="mod_a184" <?php echo $c184; ?> value="1"/><label for="mod_item-ajustes-dEmpresa-dGenerales">&nbsp;&nbsp;&nbsp;&nbsp;Datos Generales</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-dEmpresa-cLogo" name="mod_a185" <?php echo $c185; ?> value="1"/><label for="mod_item-ajustes-dEmpresa-cLogo">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Logo</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-dEmpresa-cFavicon" name="mod_a186" <?php echo $c186; ?> value="1"/><label for="mod_item-ajustes-dEmpresa-cFavicon">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Favicon</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-dEmpresa-cfCertificado" name="mod_a187" <?php echo $c187; ?> value="1"/><label for="mod_item-ajustes-dEmpresa-cfCertificado">&nbsp;&nbsp;&nbsp;&nbsp;Configurar Certificado</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-dEmpresa-cCertificado" name="mod_a188" <?php echo $c188; ?> value="1"/><label for="mod_item-ajustes-dEmpresa-cCertificado">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Certificado</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-dEmpresa-sCorreo" name="mod_a189" <?php echo $c189; ?> value="1"/><label for="mod_item-ajustes-dEmpresa-sCorreo">&nbsp;&nbsp;&nbsp;&nbsp;Servidor Correo</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-ajustes-establecimientos" style="position: absolute; opacity: 0;"/><label for="mod_item-ajustes-establecimientos">Establecimientos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-establecimientos-ver" name="mod_a190" <?php echo $c190; ?> value="1"/><label for="mod_item-ajustes-establecimientos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-establecimientos-agregar" name="mod_a191" <?php echo $c191; ?> value="1"/><label for="mod_item-ajustes-establecimientos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-establecimientos-editar" name="mod_a192" <?php echo $c192; ?> value="1"/><label for="mod_item-ajustes-establecimientos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-establecimientos-eliminar" name="mod_a193" <?php echo $c193; ?> value="1"/><label for="mod_item-ajustes-establecimientos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-ajustes-seriesCorrelativos" style="position: absolute; opacity: 0;"/><label for="mod_item-ajustes-seriesCorrelativos">Series Correlativos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-seriesCorrelativos-ver" name="mod_a194" <?php echo $c194; ?> value="1"/><label for="mod_item-ajustes-seriesCorrelativos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-seriesCorrelativos-editar" name="mod_a195" <?php echo $c195; ?> value="1"/><label for="mod_item-ajustes-seriesCorrelativos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-ajustes-cUsuarios" style="position: absolute; opacity: 0;"/><label for="mod_item-ajustes-cUsuarios">Cuentas Usuarios</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-cUsuarios-ver" name="mod_a196" <?php echo $c196; ?> value="1"/><label for="mod_item-ajustes-cUsuarios-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-cUsuarios-agregar" name="mod_a197" <?php echo $c197; ?> value="1"/><label for="mod_item-ajustes-cUsuarios-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-cUsuarios-editar" name="mod_a198" <?php echo $c198; ?> value="1"/><label for="mod_item-ajustes-cUsuarios-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-aUsuarios-clave" name="mod_a263" <?php echo $c263; ?> value="1"/><label for="mod_item-ajustes-aUsuarios-clave">&nbsp;&nbsp;&nbsp;&nbsp;Editar Contrase&ntilde;a</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-cUsuarios-eliminar" name="mod_a199" <?php echo $c199; ?> value="1"/><label for="mod_item-ajustes-cUsuarios-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-ajustes-aUsuarios" style="position: absolute; opacity: 0;"/><label for="mod_item-ajustes-aUsuarios">Accesos Usuarios</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-aUsuarios-ver" name="mod_a200" <?php echo $c200; ?> value="1"/><label for="mod_item-ajustes-aUsuarios-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-aUsuarios-agregar" name="mod_a201" <?php echo $c201; ?> value="1"/><label for="mod_item-ajustes-aUsuarios-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-aUsuarios-editar" name="mod_a202" <?php echo $c202; ?> value="1"/><label for="mod_item-ajustes-aUsuarios-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-aUsuarios-eliminar" name="mod_a203" <?php echo $c203; ?> value="1"/><label for="mod_item-ajustes-aUsuarios-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-lUsuarios" name="mod_a204" <?php echo $c204; ?> value="1"/><label for="mod_item-ajustes-lUsuarios">&nbsp;&nbsp;&nbsp;&nbsp;Log Usuarios</label></li>
                            <li><input type="checkbox" id="mod_item-ajustes-almacenes" style="position: absolute; opacity: 0;"/><label for="mod_item-ajustes-almacenes">Almacenes</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-almacenes-ver" name="mod_a205" <?php echo $c205; ?> value="1"/><label for="mod_item-ajustes-almacenes-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-almacenes-agregar" name="mod_a206" <?php echo $c206; ?> value="1"/><label for="mod_item-ajustes-almacenes-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-almacenes-editar" name="mod_a207" <?php echo $c207; ?> value="1"/><label for="mod_item-ajustes-almacenes-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-almacenes-eliminar" name="mod_a208" <?php echo $c208; ?> value="1"/><label for="mod_item-ajustes-almacenes-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li class="hidden"><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-respaldo" name="mod_a209" <?php echo $c209; ?> value="1"/><label for="mod_item-ajustes-respaldo">&nbsp;&nbsp;&nbsp;&nbsp;Respaldo</label></li>
                            <li class="hidden"><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-backup" name="mod_a210" <?php echo $c210; ?> value="1"/><label for="mod_item-ajustes-backup">&nbsp;&nbsp;&nbsp;&nbsp;Backup</label></li>
                        </ul>
                    </li>
                    <li><input  type="checkbox" id="mod_item-reportes" style="position: absolute; opacity: 0;"/><label for="mod_item-reportes">Reportes</label>
                        <ul>
                            <li class="hidden"><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-gastos" name="mod_a211" <?php echo $c211; ?> value="1"/><label for="mod_item-reportes-gastos">&nbsp;&nbsp;&nbsp;&nbsp;Gastos</label></li>
                            <li><input type="checkbox" id="mod_item-reportes-ventas" style="position: absolute; opacity: 0;"/><label for="mod_item-reportes-ventas">Ventas</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-ventas-vUsuario" name="mod_a212" <?php echo $c212; ?> value="1"/><label for="mod_item-reportes-ventas-vUsuario">&nbsp;&nbsp;&nbsp;&nbsp;Ventas Usuario</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-ventas-vCliente" name="mod_a213" <?php echo $c213; ?> value="1"/><label for="mod_item-reportes-ventas-vCliente">&nbsp;&nbsp;&nbsp;&nbsp;Ventas Cliente</label></li>
                                    <li class="hidden"><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-ventas-vResumen" name="mod_a214" <?php echo $c214; ?> value="1"/><label for="mod_item-reportes-ventas-vResumen">&nbsp;&nbsp;&nbsp;&nbsp;Resumen</label></li>
                                </ul>
                            </li>
                            <li class="hidden"><input type="checkbox" id="mod_item-reportes-compras" style="position: absolute; opacity: 0;"/><label for="mod_item-reportes-compras">Compras</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-compras-cUsuario" name="mod_a215" <?php echo $c215; ?> value="1"/><label for="mod_item-reportes-compras-cUsuario">&nbsp;&nbsp;&nbsp;&nbsp;Compras Usuario</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-compras-cProveedor" name="mod_a216" <?php echo $c216; ?> value="1"/><label for="mod_item-reportes-compras-cProveedor">&nbsp;&nbsp;&nbsp;&nbsp;Compras Proveedor</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-compras-cResumen" name="mod_a217" <?php echo $c217; ?> value="1"/><label for="mod_item-reportes-compras-cResumen">&nbsp;&nbsp;&nbsp;&nbsp;Resumen</label></li>
                                </ul>
                            </li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-consolidado" name="mod_a218" <?php echo $c218; ?> value="1"/><label for="mod_item-reportes-consolidado">&nbsp;&nbsp;&nbsp;&nbsp;Consolidado</label></li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-bmod_items" name="mod_a219" <?php echo $c219; ?> value="1"/><label for="mod_item-reportes-bmod_items">&nbsp;&nbsp;&nbsp;&nbsp;Balance &Iacute;tems</label></li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-umod_items" name="mod_a220" <?php echo $c220; ?> value="1"/><label for="mod_item-reportes-umod_items">&nbsp;&nbsp;&nbsp;&nbsp;Utilidad &Iacute;tems</label></li>
                            <li class="hidden"><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-iVe" name="mod_a221" <?php echo $c221; ?> value="1"/><label for="mod_item-reportes-iVe">&nbsp;&nbsp;&nbsp;&nbsp;Ingresos VS Egresos</label></li>
                        </ul>
                    </li>
                </ul>
              </div>
          </div>