<style>
   .scroll {
  max-height: 500px;
  overflow: auto;
}
</style>
<div class="modal fade" id="abonoFactura" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Cuenta Abono</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div class="table-responsive" style="max-height: 550px; border: 1px solid #9b9b9b; border-radius: 13px;">
               <table class="table table-sm">
                  <thead>
                     <tr>
                        <th style="display: none;">#</th>
                        <th>C&oacute;digo</th>
                        <th>Descripci&oacute;n</th>
                     </tr>
                  </thead>
               </table>
               <div class="scroll" style="margin-top: -20px;">
                  <table class="display table dt-responsive" style="width:100%" id="tableAbono">
                    <tbody>
                     <?php
                     $sql = "select * from pcge where pcge_id=1492 or pcge_id=1493 or pcge_id=1494 or pcge_id=1495 or pcge_id=1496 or pcge_id=1497 or pcge_id=1498 or pcge_id=1499 or pcge_id=1500 or pcge_id=1501 or pcge_id=1502 or pcge_id=1503 or pcge_id=1504 or pcge_id=1505 or pcge_id=1506 or pcge_id=1507 or pcge_id=1508 or pcge_id=1509 or pcge_id=1510 or pcge_id=1511 or pcge_id=1512 or pcge_id=1513 or pcge_id=1514 or pcge_id=1515 or pcge_id=1516 or pcge_id=1517 or pcge_id=1518 or pcge_id=1519 or pcge_id=1520 or pcge_id=1521 or pcge_id=1522 or pcge_id=1523 or pcge_id=1524 or pcge_id=1525 or pcge_id=1526 or pcge_id=1527 or pcge_id=1528 or pcge_id=1529 or pcge_id=1530 or pcge_id=1531 or pcge_id=1532 or pcge_id=1533 or pcge_id=1534 or pcge_id=1535 or pcge_id=1536 or pcge_id=1538 or pcge_id=1539 or pcge_id=1540 or pcge_id=1541 or pcge_id=1542 or pcge_id=1543 or pcge_id=1544 or pcge_id=1545 or pcge_id=1546 or pcge_id=1547 or pcge_id=1548 or pcge_id=1549 or pcge_id=1550 or pcge_id=1551 or pcge_id=1552 or pcge_id=1553 or pcge_id=1554 or pcge_id=1556 or pcge_id=1557 or pcge_id=1558 or pcge_id=1559 or pcge_id=1560 or pcge_id=1561 or pcge_id=1562 or pcge_id=1563 or pcge_id=1564 or pcge_id=1565 or pcge_id=1566 or pcge_id=1567 or pcge_id=1568 order by pcge_id asc";
                     $query = mysqli_query($con,$sql);
                     while ($row = mysqli_fetch_array($query)) {
                        $pcge_id          = $row['pcge_id'];
                        $pcge_codigo      = $row['pcge_codigo'];
                        $pcge_descripcion = $row['pcge_descripcion'];

                     ?>
                      <tr data-dismiss="modal">
                        <td style="display: none;"><?php echo $pcge_id; ?></td>
                        <td><?php echo $pcge_codigo; ?></td>
                        <td><?php echo $pcge_descripcion; ?></td>
                      </tr>
                      <?php } ?>
                    </tbody>
                  </table>
               </div>
            </div>
            </div>
         </div>
     </div>
   </div>