<form method="post" id="guardar_topico" name="guardar_topico" autocomplete="off" class="form-horizontal" autocomplete="off">
   <div class="modal fade" id="nuevoTopico" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Nuevo Registro</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div id="resultados_ajax"></div>
               <div class="row">
                   <div class="form-group col-md-12">
                       <label for="topico_idCliente">Cliente *</label>
                       <select id="topico_idCliente" name="topico_idCliente" class="form-control selectTopCliente" style="width: 100%;" required>
                          <option></option>
                          <?php $tienda = $_SESSION['tienda'];
                             $sql_cliente ="select * from admision, clientes where admision_idCliente=clientes.cliente_id and clientes.cliente_sucursal='$tienda' order by clientes.cliente_nombre asc";
                             $row_cliente          =mysqli_query($con,$sql_cliente);
                             while ($row1_cliente = mysqli_fetch_array($row_cliente)) {
                                $cliente_nombre = $row1_cliente["cliente_nombre"];
                                $cliente_id     = $row1_cliente["cliente_id"];
                          ?>
                          <option value="<?php echo $cliente_id;?>"><?php  echo $cliente_nombre;?></option>

                          <?php } ?>
                       </select>
                   </div>
                   <div class="form-group col-md-4">
                       <label for="topico_peso">Peso *</label>
                       <input type="text" class="form-control" id="topico_peso" name="topico_peso" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Peso" required>
                   </div>
                   <div class="form-group col-md-4">
                       <label for="topico_talla">Talla *</label>
                       <input type="text" class="form-control" id="topico_talla" name="topico_talla" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Talla" required>
                   </div>
                   <div class="form-group col-md-4">
                       <label for="topico_presion">Presi&oacute;n *</label>
                       <input type="text" class="form-control" id="topico_presion" name="topico_presion" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Presi&oacute;n" required>
                   </div>
                   <div class="form-group col-md-4">
                       <label for="topico_temperatura">Temperatura *</label>
                       <input type="text" class="form-control" id="topico_temperatura" name="topico_temperatura" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Temperatura" required>
                   </div>
                   <div class="form-group col-md-4">
                       <label for="topico_saturacion">Saturaci&oacute;n *</label>
                       <input type="text" class="form-control" id="topico_saturacion" name="topico_saturacion" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Saturaci&oacute;n" required>
                   </div>
                   <div class="form-group col-md-4">
                       <label for="topico_idEspecialidad">Especialidad *</label>
                       <select id="topico_idEspecialidad" name="topico_idEspecialidad" class="form-control selectTopEsp" style="width: 100%;" required>
                          <option></option>
                          <?php $tienda = $_SESSION['tienda'];
                             $sql_especialidades ="select * from especialidades where especialidad_sucursal='$tienda' order by especialidad_nombre asc";
                             $row_especialidades          =mysqli_query($con,$sql_especialidades);
                             while ($row1_especialidades = mysqli_fetch_array($row_especialidades)) {
                                $especialidad_nombre = $row1_especialidades["especialidad_nombre"];
                                $especialidad_id     = $row1_especialidades["especialidad_id"];
                          ?>
                          <option value="<?php echo $especialidad_id;?>"><?php  echo $especialidad_nombre;?></option>

                          <?php } ?>
                       </select>
                   </div>
               </div>
             </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">Cancelar</button>
                 <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
             </div>
         </div>
     </div>
   </div>
</form>
<script>
$('.selectTopEsp').select2({
  placeholder: 'Selecciona una especialidad',
  width: 'resolve',
  dropdownParent: $("#nuevoTopico")
  //theme: "classic"
});
$('.selectTopCliente').select2({
  placeholder: 'Selecciona un cliente',
  width: 'resolve',
  dropdownParent: $("#nuevoTopico")
  //theme: "classic"
});
</script>