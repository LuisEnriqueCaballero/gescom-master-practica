<form method="post" id="guardar_especialidad" name="guardar_especialidad" autocomplete="off" class="form-horizontal" autocomplete="off">
   <div class="modal fade" id="nuevoEspecialidad" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Nueva Especialidad</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div id="resultados_ajax"></div>
               <div class="row">
                   <div class="form-group col-md-12">
                       <label for="nom_especialidad">Nombre *</label>
                       <input type="text" class="form-control" id="nom_especialidad" name="nom_especialidad" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" autofocus required>
                   </div>
                   <div class="form-group col-md-12">
                       <label for="desc_especialidad">Descripci&oacute;n *</label>
                       <input type="text" class="form-control" id="desc_especialidad" name="desc_especialidad" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Descripci&oacute;n" value="--" required>
                   </div>
               </div>
             </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">Cancelar</button>
                 <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
             </div>
         </div>
     </div>
   </div>
</form>