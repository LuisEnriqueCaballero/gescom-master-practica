<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
/* Connect To Database*/
//session_start();
//require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
//require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos
?>
<form method="post" id="editar_especialidad" name="editar_especialidad" autocomplete="off" class="form-horizontal">
   <div class="modal fade" id="editarEspecialidad" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Editar Especialidad</h4>
             </div>
            <div class="modal-body">
              <div id="resultados_ajax2"></div>
              <div class="row">
                 <div class="form-group col-md-12">
                        <input type="text" class="form-control" id="mod_marcaEs" name="mod_marcaEs" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" autofocus="" required>
                        <input type="hidden" name="mod_idEs" id="mod_idEs">
                  </div>
                  <div class="form-group col-md-12">
                        <input type="text" class="form-control" id="mod_descripcionEs" name="mod_descripcionEs" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Descripci&oacute;n" required>
                  </div>
              </div>
                  
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="actualizar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>