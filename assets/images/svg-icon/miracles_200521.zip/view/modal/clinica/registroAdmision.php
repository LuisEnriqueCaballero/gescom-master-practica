<form method="post" id="guardar_admision" name="guardar_admision" autocomplete="off" class="form-horizontal" autocomplete="off">
   <div class="modal fade" id="nuevoAdmision" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Nueva Admisi&oacute;n</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div id="resultados_ajax"></div>
               <div class="row">
                   <div class="form-group col-md-12">
                       <label for="admision_idCliente">Cliente *</label>
                       <input type="text" id="id_cliente" name="admision_idCliente">
                       <input type="text" class="form-control" id="cliente_nombre1" placeholder="Buscar cliente por documento o nombre..." required="required" tabindex="2" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();">
                   </div>
                   <div class="form-group col-md-6">
                       <label for="admision_edad">F. Nacimiento *</label>
                       <input type="date" class="form-control" id="cliente_fechaNacimiento" name="admision_edad" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Edad" required>
                   </div>
                   <div class="form-group col-md-6 hidden">
                       <label for="admision_deriva">Se deriva a *</label>
                       <select id="admision_deriva" name="admision_deriva" class="form-control" style="width: 100%;" required>
                          <option value="1">T&oacute;pico</option>
                          <option value="2">Atenci&oacute;n</option>
                       </select>
                   </div>
                   <div class="form-group col-md-6">
                       <label for="admision_idEspecialidad">Especialidad *</label>
                       <select id="admision_idEspecialidad" name="admision_idEspecialidad" class="form-control selectAdEsp" style="width: 100%;" required>
                          <option></option>
                          <?php $tienda = $_SESSION['tienda'];
                             $sql_especialidades ="select * from especialidades where especialidad_sucursal='$tienda' order by especialidad_nombre asc";
                             $row_especialidades          =mysqli_query($con,$sql_especialidades);
                             while ($row1_especialidades = mysqli_fetch_array($row_especialidades)) {
                                $especialidad_nombre = $row1_especialidades["especialidad_nombre"];
                                $especialidad_id     = $row1_especialidades["especialidad_id"];
                          ?>
                          <option value="<?php echo $especialidad_id;?>"><?php  echo $especialidad_nombre;?></option>

                          <?php } ?>
                       </select>
                   </div>
               </div>
             </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">Cancelar</button>
                 <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
             </div>
         </div>
     </div>
   </div>
</form>