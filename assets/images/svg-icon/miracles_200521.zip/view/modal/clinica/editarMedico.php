<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
//session_start();
/* Connect To Database*/
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos
?>
<form method="post" id="editar_medico" name="editar_medico" autocomplete="off" class="form-horizontal">
   <div class="modal fade" id="editarMedico" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Editar M&eacute;dico</h4>
             </div>
            <div class="modal-body">
              <div id="resultados_ajax2"></div>
               <div class="form-group">
                <input type="hidden" name="mod_idMedico" id="mod_idMedico">
                  <div class="col-sm-12">
                     <select required id="mod_idColaborador" name="mod_idColaborador" class="form-control" style="width: 100%;">
                        <option value="">SELECCIONAR COLABORADOR</option>
                        <?php
                           $tienda = $_SESSION['tienda'];

                           $tipo_cliente ="select * from colaboradores where colaborador_nombres!='ADMINISTRADOR' and colaborador_sucursal='$tienda'";
                           $row          =mysqli_query($con,$tipo_cliente);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $colaborador_nombres = $row4["colaborador_nombres"];
                              $colaborador_id     = $row4["colaborador_id"];
                        ?>
                        <option value="<?php echo $colaborador_id;?>"><?php  echo $colaborador_nombres;?></option>
                        <?php } ?>
                     </select>
                  </div>
               </div>
               <div class="form-group">
                  <div class="col-sm-12">
                     <select required id="mod_idEspecialidad" name="mod_idEspecialidad" class="form-control" style="width: 100%;">
                        <option value="">SELECCIONAR ESPECIALIDAD</option>
                        <?php
                           $tienda = $_SESSION['tienda'];

                           $tipo_cliente ="select * from especialidades where especialidad_sucursal='$tienda'";
                           $row          =mysqli_query($con,$tipo_cliente);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $especialidad_nombre = $row4["especialidad_nombre"];
                              $especialidad_id     = $row4["especialidad_id"];
                        ?>
                        <option value="<?php echo $especialidad_id;?>"><?php  echo $especialidad_nombre;?></option>
                        <?php } ?>
                     </select>
                  </div>
               </div>
               <div class="form-group">
                  <div class="col-sm-12">
                    <input type="text" class="form-control" id="mod_tarjetaProfesional" name="mod_tarjetaProfesional" placeholder="Tarjeta profesional" required onKeyUp="this.value=this.value.toUpperCase();">
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="actualizar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>