<form method="post" id="guardar_plan" name="guardar_plan" autocomplete="off" class="form-horizontal" autocomplete="off">
   <div class="modal fade" id="nuevoPlan" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog modal-lg">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Nueva Cuenta</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div id="resultados_ajax"></div>
               <input type="hidden" name="mod_idPlan1" id="mod_idPlan1">
               <div class="row">
                  <div class="form-group col-md-6">
                       <label for="padre_cuenta">Cuenta Principal *</label>
                       <div id="cargaPlanContable"></div>
                   </div>
                   <div class="form-group col-md-6">
                       <label for="codigo_cuenta">C&oacute;digo *</label>
                       <input type="text" class="form-control" id="codigo_cuenta" name="codigo_cuenta" onKeyUp="this.value=this.value.toUpperCase();" placeholder="C&oacute;digo" autofocus required>
                   </div>

                   <div class="form-group col-md-12">
                       <label for="nombre_cuenta">Nombre *</label>
                       <input type="text" class="form-control" id="nombre_cuenta" name="nombre_cuenta" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" required>
                   </div>

                   <div class="form-group col-md-6">
                       <label for="naturaleza_cuenta">Naturaleza *</label>
                       <select class="form-control" id="naturaleza_cuenta" name="naturaleza_cuenta">
                          <option value="1">DEUDORA</option>
                          <option value="2">ACREEDORA</option>
                       </select>
                   </div>

                   <div class="form-group col-md-6">
                       <label for="estado_cuenta">Estado *</label>
                       <select class="form-control" id="estado_cuenta" name="estado_cuenta">
                          <option value="1">ACTIVADO</option>
                          <option value="2">DESACTIVADO</option>
                       </select>
                   </div>
               </div>
             </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">Cancelar</button>
                 <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
             </div>
         </div>
     </div>
   </div>

</form>
<script>
  $("#codigo_cuenta").focus();
</script>