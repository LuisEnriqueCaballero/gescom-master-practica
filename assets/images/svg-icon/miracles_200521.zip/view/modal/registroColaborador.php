<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
/* Connect To Database*/
require_once "../../config/db.php";
require_once "../../config/conexion.php";
$tienda = $_SESSION['tienda'];

$user_id                = $_SESSION['usuario_id'];
//
$sql_usuario=mysqli_query($con,"select * from usuarios where usuario_id=$user_id");
$rw_usuario=mysqli_fetch_array($sql_usuario);
$usuario_accesos=$rw_usuario['usuario_accesos'];
//Validamos los accesos
$sql_acceso             = "select * from accesos where acceso_id=$usuario_accesos";
$rw1                    = mysqli_query($con,$sql_acceso);//recuperando el registro
$rs1                    = mysqli_fetch_array($rw1);//trasformar el registro en un vector asociativo
$modulo                 = $rs1["acceso_permiso"];
$a                      = explode(".", $modulo); 
?>
<form method="post" id="guardar_colaborador" name="guardar_colaborador" autocomplete="off">
   <div class="modal fade" id="nuevoColaborador" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog modal-lg">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal" style="cursor: url(../img/company/cursorH1.png), pointer;"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Nuevo Colaborador</h4>
             </div>
             <!--Modal body-->
              <div class="modal-body">
                <div id="resultados_ajax2"></div>
               <div class="row">
                  <div class="col-md-6">
                     <label for="tipo_colaborador">Tipo de documento *</label>
                     <select required id="tipo_colaborador" name="tipo_colaborador" class="form-control" onchange="getval(this);">
                        <option value="">SELECCIONAR</option>
                        <?php           
                           $tipo_cliente ="select * from sunat_tipocliente where (sunat_tipoCliente_id=2 or sunat_tipoCliente_id=3 or sunat_tipoCliente_id=5 or sunat_tipoCliente_id=6)";
                           $row          =mysqli_query($con,$tipo_cliente);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $sunat_tipoCliente_nombre = $row4["sunat_tipoCliente_nombre"];
                              $sunat_tipoCliente_id     = $row4["sunat_tipoCliente_id"];
                        ?>
                        <option value="<?php echo $sunat_tipoCliente_id;?>"><?php  echo $sunat_tipoCliente_nombre;?></option>
                        <?php } ?>
                     </select>
                  </div>
                  <div class="col-md-6">
                     <label for="documento_colaborador">Documento</label>
                     <div class="input-group mar-btm">
                          <input type="text" class="form-control" name="documento_colaborador" id="documento_colaborador" onKeyUp="this.value=this.value.toUpperCase();" autocomplete="off" placeholder="Documento" required>
                          <span class="input-group-btn">
                              <div id="tipo_boton"><div class="btn btn-primary" disabled style="cursor: url(../img/company/disabled.png), pointer;"><i class="fa fa-search"></i></div></div>
                          </span>
                      </div>
                  </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="nom_colaborador">Nombres *</label>
                       <input type="text" class="form-control" id="nom_colaborador" name="nom_colaborador" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Apellidos y nombres" required>
                   </div>
                   <div class="col-md-6">
                       <label for="domicilio_colaborador">Domicilio *</label>
                       <input type="text" class="form-control" id="domicilio_colaborador" name="domicilio_colaborador" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Domicilio" required>
                   </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="tel_colaborador">Tel&eacute;fono</label>
                       <input type="text" class="form-control" id="tel_colaborador" name="tel_colaborador" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Tel&eacute;fono">
                   </div>
                   <div class="col-md-6">
                       <label for="email_colaborador">E-Mail *</label>
                       <input type="email" class="form-control" id="email_colaborador" name="email_colaborador" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="E-Mail" required>
                   </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="sueldo_colaborador">Salario *</label>
                       <input type="text" class="form-control" id="sueldo_colaborador" name="sueldo_colaborador" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Salario" required>
                   </div>
                   <div class="col-md-6">
                       <label for="cumpleanos_colaborador">Cumplea&ntilde;os *</label>
                       
                       <div id="demo-dp-component">
                            <div class="input-group date">
                              <input type="text" class="form-control" id="cumpleanos_colaborador" name="cumpleanos_colaborador" required readonly>
                              <span class="input-group-addon"><i class="demo-pli-calendar-4"></i></span>
                            </div>
                        </div>
                   </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="horario_colaborador">Hora de ingreso *</label>
                       <div class="input-group date">
                          <input type="time" class="form-control" id="horario_colaborador" name="horario_colaborador" required>
                          <span class="input-group-addon"><i class="demo-pli-clock"></i></span>
                      </div>
                   </div>
                   <div class="col-md-6">
                       <label for="sexo_colaborador">Sexo *</label>
                       <select required id="sexo_colaborador" name="sexo_colaborador" class="form-control">
                           <option value="">SELECCIONAR</option>
                           <option value="1">MASCULINO</option>
                           <option value="2">FEMENINO</option>
                        </select>
                   </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="asingacion_colaborador">Asignaci&oacute;n familiar *</label>
                       <select required id="asingacion_colaborador" name="asingacion_colaborador" class="form-control" onchange="getAsignacion(this);">
                           <option value="1">NO</option>
                           <option value="2">S&Iacute;</option>
                        </select>
                   </div>
                   <div class="col-md-6">
                       <label for="colaborador_hijos">Hijos *</label>
                       <input type="number" class="form-control" id="colaborador_hijos" name="colaborador_hijos" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Hijos" required value="0" readonly>
                   </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                       <label for="colaborador_snpAfp">SNP/AFP *</label>
                       <select required id="colaborador_snpAfp" name="colaborador_snpAfp" class="form-control" onchange="getSAfp(this);">
                           <option value="2">AFP</option>
                           <option value="1">SNP</option>
                        </select>
                   </div>
                   <div class="col-md-6">
                      <label for="colaborador_afp">AFP *</label>
                      <div id="muestraValorAfp"></div>

                   </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                      <label for="colaborador_cargo">Cargo *</label>
                      <div class="input-group">
                          <div id="cargaCargoAjax"></div>
                          <?php if ($a[222] == 1) { ?>
                            <span class="input-group-btn">
                              <div id="tipo_boton"><div class="btn btn-primary" data-toggle='modal' data-target='#nuevoCargo'><i class="fa fa-plus"></i></div></div>
                            </span>
                          <?php } else { ?>
                            <span class="input-group-btn">
                              <div id="tipo_boton"><div class="btn btn-primary disabled"><i class="fa fa-plus"></i></div></div>
                            </span>
                          <?php } ?>
                          
                      </div>

                   </div>
                   <div class="col-md-6">
                       <label for="colaborador_fechaIngreso">Fecha Ingreso *</label>
                       <div id="demo-dp-component">
                            <div class="input-group date">
                                <input type="text" class="form-control" id="colaborador_fechaIngreso" name="colaborador_fechaIngreso" required readonly>
                                <span class="input-group-addon"><i class="demo-pli-calendar-4"></i></span>
                            </div>
                        </div>
                   </div>
               </div>
               <div class="row">
                   <div class="col-md-6">
                      <label for="colaborador_banco">Banco *</label>
                        <div class="input-group">
                         <div id="cargaBancoAjax"></div>
                          <?php if ($a[104] == 1) { ?>
                            <span class="input-group-btn">
                              <div id="tipo_boton"><div class="btn btn-primary" data-toggle='modal' data-target='#nuevoBanco'><i class="fa fa-plus"></i></div></div>
                            </span>
                          <?php } else { ?>
                            <span class="input-group-btn">
                              <div id="tipo_boton"><div class="btn btn-primary disabled"><i class="fa fa-plus"></i></div></div>
                            </span>
                          <?php } ?>
                      </div>

                   </div>
                   <div class="col-md-6">
                       <label for="colaborador_numeroCuenta">Cuenta Bancaria *</label>
                       <input type="text" class="form-control" id="colaborador_numeroCuenta" name="colaborador_numeroCuenta" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Cuenta Bancaria" required>
                   </div>
               </div>
              </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button" style="cursor: url(../img/company/cursorH1.png), pointer;">No, cancelar</button>
                 <button type="submit" class="btn btn-primary" id="guardar_datos" style="cursor: url(../img/company/cursorH1.png), pointer;">S&iacute;, continuar</button>
             </div>
         </div>
     </div>
   </div>
</form>
<script>
   function getval(sel)
  {
   if(sel.value==''){
      vt.info("Debes seleccionar un tipo de documento.", {
          duration: 5000,
          fadeDuration: 200,
          title: "Oopss!",
          position: "top-right"
      })
      $("#tipo_boton").html('<div class="btn btn-primary" disabled><i class="fa fa-search"></i></div>');
      $("#documento_colaborador").val('');
      $("#nom_colaborador").val('');
      $("#domicilio_colaborador").val('');
      $('#documento_colaborador').attr('placeholder','Documento');
      $('#nom_colaborador').attr('placeholder','Apellidos y nombres');
      $('#domicilio_colaborador').attr('placeholder','Domicilio');
      $('#domicilio_colaborador').val('');
      $('#documento_colaborador').mask('9');
   }
   if(sel.value==1){
      $("#tipo_boton").html('<div class="btn btn-primary" disabled style="cursor: url(../img/company/disabled.png), pointer;"><i class="fa fa-search"></i></div>');
      $("#documento_colaborador").val('');
      $("#nom_colaborador").val('');
      $("#domicilio_colaborador").val('');
      $('#documento_colaborador').attr('placeholder','Documento');
      $('#nom_colaborador').attr('placeholder','Apellidos y nombres');
      $('#domicilio_colaborador').attr('placeholder','Domicilio');
      $('#domicilio_colaborador').val('');
      $('#documento_colaborador').focus();
      $('#documento_colaborador').mask('999999999999999');
   }
   if(sel.value==2){
      $("#tipo_boton").html('<div id="botoncitoDNI" class="input-group-addon btn btn-white" style="border: 1px solid #666;" style="cursor: url(../img/company/cursorH1.png), pointer;"><i class="nohidden1"></i></div>');
      $("#documento_colaborador").val('');
      $("#nom_colaborador").val('');
      $("#domicilio_colaborador").val('');
      $('#documento_colaborador').attr('placeholder','DNI');
      $('#nom_colaborador').attr('placeholder','Apellidos y nombres');
      $('#domicilio_colaborador').attr('placeholder','Domicilio');
      $('#domicilio_colaborador').val('');
      $('#documento_colaborador').focus();
      $('#documento_colaborador').mask('99999999');

      $(function(){
         $('.nohidden1').html("<img src='../assets/images/svg-icon/reniec.svg' class='img-fluid' alt='settings' style='width: 17px; height: 17px;'>");
         $('#botoncitoDNI').on('click', function(){
           var documento_colaborador = $('#documento_colaborador').val();
           var url = '../ajax/consultas/reniecColaborador.php';
           $('.nohidden1').html('<img src="../assets/images/svg-icon/loading.svg" width="17px">');
           $.ajax({
             type:'POST',
             url:url,
             data:'documento_colaborador='+documento_colaborador,
             success: function(datos_dni){
               $('.nohidden1').html("<img src='../assets/images/svg-icon/reniec.svg' class='img-fluid' alt='settings' style='width: 17px; height: 17px;'>");
               $('#domicilio_colaborador').focus();
               var datos = eval(datos_dni);
               var nada ='nada';
               if(datos_dni != nada)
                {
                  $('#numero_dni').text(datos[0]);
                  $('#nom_colaborador').val(datos[1]);
                  $('#estado_del_contribuyente').val(datos[2]);
                  $('#condicion_de_domicilio').val(datos[3]);
                  $('#ubgclienteruc').val(datos[4]);
                  $('#tipo_de_via').val(datos[5]);
                  $('#nombre_de_via').val(datos[6]);
                  $('#codigo_de_zona').val(datos[7]);
                  $('#numero').val(datos[8]);
                  $('#interior').val(datos[9]);
                  $('#lote').val(datos[10]);
                  $('#dpto').val(datos[11]);
                  $('#manzana').val(datos[12]);
                  $('#kilometro').val(datos[13]);
                  $('#depclienteruc').val(datos[14]);
                  $('#proclienteruc').val(datos[15]);
                  $('#disclienteruc').val(datos[16]);
                  $('#direccion').val(datos[17]);
                  $('#direcclienteruc').val(datos[18]);
                  $('#ultima_actualizacion').val(datos[19]);
               } if(datos[24] == '  ') {
                 vt.info("No pudimos encontrar el documento.", {
                    duration: 5000,
                    fadeDuration: 200,
                    title: "Oopss!",
                    position: "top-right"
                })
                 $("#documento_colaborador").val('');
                 $("#nom_colaborador").val('');
                 $("#domicilio_colaborador").val('');
                 $('#documento_colaborador').focus();
               }  
            }
           });
         return false;
         });
      });
   }
   if(sel.value==3){
      $("#tipo_boton").html('<div class="btn btn-primary" disabled style="cursor: url(../img/company/disabled.png), pointer;"><i class="fa fa-search"></i></div>');
      $("#documento_colaborador").val('');
      $("#nom_colaborador").val('');
      $("#domicilio_colaborador").val('');
      $('#documento_colaborador').attr('placeholder','Carnet de extranjeria');
      $('#nom_colaborador').attr('placeholder','Apellidos y nombres');
      $('#domicilio_colaborador').attr('placeholder','Domicilio');
      $('#domicilio_colaborador').val('');
      $('#documento_colaborador').focus();
      $('#documento_colaborador').mask('999999999999');
   }
   if(sel.value==4){
      $("#tipo_boton").html('<div id="botoncitoRUC" class="input-group-addon btn btn-white" style="border: 1px solid #666;" style="cursor: url(../img/company/cursorH1.png), pointer;"><i class="nohidden1"></i></div>');
      $("#documento_colaborador").val('');
      $("#nom_colaborador").val('');
      $("#domicilio_colaborador").val('');
      $('#documento_colaborador').attr('placeholder','RUC');
      $('#nom_colaborador').attr('placeholder','Razon Social');
      $('#domicilio_colaborador').attr('placeholder','Domicilio');
      $('#domicilio_colaborador').val('');
      $('#documento_colaborador').focus();
      $('#documento_colaborador').mask('99999999999');

      $(function(){
         $('.nohidden1').html("<img src='../assets/images/svg-icon/sunat.svg' class='img-fluid' alt='settings' style='width: 17px; height: 17px;'>");
         $('#botoncitoRUC').on('click', function(){
           var documento_colaborador = $('#documento_colaborador').val();
           var url = '../ajax/consultas/sunatColaborador.php';
           $('.nohidden1').html('<img src="../assets/images/svg-icon/loading.svg" width="17px">');
           $.ajax({
             type:'POST',
             url:url,
             data:'documento_colaborador='+documento_colaborador,
             success: function(datos_ruc){
               $('.nohidden1').html("<img src='../assets/images/svg-icon/sunat.svg' class='img-fluid' alt='settings' style='width: 17px; height: 17px;'>");
               var datos = eval(datos_ruc);
               var datos = eval(datos_ruc);
               var nada ='nada';
               if(datos_ruc != nada){
                 $('#numero_ruc').text(datos[0]);
                 $('#nom_colaborador').val(datos[1]);
                 $('#estado_del_contribuyente').val(datos[2]);
                 $('#condicion_de_domicilio').val(datos[3]);
                 $('#ubgclienteruc').val(datos[4]);
                 $('#tipo_de_via').val(datos[5]);
                 $('#nombre_de_via').val(datos[6]);
                 $('#codigo_de_zona').val(datos[7]);
                 $('#numero').val(datos[8]);
                 $('#interior').val(datos[9]);
                 $('#lote').val(datos[10]);
                 $('#dpto').val(datos[11]);
                 $('#manzana').val(datos[12]);
                 $('#kilometro').val(datos[13]);
                 if (datos[14] == '') {
                    $('#domicilio_colaborador').focus();
                 }
                 if (datos[14] != '') {
                    $('#tel_colaborador').focus();
                 }
                 $('#depclienteruc').val(datos[14]);
                 $('#proclienteruc').val(datos[15]);
                 $('#disclienteruc').val(datos[16]);
                 $('#domicilio_colaborador').val(datos[17]);
                 $('#direcclienteruc').val(datos[18]);
                 $('#ultima_actualizacion').val(datos[19]);
               } if(datos[0] == ''){
                 //alert('RUC no válido o no registrado');
                 vt.info("No pudimos encontrar el documento.", {
                    duration: 5000,
                    fadeDuration: 200,
                    title: "Oopss!",
                    position: "top-right"
                })
                 $("#documento_colaborador").val('');
                 $('#documento_colaborador').focus();
               }    
             }
           });
           return false;
         });
       });
   }
   if(sel.value==5){
      $("#tipo_boton").html('<div class="btn btn-primary" disabled style="cursor: url(../img/company/disabled.png), pointer;"><i class="fa fa-search"></i></div>');
      $("#documento_colaborador").val('');
      $("#nom_colaborador").val('');
      $("#domicilio_colaborador").val('');
      $('#documento_colaborador').attr('placeholder','Pasaporte');
      $('#nom_colaborador').attr('placeholder','Apellidos y nombres');
      $('#domicilio_colaborador').attr('placeholder','Domicilio');
      $('#domicilio_colaborador').val('');
      $('#documento_colaborador').focus();
      $('#documento_colaborador').mask('999999999999');
   }
   if(sel.value==6){
      $("#tipo_boton").html('<div class="btn btn-primary" disabled><i class="fa fa-search"></i></div>');
      $("#documento_colaborador").val('');
      $("#nom_colaborador").val('');
      $("#domicilio_colaborador").val('');
      $('#documento_colaborador').attr('placeholder','Cedula');
      $('#nom_colaborador').attr('placeholder','Apellidos y nombres');
      $('#domicilio_colaborador').attr('placeholder','Domicilio');
      $('#domicilio_colaborador').val('');
      $('#documento_colaborador').focus();
      $('#documento_colaborador').mask('999999999999999');
   }
  }
</script>
<script>
function getAsignacion(selAsig)
{
  if(selAsig.value==1){
    $("#colaborador_hijos").attr('readonly',true);
    $("#colaborador_hijos").val('0');
  }
  if(selAsig.value==2){
    $("#colaborador_hijos").attr('readonly',false);
  }
}
</script>
<script>
function getSAfp(selSA)
{
  if(selSA.value==2){
    $("#muestraValorAfp").load('../ajax/ajaxAfp.php');
    //console.log(selSA.value);
  }
  if(selSA.value==1){
    $("#muestraValorAfp").load('../ajax/ajaxAfp1.php');
    //console.log(selSA.value);
  }
}
</script>
<!-- Seleccionamos la fecha de nacimiento -->
<script>
$(function() {
  $('#cumpleanos_colaborador').daterangepicker({
    singleDatePicker: true,
    showDropdowns: true,
    minYear: 1901,
    buttonClasses: ['btn', 'btn-sm'],
    applyClass: 'btn-primary',
    cancelClass: 'btn-danger',
    locale: {
      format: "DD/MM/YYYY",
      separator: " - ",
      applyLabel: "Aplicar",
      cancelLabel: "Cancelar",
      fromLabel: "Desde",
      toLabel: "Hasta",
      customRangeLabel: "Personalizado",
      daysOfWeek: [
      "Do",
      "Lu",
      "Ma",
      "Mi",
      "Ju",
      "Vi",
      "Sa"
      ],
      monthNames: [
      "Enero",
      "Febrero",
      "Marzo",
      "Abril",
      "Mayo",
      "Junio",
      "Julio",
      "Agosto",
      "Septiembre",
      "Octubre",
      "Noviembre",
      "Diciembre"
      ],
    },
    maxYear: parseInt(moment().format('YYYY'),10)
  }, function(start, end, label) {
    var years = moment().diff(start, 'years');
    vt.info("El colaborador tiene "+ years +" de edad.", {
        duration: 2000,
        fadeDuration: 200,
        title: "Excelente!",
        position: "top-center"
    })
  });
});
</script>
<!-- Seleccionamos la fecha de ingreso -->
<script>
$(function() {
  $('#colaborador_fechaIngreso').daterangepicker({
    singleDatePicker: true,
    showDropdowns: true,
    minYear: 1901,
    buttonClasses: ['btn', 'btn-sm'],
    applyClass: 'btn-primary',
    cancelClass: 'btn-danger',
    locale: {
      format: "DD/MM/YYYY",
      separator: " - ",
      applyLabel: "Aplicar",
      cancelLabel: "Cancelar",
      fromLabel: "Desde",
      toLabel: "Hasta",
      customRangeLabel: "Personalizado",
      daysOfWeek: [
      "Do",
      "Lu",
      "Ma",
      "Mi",
      "Ju",
      "Vi",
      "Sa"
      ],
      monthNames: [
      "Enero",
      "Febrero",
      "Marzo",
      "Abril",
      "Mayo",
      "Junio",
      "Julio",
      "Agosto",
      "Septiembre",
      "Octubre",
      "Noviembre",
      "Diciembre"
      ],
    },
    maxYear: parseInt(moment().format('YYYY'),10)
  }, function(start, end, label) {
    var years = moment().diff(label, 'years');
  });
});
</script>
<script>
$('#documento_colaborador').mask('9');
</script>