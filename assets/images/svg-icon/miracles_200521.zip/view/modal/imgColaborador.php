<div class="modal fade" id="imgColaborador" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
     <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
            <h4 class="modal-title">Cargar Foto</h4>
        </div>
        <div class="modal-body">
        	<div id="load_img_mod"></div>
			<div class="outer_img"></div>
        </div>
     </div>
  </div>
</div>