<form class="form-horizontal"  method="post" name="guardar_prestamo" id="guardar_prestamo" autocomplete="off">
   <div class="modal fade" id="nuevoPrestamo" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
          <div id="resultados_ajax"></div>
            <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Agregar Gasto</h4>
             </div>
            <div class="modal-body">
              <div class="form-group col-md-12">
                    <label for="prestamo_moneda" class="control-label">Moneda:</label>
                    <select class="form-control" required id="prestamo_moneda" name="prestamo_moneda">
                      <option value="">-- Selecciona Moneda --</option>
                      <option value="115">SOLES</option>
                      <option value="151">D&Oacute;LARES</option>
                    </select>
               </div>
               <div class="form-group col-md-12">
                    <label for="prestamo_monto" class="control-label">Monto:</label>
                    <input type="text" class="form-control" id="prestamo_monto" name="prestamo_monto" autocomplete="off" pattern="^[0-9]{1,5}(\.[0-9]{0,2})?$" title="Ingresa sólo números con 0 ó 2 decimales" maxlength="8" required autofocus>
               </div>
               <div class="form-group col-md-12">
                     <label for="prestamo_concepto" class="control-label">En Concepto de:</label>
                  <input type="text" class="form-control UpperCase" id="prestamo_concepto" name="prestamo_concepto" autocomplete="off" required onKeyUp="this.value=this.value.toUpperCase();">
               </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
              <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>