  <form class="form-horizontal"  method="post" name="add_abono" id="add_abono" autocomplete="off">
   <div class="modal fade" id="add-stock" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
          <div id="resultados_ajax"></div>
            <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Agregar Movimiento</h4>
             </div>
            <div class="modal-body">
              <div class="form-group col-md-12">
                    <label for="movimiento_tipoOperacion" class="control-label">Tipo:</label>
                    <select class="form-control" required id="movimiento_tipoOperacion" name="movimiento_tipoOperacion">
                      <option value="">-- Selecciona tipo --</option>
                      <option value="1">Entrada</option>
                      <option value="2">Salida</option>
                    </select>
               </div>
               <div class="form-group col-md-12">
                    <input type="hidden" name="mod_id" id="mod_id">
                    <label for="movimiento_monto" class="control-label">Abono:</label>
                    <input type="text" class="form-control" id="movimiento_monto" name="movimiento_monto" autocomplete="off" pattern="^[0-9]{1,5}(\.[0-9]{0,2})?$" title="Ingresa sólo números con 0 ó 2 decimales" maxlength="8" required autofocus>
               </div>
               <div class="form-group col-md-12">
                     <label for="movimiento_concepto" class="control-label">En Concepto de:</label>
                  <input type="text" class="form-control UpperCase" id="movimiento_concepto" name="movimiento_concepto" autocomplete="off" required>
               </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
              <button type="submit" class="btn btn-primary" id="actualizar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>