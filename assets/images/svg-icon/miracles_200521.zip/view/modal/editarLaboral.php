<form method="post" id="editar_variable" name="editar_variable" autocomplete="off" class="form-horizontal" autocomplete="off">
   <div class="modal fade" id="editarVariable" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Editar Variable</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div id="resultados_ajax2"></div>
               <input type="hidden" name="mod_idVariable" id="mod_idVariable">
               <div class="row">
                   <div class="col-md-6">
                       <label for="mod_codigo">C&oacute;digo *</label>
                       <input type="text" class="form-control" id="mod_codigo" name="mod_codigo" onKeyUp="this.value=this.value.toUpperCase();" placeholder="C&oacute;digo" autofocus required>
                   </div>
                   <div class="col-md-6">
                       <label for="mod_color">Color *</label>
                       <input type="color" class="form-control" id="mod_color" name="mod_color" required>
                   </div>
                   <div class="col-md-12">
                       <label for="mod_nombre">Nombre *</label>
                       <input type="text" class="form-control" id="mod_nombre" name="mod_nombre" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" required>
                   </div>
                   <div class="col-md-12">
                       <label for="mod_descripcion">Descripci&oacute;n *</label>
                       <input type="text" class="form-control" id="mod_descripcion" name="mod_descripcion" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Descripci&oacute;n" autofocus required>
                   </div>
                 </div>
             </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">Cancelar</button>
                 <button type="submit" class="btn btn-primary" id="actualizar_datos">Aceptar</button>
             </div>
         </div>
     </div>
   </div>
</form>