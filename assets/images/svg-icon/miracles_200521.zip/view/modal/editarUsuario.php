<?php
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
/* Connect To Database*/
//session_start();
require_once "../../config/db.php"; //Contiene las variables de configuracion para conectar a la base de datos
require_once "../../config/conexion.php"; //Contiene funcion que conecta a la base de datos
$tienda = $_SESSION['tienda'];
$empresa = $_SESSION['datosEmpresa_id'];
?>
<form method="post" id="editar_usuario" name="editar_usuario" autocomplete="off" class="form-horizontal">

   <div class="modal fade" id="editarUsuario" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
              <h4 class="modal-title">Editar Usuario</h4>
            </div>
            <div class="modal-body">
              <div id="resultados_ajax2"></div>
              <input type="hidden" name="mod_idUsuario" id="mod_idUsuario">
              <input type="hidden" name="mod_idUsuarioColaborador" id="mod_idUsuarioColaborador">
              <div class="row">
                  <div class="form-group col-sm-12">
                     <label for="mod_user_name">Usuario *</label>
                     <input type="text" class="form-control" id="mod_user_name" name="mod_user_name" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Usuario" required onBlur="validaUsuario()">
                     <span id="estadousuario1"></span> 
                  </div>
                  <p><img src="../img/company/LoaderIcon.gif" style="width: 22px; display:none;" id="loaderIcon1" /></p>
               </div>
               <!--<div class="row">
                  <div class="form-group col-sm-12">
                     <label for="mod_user_password_new">Contrase&ntilde;a</label>
                    <input type="password" class="form-control" id="mod_user_password_new" name="mod_user_password_new" placeholder="Contrase&ntilde;a" onKeyUp="this.value=this.value.toUpperCase();" onBlur="validaContrasena();">
                  </div>
               </div>
               <div class="row">
                  <div class="form-group col-sm-12">
                     <label for="mod_user_password_repeat">Repite Contrase&ntilde;a</label>
                    <input type="password" class="form-control" id="mod_user_password_repeat" name="mod_user_password_repeat" placeholder="Repite contrase&ntilde;a" onKeyUp="this.value=this.value.toUpperCase();" readonly>
                  </div>
               </div>-->
               <div class="row">
                  <div class="form-group col-sm-12">
                     <label for="mod_usuario_persmiso">Permiso *</label>
                    <select name="mod_usuario_persmiso" id="mod_usuario_persmiso" class="form-control" style="width: 100%; text-align: left;" required>
                        <option>-- Selecciona Acceso --</option>
                        <?php
                           $sql_segmento ="select * from accesos where acceso_sucursal='$tienda' order by acceso_id asc";
                           $row          =mysqli_query($con,$sql_segmento);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $acceso_nombre = $row4["acceso_nombre"];
                              $acceso_id     = $row4["acceso_id"];
                        ?>
                        <option value="<?php echo $acceso_id;?>"><?php  echo $acceso_nombre;?></option>

                        <?php } ?>
                    </select>
                  </div>
               </div>
               <div class="row">
                  <div class="form-group col-sm-12">
                     <label for="mod_usuario_establecimiento">Establecimiento *</label>
                    <select name="mod_usuario_establecimiento" id="mod_usuario_establecimiento" class="form-control" style="width: 100%; text-align: left;">
                        <?php 
                           $sql_segmento ="select * from sucursales where sucursal_idEmpresa='$empresa' and sucursal_activo='1' and sucursal_tienda='$tienda' order by sucursal_tienda asc";
                           $row          =mysqli_query($con,$sql_segmento);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $sucursal_nombre = $row4["sucursal_nombre"];
                              $sucursal_tienda     = $row4["sucursal_tienda"];
                        ?>
                        <option value="<?php echo $sucursal_tienda;?>"><?php  echo $sucursal_nombre;?></option>

                        <?php } ?>
                        <option value="0">TODAS</option>
                    </select>
                  </div>
               </div>
                  
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="actualizar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>