<?php
$sex = $_SESSION['usuario_sexo'];
if ($sex==1) {
   $sexo = "o";
}
if ($sex==2) {
   $sexo = "a";
}
?>	
	<form id="cambiar1">
		<div class="modal fade" id="cambio1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			            <h5 class="modal-title" id="myModalLabel"><font color="black">¿Estas segur<?php echo $sexo; ?>?</font></h5>
					</div>
					<div class="modal-body">
						<input type="hidden" id="id_nota" name="id_nota">
						<p>Se marcará la nota como realizada. ¿Deseas continuar?</p>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancelar</button>
						<button type="submit" class="btn btn-danger waves-effect waves-light">Aceptar</button>
					</div>
				</div>
			</div>
		</div>
	</form>