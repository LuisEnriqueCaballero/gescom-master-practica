<form method="post" id="guardar_pago" name="guardar_pago" autocomplete="off" class="form-horizontal">
   <div class="modal fade" id="nuevoPago" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title" id="exampleModalCenterTitle">Nuevo Pago</h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <div class="modal-body">
              <div id="resultados_ajax"></div>
               <div class="form-group row">
                  <div class="col-sm-6">
                     <select class="form-control" onchange="cambiaDatos(this);">
                        <option value="">SELECCIONAR</option>
                        <?php
                           $tienda = $_SESSION['tienda'];

                           $tipo_cliente ="select * from colaboradores where colaborador_sucursal='$tienda' and colaborador_nombres!='ADMINISTRADOR'";
                           $row          =mysqli_query($con,$tipo_cliente);
                           while ($row4 = mysqli_fetch_array($row)) {
                              $colaborador_nombres = $row4["colaborador_nombres"];
                              $colaborador_id     = $row4["colaborador_id"];
                        ?>
                        <option value="<?php echo $colaborador_id;?>"><?php  echo $colaborador_nombres;?></option>
                        <?php } ?>
                     </select>
                  </div>
                  <div class="col-sm-6">
                     <div style="margin-top: -7px;">
                         <div id="cargaSalario" style="margin-top: -12px;"><label id="muestraSalario"><b>Salario:</b> --</label><br></div>
                         <div id="cargaAsignacion" style="margin-top: -12px;"><label id="muestrAsignacion"><b>Asignaci&oacute;n Familiar:</b> --</label><br></div>
                         <div id="cargaCargo" style="margin-top: -12px;"><label id="muestraCargo"><b>Cargo:</b> --</label></div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>
<script>
   $("#banco_nombre").focus();
</script>
<script>
function cambiaDatos(sel)
{
  if(sel.value==2){
    //toastr.error("Hijos","Oopss!");
    $("#cargaSalario").html('<div id="muestraAfp"><select required id="afp" name="afp" class="form-control"><option value="">SELECCIONAR</option><?php $tipo_afp ="select * from afp";$row_afp          =mysqli_query($con,$tipo_afp);while ($row1_afp = mysqli_fetch_array($row_afp)) {$afp_nombre = $row1_afp["afp_nombre"];$afp_id     = $row1_afp["afp_id"];?><option value="<?php echo $afp_id;?>"><?php  echo $afp_nombre;?></option><?php } ?></select></div>');
  }
  if(sel.value==1){
    //toastr.error("Hijos","Oopss!");
    $("#muestraAfp").html('<div id="muestraAfp"><select class="form-control" disabled><option value="0">SELECCIONAR</option><input type="hidden" id="afp" name="afp" value="0"></div>');
  }
}
</script>