<?php 
$empresa  = $_SESSION['datosEmpresa_id'];
//Validamos el rubro
$sql_rubro              = "select * from datosempresa where datosEmpresa_id=$empresa";
$rw_rubro               = mysqli_query($con,$sql_rubro);//recuperando el registro
$rs_rubro               = mysqli_fetch_array($rw_rubro);//trasformar el registro en un vector asociativo
$modulo_rubro           = $rs_rubro["datosEmpresa_rubro"];
$rubro                  = explode(".", $modulo_rubro); 
?>
<form method="post" id="editar_permisos" name="editar_permisos" autocomplete="off">
   <div class="modal fade" id="editarAcceso" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="display: none;">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                <h4 class="modal-title">Editar Grupo</h4>
            </div>
            <div class="modal-body">
              <input type="hidden" name="mod_idAcceso" id="mod_idAcceso">
              
                <div class="form-group row">
                  <div class="col-sm-12">
                     <label for="mod_nombres" class="control-label">Nombre:</label>
                  <input type="text" class="form-control UpperCase" id="mod_nombres" name="mod_nombres" autocomplete="off" required placeholder="Nombre del grupo de acceso" onKeyUp="this.value=this.value.toUpperCase();">
                  </div>
                </div>

              <div class="css-treeview">
                <ul>
                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-inicio" name="a1" value="1"/><label for="mod_item-inicio">&nbsp;&nbsp;&nbsp;&nbsp;Inicio</label></li>
                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-tpv" name="a2" value="1"/><label for="mod_item-tpv">&nbsp;&nbsp;&nbsp;&nbsp;TPV</label></li>
                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-notas" name="a3" value="1"/><label for="mod_item-notas">&nbsp;&nbsp;&nbsp;&nbsp;Notas</label></li>
                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-anuncios" name="a4" value="1"/><label for="mod_item-anuncios">&nbsp;&nbsp;&nbsp;&nbsp;Anuncios</label></li>
                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-calendario" name="a5" value="1"/><label for="mod_item-calendario">&nbsp;&nbsp;&nbsp;&nbsp;Calendario</label></li>
                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-archivos" name="a6" value="1"/><label for="mod_item-archivos">&nbsp;&nbsp;&nbsp;&nbsp;Archivos</label></li>
                    <li><input type="checkbox" id="mod_item-caja" style="position: absolute; opacity: 0;"/><label for="mod_item-caja">Caja</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-caja-actual" style="position: absolute; opacity: 0;"/><label for="mod_item-caja-actual">Administrar Caja</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-caja-actual-aperturar" name="a7" value="1"/><label for="mod_item-caja-actual-aperturar">&nbsp;&nbsp;&nbsp;&nbsp;Aperturar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-caja-actual-cerrar" name="a8" value="1"/><label for="mod_item-caja-actual-cerrar">&nbsp;&nbsp;&nbsp;&nbsp;Cerrar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-caja-movimientos" style="position: absolute; opacity: 0;"/><label for="mod_item-caja-movimientos">Hist&oacute;rico Caja</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-caja-movimientos-pdf" name="a9" value="1"/><label for="mod_item-caja-movimientos-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-caja-movimientos-excel" name="a10" value="1"/><label for="mod_item-caja-movimientos-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-caja-movimientos-cerrarCajas" name="a230" value="1"/><label for="mod_item-caja-movimientos-cerrarCajas">&nbsp;&nbsp;&nbsp;&nbsp;Cerrar Cajas</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-personas" style="position: absolute; opacity: 0;"/><label for="mod_item-personas">Personas</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-personas-clientes" style="position: absolute; opacity: 0;"/><label for="mod_item-personas-clientes">Clientes</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-clientes-ver" name="a11" value="1"/><label for="mod_item-personas-clientes-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-clientes-agregar" name="a12" value="1"/><label for="mod_item-personas-clientes-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-clientes-editar" name="a13" value="1"/><label for="mod_item-personas-clientes-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-clientes-eliminar" name="a14" value="1"/><label for="mod_item-personas-clientes-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-personas-proveedores" style="position: absolute; opacity: 0;"/><label for="mod_item-personas-proveedores">Proveedores</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-proveedores-ver" name="a15" value="1"/><label for="mod_item-personas-proveedores-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-proveedores-agregar" name="a16" value="1"/><label for="mod_item-personas-proveedores-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-proveedores-editar" name="a17" value="1"/><label for="mod_item-personas-proveedores-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-proveedores-eliminar" name="a18" value="1"/><label for="mod_item-personas-proveedores-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-personas-colaboradores" style="position: absolute; opacity: 0;"/><label for="mod_item-personas-colaboradores">Colaboradores</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-colaboradores-ver" name="a19" value="1"/><label for="mod_item-personas-colaboradores-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-colaboradores-agregar" name="a20" value="1"/><label for="mod_item-personas-colaboradores-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-colaboradores-editar" name="a21" value="1"/><label for="mod_item-personas-colaboradores-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-colaboradores-usuario" name="a22" value="1"/><label for="mod_item-personas-colaboradores-usuario">&nbsp;&nbsp;&nbsp;&nbsp;Crear Usuario</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-colaboradores-foto" name="a23" value="1"/><label for="mod_item-personas-colaboradores-foto">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Foto</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-colaboradores-firma" name="a23" value="1"/><label for="mod_item-personas-colaboradores-firma">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Firma</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-personas-colaboradores-eliminar" name="a24" value="1"/><label for="mod_item-personas-colaboradores-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <?php if ($rubro[3]==1) { ?>
                    <li><input type="checkbox" id="mod_item-clinica" style="position: absolute; opacity: 0;"/><label for="mod_item-clinica">Cl&iacute;nica</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-clinica-admision" style="position: absolute; opacity: 0;"/><label for="mod_item-clinica-admision">Admisi&oacute;n</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-admision-ver" name="a232" value="1"/><label for="mod_item-clinica-admision-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-admision-agregar" name="a233" value="1"/><label for="mod_item-clinica-admision-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-clinica-topico" style="position: absolute; opacity: 0;"/><label for="mod_item-clinica-topico">T&oacute;pico</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-topico-ver" name="a234" value="1"/><label for="mod_item-clinica-topico-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-topico-agregar" name="a235" value="1"/><label for="mod_item-clinica-topico-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-clinica-historias" style="position: absolute; opacity: 0;"/><label for="mod_item-clinica-historias">Historias</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-historias-ver" name="a236" value="1"/><label for="mod_item-clinica-historias-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-historias-agregar" name="a237" value="1"/><label for="mod_item-clinica-historias-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Imprimir</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-historias-editar" name="a238" value="1"/><label for="mod_item-clinica-historias-editar">&nbsp;&nbsp;&nbsp;&nbsp;Facturar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-clinica-especialidades" style="position: absolute; opacity: 0;"/><label for="mod_item-clinica-especialidades">Especialidades</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-especialidades-ver" name="a239" value="1"/><label for="mod_item-clinica-especialidades-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-especialidades-agregar" name="a240" value="1"/><label for="mod_item-clinica-especialidades-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-especialidades-editar" name="a241" value="1"/><label for="mod_item-clinica-especialidades-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-especialidades-eliminar" name="a242" value="1"/><label for="mod_item-clinica-especialidades-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-clinica-medicos" style="position: absolute; opacity: 0;"/><label for="mod_item-clinica-medicos">M&eacute;dicos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-medicos-ver" name="a243" value="1"/><label for="mod_item-clinica-medicos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-medicos-agregar" name="a244" value="1"/><label for="mod_item-clinica-medicos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-medicos-editar" name="a245" value="1"/><label for="mod_item-clinica-medicos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-medicos-eliminar" name="a246" value="1"/><label for="mod_item-clinica-medicos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-clinica-atencion" style="position: absolute; opacity: 0;"/><label for="mod_item-clinica-atencion">Atenci&oacute;n</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-atencion-ver" name="a247" value="1"/><label for="mod_item-clinica-atencion-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-clinica-atencion-agregar" name="a248" value="1"/><label for="mod_item-clinica-atencion-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Atender</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <?php } ?>
                    <li><input type="checkbox" id="mod_item-marketing" style="position: absolute; opacity: 0;"/><label for="mod_item-marketing">Marketing</label>
                        <ul>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-marketing-email" name="a25" value="1"/><label for="mod_item-marketing-email">&nbsp;&nbsp;&nbsp;&nbsp;Email</label></li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-marketing-whatsapp" name="a26" value="1"/><label for="mod_item-marketing-whatsapp">&nbsp;&nbsp;&nbsp;&nbsp;WhatsApp</label></li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-articulos" style="position: absolute; opacity: 0;"/><label for="mod_item-articulos">Art&iacute;culos</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-articulos-marcas" style="position: absolute; opacity: 0;"/><label for="mod_item-articulos-marcas">Marcas</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-marcas-ver" name="a27" value="1"/><label for="mod_item-articulos-marcas-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-marcas-agregar" name="a28" value="1"/><label for="mod_item-articulos-marcas-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-marcas-editar" name="a29" value="1"/><label for="mod_item-articulos-marcas-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-marcas-eliminar" name="a30" value="1"/><label for="mod_item-articulos-marcas-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-articulos-categorias" style="position: absolute; opacity: 0;"/><label for="mod_item-articulos-categorias">Categor&iacute;as</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-categorias-ver" name="a31" value="1"/><label for="mod_item-articulos-categorias-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-categorias-agregar" name="a32" value="1"/><label for="mod_item-articulos-categorias-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-categorias-editar" name="a33" value="1"/><label for="mod_item-articulos-categorias-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-categorias-eliminar" name="a34" value="1"/><label for="mod_item-articulos-categorias-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-articulos-mod_items" style="position: absolute; opacity: 0;"/><label for="mod_item-articulos-mod_items">&Iacute;tems</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-mod_items-ver" name="a35" value="1"/><label for="mod_item-articulos-mod_items-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-mod_items-agregar" name="a36" value="1"/><label for="mod_item-articulos-mod_items-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-mod_items-editar" name="a37" value="1"/><label for="mod_item-articulos-mod_items-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-mod_items-eliminar" name="a38" value="1"/><label for="mod_item-articulos-mod_items-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-mod_items-foto" name="a39" value="1"/><label for="mod_item-articulos-mod_items-foto">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Foto</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-mod_items-especificaciones" name="a40" value="1"/><label for="mod_item-articulos-mod_items-especificaciones">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Especificaciones</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-mod_items-ficha" name="a41" value="1"/><label for="mod_item-articulos-mod_items-ficha">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Ficha T&eacute;cnica</label></li>
                                </ul>
                            </li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-kardex" name="a42" value="1"/><label for="mod_item-articulos-kardex">&nbsp;&nbsp;&nbsp;&nbsp;Kardex</label></li>
                            <li><input type="checkbox" id="mod_item-articulos-traslados" style="position: absolute; opacity: 0;"/><label for="mod_item-articulos-traslados">Traslados</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-traslados-ver" name="a43" value="1"/><label for="mod_item-articulos-traslados-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-traslados-agregar" name="a44" value="1"/><label for="mod_item-articulos-traslados-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-articulos-ajustes" style="position: absolute; opacity: 0;"/><label for="mod_item-articulos-ajustes">Ajustes</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-ajustes-ver" name="a45" value="1"/><label for="mod_item-articulos-ajustes-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-ajustes-agregar" name="a46" value="1"/><label for="mod_item-articulos-ajustes-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar Stock</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-articulos-ajustes-eliminar" name="a47" value="1"/><label for="mod_item-articulos-ajustes-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Quitar Stock</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-ventas" style="position: absolute; opacity: 0;"/><label for="mod_item-ventas">Ventas</label>
                        <ul>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-nboleta" name="a48" value="1"/><label for="mod_item-ventas-nboleta">&nbsp;&nbsp;&nbsp;&nbsp;Nueva Boleta</label></li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-nfactura" name="a49" value="1"/><label for="mod_item-ventas-nfactura">&nbsp;&nbsp;&nbsp;&nbsp;Nueva Factura</label></li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-npedido" name="a50" value="1"/><label for="mod_item-ventas-npedido">&nbsp;&nbsp;&nbsp;&nbsp;Nuevo Pedido</label></li>
                            <li><input type="checkbox" id="mod_item-ventas-documentos" style="position: absolute; opacity: 0;"/><label for="mod_item-ventas-documentos">Historial Documentos</label>
                                <ul>
                                    <li><input type="checkbox" id="mod_item-ventas-documentos-boletas" style="position: absolute; opacity: 0;"/><label for="mod_item-ventas-documentos-boletas">Boletas</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-boletas-ver" name="a51" value="1"/><label for="mod_item-ventas-documentos-boletas-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-boletas-anular" name="a52" value="1"/><label for="mod_item-ventas-documentos-boletas-anular">&nbsp;&nbsp;&nbsp;&nbsp;Anular</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-boletas-pdf" name="a53" value="1"/><label for="mod_item-ventas-documentos-boletas-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-boletas-excel" name="a54" value="1"/><label for="mod_item-ventas-documentos-boletas-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                        </ul>
                                    </li>
                                    <li><input type="checkbox" id="mod_item-ventas-documentos-facturas" style="position: absolute; opacity: 0;"/><label for="mod_item-ventas-documentos-facturas">Facturas</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-facturas-ver" name="a55" value="1"/><label for="mod_item-ventas-documentos-facturas-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-facturas-anular" name="a56" value="1"/><label for="mod_item-ventas-documentos-facturas-anular">&nbsp;&nbsp;&nbsp;&nbsp;Anular</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-facturas-pdf" name="a57" value="1"/><label for="mod_item-ventas-documentos-facturas-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-facturas-excel" name="a58" value="1"/><label for="mod_item-ventas-documentos-facturas-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                        </ul>
                                    </li>
                                    <li><input type="checkbox" id="mod_item-ventas-documentos-nCreditos" style="position: absolute; opacity: 0;"/><label for="mod_item-ventas-documentos-nCreditos">N. Cr&eacute;ditos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nCreditos-ver" name="a59" value="1"/><label for="mod_item-ventas-documentos-nCreditos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nCreditos-pdf" name="a60" value="1"/><label for="mod_item-ventas-documentos-nCreditos-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nCreditos-excel" name="a61" value="1"/><label for="mod_item-ventas-documentos-nCreditos-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                        </ul>
                                    </li>
                                    <li><input type="checkbox" id="mod_item-ventas-documentos-nDebitos" style="position: absolute; opacity: 0;"/><label for="mod_item-ventas-documentos-nDebitos">N. D&eacute;bitos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nDebitos-ver" name="a62" value="1"/><label for="mod_item-ventas-documentos-nDebitos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nDebitos-pdf" name="a63" value="1"/><label for="mod_item-ventas-documentos-nDebitos-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nDebitos-excel" name="a64" value="1"/><label for="mod_item-ventas-documentos-nDebitos-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                        </ul>
                                    </li>
                                    <li><input type="checkbox" id="mod_item-ventas-documentos-nPedidos" style="position: absolute; opacity: 0;"/><label for="mod_item-ventas-documentos-nPedidos">N. Pedidos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nPedidos-ver" name="a65" value="1"/><label for="mod_item-ventas-documentos-nPedidos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nPedidos-facturar" name="a66" value="1"/><label for="mod_item-ventas-documentos-nPedidos-facturar">&nbsp;&nbsp;&nbsp;&nbsp;Facturar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nPedidos-anular" name="a67" value="1"/><label for="mod_item-ventas-documentos-nPedidos-anular">&nbsp;&nbsp;&nbsp;&nbsp;Anular</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nPedidos-pdf" name="a68" value="1"/><label for="mod_item-ventas-documentos-nPedidos-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ventas-documentos-nPedidos-excel" name="a69" value="1"/><label for="mod_item-ventas-documentos-nPedidos-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-cotizaciones" style="position: absolute; opacity: 0;"/><label for="mod_item-cotizaciones">Cotizaciones</label>
                        <ul>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-cotizaciones-nCotizacion" name="a70" value="1"/><label for="mod_item-cotizaciones-nCotizacion">&nbsp;&nbsp;&nbsp;&nbsp;Nueva Cotizaci&oacute;n</label></li>
                            <li><input type="checkbox" id="mod_item-cotizaciones-cotizaciones" style="position: absolute; opacity: 0;"/><label for="mod_item-cotizaciones-cotizaciones">Historial Cotizaciones</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-cotizaciones-cotizaciones-ver" name="a71" value="1"/><label for="mod_item-cotizaciones-cotizaciones-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-cotizaciones-cotizaciones-facturar" name="a72" value="1"/><label for="mod_item-cotizaciones-cotizaciones-facturar">&nbsp;&nbsp;&nbsp;&nbsp;Facturar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-cotizaciones-cotizaciones-anular" name="a73" value="1"/><label for="mod_item-cotizaciones-cotizaciones-anular">&nbsp;&nbsp;&nbsp;&nbsp;Anular</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-cotizaciones-cotizaciones-pdf" name="a74" value="1"/><label for="mod_item-cotizaciones-cotizaciones-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-cotizaciones-cotizaciones-excel" name="a75" value="1"/><label for="mod_item-cotizaciones-cotizaciones-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-egresos" style="position: absolute; opacity: 0;"/><label for="mod_item-egresos">Egresos</label>
                        <ul>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-nCompra" name="a76" value="1"/><label for="mod_item-egresos-nCompra">&nbsp;&nbsp;&nbsp;&nbsp;Nueva Compra</label></li>
                            <li><input type="checkbox" id="mod_item-egresos-compras" style="position: absolute; opacity: 0;"/><label for="mod_item-egresos-compras">Historial Compras</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-compras-ver" name="a77" value="1"/><label for="mod_item-egresos-compras-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-compras-anular" name="a78" value="1"/><label for="mod_item-egresos-compras-anular">&nbsp;&nbsp;&nbsp;&nbsp;Anular</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-compras-pdf" name="a79" value="1"/><label for="mod_item-egresos-compras-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-compras-excel" name="a80" value="1"/><label for="mod_item-egresos-compras-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                </ul>
                            </li>
                            <!--<li><input type="checkbox" id="mod_item-egresos-categorias" style="position: absolute; opacity: 0;"/><label for="mod_item-egresos-categorias">Categor&iacute;a Gastos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-categorias-ver" name="a81" value="1"/><label for="mod_item-egresos-categorias-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-categorias-agregar" name="a82" value="1"/><label for="mod_item-egresos-categorias-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-categorias-editar" name="a83" value="1"/><label for="mod_item-egresos-categorias-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-categorias-eliminar" name="a84" value="1"/><label for="mod_item-egresos-categorias-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>-->
                            <li><input type="checkbox" id="mod_item-egresos-gastos" style="position: absolute; opacity: 0;"/><label for="mod_item-egresos-gastos">Historial Gastos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-gastos-ver" name="a85" value="1"/><label for="mod_item-egresos-gastos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <!--<li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-gastos-anular" name="a86" value="1"/><label for="mod_item-egresos-gastos-anular">&nbsp;&nbsp;&nbsp;&nbsp;Anular</label></li>-->
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-gastos-pdf" name="a87" value="1"/><label for="mod_item-egresos-gastos-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-egresos-gastos-excel" name="a88" value="1"/><label for="mod_item-egresos-gastos-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-fElectronica" style="position: absolute; opacity: 0;"/><label for="mod_item-fElectronica">Fact. Electr&oacute;nica</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-fElectronica-nDebito" style="position: absolute; opacity: 0;"/><label for="mod_item-fElectronica-nDebito">Nota D&eacute;bito</label>
                                <ul>
                                  <li><input class="magic-checkbox" type="checkbox" id="mod_item-fElectronica-nDebito-factura" name="a89" value="1"/><label for="mod_item-fElectronica-nDebito-factura">&nbsp;&nbsp;&nbsp;&nbsp;Nuevo Para Factura</label></li>
                                  <li><input class="magic-checkbox" type="checkbox" id="mod_item-fElectronica-nDebito-boleta" name="a90" value="1"/><label for="mod_item-fElectronica-nDebito-boleta">&nbsp;&nbsp;&nbsp;&nbsp;Nuevo Para Boleta</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-fElectronica-nCredito" style="position: absolute; opacity: 0;"/><label for="mod_item-fElectronica-nCredito">Nota Cr&eacute;dito</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-fElectronica-nCredito-factura" name="a91" value="1"/><label for="mod_item-fElectronica-nCredito-factura">&nbsp;&nbsp;&nbsp;&nbsp;Nuevo Para Factura</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-fElectronica-nCredito-boleta" name="a92" value="1"/><label for="mod_item-fElectronica-nCredito-boleta">&nbsp;&nbsp;&nbsp;&nbsp;Nuevo Para Boleta</label></li>
                                </ul>
                            </li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-fElectronica-rDiario" name="a93" value="1"/><label for="mod_item-fElectronica-rDiario">&nbsp;&nbsp;&nbsp;&nbsp;Resumen Diario</label></li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-fElectronica-cBaja" name="a94" value="1"/><label for="mod_item-fElectronica-cBaja">&nbsp;&nbsp;&nbsp;&nbsp;Comunicaci&oacute;n Baja</label></li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-fElectronica-gRemision" name="a95" value="1"/><label for="mod_item-fElectronica-gRemision">&nbsp;&nbsp;&nbsp;&nbsp;Gu&iacute;a Remisi&oacute;n</label></li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-contabilidad" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad">Contabilidad</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-contabilidad-lElectronicos" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-lElectronicos">Libros Electr&oacute;nicos</label>
                                <ul>
                                    <li><input type="checkbox" id="mod_item-contabilidad-lElectronicos-cb" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-lElectronicos-cb">Caja Bancos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-cb-mEfectivo" name="a96" value="1"/><label for="mod_item-contabilidad-lElectronicos-cb-mEfectivo">&nbsp;&nbsp;&nbsp;&nbsp;Mov. Efectivo</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-cb-mCta" name="a97" value="1"/><label for="mod_item-contabilidad-lElectronicos-cb-mCta">&nbsp;&nbsp;&nbsp;&nbsp;Mov. Cta. Corriente</label></li>
                                        </ul>
                                    </li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-rInventario" name="a98" value="1"/><label for="mod_item-contabilidad-lElectronicos-rInventario">&nbsp;&nbsp;&nbsp;&nbsp;Registro Inventarios</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-rCompras" name="a99" value="1"/><label for="mod_item-contabilidad-lElectronicos-rCompras">&nbsp;&nbsp;&nbsp;&nbsp;Registro Compras</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-rVentas" name="a100" value="1"/><label for="mod_item-contabilidad-lElectronicos-rVentas">&nbsp;&nbsp;&nbsp;&nbsp;Registro Ventas</label></li>
                                    <li><input type="checkbox" id="mod_item-contabilidad-lElectronicos-lDiario" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-lElectronicos-lDiario">Libro Diario</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-lDiario-ver" name="a101" value="1"/><label for="mod_item-contabilidad-lElectronicos-lDiario-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-lDiario-agregar" name="a102" value="1"/><label for="mod_item-contabilidad-lElectronicos-lDiario-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Registrar Asiento</label></li>
                                        </ul>
                                    </li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-lElectronicos-lMayor" name="a103" value="1"/><label for="mod_item-contabilidad-lElectronicos-lMayor">&nbsp;&nbsp;&nbsp;&nbsp;Libro Mayor</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-contabilidad-bancos" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-bancos">Listado Bancos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-bancos-ver" name="a104" value="1"/><label for="mod_item-contabilidad-bancos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-bancos-agregar" name="a105" value="1"/><label for="mod_item-contabilidad-bancos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-bancos-editar" name="a106" value="1"/><label for="mod_item-contabilidad-bancos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-bancos-eliminar" name="a107" value="1"/><label for="mod_item-contabilidad-bancos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-contabilidad-cBancarias" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-cBancarias">Cuentas Bancarias</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-cBancarias-ver" name="a108" value="1"/><label for="mod_item-contabilidad-cBancarias-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-cBancarias-agregar" name="a109" value="1"/><label for="mod_item-contabilidad-cBancarias-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-cBancarias-editar" name="a110" value="1"/><label for="mod_item-contabilidad-cBancarias-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-cBancarias-eliminar" name="a111" value="1"/><label for="mod_item-contabilidad-cBancarias-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                    <li><input type="checkbox" id="mod_item-contabilidad-cBancarias-movimientos" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-cBancarias-movimientos">Movimientos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-cBancarias-movimientos-ver" name="a112" value="1"/><label for="mod_item-contabilidad-cBancarias-movimientos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-cBancarias-movimientos-agregar" name="a113" value="1"/><label for="mod_item-contabilidad-cBancarias-movimientos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-contabilidad-mPago" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-mPago">Medio Pago</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-mPago-ver" name="a226" value="1"/><label for="mod_item-contabilidad-mPago-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-mPago-agregar" name="a227" value="1"/><label for="mod_item-contabilidad-mPago-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-mPago-editar" name="a228" value="1"/><label for="mod_item-contabilidad-mPago-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-mPago-eliminar" name="a229" value="1"/><label for="mod_item-contabilidad-mPago-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-contabilidad-pcge" style="position: absolute; opacity: 0;"/><label for="mod_item-contabilidad-pcge">PCGE</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-pcge-ver" name="a114" value="1"/><label for="mod_item-contabilidad-pcge-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-pcge-agregar" name="a115" value="1"/><label for="mod_item-contabilidad-pcge-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-pcge-editar" name="a116" value="1"/><label for="mod_item-contabilidad-pcge-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-contabilidad-pcge-eliminar" name="a117" value="1"/><label for="mod_item-contabilidad-pcge-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-creditos" style="position: absolute; opacity: 0;"/><label for="mod_item-creditos">Cr&eacute;ditos</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-creditos-cPagar" style="position: absolute; opacity: 0;"/><label for="mod_item-creditos-cPagar">Cuentas Por Pagar</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-creditos-cPagar-ver" name="a118" value="1"/><label for="mod_item-creditos-cPagar-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input type="checkbox" id="mod_item-creditos-cPagar-movimientos" style="position: absolute; opacity: 0;"/><label for="mod_item-creditos-cPagar-movimientos">Movimientos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-creditos-cPagar-movimientos-ver" name="a119" value="1"/><label for="mod_item-creditos-cPagar-movimientos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-creditos-cPagar-movimientos-agregar" name="a120" value="1"/><label for="mod_item-creditos-cPagar-movimientos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-creditos-cCobrar" style="position: absolute; opacity: 0;"/><label for="mod_item-creditos-cCobrar">Cuentas Por Cobrar</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-creditos-cCobrar-ver" name="a121" value="1"/><label for="mod_item-creditos-cCobrar-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input type="checkbox" id="mod_item-creditos-cCobrar-movimientos" style="position: absolute; opacity: 0;"/><label for="mod_item-creditos-cCobrar-movimientos">Movimientos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-creditos-cCobrar-movimientos-ver" name="a122" value="1"/><label for="mod_item-creditos-cCobrar-movimientos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-creditos-cCobrar-movimientos-agregar" name="a123" value="1"/><label for="mod_item-creditos-cCobrar-movimientos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-rrhh" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh">RR.HH</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-rrhh-vDescansos" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-vDescansos">Variables Laborales</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vDescansos-ver" name="a124" value="1"/><label for="mod_item-rrhh-vDescansos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vDescansos-agregar" name="a125" value="1"/><label for="mod_item-rrhh-vDescansos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vDescansos-editar" name="a126" value="1"/><label for="mod_item-rrhh-vDescansos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vDescansos-eliminar" name="a127" value="1"/><label for="mod_item-rrhh-vDescansos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-rrhh-cAsistencia" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-cAsistencia">Consulta Asistencia</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-cAsistencia-ver" name="a128" value="1"/><label for="mod_item-rrhh-cAsistencia-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-cAsistencia-pdf" name="a129" value="1"/><label for="mod_item-rrhh-cAsistencia-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-cAsistencia-excel" name="a130" value="1"/><label for="mod_item-rrhh-cAsistencia-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-rrhh-lAsistencia" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-lAsistencia">Lista Asistencia</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lAsistencia-ver" name="a132" value="1"/><label for="mod_item-rrhh-lAsistencia-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lAsistencia-entrada" name="a133" value="1"/><label for="mod_item-rrhh-lAsistencia-entrada">&nbsp;&nbsp;&nbsp;&nbsp;Registrar Entrada</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lAsistencia-salida" name="a131" value="1"/><label for="mod_item-rrhh-lAsistencia-salida">&nbsp;&nbsp;&nbsp;&nbsp;Registrar Salida</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lAsistencia-pdf" name="a134" value="1"/><label for="mod_item-rrhh-lAsistencia-pdf">&nbsp;&nbsp;&nbsp;&nbsp;Exportar PDF</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lAsistencia-excel" name="a135" value="1"/><label for="mod_item-rrhh-lAsistencia-excel">&nbsp;&nbsp;&nbsp;&nbsp;Exportar Excel</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-rrhh-lDescanso" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-lDescanso">Lista Descanso</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lDescanso-ver" name="a136" value="1"/><label for="mod_item-rrhh-lDescanso-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lDescanso-agregar" name="a137" value="1"/><label for="mod_item-rrhh-lDescanso-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lDescanso-editar" name="a138" value="1"/><label for="mod_item-rrhh-lDescanso-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-lDescanso-eliminar" name="a139" value="1"/><label for="mod_item-rrhh-lDescanso-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-rrhh-vacaciones" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-vacaciones">Vacaciones</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vacaciones-ver" name="a140" value="1"/><label for="mod_item-rrhh-vacaciones-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vacaciones-agregar" name="a141" value="1"/><label for="mod_item-rrhh-vacaciones-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vacaciones-editar" name="a142" value="1"/><label for="mod_item-rrhh-vacaciones-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-vacaciones-eliminar" name="a143" value="1"/><label for="mod_item-rrhh-vacaciones-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-rrhh-contratos" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-contratos">Contratos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-contratos-ver" name="a144" value="1"/><label for="mod_item-rrhh-contratos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-contratos-agregar" name="a145" value="1"/><label for="mod_item-rrhh-contratos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-contratos-editar" name="a146" value="1"/><label for="mod_item-rrhh-contratos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-contratos-eliminar" name="a147" value="1"/><label for="mod_item-rrhh-contratos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-rrhh-cargos" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-cargos">Cargos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-cargos-ver" name="a222" value="1"/><label for="mod_item-rrhh-cargos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-cargos-agregar" name="a223" value="1"/><label for="mod_item-rrhh-cargos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-cargos-editar" name="a224" value="1"/><label for="mod_item-rrhh-cargos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-cargos-eliminar" name="a225" value="1"/><label for="mod_item-rrhh-cargos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-rrhh-pagos" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-pagos">Pagos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-pagos-ver" name="a148" value="1"/><label for="mod_item-rrhh-pagos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-pagos-agregar" name="a149" value="1"/><label for="mod_item-rrhh-pagos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-pagos-editar" name="a150" value="1"/><label for="mod_item-rrhh-pagos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-pagos-eliminar" name="a151" value="1"/><label for="mod_item-rrhh-pagos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-rrhh-planilla" style="position: absolute; opacity: 0;"/><label for="mod_item-rrhh-planilla">Planilla</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-planilla-ver" name="a152" value="1"/><label for="mod_item-rrhh-planilla-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-planilla-agregar" name="a153" value="1"/><label for="mod_item-rrhh-planilla-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-planilla-editar" name="a154" value="1"/><label for="mod_item-rrhh-planilla-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-rrhh-planilla-eliminar" name="a155" value="1"/><label for="mod_item-rrhh-planilla-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-crm" style="position: absolute; opacity: 0;"/><label for="mod_item-crm">CRM</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-crm-tareas" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-tareas">Tareas</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-tareas-ver" name="a156" value="1"/><label for="mod_item-crm-tareas-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-tareas-agregar" name="a157" value="1"/><label for="mod_item-crm-tareas-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-tareas-editar" name="a158" value="1"/><label for="mod_item-crm-tareas-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-tareas-eliminar" name="a159" value="1"/><label for="mod_item-crm-tareas-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-crm-proyectos" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-proyectos">Proyectos</label>
                                <ul>
                                    <li><input type="checkbox" id="mod_item-crm-proyectos-programas" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-proyectos-programas">Programas</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-programas-ver" name="a160" value="1"/><label for="mod_item-crm-proyectos-programas-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-programas-agregar" name="a249" value="1"/><label for="mod_item-crm-proyectos-programas-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-programas-editar" name="a250" value="1"/><label for="mod_item-crm-proyectos-programas-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-programas-eliminar" name="a251" value="1"/><label for="mod_item-crm-proyectos-programas-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                        </ul>
                                    </li>
                                    <li><input type="checkbox" id="mod_item-crm-proyectos-grupos" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-proyectos-grupos">Grupos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-grupos-ver" name="a161" value="1"/><label for="mod_item-crm-proyectos-grupos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-grupos-agregar" name="a252" value="1"/><label for="mod_item-crm-proyectos-grupos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-grupos-editar" name="a253" value="1"/><label for="mod_item-crm-proyectos-grupos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-grupos-eliminar" name="a254" value="1"/><label for="mod_item-crm-proyectos-grupos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                        </ul>
                                    </li>
                                    <li><input type="checkbox" id="mod_item-crm-proyectos-miembros" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-proyectos-miembros">Miembros</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-miembros-ver" name="a162" value="1"/><label for="mod_item-crm-proyectos-miembros-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-miembros-agregar" name="a255" value="1"/><label for="mod_item-crm-proyectos-miembros-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-miembros-editar" name="a256" value="1"/><label for="mod_item-crm-proyectos-miembros-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-miembros-eliminar" name="a257" value="1"/><label for="mod_item-crm-proyectos-miembros-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                        </ul>
                                    </li>
                                    <li><input type="checkbox" id="mod_item-crm-proyectos-poyectos" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-proyectos-poyectos">Proyectos</label>
                                        <ul>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-poyectos-ver" name="a163" value="1"/><label for="mod_item-crm-proyectos-poyectos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-poyectos-agregar" name="a258" value="1"/><label for="mod_item-crm-proyectos-poyectos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-poyectos-editar" name="a259" value="1"/><label for="mod_item-crm-proyectos-poyectos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-proyectos-poyectos-eliminar" name="a260" value="1"/><label for="mod_item-crm-proyectos-poyectos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-crm-callCenter" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-callCenter">Call Center</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-callCenter-ver" name="a164" value="1"/><label for="mod_item-crm-callCenter-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-callCenter-agregar" name="a165" value="1"/><label for="mod_item-crm-callCenter-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-callCenter-editar" name="a166" value="1"/><label for="mod_item-crm-callCenter-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-callCenter-eliminar" name="a167" value="1"/><label for="mod_item-crm-callCenter-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-crm-propuestas" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-propuestas">Propuestas</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-propuestas-ver" name="a168" value="1"/><label for="mod_item-crm-propuestas-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-propuestas-agregar" name="a168" value="1"/><label for="mod_item-crm-propuestas-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-propuestas-editar" name="a170" value="1"/><label for="mod_item-crm-propuestas-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-propuestas-eliminar" name="a171" value="1"/><label for="mod_item-crm-propuestas-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-crm-presupuestos" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-presupuestos">Presupuestos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-presupuestos-ver" name="a172" value="1"/><label for="mod_item-crm-presupuestos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-presupuestos-agregar" name="a173" value="1"/><label for="mod_item-crm-presupuestos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-presupuestos-editar" name="a174" value="1"/><label for="mod_item-crm-presupuestos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-presupuestos-eliminar" name="a175" value="1"/><label for="mod_item-crm-presupuestos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-crm-hTickets" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-hTickets">Historial Tickets</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-hTickets-ver" name="a176" value="1"/><label for="mod_item-crm-hTickets-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-hTickets-agregar" name="a177" value="1"/><label for="mod_item-crm-hTickets-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-hTickets-editar" name="a178" value="1"/><label for="mod_item-crm-hTickets-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-hTickets-eliminar" name="a179" value="1"/><label for="mod_item-crm-hTickets-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-crm-cPotenciales" style="position: absolute; opacity: 0;"/><label for="mod_item-crm-cPotenciales">Clientes Potenciales</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-cPotenciales-ver" name="a180" value="1"/><label for="mod_item-crm-cPotenciales-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-cPotenciales-agregar" name="a181" value="1"/><label for="mod_item-crm-cPotenciales-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-cPotenciales-editar" name="a182" value="1"/><label for="mod_item-crm-cPotenciales-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-crm-cPotenciales-eliminar" name="a183" value="1"/><label for="mod_item-crm-cPotenciales-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><input type="checkbox" id="mod_item-ajustes" style="position: absolute; opacity: 0;"/><label for="mod_item-ajustes">Ajustes</label>
                        <ul>
                            <li><input type="checkbox" id="mod_item-ajustes-dEmpresa" style="position: absolute; opacity: 0;"/><label for="mod_item-ajustes-dEmpresa">Datos Empresa</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-dEmpresa-dGenerales" name="a184" value="1"/><label for="mod_item-ajustes-dEmpresa-dGenerales">&nbsp;&nbsp;&nbsp;&nbsp;Datos Generales</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-dEmpresa-cLogo" name="a185" value="1"/><label for="mod_item-ajustes-dEmpresa-cLogo">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Logo</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-dEmpresa-cFavicon" name="a186" value="1"/><label for="mod_item-ajustes-dEmpresa-cFavicon">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Favicon</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-dEmpresa-cfCertificado" name="a187" value="1"/><label for="mod_item-ajustes-dEmpresa-cfCertificado">&nbsp;&nbsp;&nbsp;&nbsp;Configurar Certificado</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-dEmpresa-cCertificado" name="a188" value="1"/><label for="mod_item-ajustes-dEmpresa-cCertificado">&nbsp;&nbsp;&nbsp;&nbsp;Cargar Certificado</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-dEmpresa-sCorreo" name="a189" value="1"/><label for="mod_item-ajustes-dEmpresa-sCorreo">&nbsp;&nbsp;&nbsp;&nbsp;Servidor Correo</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-ajustes-establecimientos" style="position: absolute; opacity: 0;"/><label for="mod_item-ajustes-establecimientos">Establecimientos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-establecimientos-ver" name="a190" value="1"/><label for="mod_item-ajustes-establecimientos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-establecimientos-agregar" name="a191" value="1"/><label for="mod_item-ajustes-establecimientos-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-establecimientos-editar" name="a192" value="1"/><label for="mod_item-ajustes-establecimientos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-establecimientos-eliminar" name="a193" value="1"/><label for="mod_item-ajustes-establecimientos-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-ajustes-seriesCorrelativos" style="position: absolute; opacity: 0;"/><label for="mod_item-ajustes-seriesCorrelativos">Series Correlativos</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-seriesCorrelativos-ver" name="a194" value="1"/><label for="mod_item-ajustes-seriesCorrelativos-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-seriesCorrelativos-editar" name="a195" value="1"/><label for="mod_item-ajustes-seriesCorrelativos-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-ajustes-cUsuarios" style="position: absolute; opacity: 0;"/><label for="mod_item-ajustes-cUsuarios">Cuentas Usuarios</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-cUsuarios-ver" name="a196" value="1"/><label for="mod_item-ajustes-cUsuarios-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-cUsuarios-agregar" name="a197" value="1"/><label for="mod_item-ajustes-cUsuarios-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-cUsuarios-editar" name="a198" value="1"/><label for="mod_item-ajustes-cUsuarios-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-cUsuarios-eliminar" name="a199" value="1"/><label for="mod_item-ajustes-cUsuarios-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-ajustes-aUsuarios" style="position: absolute; opacity: 0;"/><label for="mod_item-ajustes-aUsuarios">Accesos Usuarios</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-aUsuarios-ver" name="a200" value="1"/><label for="mod_item-ajustes-aUsuarios-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-aUsuarios-agregar" name="a201" value="1"/><label for="mod_item-ajustes-aUsuarios-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-aUsuarios-editar" name="a202" value="1"/><label for="mod_item-ajustes-aUsuarios-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-aUsuarios-eliminar" name="a203" value="1"/><label for="mod_item-ajustes-aUsuarios-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-lUsuarios" name="a204" value="1"/><label for="mod_item-ajustes-lUsuarios">&nbsp;&nbsp;&nbsp;&nbsp;Log Usuarios</label></li>
                            <li><input type="checkbox" id="mod_item-ajustes-almacenes" style="position: absolute; opacity: 0;"/><label for="mod_item-ajustes-almacenes">Almacenes</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-almacenes-ver" name="a205" value="1"/><label for="mod_item-ajustes-almacenes-ver">&nbsp;&nbsp;&nbsp;&nbsp;Visualizar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-almacenes-agregar" name="a206" value="1"/><label for="mod_item-ajustes-almacenes-agregar">&nbsp;&nbsp;&nbsp;&nbsp;Agregar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-almacenes-editar" name="a207" value="1"/><label for="mod_item-ajustes-almacenes-editar">&nbsp;&nbsp;&nbsp;&nbsp;Editar</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-almacenes-eliminar" name="a208" value="1"/><label for="mod_item-ajustes-almacenes-eliminar">&nbsp;&nbsp;&nbsp;&nbsp;Eliminar</label></li>
                                </ul>
                            </li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-respaldo" name="a209" value="1"/><label for="mod_item-ajustes-respaldo">&nbsp;&nbsp;&nbsp;&nbsp;Respaldo</label></li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-ajustes-backup" name="a210" value="1"/><label for="mod_item-ajustes-backup">&nbsp;&nbsp;&nbsp;&nbsp;Backup</label></li>
                        </ul>
                    </li>
                    <li><input  type="checkbox" id="mod_item-reportes" style="position: absolute; opacity: 0;"/><label for="mod_item-reportes">Reportes</label>
                        <ul>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-gastos" name="a211" value="1"/><label for="mod_item-reportes-gastos">&nbsp;&nbsp;&nbsp;&nbsp;Gastos</label></li>
                            <li><input type="checkbox" id="mod_item-reportes-ventas" style="position: absolute; opacity: 0;"/><label for="mod_item-reportes-ventas">Ventas</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-ventas-vUsuario" name="a212" value="1"/><label for="mod_item-reportes-ventas-vUsuario">&nbsp;&nbsp;&nbsp;&nbsp;Ventas Usuario</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-ventas-vCliente" name="a213" value="1"/><label for="mod_item-reportes-ventas-vCliente">&nbsp;&nbsp;&nbsp;&nbsp;Ventas Cliente</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-ventas-vResumen" name="a214" value="1"/><label for="mod_item-reportes-ventas-vResumen">&nbsp;&nbsp;&nbsp;&nbsp;Resumen</label></li>
                                </ul>
                            </li>
                            <li><input type="checkbox" id="mod_item-reportes-compras" style="position: absolute; opacity: 0;"/><label for="mod_item-reportes-compras">Compras</label>
                                <ul>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-compras-cUsuario" name="a215" value="1"/><label for="mod_item-reportes-compras-cUsuario">&nbsp;&nbsp;&nbsp;&nbsp;Compras Usuario</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-compras-cProveedor" name="a216" value="1"/><label for="mod_item-reportes-compras-cProveedor">&nbsp;&nbsp;&nbsp;&nbsp;Compras Proveedor</label></li>
                                    <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-compras-cResumen" name="a217" value="1"/><label for="mod_item-reportes-compras-cResumen">&nbsp;&nbsp;&nbsp;&nbsp;Resumen</label></li>
                                </ul>
                            </li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-consolidado" name="a218" value="1"/><label for="mod_item-reportes-consolidado">&nbsp;&nbsp;&nbsp;&nbsp;Consolidado</label></li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-bmod_items" name="a219" value="1"/><label for="mod_item-reportes-bmod_items">&nbsp;&nbsp;&nbsp;&nbsp;Balance &Iacute;tems</label></li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-umod_items" name="a220" value="1"/><label for="mod_item-reportes-umod_items">&nbsp;&nbsp;&nbsp;&nbsp;Utilidad &Iacute;tems</label></li>
                            <li><input class="magic-checkbox" type="checkbox" id="mod_item-reportes-iVe" name="a221" value="1"/><label for="mod_item-reportes-iVe">&nbsp;&nbsp;&nbsp;&nbsp;Ingresos VS Egresos</label></li>
                        </ul>
                    </li>
                </ul>
              </div>


            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal" style="cursor: url(../img/company/cursorH1.png), pointer;">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="actualizar_datos" style="cursor: url(../img/company/cursorH1.png), pointer;">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>