<form method="post" id="guardar_diario" name="guardar_diario" autocomplete="off" class="form-horizontal" autocomplete="off">
   <div class="modal fade" id="nuevoDiario" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Nuevo Asiento</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div id="resultados_ajax"></div>
               <div class="row">
                   <div class=" col-md-6">
                       <label for="diario_fecha">Fecha *</label>
                       <input type="text" class="form-control" id="diario_fecha" name="diario_fecha" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Fecha" autofocus required>
                   </div>
                   <div class=" col-md-6">
                       <label for="diario_libro">Libro *</label>
                       <select class="selectD form-control" id="diario_libro" name="diario_libro" style="width: 100%;">
                          <option value=""></option>
                          <option value="1">Compras</option>
                          <option value="2">Ventas</option>
                          <option value="3">Inventario</option>
                       </select>
                   </div>
                   <div class=" col-md-12">
                       <label for="diario_glosa">Glosa O Descripci&oacute;n De La Operaci&oacute;n *</label>
                       <input type="text" class="form-control" id="diario_glosa" name="diario_glosa" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Glosa O Descripci&oacute;n De La Operaci&oacute;n" required>
                   </div>
                   <div class=" col-md-12" style="padding: 10px;">
                      <div class="col-md-4">
                        <div class="btn btn-success btn-block">Cargar</div>
                      </div>
                      <div class="col-md-4">
                        <div class="btn btn-danger btn-block">Abonar</div>
                      </div>
                      <div class="col-md-4">
                        <div class="btn btn-warning btn-block">Tributos</div>
                      </div>
                   </div>
                   <div class=" col-md-12">
                        <label for="desc_categoria">Detalle</label>
                        <table class="table table-bordered">
                          <thead>
                            <th>C&oacute;digo</th>
                            <th>Descripci&oacute;n</th>
                            <th>Monto</th>
                          </thead>
                          <tbody>
                            <td>--</td>
                            <td>--</td>
                            <td>0.00</td>
                          </tbody>
                        </table>
                   </div>
                   <div class=" col-md-12">
                        <table class="table">
                          <thead>
                            <th>Debe</th>
                            <th>Haber</th>
                          </thead>
                          <tbody>
                            <td>0.00</td>
                            <td>0.00</td>
                          </tbody>
                          <tfoot>
                            <td>Dieferencia:</td>
                            <td>0.00</td>
                          </tfoot>
                        </table>
                   </div>
               </div>
             </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">Cancelar</button>
                 <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
             </div>
         </div>
     </div>
   </div>

</form>
<script>
$('#diario_libro').select2({
  placeholder: 'Selecciona una opcion',
  width: 'resolve',
  dropdownParent: $("#nuevoDiario")
  //theme: "classic"
});
</script>