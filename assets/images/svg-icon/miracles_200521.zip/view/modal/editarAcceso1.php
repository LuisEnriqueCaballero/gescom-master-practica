<form method="post" id="editar_permisos" name="editar_permisos">
   <div class="modal fade" id="editarAcceso" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Editar Acceso</h4>
            </div>
            <div class="modal-body">
                <div id="loader2" class="text-center"></div>
               <div id="datos_ajax_delete"></div>
               <div class="outer_div2"></div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="actualizar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>