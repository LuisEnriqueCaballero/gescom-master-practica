<div class="modal fade" id="ModalDetallePlan" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <!--Modal header-->
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
        <h4 class="modal-title"><span id="plan_nombre"></span></h4>
      </div>
      <!--Modal body-->
      <div class="modal-body">
        <div id="resultados_ajax"></div>
        <input type='hidden' name='mod_idPlan2' id='mod_idPlan2'>
        <div class="row">
          <div class="col-md-12">
            <label for="plan_codigo"><strong>C&oacute;digo</strong></label><br>
            <span id="plan_codigo"></span>
          </div>
          <div class="col-md-6">
            <label for="plan_naturaleza"><strong>Naturaleza</strong></label><br>
            <span id="plan_naturaleza"></span>
          </div>
          <div class="col-md-6">
            <label for="plan_estado"><strong>Estado</strong></label><br>
            <span id="plan_estado"></span>
          </div>
        </div>
      </div>
      <!--Modal footer-->
      <div class="modal-footer">
        <button data-dismiss="modal" class="btn btn-default" type="button">Cerrar</button>
      </div>
    </div>
  </div>
</div>