<?php
$tienda = $_SESSION['tienda'];
?>
<form method="post" id="guardar_asistenciaModal" name="guardar_asistenciaModal" autocomplete="off" class="form-horizontal" autocomplete="off">
   <div class="modal fade" id="nuevoAsistencia" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Registro Entrada</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div id="resultados_ajax"></div>
               <div class="row">
                   <div class="col-md-12">
                       <label for="asistencia_idColaborador">Colaborador *</label>
                       <select class="form-control" id="asistencia_idColaborador" name="asistencia_idColaborador" required>
                         <option value="">-- Selecciona Colaborador --</option>
                         <?php
                          $sql_colaborador=mysqli_query($con,"select * from colaboradores where colaborador_sucursal=$tienda");
                          while ($row_col = mysqli_fetch_array($sql_colaborador)) {
                            $nombres = $row_col['colaborador_nombres'];
                            $id      = $row_col['colaborador_id'];
                          ?>
                          <option value="<?php echo $id; ?>"><?php echo $nombres; ?></option>
                          <?php }
                         ?>
                       </select>
                   </div>
                   <div class="col-md-6">
                       <label for="asistencia_ingreso">Fecha *</label>
                       <input type="date" class="form-control" id="asistencia_ingreso" name="asistencia_ingreso" value="<?php echo date('Y-m-d'); ?>" required>
                   </div>
                   <div class="col-md-6">
                       <label for="asistencia_ingreso_hora">Hora *</label>
                       <input type="time" class="form-control" id="asistencia_ingreso_hora" name="asistencia_ingreso_hora" value="<?php echo date('H:i'); ?>" required>
                   </div>
                   <div class="col-md-12">
                       <label for="asistencia_idVariable">Variable *</label>
                       <select class="form-control" id="asistencia_idVariable" name="asistencia_idVariable" required>
                         <option value="">-- Selecciona Variable --</option>
                         <?php
                          $sql_variable=mysqli_query($con,"select * from variable_laboral where (laboral_sucursal='$tienda' or laboral_sucursal='0')");
                          while ($row_var = mysqli_fetch_array($sql_variable)) {
                            $laboral_nombre = $row_var['laboral_nombre'];
                            $laboral_id     = $row_var['laboral_id'];
                          ?>
                          <option value="<?php echo $laboral_id; ?>"><?php echo $laboral_nombre; ?></option>
                          <?php }
                         ?>
                       </select>
                   </div>
               </div>
             </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">Cancelar</button>
                 <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
             </div>
         </div>
     </div>
   </div>
</form>