<form method="post" id="guardar_programa" name="guardar_programa" autocomplete="off" class="form-horizontal">
   <div class="modal fade" id="nuevoPrograma" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
               <h4 class="modal-title">Nuevo Programa</h4>
            </div>
            <div class="modal-body">
              <div id="resultados_ajax"></div>
               <div class="form-group row">
                  <div class="col-sm-12">
                     <input type="text" class="form-control" id="programa_nombre" name="programa_nombre" autocomplete="off" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" autofocus="" required>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
               <button type="submit" class="btn btn-primary" id="guardar_datos">Aceptar</button>
            </div>
         </div>
      </div>
   </div>
</form>