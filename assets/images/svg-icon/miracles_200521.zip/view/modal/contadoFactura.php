<style>
   .scroll {
  max-height: 500px;
  overflow: auto;
}
</style>

<div class="modal fade" id="contadoFactura" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Pago Contado</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
              <div class="table-responsive" style="max-height: 550px; border: 1px solid #9b9b9b; border-radius: 13px;">
               <table class="table table-sm">
                  <thead>
                     <tr>
                        <th style="display: none;">#</th>
                        <th>C&oacute;digo</th>
                        <th>Descripci&oacute;n</th>
                     </tr>
                  </thead>
               </table>
               <div class="scroll" style="margin-top: -20px;">
                  <table class="display table dt-responsive" style="width:100%" id="tableContado">
                    <tbody>
                     <?php
                     $sql = "select * from pcge where pcge_id<=14 order by pcge_id asc";
                     $query = mysqli_query($con,$sql);
                     while ($row = mysqli_fetch_array($query)) {
                        $pcge_id          = $row['pcge_id'];
                        $pcge_codigo      = $row['pcge_codigo'];
                        $pcge_descripcion = $row['pcge_descripcion'];

                     ?>
                      <tr data-dismiss="modal">
                        <td style="display: none;"><?php echo $pcge_id; ?></td>
                        <td><?php echo $pcge_codigo; ?></td>
                        <td><?php echo $pcge_descripcion; ?></td>
                      </tr>
                      <?php } ?>
                    </tbody>
                  </table>
               </div>
            </div>
            </div>
         </div>
     </div>
   </div>