<form method="post" id="editar_medioPago" name="editar_medioPago" autocomplete="off" class="form-horizontal" autocomplete="off">
   <div class="modal fade" id="editarMedio" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
             <!--Modal header-->
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                 <h4 class="modal-title">Editar Medio</h4>
             </div>
             <!--Modal body-->
             <div class="modal-body">
               <div id="resultados_ajax2"></div>
               <input type="hidden" name="mod_idMedioPago" id="mod_idMedioPago">
               <div class="row">
                   <div class="form-group col-md-12">
                       <label for="mod_nombre">Nombre *</label>
                       <input type="text" class="form-control" id="mod_nombre" name="mod_nombre" onKeyUp="this.value=this.value.toUpperCase();" placeholder="Nombre" autofocus required>
                   </div>
                   <div class="form-group col-md-12">
                       <label for="mod_destino">Destino Contable*</label>
                       <select class="form-control" id="mod_destino" name="mod_destino" style="width: 100%;" required>
                         <option value="">-- Selecciona Destino --</option>
                         <option value="1">CAJA</option>
                         <option value="2">BANCO</option>
                       </select>
                   </div>
               </div>
             </div>
             <!--Modal footer-->
             <div class="modal-footer">
                 <button data-dismiss="modal" class="btn btn-default" type="button">Cancelar</button>
                 <button type="submit" class="btn btn-primary" id="actualizar_datos">Aceptar</button>
             </div>
         </div>
     </div>
   </div>
</form>