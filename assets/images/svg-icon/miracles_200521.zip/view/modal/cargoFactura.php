<style>
   .scroll {
  max-height: 500px;
  overflow: auto;
}
</style>
<div class="modal fade" id="cargoFactura" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <!--Modal header-->
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
        <h4 class="modal-title">Cuenta Cargo</h4>
      </div>
      <!--Modal body-->
      <div class="modal-body">
        <div class="table-responsive" style="max-height: 550px; border: 1px solid #9b9b9b; border-radius: 13px;">
          <table class="table table-sm">
            <thead>
              <tr>
                <th style="display: none;">#</th>
                <th>C&oacute;digo</th>
                <th>Descripci&oacute;n</th>
              </tr>
            </thead>
          </table>
          <div class="scroll" style="margin-top: -20px;">
            <table class="display table dt-responsive" style="width:100%;" id="tableCargo">
              <tbody>
                <?php
                $sql = "select * from pcge where pcge_id=52 or pcge_id=53 or pcge_id=54 or pcge_id=55 or pcge_id=56 or pcge_id=57 or pcge_id=58 or pcge_id=59 or pcge_id=60 or pcge_id=61 or pcge_id=62 or pcge_id=63 or pcge_id=64 or pcge_id=65 or pcge_id=66 or pcge_id=67 or pcge_id=68 or pcge_id=69 or pcge_id=70 or pcge_id=71 or pcge_id=72 or pcge_id=73 or pcge_id=74 or pcge_id=75 or pcge_id=76 or pcge_id=77 or pcge_id=78 or pcge_id=79 or pcge_id=80 or pcge_id=81 or pcge_id=82 or pcge_id=83 or pcge_id=84 or pcge_id=85 or pcge_id=86 or pcge_id=87 or pcge_id=88 or pcge_id=89 or pcge_id=90 or pcge_id=100 or pcge_id=101 or pcge_id=102 or pcge_id=103 or pcge_id=104 or pcge_id=105 or pcge_id=106 or pcge_id=107 or pcge_id=108 or pcge_id=109 or pcge_id=110 or pcge_id=111 or pcge_id=112 or pcge_id=113 or pcge_id=132 or pcge_id=133 or pcge_id=134 or pcge_id=135 or pcge_id=136 or pcge_id=137 or pcge_id=138 or pcge_id=139 or pcge_id=140 or pcge_id=141 or pcge_id=142 or pcge_id=143 or pcge_id=144 or pcge_id=145 or pcge_id=146 or pcge_id=147 or pcge_id=148 or pcge_id=149 or pcge_id=150 or pcge_id=151 or pcge_id=152 or pcge_id=153 or pcge_id=154 or pcge_id=155 or pcge_id=156 or pcge_id=157 or pcge_id=158 or pcge_id=159 or pcge_id=160 or pcge_id=161 or pcge_id=162 or pcge_id=163 or pcge_id=164 or pcge_id=165 or pcge_id=166 or pcge_id=167 or pcge_id=168 or pcge_id=169 or pcge_id=170 or pcge_id=171 or pcge_id=172 or pcge_id=173 or pcge_id=174 or pcge_id=175 or pcge_id=176 or pcge_id=177 or pcge_id=178 or pcge_id=179 or pcge_id=180 or pcge_id=181 or pcge_id=182 or pcge_id=183 or pcge_id=184 or pcge_id=185 or pcge_id=186 or pcge_id=187 or pcge_id=188 or pcge_id=189 or pcge_id=190 or pcge_id=191 or pcge_id=192 or pcge_id=193 or pcge_id=194 or pcge_id=195 or pcge_id=196 or pcge_id=197 or pcge_id=198 or pcge_id=199 or pcge_id=200 or pcge_id=201 or pcge_id=202 or pcge_id=203 order by pcge_id asc";
                $query = mysqli_query($con,$sql);
                while ($row = mysqli_fetch_array($query)) {
                  $pcge_id          = $row['pcge_id'];
                  $pcge_codigo      = $row['pcge_codigo'];
                  $pcge_descripcion = $row['pcge_descripcion'];
                ?>
                <tr data-dismiss="modal">
                  <td style="display: none;"><?php echo $pcge_id; ?></td>
                  <td><?php echo $pcge_codigo; ?></td>
                  <td><?php echo $pcge_descripcion; ?></td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>