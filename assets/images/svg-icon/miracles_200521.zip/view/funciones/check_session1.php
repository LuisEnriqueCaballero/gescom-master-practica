<?php  
/*-------------------------
Autor: Developer Technology
Web: www.developer-technology.net
Mail: info@developer-technology.net
---------------------------*/
session_start();
if(isset($_SESSION["datosEmpresa_id"]))
{
	echo '0';
}
else
{
	echo '1';
}