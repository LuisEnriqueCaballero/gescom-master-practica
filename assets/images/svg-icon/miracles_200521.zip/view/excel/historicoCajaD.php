<?php
session_start();
require_once ("../../config/db.php");
require_once ("../../config/conexion.php");
$range = $_GET['range'];
//$moneda = $_GET['moneda'];
$user_id = $_SESSION['usuario_id'];
$tienda1 = $_SESSION['tienda'];
$empresa = $_SESSION['datosEmpresa_id'];
header("Content-type: application/vnd.ms-excel" ) ; 
header("Content-Disposition: attachment; filename=Historial Caja Dolares".$range.".xls" ) ;

$action  = (isset($_REQUEST['action']) && $_REQUEST['action'] != null) ? $_REQUEST['action'] : '';

if ($action == 'ajax') {
        
    $daterange   = $_GET['range'];

    list($f_inicio, $f_final)                    = explode(" - ", $daterange); //Extrae la fecha inicial y la fecha final en formato espa?ol
    list($dia_inicio, $mes_inicio, $anio_inicio) = explode("/", $f_inicio); //Extrae fecha inicial
    $fecha_inicial                               = "$anio_inicio-$mes_inicio-$dia_inicio 00:00:00"; //Fecha inicial formato ingles
    list($dia_fin, $mes_fin, $anio_fin)          = explode("/", $f_final); //Extrae la fecha final
    $fecha_final                                 = "$anio_fin-$mes_fin-$dia_fin 23:59:59";

    $sTable    = "historico_caja_usd, caja, usuarios";
    $campos    = "*";
    $sWhere    = "caja.caja_idUsuario=usuarios.usuario_id and historico_caja_usd.historico_idCaja=caja.caja_id and historico_caja_usd.historico_sucursal='$tienda1' and historico_caja_usd.historico_apertura between '$fecha_inicial' and '$fecha_final'";

    $sWhere .= " group by historico_caja_usd.historico_id";

    $count_query   = mysqli_query($con, "SELECT count(*) AS numrows FROM $sTable WHERE $sWhere");
    $row= mysqli_fetch_array($count_query);
    $numrows = $row['numrows'];
    $sql="SELECT * FROM  $sTable WHERE $sWhere ";
    $query = mysqli_query($con, $sql);

    if ($numrows > 0){ ?>

    <div class="table-responsive">
        <div>

            <?php
        
            $sql_empresa=mysqli_query($con,"select * from datosempresa WHERE datosEmpresa_id=$empresa");
            $rw_tienda=mysqli_fetch_array($sql_empresa);

            $datosEmpresa_id=$rw_tienda['datosEmpresa_id'];
            $datosEmpresa_nombre=$rw_tienda['datosEmpresa_nombre'];
            $datosEmpresa_ruc=$rw_tienda['datosEmpresa_ruc'];

            ?>

            <h5>HIST&Oacute;RICO DE CAJA</h5>
            <span><strong>PERIODO:</strong> <?php echo $daterange; ?></span><br>
            <span><strong>RUC:</strong> <?php echo $datosEmpresa_ruc; ?></span><br>
            <span><strong>MONEDA:</strong> D&Oacute;LARES (USD)</span>
        </div>
        <br>
        <table style="border: 0.5px solid #000;">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Usuario</th>
                    <th>Fecha Apertura</th>
                    <th>Ingresos</th>
                    <th>Devoluciones</th>
                    <th>Pr&eacute;stamos</th>
                    <th>Gastos</th>
                    <th>Saldo</th>
                    <th>Fecha Cierre</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $a1 = 1;
                while ($row = mysqli_fetch_array($query)) {
        
                    $caja_id            = $row['caja_id'];
                    $caja_fechaApertura = date("d/m/Y", strtotime($row['historico_apertura']));
                    $usuario_alias      = $row['usuario_alias'];
                    $historico_ingresos      = $row['historico_ingresos'];
                    $historico_devoluciones      = $row['historico_devoluciones'];
                    $historico_prestamos      = $row['historico_prestamos'];
                    $historico_gastos      = $row['historico_gastos'];
                    $historico_cierre = date("d/m/Y", strtotime($row['historico_cierre']));
                    $caja_estado = $row['caja_estado'];

                    $egresos = $historico_devoluciones+$historico_prestamos+$historico_gastos;
                    $saldo = $historico_ingresos-$egresos;

                    if ($caja_estado == 1) {
                        $cierre = 'ABIERTO';
                    }
                    if ($caja_estado == 0) {
                        $cierre = $historico_cierre;
                    }
                ?>
                <tr>
                    <td><?php echo $a1++; ?></td>
                    <td><?php echo $usuario_alias; ?></td>
                    <td><?php echo $caja_fechaApertura; ?></td>
                    <td><?php echo number_format($historico_ingresos,2); ?></td>
                    <td><?php echo number_format($historico_devoluciones,2); ?></td>
                    <td><?php echo number_format($historico_prestamos,2); ?></td>
                    <td><?php echo number_format($historico_gastos,2); ?></td>
                    <td><?php echo number_format($saldo,2); ?></td>
                    <td><?php echo $cierre; ?></td>
                </tr>
        <?php } ?>
                <tr>
                    <td colspan="3"><strong>TOTALES</strong></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            </tbody>
        </table>
    </div>
    <?php } ?>
<?php } ?>