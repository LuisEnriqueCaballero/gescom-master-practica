<?php
session_start();
require_once ("../../config/db.php");
require_once ("../../config/conexion.php");
$range = $_GET['range'];
//$moneda = $_GET['moneda'];
$user_id = $_SESSION['usuario_id'];
$tienda = $_SESSION['tienda'];
$empresa = $_SESSION['datosEmpresa_id'];
header("Content-type: application/vnd.ms-excel" ) ; 
header("Content-Disposition: attachment; filename=Historial Facturas ".$range.".xls" ) ;

$action  = (isset($_REQUEST['action']) && $_REQUEST['action'] != null) ? $_REQUEST['action'] : '';

if ($action == 'ajax') {
        
    $daterange   = $_GET['range'];

    list($f_inicio, $f_final)                    = explode(" - ", $daterange); //Extrae la fecha inicial y la fecha final en formato espa?ol
    list($dia_inicio, $mes_inicio, $anio_inicio) = explode("/", $f_inicio); //Extrae fecha inicial
    $fecha_inicial                               = "$anio_inicio-$mes_inicio-$dia_inicio 00:00:00"; //Fecha inicial formato ingles
    list($dia_fin, $mes_fin, $anio_fin)          = explode("/", $f_final); //Extrae la fecha final
    $fecha_final                                 = "$anio_fin-$mes_fin-$dia_fin 23:59:59";

    $sTable    = "facturas, clientes";
    $campos    = "*";
    $sWhere    = "facturas.factura_idCliente=clientes.cliente_id and facturas.factura_sucursal=$tienda and facturas.factura_tipo=1 and facturas.factura_venCom=1 and facturas.factura_correlativo>0 and facturas.consumo=0 and facturas.factura_fecha between '$fecha_inicial' and '$fecha_final'";

    $sWhere .= " group by facturas.factura_id";

    $count_query   = mysqli_query($con, "SELECT count(*) AS numrows FROM $sTable WHERE $sWhere");
    $row= mysqli_fetch_array($count_query);
    $numrows = $row['numrows'];
    $sql="SELECT * FROM  $sTable WHERE $sWhere ";
    $query = mysqli_query($con, $sql);

    if ($numrows > 0){ ?>

    <div class="table-responsive">
    <div>

        <?php
    
        $sql_empresa=mysqli_query($con,"select * from datosempresa WHERE datosEmpresa_id=$empresa");
        $rw_tienda=mysqli_fetch_array($sql_empresa);
        $datosEmpresa_id=$rw_tienda['datosEmpresa_id'];
        $datosEmpresa_nombre=$rw_tienda['datosEmpresa_nombre'];
        $ruc1=$rw_tienda['datosEmpresa_ruc'];

        $sql_sucursal=mysqli_query($con,"select * from sucursales WHERE sucursal_tienda=$tienda");
        $rw_suc=mysqli_fetch_array($sql_sucursal);
        $sucursal_nombre=$rw_suc['sucursal_nombre'];

        ?>

        <h3 style="text-align: center;">HIST&Oacute;RICO DE BOLETAS</h3>
        <span><strong>ESTABLECIMIENTO:</strong> <?php echo $sucursal_nombre; ?></span><br>
        <span><strong>PERIODO:</strong> <?php echo $daterange; ?></span>
    </div>
    <br>
    <table style="border: 0.5px solid #000;">
        <thead>
            <tr>
                <th>#</th>
                <th>Doc</th>
                <th>Fecha</th>
                <th>Cliente</th>
                <th>Total</th>
                <th>Moneda</th>
                <th>Condic&oacute;n</th>
                <th>Pago</th>
                <th>Hora Env&iacute;o | Observaci&oacute;n</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $a1 = 1;
            while ($row = mysqli_fetch_array($query)) {
    
                $factura_id=$row['factura_id'];
                $factura_correlativo=$row['factura_correlativo'];
                $factura_resumen=$row['factura_resumen'];
                $fecha=date("d/m/Y", strtotime($row['factura_fecha']));
                $vence=date("d/m/Y", strtotime($row['factura_fechaElimina']));

                $dia_em=date("d", strtotime($row['factura_fecha']));
                $mes_em=date("m", strtotime($row['factura_fecha']));
                $anio_em=date("Y", strtotime($row['factura_fecha']));

                $dia_ve=date("d", strtotime($row['factura_fechaElimina']));
                $mes_ve=date("m", strtotime($row['factura_fechaElimina']));
                $anio_ve=date("Y", strtotime($row['factura_fechaElimina']));

                $cliente_nombre=$row['cliente_nombre'];

                $cliente_telefono=$row['cliente_telefono'];
                $cliente_documento=$row['cliente_documento'];
                $cliente_email=$row['cliente_email'];
                $factura_folio=$row['factura_folio'];

                $factura_gravada=$row['factura_gravada'];
                $factura_inafecta=$row['factura_inafecta'];
                $factura_exonerada=$row['factura_exonerada'];
                $factura_igv=$row['factura_igv'];
                $factura_icbper=$row['factura_icbper'];

                $factura_activo=$row['factura_activo'];

                $factura_credito=$row['factura_credito'];

                $aceptado1 = $row['factura_aceptado'];
                $ref=$row['ref'];

                //$usuario1= mysqli_query($con, "select * from detallefactura where detalleFactura_correlativo='".$factura_correlativo."' and detalleFactura_folio='".$factura_folio."'");
                //while ($row6=mysqli_fetch_array($usuario1)){
                $sql_empresa=mysqli_query($con,"select * from detallefactura where detalleFactura_correlativo='".$factura_correlativo."' and detalleFactura_folio='".$factura_folio."'");
                $row6=mysqli_fetch_array($sql_empresa);
                $detalleFactura_idProducto = $row6['detalleFactura_idProducto'];
                $detalleFactura_cantidad = $row6['detalleFactura_cantidad'];
                $id_detalle = $row6['detalleFactura_folio'];

                $usuario2= mysqli_query($con, "select * from productos where producto_id='".$detalleFactura_idProducto."'");
                $row7= mysqli_fetch_array($usuario2);
                $producto_catPro = $row7['producto_idCategoria'];
                //}

                /*if ($producto_catPro==1) {
                    $icbper = 0.2*$detalleFactura_cantidad;
                }
                if ($producto_catPro<>1) {
                    $icbper = "0";
                }*/
                
                $tip=0;
                $estado_factura1=$row['factura_tipo'];
                if($estado_factura1==1){
                    $tip="01";
                }
                if($estado_factura1==2){
                    $tip="03";
                }
                if($estado_factura1==3){
                    $tip="07";
                }
                if($estado_factura1==4){
                    $tip="08";
                }
                if($estado_factura1==6){
                    $tip="07";
                }
                if($estado_factura1==7){
                    $tip="08";
                }


                $mP= mysqli_query($con, "select * from medio_pago where medioPago_id=$ref and (medioPago_idSucursal=$tienda or medioPago_idSucursal=0)");
                $row_mp= mysqli_fetch_array($mP);
                $medioPago_nombre = $row_mp['medioPago_nombre'];

                $factura_correlativo1=str_pad($factura_correlativo, 8, "0", STR_PAD_LEFT);
                $doc1="$ruc1-$tip-$factura_folio-$factura_correlativo1.XML";
                
                $doc2="$ruc1-$tip-$factura_folio-$factura_correlativo1";
                
                $doc3="R-$ruc1-$tip-$factura_folio-$factura_correlativo1.XML";
                //$aceptado1="No enviado";
                $fecha3="";
                $hora3="";

                $respuesS="";

                if (file_exists('../documentos/cdr/'.$ruc1.'/'.$doc3.'')) {
                    $xml = file_get_contents('../documentos/cdr/'.$ruc1.'/'.$doc3.'');
                    #== Obteniendo datos del archivo .XML 
                    $aceptado="";
                    $DOM = new DOMDocument('1.0', 'ISO-8859-1');
                    $DOM->preserveWhiteSpace = FALSE;
                    $DOM->loadXML($xml);
                    ### DATOS DE LA FACTURA ####################################################
                    // Obteniendo RUC.
                    $DocXML = $DOM->getElementsByTagName('Description');
                    foreach($DocXML as $Nodo){
                        $aceptado = $Nodo->nodeValue; 
                    }  
                    $DocXML = $DOM->getElementsByTagName('ResponseDate');
                    foreach($DocXML as $Nodo){
                        $fecha3 = $Nodo->nodeValue; 
                    }
                    $DocXML = $DOM->getElementsByTagName('ResponseTime');
                    foreach($DocXML as $Nodo){
                    $hora3 = $Nodo->nodeValue; 
                    }
                    $fecha3=date("d/m/Y", strtotime($fecha3));
                    $pos = strpos($aceptado, "aceptada");
                    if ($pos === false) {
                        $aceptado1= "No aceptada";
                    } else {
                    $aceptado1= "Aceptada";

                    }
                }

                if($aceptado1=="Aceptada" || $row['factura_obs']=="soap-env:Client.1033"){
                    $aceptado1= "Aceptada"; 
                    $respuesS = "El documento ha sido enviado y aceptado";
                 } elseif($row['factura_aceptado']=="No aceptada") {
                    $aceptado1= "Rechazado";
                    $fecha3=$row['factura_obs'];

                    $codigo = $fecha3;
                    $linea = substr($codigo, -4);

                    $sql_sunat=mysqli_query($con,"select * from retornosunat where codigo = $linea");
                    $rw_sunat=mysqli_fetch_array($sql_sunat);
                    $respuesS =  $rw_sunat['descripcion'];
                 }
                 //print"$aceptado1";
                 if($fecha3=="" and $aceptado1=="Aceptada" || $row['factura_obs']=="soap-env:Client.1033"){
                     $fecha3=" ";
                 } 
                $estado_factura=$row['factura_condiciones'];
                $ven_com=$row['factura_venCom'];
                $moneda=$row['factura_moneda'];

                if ($moneda==115) {
                    $mon="PEN";
                }
                if ($moneda==151) {
                    $mon="USD";
                }

                
                if($estado_factura1==1){
                    $estado1="Factura";
                    $total_venta=$row['factura_ventaTotal'];
                    
                }
                if($estado_factura1==2){
                    $estado1="Boleta";
                    $total_venta=$row['factura_ventaTotal'];    
                }
                if($estado_factura1==3){
                    $estado1="Nota Cr&eacute;dito";
                    $total_venta=$row['factura_ventaTotal'];   
                }
                if($estado_factura1==4){
                    $estado1="Nota D&eacute;bito";
                    $total_venta=$row['factura_ventaTotal'];    
                }
                if($estado_factura1==5){
                    $estado1="N. Venta";
                    $total_venta=$row['factura_ventaTotal']; 
                }
                if($estado_factura1==6){
                    $estado1="Nota Cr&eacute;dito";
                    $total_venta=$row['factura_ventaTotal'];    
                }
                if($estado_factura1==7){
                    $estado1="Nota D&eacute;bito";
                    $total_venta=$row['factura_ventaTotal']; 
                }

                //$fechaActual = date('Y-m-d'); 
                $fecha1=mktime(0,0,0,$mes_em,$dia_em,$anio_em);
                $fecha2=mktime(0,0,0,$mes_ve,$dia_ve,$anio_ve);

                $diferencia=$fecha2-$fecha1;
                $dias=$diferencia/(60*60*24);

                if ($factura_activo == 1) {
                    $displayA = "";
                   if($estado_factura == 1) {
                        $estado2="Contado";
                        $text_pago = "secondary";
                    }
                    if($estado_factura == 2) {
                        $estado2="Cheque";
                        $text_pago = "secondary";
                        
                    }
                    if($estado_factura == 3) {
                        $estado2="Transf Bancaria";
                        $text_pago = "secondary";
                    }

                    if($estado_factura == 4) {
                        if ($factura_credito == 2) {
                            $estado2="Cr&eacute;dito a ".$dias." d&iacute;as";
                            $text_pago = "warning";
                        }
                        if ($factura_credito == 1) {
                            $estado2="Cr&eacute;dito (Pagada)";
                            $text_pago = "info";
                        }
                    }

                    /*if($estado_factura == 4) {
                        $estado2="Cr&eacute;dito ".dias_pasados($fecha_dada,$fecha_actual)." d&iacute;as";
                        $text_pago = "warning";
                    }*/
                }

                if ($factura_activo <> 1) {
                    $del = "<del>";
                    $del1 = "</del>";
                    $displayA = "none";
                    $estado2="Anulado";
                    $text_pago = "danger";
                    $color_txt = "red";
                }
                if ($factura_activo == 1) {
                    $del = "";
                    $del1 = "";
                    $color_txt = "";
                }

                if ($aceptado1 == 'Aceptada') {
                   $estado_envio = 'Aceptada';
                   $estado_texto = 'success';
                   $color = 'black';
                   $input = '<li><a style="cursor: url(../img/company/cursorH1.png), pointer; display: none;" ><img src="../assets/images/svg-icon/sunat.svg" class="img-fluid" alt="settings" style="width: 15px; height: 15px;"> Enviar SUNAT</a></li>';
                   $ver_cdr = '<li><a onclick="imprimir_factura1('.$doc3.');" style="cursor: url(../img/company/cursorH1.png), pointer;"><img src="../assets/images/svg-icon/cdr.svg" class="img-fluid" alt="settings" style="width: 15px; height: 15px;"> Ver CDR</a></li>';
                   $ver_xml = '<li><a onclick="imprimir_factura2('.$doc1.');" style="cursor: url(../img/company/cursorH1.png), pointer;"><img src="../assets/images/svg-icon/xml.svg" class="img-fluid" alt="settings" style="width: 15px; height: 15px;"> XML Firmado</a></li>';
                }
                if ($aceptado1 == 'Rechazado') {
                   $estado_envio = 'Rechazado';
                   $estado_texto = 'danger';
                   $color = 'red';
                   $input = '<li><a style="cursor: url(../img/company/cursorH1.png), pointer; display: none;" ><img src="../assets/images/svg-icon/sunat.svg" class="img-fluid" alt="settings" style="width: 15px; height: 15px;"> Enviar SUNAT</a></li>';
                   $ver_cdr = '<li><a style="cursor: url(../img/company/cursorH1.png), pointer; display: none;"><img src="../assets/images/svg-icon/cdr.svg" class="img-fluid" alt="settings" style="width: 15px; height: 15px;"> Ver CDR</a></li>';
                   $ver_xml = '<li><a onclick="imprimir_factura2('.$doc1.');" style="cursor: url(../img/company/cursorH1.png), pointer;"><img src="../assets/images/svg-icon/xml.svg" class="img-fluid" alt="settings" style="width: 15px; height: 15px;"> XML Firmado</a></li>';
                }
                if ($aceptado1 == '' or $aceptado1=='No enviado') {
                   $estado_envio = 'Pendiente';
                   $estado_texto = 'warning';
                   $color = 'black';
                   $input = '<li><a style="cursor: url(../img/company/cursorH1.png), pointer;" onclick="enviar('.$doc2.');"><img src="../assets/images/svg-icon/sunat.svg" class="img-fluid" alt="settings" style="width: 15px; height: 15px;"> Enviar SUNAT</a></li>';
                   $ver_cdr = '<li><a style="cursor: url(../img/company/cursorH1.png), pointer; display: none;"><img src="../assets/images/svg-icon/cdr.svg" class="img-fluid" alt="settings" style="width: 15px; height: 15px;"> Ver CDR</a></li>';
                   $ver_xml = '<li><a onclick="imprimir_factura('.$doc1.');" style="cursor: url(../img/company/cursorH1.png), pointer;"><img src="../assets/images/svg-icon/xml.svg" class="img-fluid" alt="settings" style="width: 15px; height: 15px;"> XML Sin Firmar</a></li>';
                }
                if ($aceptado1=='No enviado') {
                   $estado_envio = 'Reenviar';
                   $estado_texto = 'secondary';
                   $color = 'black';
                   $input = '<li><a style="cursor: url(../img/company/cursorH1.png), pointer;" onclick="enviar('.$doc2.');"><img src="../assets/images/svg-icon/sunat.svg" class="img-fluid" alt="settings" style="width: 15px; height: 15px;"> Reenviar SUNAT</a></li>';
                   $ver_cdr = '<li><a style="cursor: url(../img/company/cursorH1.png), pointer; display: none;"><img src="../assets/images/svg-icon/cdr.svg" class="img-fluid" alt="settings" style="width: 15px; height: 15px;"> Ver CDR</a></li>';
                   $ver_xml = '<li><a onclick="imprimir_factura('.$doc1.');" style="cursor: url(../img/company/cursorH1.png), pointer;"><img src="../assets/images/svg-icon/xml.svg" class="img-fluid" alt="settings" style="width: 15px; height: 15px;"> XML Sin Firmar</a></li>';
                }

                //suma ingresos
                $suma1= mysqli_query($con, "select SUM(factura_ventaTotal) AS ingresos FROM facturas, clientes where facturas.factura_idCliente=clientes.cliente_id and facturas.factura_sucursal=$tienda and facturas.factura_tipo=1 and facturas.factura_venCom=1 and facturas.factura_correlativo>0 and facturas.consumo=0 and facturas.factura_fecha between '$fecha_inicial' and '$fecha_final'");
                $row1= mysqli_fetch_array($suma1);
                $ingresos = $row1['ingresos'];

            ?>
            <tr>
                <td><?php echo $a1++; ?></td>
                <td><?php echo $factura_folio."-".$factura_correlativo; ?></td>
                <td><?php echo $fecha; ?></td>
                <td><?php echo $cliente_nombre; ?></td>
                <td><?php echo number_format ($total_venta+$factura_icbper,2); ?></td>
                <td><?php echo $mon; ?></td>
                <td><?php echo $estado2; ?></td>
                <td><?php echo $medioPago_nombre; ?></td>
                <td><?php echo $fecha3.' | '.$hora3; ?></td>
                <td><?php echo $estado_envio; ?></td>
            </tr>
    <?php } ?>
            <tr>
                <td colspan="4"><strong>TOTALES</strong></td>
                <td><strong><?php echo number_format($ingresos,2); ?></strong></td>
                <td colspan="5"></td>
            </tr>
        </tbody>
    </table>
</div>
    <?php } ?>
<?php } ?>