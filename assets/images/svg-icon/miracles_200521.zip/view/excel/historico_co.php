<?php
session_start();
require_once ("../../config/db.php");
require_once ("../../config/conexion.php");
$range = $_GET['range'];
//$moneda = $_GET['moneda'];
$user_id = $_SESSION['usuario_id'];
$tienda = $_SESSION['tienda'];
$empresa = $_SESSION['datosEmpresa_id'];
header("Content-type: application/vnd.ms-excel" ) ; 
header("Content-Disposition: attachment; filename=Historial Cotizaciones ".$range.".xls" ) ;

$action  = (isset($_REQUEST['action']) && $_REQUEST['action'] != null) ? $_REQUEST['action'] : '';

if ($action == 'ajax') {
        
    $daterange   = $_GET['range'];

    list($f_inicio, $f_final)                    = explode(" - ", $daterange); //Extrae la fecha inicial y la fecha final en formato espa?ol
    list($dia_inicio, $mes_inicio, $anio_inicio) = explode("/", $f_inicio); //Extrae fecha inicial
    $fecha_inicial                               = "$anio_inicio-$mes_inicio-$dia_inicio 00:00:00"; //Fecha inicial formato ingles
    list($dia_fin, $mes_fin, $anio_fin)          = explode("/", $f_final); //Extrae la fecha final
    $fecha_final                                 = "$anio_fin-$mes_fin-$dia_fin 23:59:59";

    $sTable    = "facturas_cotizaciones, clientes";
    $campos    = "*";
    $sWhere    = "facturas_cotizaciones.cotizacion_idCliente=clientes.cliente_id and facturas_cotizaciones.cotizacion_sucursal=$tienda and facturas_cotizaciones.cotizacion_correlativo>0 and facturas_cotizaciones.cotizacion_fecha between '$fecha_inicial' and '$fecha_final'";

    $sWhere .= " group by facturas_cotizaciones.cotizacion_id";

    $count_query   = mysqli_query($con, "SELECT count(*) AS numrows FROM $sTable WHERE $sWhere");
    $row= mysqli_fetch_array($count_query);
    $numrows = $row['numrows'];
    $sql="SELECT * FROM  $sTable WHERE $sWhere ";
    $query = mysqli_query($con, $sql);

    if ($numrows > 0){ ?>

<div class="table-responsive">
    <div>

        <?php
    
        $sql_empresa=mysqli_query($con,"select * from datosempresa WHERE datosEmpresa_id=$empresa");
        $rw_tienda=mysqli_fetch_array($sql_empresa);
        $datosEmpresa_id=$rw_tienda['datosEmpresa_id'];
        $datosEmpresa_nombre=$rw_tienda['datosEmpresa_nombre'];
        $ruc1=$rw_tienda['datosEmpresa_ruc'];

        $sql_sucursal=mysqli_query($con,"select * from sucursales WHERE sucursal_tienda=$tienda");
        $rw_suc=mysqli_fetch_array($sql_sucursal);
        $sucursal_nombre=$rw_suc['sucursal_nombre'];

        ?>

        <h3 style="text-align: center;">HIST&Oacute;RICO DE COTIZACIONES</h3>
        <span><strong>ESTABLECIMIENTO:</strong> <?php echo $sucursal_nombre; ?></span><br>
        <span><strong>PERIODO:</strong> <?php echo $daterange; ?></span>
    </div>
    <br>
    <table style="border: 0.5px solid #000;">
        <thead>
            <tr>
                <th>#</th>
                <th>Doc</th>
                <th>Fecha</th>
                <th>Cliente</th>
                <th>Total</th>
                <th>Moneda</th>
                <th>Pago</th>
                <th>D&iacute;as</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $a1 = 1;
        while ($row = mysqli_fetch_array($query)) {
            $cotizacion_id=$row['cotizacion_id'];
            $cotizacion_correlativo=$row['cotizacion_correlativo'];
            $fecha=date("d/m/Y", strtotime($row['cotizacion_fecha']));
            $vence=date("d/m/Y", strtotime($row['cotizacion_fechaElimina']));
            $cliente_nombre=$row['cliente_nombre'];

            $cliente_telefono=$row['cliente_telefono'];
            $cliente_documento=$row['cliente_documento'];
            $cliente_email=$row['cliente_email'];
            $cotizacion_folio=$row['cotizacion_folio'];

            $cotizacion_gravada=$row['cotizacion_gravada'];
            $cotizacion_inafecta=$row['cotizacion_inafecta'];
            $cotizacion_exonerada=$row['cotizacion_exonerada'];
            $cotizacion_igv=$row['cotizacion_igv'];

            $cotizacion_activo=$row['cotizacion_activo'];
            $cotizacion_estado=$row['cotizacion_estado'];
            $cotizacion_dias=$row['cotizacion_dias'];
            $cotizacion_modifica=$row['cotizacion_modifica'];

            $sql_empresa=mysqli_query($con,"select * from detallecotizacion where detalleCotizacion_correlativo='".$cotizacion_correlativo."' and detalleCotizacion_folio='".$cotizacion_folio."'");
            $row6=mysqli_fetch_array($sql_empresa);
            $detallecotizacion_idProducto = $row6['detalleCotizacion_idProducto'];
            $detallecotizacion_cantidad = $row6['detalleCotizacion_cantidad'];
            $id_detalle = $row6['detalleCotizacion_folio'];

            $usuario2= mysqli_query($con, "select * from productos where producto_id='".$detallecotizacion_idProducto."'");
            $row7= mysqli_fetch_array($usuario2);
            $producto_catPro = $row7['producto_idCategoria'];

            $estado_factura1=$row['cotizacion_tipo'];

            $cotizacion_correlativo1=str_pad($cotizacion_correlativo, 8, "0", STR_PAD_LEFT);
           
            $estado_factura=$row['cotizacion_condiciones'];
            $moneda=$row['cotizacion_moneda'];

            if ($moneda==115) {
                $mon="PEN";
            }
            if ($moneda==151) {
                $mon="USD";
            }

            if ($cotizacion_activo == 1) {
                $displayA = "";
               if($estado_factura == 1) {
                    $estado2="Contado";
                    $text_pago = "secondary";
                }
                if($estado_factura == 2) {
                    $estado2="Cheque";
                    $text_pago = "secondary";
                    
                }
                if($estado_factura == 3) {
                    $estado2="Transf Bancaria";
                    $text_pago = "secondary";
                }
                if($estado_factura == 4) {
                    $estado2="Cr&eacute;dito";
                    $text_pago = "warning";
                }
            }
            if ($cotizacion_activo <> 1) {
                $displayA = "none";
                $estado2="Anulado";
                $text_pago = "danger";
            }
            
            if($estado_factura1==9){
                $estado1="Cotizaci&oacute;n";
                $total_venta=$row['cotizacion_ventaTotal'];
                
            }

            if ($cotizacion_estado == 1) {
                $txt_cot = "pink";
                $factura_cot = "Sin Facturar";

            }
            if ($cotizacion_estado == 2) {
                $txt_cot = "mint";
                $factura_cot = "Facturado: ".$cotizacion_modifica;

            }
            if ($cotizacion_estado == 3) {
                $txt_cot = "danger";
                $factura_cot = "Rechazado";

            }

            if ($cotizacion_estado == 1) {
                $displayB = "";
            }
            if ($cotizacion_estado == 2) {
                $displayB = "none";
            }

            $titulo = $cotizacion_folio."-".$cotizacion_correlativo;

            //suma ingresos
            $suma1= mysqli_query($con, "select SUM(cotizacion_ventaTotal) AS ingresos FROM facturas_cotizaciones, clientes where facturas_cotizaciones.cotizacion_idCliente=clientes.cliente_id and facturas_cotizaciones.cotizacion_sucursal=$tienda and facturas_cotizaciones.cotizacion_correlativo>0 and facturas_cotizaciones.cotizacion_fecha between '$fecha_inicial' and '$fecha_final'");
            $row1= mysqli_fetch_array($suma1);
            $ingresos = $row1['ingresos'];

            ?>
            <tr>
                <td><?php echo $a1++; ?></td>
                <td><?php echo $cotizacion_folio."-".$cotizacion_correlativo; ?></td>
                <td><?php echo $fecha; ?></td>
                <td><?php echo $cliente_nombre; ?></td>
                <td><?php echo number_format ($total_venta,2); ?></td>
                <td><?php echo $mon; ?></td>
                <td><?php echo $estado2; ?></td>
                <td><?php echo $cotizacion_dias.' D&iacute;as'; ?></td>
                <td><?php echo $factura_cot; ?></td>
            </tr>
    <?php } ?>
            <tr>
                <td colspan="4"><strong>TOTALES</strong></td>
                <td><strong><?php echo number_format($ingresos,2); ?></strong></td>
                <td colspan="4"></td>
            </tr>
        </tbody>
    </table>
</div>
    <?php } ?>
<?php } ?>