<?php
session_start();
require_once ("../../config/db.php");
require_once ("../../config/conexion.php");
$range = $_GET['range'];
//$moneda = $_GET['moneda'];
$user_id = $_SESSION['usuario_id'];
$tienda = $_SESSION['tienda'];
$empresa = $_SESSION['datosEmpresa_id'];
header("Content-type: application/vnd.ms-excel" ) ; 
header("Content-Disposition: attachment; filename=Historial Compras ".$range.".xls" ) ;

$action  = (isset($_REQUEST['action']) && $_REQUEST['action'] != null) ? $_REQUEST['action'] : '';

if ($action == 'ajax') {
        
    $daterange   = $_GET['range'];

    list($f_inicio, $f_final)                    = explode(" - ", $daterange); //Extrae la fecha inicial y la fecha final en formato espa?ol
    list($dia_inicio, $mes_inicio, $anio_inicio) = explode("/", $f_inicio); //Extrae fecha inicial
    $fecha_inicial                               = "$anio_inicio-$mes_inicio-$dia_inicio 00:00:00"; //Fecha inicial formato ingles
    list($dia_fin, $mes_fin, $anio_fin)          = explode("/", $f_final); //Extrae la fecha final
    $fecha_final                                 = "$anio_fin-$mes_fin-$dia_fin 23:59:59";

    $sTable    = "facturas_compras, proveedores";
    $campos    = "*";
    $sWhere    = "facturas_compras.compras_idProveedor=proveedores.proveedor_id and facturas_compras.compras_sucursal=$tienda and facturas_compras.compras_correlativo>0 and facturas_compras.compras_fecha between '$fecha_inicial' and '$fecha_final'";

    $sWhere .= " group by facturas_compras.compras_id";

    $count_query   = mysqli_query($con, "SELECT count(*) AS numrows FROM $sTable WHERE $sWhere");
    $row= mysqli_fetch_array($count_query);
    $numrows = $row['numrows'];
    $sql="SELECT * FROM  $sTable WHERE $sWhere ";
    $query = mysqli_query($con, $sql);

    if ($numrows > 0){ ?>

<div class="table-responsive">
    <div>

        <?php
    
        $sql_empresa=mysqli_query($con,"select * from datosempresa WHERE datosEmpresa_id=$empresa");
        $rw_tienda=mysqli_fetch_array($sql_empresa);
        $datosEmpresa_id=$rw_tienda['datosEmpresa_id'];
        $datosEmpresa_nombre=$rw_tienda['datosEmpresa_nombre'];
        $ruc1=$rw_tienda['datosEmpresa_ruc'];

        $sql_sucursal=mysqli_query($con,"select * from sucursales WHERE sucursal_tienda=$tienda");
        $rw_suc=mysqli_fetch_array($sql_sucursal);
        $sucursal_nombre=$rw_suc['sucursal_nombre'];

        ?>

        <h3 style="text-align: center;">HIST&Oacute;RICO DE COMPRAS</h3>
        <span><strong>ESTABLECIMIENTO:</strong> <?php echo $sucursal_nombre; ?></span><br>
        <span><strong>PERIODO:</strong> <?php echo $daterange; ?></span>
    </div>
    <br>
    <table style="border: 0.5px solid #000;">
        <thead>
            <tr>
                <th>#</th>
                <th>Doc</th>
                <th>Tipo</th>
                <th>Fecha</th>
                <th>Proveedor</th>
                <th>Total</th>
                <th>Moneda</th>
                <th>Pago</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $a1 = 1;
        while ($row = mysqli_fetch_array($query)) {
            $cotizacion_id=$row['compras_id'];
            $cotizacion_correlativo=$row['compras_correlativo'];
            $fecha=date("d/m/Y", strtotime($row['compras_fecha']));
            $vence=date("d/m/Y", strtotime($row['compras_vencimiento']));

            $dia_em=date("d", strtotime($row['compras_fecha']));
            $mes_em=date("m", strtotime($row['compras_fecha']));
            $anio_em=date("Y", strtotime($row['compras_fecha']));

            $dia_ve=date("d", strtotime($row['compras_vencimiento']));
            $mes_ve=date("m", strtotime($row['compras_vencimiento']));
            $anio_ve=date("Y", strtotime($row['compras_vencimiento']));

            $cliente_nombre=$row['proveedor_nombre'];

            $cliente_telefono=$row['proveedor_telefono'];
            $cliente_documento=$row['proveedor_documento'];
            $cliente_email=$row['proveedor_email'];
            $cotizacion_folio=$row['compras_folio'];

            $cotizacion_activo=$row['compras_activo'];
            $cotizacion_estado=$row['compras_estado'];

            $cotizacion_adjuntoo=$row['compras_adjunto'];

            $estado_factura1=$row['compras_tipo'];

            $cotizacion_correlativo1=str_pad($cotizacion_correlativo, 8, "0", STR_PAD_LEFT);
           
            $estado_factura=$row['compras_condiciones'];

            $moneda=$row['compras_moneda'];

            if ($moneda==115) {
                $mon="PEN";
            }
            if ($moneda==151) {
                $mon="USD";
            }

            
            if($estado_factura1==1){
                $estado1="Factura";
                $total_venta=$row['compras_total'];
                
            }
            if($estado_factura1==2){
                $estado1="Boleta";
                $total_venta=$row['compras_total'];    
            }
            if($estado_factura1==3){
                $estado1="Nota Cr&eacute;dito";
                $total_venta=$row['compras_total'];   
            }
            if($estado_factura1==4){
                $estado1="Nota D&eacute;bito";
                $total_venta=$row['compras_total'];    
            }
            if($estado_factura1==5){
                $estado1="N. Venta";
                $total_venta=$row['compras_total']; 
            }
            if($estado_factura1==6){
                $estado1="Nota Cr&eacute;dito";
                $total_venta=$row['compras_total'];    
            }
            if($estado_factura1==7){
                $estado1="Nota D&eacute;bito";
                $total_venta=$row['compras_total']; 
            }

            //$fechaActual = date('Y-m-d'); 
            $fecha1=mktime(0,0,0,$mes_em,$dia_em,$anio_em);
            $fecha2=mktime(0,0,0,$mes_ve,$dia_ve,$anio_ve);

            $diferencia=$fecha2-$fecha1;
            $dias=$diferencia/(60*60*24);

            if ($cotizacion_activo == 1) {
                $displayA = "";
               if($estado_factura == 1) {
                    $estado2="Contado";
                    $text_pago = "secondary";
                }
                if($estado_factura == 2) {
                    $estado2="Cheque";
                    $text_pago = "secondary";
                    
                }
                if($estado_factura == 3) {
                    $estado2="Transf Bancaria";
                    $text_pago = "secondary";
                }
                if($estado_factura == 4) {
                    if ($cotizacion_estado == 2) {
                        $estado2="Cr&eacute;dito a ".$dias." d&iacute;as";
                        $text_pago = "warning";
                    }
                    if ($cotizacion_estado == 1) {
                        $estado2="Cr&eacute;dito (Pagada)";
                        $text_pago = "info";
                    }
                }
            }
            if ($cotizacion_activo <> 1) {
                $displayA = "none";
                $estado2="Anulado";
                $text_pago = "danger";
            }

            //suma ingresos
            $suma1= mysqli_query($con, "select SUM(compras_total) AS ingresos FROM facturas_compras, proveedores where facturas_compras.compras_idProveedor=proveedores.proveedor_id and facturas_compras.compras_sucursal=$tienda and facturas_compras.compras_correlativo>0 and facturas_compras.compras_fecha between '$fecha_inicial' and '$fecha_final'");
            $row1= mysqli_fetch_array($suma1);
            $ingresos = $row1['ingresos'];

            ?>
            <tr>
                <td><?php echo $a1++; ?></td>
                <td><?php echo $cotizacion_folio."-".$cotizacion_correlativo; ?></td>
                <td><?php echo $estado1; ?></td>
                <td><?php echo $fecha; ?></td>
                <td><?php echo $cliente_nombre; ?></td>
                <td><?php echo number_format ($total_venta,2); ?></td>
                <td><?php echo $mon; ?></td>
                <td><?php echo $estado2; ?></td>
            </tr>
    <?php } ?>
            <tr>
                <td colspan="5"><strong>TOTALES</strong></td>
                <td><strong><?php echo number_format($ingresos,2); ?></strong></td>
                <td colspan="2"></td>
            </tr>
        </tbody>
    </table>
</div>
    <?php } ?>
<?php } ?>