<?php
session_start();
require_once ("../../config/db.php");
require_once ("../../config/conexion.php");
$range = $_GET['range'];
$moneda = $_GET['moneda'];
$user_id = $_SESSION['usuario_id'];
$tienda1 = $_SESSION['tienda'];
$empresa = $_SESSION['datosEmpresa_id'];
header("Content-type: application/vnd.ms-excel" ) ; 
header("Content-Disposition: attachment; filename=Registro de ventas ".$range.".xls" ) ;

$action  = (isset($_REQUEST['action']) && $_REQUEST['action'] != null) ? $_REQUEST['action'] : '';

if ($action == 'ajax') {
        
    $mes1 = mysqli_real_escape_string($con, (strip_tags($_REQUEST['range'], ENT_QUOTES)));
    $daterange=date("Y-m",strtotime($mes1));

    $sTable    = "facturas, clientes";
    $campos    = "*";
    $sWhere    = "facturas.factura_idCliente=clientes.cliente_id and facturas.factura_sucursal=$tienda1 and (facturas.factura_tipo=1 or facturas.factura_tipo=2 or facturas.factura_tipo=3 or facturas.factura_tipo=4 or facturas.factura_tipo=5 or facturas.factura_tipo=6 or facturas.factura_tipo=7) and facturas.factura_venCom=1 and facturas.factura_moneda=$moneda and facturas.factura_activo=1 and facturas.factura_correlativo>0 and facturas.consumo=0 and (DATE_FORMAT(facturas.factura_fecha, '%Y-%m')='$daterange')";


    $sWhere .= " group by facturas.factura_id";

    $count_query   = mysqli_query($con, "SELECT count(*) AS numrows FROM $sTable WHERE $sWhere");
    $row= mysqli_fetch_array($count_query);
    $numrows = $row['numrows'];
    $sql="SELECT * FROM  $sTable WHERE $sWhere ";
    $query = mysqli_query($con, $sql);

    if ($numrows > 0){ ?>

        <div class="table-responsive">
    <div>

        <?php
    
        $sql_empresa=mysqli_query($con,"select * from datosempresa WHERE datosEmpresa_id=$empresa");
        $rw_tienda=mysqli_fetch_array($sql_empresa);

        $datosEmpresa_id=$rw_tienda['datosEmpresa_id'];
        $datosEmpresa_nombre=$rw_tienda['datosEmpresa_nombre'];
        $datosEmpresa_ruc=$rw_tienda['datosEmpresa_ruc'];
        $datosEmpresa_direccion=$rw_tienda['datosEmpresa_direccion'];
        $datosEmpresa_correo=$rw_tienda['datosEmpresa_correo'];
        $datosEmpresa_telefono=$rw_tienda['datosEmpresa_telefono'];
        $datosEmpresa_ubigeo=$rw_tienda['datosEmpresa_ubigeo'];
        $datosEmpresa_departamento=$rw_tienda['datosEmpresa_departamento'];
        $datosEmpresa_provincia=$rw_tienda['datosEmpresa_provincia'];
        $datosEmpresa_distrito=$rw_tienda['datosEmpresa_distrito'];
        $datosEmpresa_logo=$rw_tienda['datosEmpresa_logo'];

        $mes1=date("m",strtotime($daterange));
        $ano=date("Y", strtotime($daterange));

        if ($mes1 == "01") {
            $mes = "Enero";
        }
        if ($mes1 == "02") {
            $mes = "Febrero";
        }
        if ($mes1 == "03") {
            $mes = "Marzo";
        }
        if ($mes1 == "04") {
            $mes = "Abril";
        }
        if ($mes1 == "05") {
            $mes = "Mayo";
        }
        if ($mes1 == "06") {
            $mes = "Junio";
        }
        if ($mes1 == "07") {
            $mes = "Junlio";
        }
        if ($mes1 == "08") {
            $mes = "Agosto";
        }
        if ($mes1 == "09") {
            $mes = "Septiembre";
        }
        if ($mes1 == "10") {
            $mes = "Octubre";
        }
        if ($mes1 == "11") {
            $mes = "Noviembre";
        }
        if ($mes1 == "12") {
            $mes = "Diciembre";
        }

        ?>

        <h5>FORMATO 14.1: REGISTRO DE VENTAS E INGRESOS</h5>
        <span><strong>PERIODO:</strong> <?php echo $mes." de ".$ano; ?></span><br>
        <span><strong>RUC:</strong> <?php echo $datosEmpresa_ruc; ?></span><br>
        <span><strong>APELLIDOS Y NOMBRES, DENOMINACI&Oacute;N O RAZ&Oacute;N SOCIAL:</strong> <?php echo $datosEmpresa_nombre; ?></span>
    </div>
    <table id="example" class="display table table-bordered" style="width:100%" border="1">
        <thead>
            <tr>
                <th rowspan="3" class='text-center' style="text-transform: uppercase;">N&uacute;mero <br> Correlativo <br> Del Registro O <br> C&oacute;digo &Uacute;nico <br> De La Operaci&oacute;n <br><br>&nbsp;</th>
                <th rowspan="3" class='text-center' style="text-transform: uppercase;">Fecha De <br> Emisi&oacute;n Del <br> Comprobante <br> De Pago <br> O Documento <br><br>&nbsp;</th>
                <th rowspan="3" class='text-center' style="text-transform: uppercase;">Fecha <br> De <br> Vencimiento <br> Y/O Pago <br><br><br>&nbsp;</th>
                <th colspan="3" class='text-center' style="text-transform: uppercase;">Comprobante De Pago <br> O Documento</th>
                <th colspan="3" class='text-center' style="text-transform: uppercase;">Informaci&oacute;n Del Cliente <br>&nbsp;</th>
                <th rowspan="3" class='text-center' style="text-transform: uppercase;">Valor <br> Facturado <br>De La <br> Exportaci&oacute;n <br><br><br>&nbsp;</th>
                <th rowspan="3" class='text-center' style="text-transform: uppercase;">Base <br> Imponible <br>De La <br> Operaci&oacute;n <br> Gravada <br><br>&nbsp;</th>
                <th colspan="2" class='text-center' style="text-transform: uppercase;">Importe Total De La Operaci&oacute;n <br> Exonerada O Inafecta</th>
                <th rowspan="3" class='text-center' style="text-transform: uppercase;">ISC <br><br><br><br>&nbsp;</th>
                <th rowspan="3" class='text-center' style="text-transform: uppercase;">IGV <br> Y/O <br> IPM <br><br><br>&nbsp;</th>
                <th rowspan="3" class='text-center' style="text-transform: uppercase;">Otros Tributos <br> Y Cargos Que <br> No Forman Parte <br> De La <br> Base Imponible <br><br>&nbsp;</th>
                <th rowspan="3" class='text-center' style="text-transform: uppercase;">Importe <br> Total <br> Del <br> Comprobante <br> De Pago <br><br>&nbsp;</th>
                <th rowspan="3" class='text-center' style="text-transform: uppercase;">Tipo <br> De <br> Cambio <br><br><br>&nbsp;</th>
                <th colspan="4" class='text-center' style="text-transform: uppercase;">Referencia Del Comprobante De Pago <br> O Documento Original Que Se Modifica</th>
            </tr>
            <tr>
                <th rowspan="2" class='text-center' style="text-transform: uppercase;">Tipo <br> (Tabla 10) <br>&nbsp;</th>
                <th rowspan="2" class='text-center' style="text-transform: uppercase;">N&deg; Serie O <br> N&deg; De Serie De La <br> M&aacute;quina Registradora <br>&nbsp;</th>
                <th rowspan="2" class='text-center' style="text-transform: uppercase;">N&uacute;mero <br><br>&nbsp;</th>
                <th colspan="2" class='text-center' style="text-transform: uppercase;">Documento De Identidad</th>
                <th rowspan="2" class='text-center' style="text-transform: uppercase;">Apellidos Y Nombres <br> Denominaci&oacute;n <br> O Raz&oacute;n Social <br>&nbsp;</th>
                <th rowspan="2" class='text-center' style="text-transform: uppercase;">Exonerada <br><br>&nbsp;&nbsp;</th>
                <th rowspan="2" class='text-center' style="text-transform: uppercase;">Inafecta <br><br>&nbsp;&nbsp;</th>
                <th rowspan="2" class='text-center' style="text-transform: uppercase;">Fecha <br><br>&nbsp;</th>
                <th rowspan="2" class='text-center' style="text-transform: uppercase;">Tipo <br> (Tabla 10) <br><br>&nbsp;</th>
                <th rowspan="2" class='text-center' style="text-transform: uppercase;">Serie <br><br>&nbsp;</th>
                <th rowspan="2" class='text-center' style="text-transform: uppercase;">N&deg; Del <br> Comprobante <br> De Pago O Documento <br><br></th>
            </tr>
            <tr>
                <th class='text-center' style="text-transform: uppercase;">Tipo <br> (Tabla 2)</th>
                <th class='text-center' style="text-transform: uppercase;">N&uacute;mero <br></th>
            </tr>
        </thead>
        <tbody>
            <?php
        $a = 1;
            while ($row = mysqli_fetch_array($query)) {
    
    $factura_id=$row['factura_id'];
    $factura_correlativo=$row['factura_correlativo'];
    $factura_resumen=$row['factura_resumen'];
    $fecha=date("d/m/Y", strtotime($row['factura_fecha']));
    $vence=date("d/m/Y", strtotime($row['factura_fechaElimina']));
    $cliente_nombre=$row['cliente_nombre'];
    $cliente_tipo=$row['cliente_tipo'];

    $cliente_telefono=$row['cliente_telefono'];
    $cliente_documento=$row['cliente_documento'];
    $cliente_email=$row['cliente_email'];
    $factura_folio=$row['factura_folio'];

    $aceptado1 = $row['factura_aceptado'];
    $factura_registro = $row['factura_registro'];

    //$usuario1= mysqli_query($con, "select * from detallefactura where detalleFactura_correlativo='".$factura_correlativo."' and detalleFactura_folio='".$factura_folio."'");
    //while ($row6=mysqli_fetch_array($usuario1)){
    $sql_empresa=mysqli_query($con,"select * from detallefactura where detalleFactura_correlativo='".$factura_correlativo."' and detalleFactura_folio='".$factura_folio."'");
    $row6=mysqli_fetch_array($sql_empresa);
    $detalleFactura_idProducto = $row6['detalleFactura_idProducto'];
    $detalleFactura_cantidad = $row6['detalleFactura_cantidad'];
    $id_detalle = $row6['detalleFactura_folio'];

    $usuario2= mysqli_query($con, "select * from productos where producto_id='".$detalleFactura_idProducto."'");
    $row7= mysqli_fetch_array($usuario2);
    $producto_catPro = $row7['producto_idCategoria'];



    $usuario_cliente= mysqli_query($con, "select * from sunat_tipocliente where sunat_tipoCliente_id='".$cliente_tipo."'");
    $row7_1= mysqli_fetch_array($usuario_cliente);
    $sunat_tipoCliente_codigo = "0".$row7_1['sunat_tipoCliente_codigo'];

    //}

    if ($producto_catPro==1) {
        $icbper = 0.2*$detalleFactura_cantidad;
    }
    if ($producto_catPro<>1) {
        $icbper = "0";
    }
    
    $tip=0;
    $estado_factura1=$row['factura_tipo'];
    if($estado_factura1==1){
        $tip="01";
    }
    if($estado_factura1==2){
        $tip="03";
    }
    if($estado_factura1==3){
        $tip="07";
    }
    if($estado_factura1==4){
        $tip="08";
    }
    if($estado_factura1==6){
        $tip="07";
    }
    if($estado_factura1==7){
        $tip="08";
    }

    $factura_correlativo1=str_pad($factura_correlativo, 8, "0", STR_PAD_LEFT);
    

    
    $estado_factura=$row['factura_condiciones'];
    $ven_com=$row['factura_venCom'];
    $moneda=$row['factura_moneda'];

    if ($moneda==1) {
        $mon="PEN";
    }
    if ($moneda==2) {
        $mon="USD";
    }

    $total_venta=$row['factura_ventaTotal'];
    $op_gravada = $row['factura_gravada'];
    $op_inafecta = $row['factura_inafecta'];
    $op_exonerada = $row['factura_exonerada'];
    $factura_igv = $row['factura_igv'];
    $factura_tipoCambio = $row['factura_tipoCambio'];

    $factura_modifica = $row['factura_modifica'];

    if ($factura_modifica != "") {
        $modifica            = explode("-", $factura_modifica);
        $modifica_folio      = $modifica[0];
        $modifica_numero     = $modifica[1];

        $modifica_numero1=str_pad($modifica_numero, 8, "0", STR_PAD_LEFT);

        $sql_modifica= mysqli_query($con, "select * from facturas where factura_folio='".$modifica_folio."' and factura_correlativo='".$modifica_numero."'");
        $rw_modifica= mysqli_fetch_array($sql_modifica);
        $modifica_tipo = $rw_modifica['factura_tipo'];
        $modifica_fecha = date("d/m/Y", strtotime($rw_modifica['factura_fecha']));

        if($modifica_tipo==1){
            $tip_mod="01";
        }
        if($modifica_tipo==2){
            $tip_mod="03";
        }
        if($modifica_tipo==3){
            $tip_mod="07";
        }
        if($modifica_tipo==4){
            $tip_mod="08";
        }
        if($modifica_tipo==6){
            $tip_mod="07";
        }
        if($modifica_tipo==7){
            $tip_mod="08";
        }

    } else {
        $modifica_folio      = "";
        $modifica_numero1    = "";
        $tip_mod             = "";
        $modifica_fecha      = "";
    }
    
    if($estado_factura1==1){
        $estado1="Factura";
        //$total_venta=$row['factura_ventaTotal'];
        
    }
    if($estado_factura1==2){
        $estado1="Boleta";
        //$total_venta=$row['factura_ventaTotal'];    
    }
    if($estado_factura1==3){
        $estado1="N Credito";
        //$total_venta=$row['factura_ventaTotal'];   
    }
    if($estado_factura1==4){
        $estado1="N Credito";
        //$total_venta=$row['factura_ventaTotal'];    
    }
    if($estado_factura1==5){
        $estado1="N. Venta";
        //$total_venta=$row['factura_ventaTotal']; 
    }
    if($estado_factura1==6){
        $estado1="N Credito";
        //$total_venta=$row['factura_ventaTotal'];    
    }
    if($estado_factura1==7){
        $estado1="N Debito";
        //$total_venta=$row['factura_ventaTotal']; 
    }
    if($estado_factura==1){
        $estado2="Efectivo";
    }
    if($estado_factura==2){
        $estado2="Cheque";
        
    }
    //suma gravada
    $suma1= mysqli_query($con, "select SUM(factura_gravada) AS total1 FROM facturas  where (factura_tipo=1 or factura_tipo=2 or factura_tipo=3 or factura_tipo=4 or factura_tipo=5 or factura_tipo=6 or factura_tipo=7) and factura_activo=1 and factura_venCom=1 and factura_sucursal='$tienda1' and facturas.factura_moneda=$moneda and consumo=0 and facturas.factura_venCom=1 and facturas.factura_activo=1 and facturas.factura_correlativo>0 and facturas.consumo=0 and (DATE_FORMAT(facturas.factura_fecha, '%Y-%m')='$daterange')");
    $row1= mysqli_fetch_array($suma1);
    $total1 = $row1['total1'];
    //suma exonerada
    $suma2= mysqli_query($con, "select SUM(factura_exonerada) AS total2 FROM facturas  where (factura_tipo=1 or factura_tipo=2 or factura_tipo=3 or factura_tipo=4 or factura_tipo=5 or factura_tipo=6 or factura_tipo=7) and factura_activo=1 and factura_venCom=1 and factura_sucursal='$tienda1' and facturas.factura_moneda=$moneda and consumo=0 and facturas.factura_venCom=1 and facturas.factura_activo=1 and facturas.factura_correlativo>0 and facturas.consumo=0 and (DATE_FORMAT(facturas.factura_fecha, '%Y-%m')='$daterange')");
    $row2= mysqli_fetch_array($suma2);
    $total2 = $row2['total2'];
    //suma inafecta
    $suma3= mysqli_query($con, "select SUM(factura_inafecta) AS total3 FROM facturas  where (factura_tipo=1 or factura_tipo=2 or factura_tipo=3 or factura_tipo=4 or factura_tipo=5 or factura_tipo=6 or factura_tipo=7) and factura_activo=1 and factura_venCom=1 and factura_sucursal='$tienda1' and facturas.factura_moneda=$moneda and consumo=0 and facturas.factura_venCom=1 and facturas.factura_activo=1 and facturas.factura_correlativo>0 and facturas.consumo=0 and (DATE_FORMAT(facturas.factura_fecha, '%Y-%m')='$daterange')");
    $row3= mysqli_fetch_array($suma3);
    $total3 = $row3['total3'];
    //suma igv
    $suma4= mysqli_query($con, "select SUM(factura_igv) AS total4 FROM facturas  where (factura_tipo=1 or factura_tipo=2 or factura_tipo=3 or factura_tipo=4 or factura_tipo=5 or factura_tipo=6 or factura_tipo=7) and factura_activo=1 and factura_venCom=1 and factura_sucursal='$tienda1' and facturas.factura_moneda=$moneda and consumo=0 and facturas.factura_venCom=1 and facturas.factura_activo=1 and facturas.factura_correlativo>0 and facturas.consumo=0 and (DATE_FORMAT(facturas.factura_fecha, '%Y-%m')='$daterange')");
    $row4= mysqli_fetch_array($suma4);
    $total4 = $row4['total4'];
    //suma total
    $suma5= mysqli_query($con, "select SUM(factura_ventaTotal) AS total5 FROM facturas  where (factura_tipo=1 or factura_tipo=2 or factura_tipo=3 or factura_tipo=4 or factura_tipo=5 or factura_tipo=6 or factura_tipo=7) and factura_activo=1 and factura_venCom=1 and factura_sucursal='$tienda1' and facturas.factura_moneda=$moneda and consumo=0 and facturas.factura_venCom=1 and facturas.factura_activo=1 and facturas.factura_correlativo>0 and facturas.consumo=0 and (DATE_FORMAT(facturas.factura_fecha, '%Y-%m')='$daterange')");
    $row5= mysqli_fetch_array($suma5);
    $total5 = $row5['total5'];
            ?>
            <tr>
                <td style="text-transform: uppercase;text-align:center;"><?php echo "V".$empresa.$tienda1."-".$factura_registro; ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo $fecha; ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo $vence; ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo $tip; ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo $factura_folio; ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo $factura_correlativo1; ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo $sunat_tipoCliente_codigo; ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo $cliente_documento; ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo $cliente_nombre; ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo "0.00"; ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo number_format ($op_gravada,2); ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo number_format ($op_exonerada,2); ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo number_format ($op_inafecta,2); ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo "0.00"; ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo number_format ($factura_igv,2); ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo "0.00"; ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo number_format ($total_venta,2); ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo number_format($factura_tipoCambio,2); ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo $modifica_fecha; ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo $tip_mod; ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo $modifica_folio; ?></td>
                <td style="text-transform: uppercase;text-align:center;"><?php echo $modifica_numero1; ?></td>
            </tr>
    <?php } ?>

            <tr>
                <td colspan="9" style="text-transform: uppercase;text-align:right;"><strong>TOTALES</strong></td>
                <td style="text-transform: uppercase;text-align:center;"><strong><?php echo "0.00"; ?></strong></td>
                <td style="text-transform: uppercase;text-align:center;"><strong><?php echo number_format($total1,2); ?></strong></td>
                <td style="text-transform: uppercase;text-align:center;"><strong><?php echo number_format($total2,2); ?></strong></td>
                <td style="text-transform: uppercase;text-align:center;"><strong><?php echo number_format($total3,2); ?></strong></td>
                <td style="text-transform: uppercase;text-align:center;"><strong><?php echo "0.00"; ?></strong></td>
                <td style="text-transform: uppercase;text-align:center;"><strong><?php echo number_format($total4,2); ?></strong></td>
                <td style="text-transform: uppercase;text-align:center;"><strong><?php echo "0.00"; ?></strong></td>
                <td style="text-transform: uppercase;text-align:center;"><strong><?php echo number_format($total5,2); ?></strong></td>
                <td colspan="5"></td>
            </tr>
        </tbody>
    </table>
</div>
    <?php } ?>
<?php } ?>