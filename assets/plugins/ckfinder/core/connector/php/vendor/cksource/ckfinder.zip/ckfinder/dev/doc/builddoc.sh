#!/bin/bash

cd "$(dirname "$0")"
doxygen ckfinder.doxyfile

